# Warnings shown under "Worth knowing"

Context and things people commonly miss. Lowest risk, but still statements of law.

14 of them.

Square brackets mark text filled in from the carer's own answers.

### Worth checking: was the child in care just before the order?

- Reference: `LOOKED_AFTER_STATUS_UNKNOWN`
- Shown under: "Worth knowing"
- Source: Special Guardianship Regulations 2005, reg 6 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/6)
- Links to: /guidance/who-can-get-an-allowance

You told us you were not sure. It matters, because it changes how strong your position is. If the child was in the council's care immediately before the order, you are squarely within the circumstances where financial support is payable. If not, those circumstances are narrower, though you can still ask.

Your social worker or the court paperwork will say.

### You are in a pilot area but already on regulation 6 support

- Reference: `KINSHIP_ZONE_EXCLUDED_REG6`
- Shown under: "Worth knowing"
- Source: Kinship Zones - kinship allowance pilot (2026-2029) (https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care)
- Links to: /guidance/kinship-zones

Your council is in the Kinship Zones pilot, but the pilot excludes carers already receiving regulation 6 financial support, so we have used the normal rules for your estimate.

For comparison, the pilot rate for your child's age band would be £187 a week with no means test.

That comparison is worth raising with your council if your current support is lower.

### What the pilot rate would be

- Reference: `KINSHIP_ZONE_COMPARISON`
- Shown under: "Worth knowing"
- Source: Kinship Zones - kinship allowance pilot (2026-2029) (https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care)
- Links to: /guidance/kinship-zones

The Kinship Zones pilot rate for your child's age band is £187 a week, not means tested.

### You are in the few days of April where the rules disagree

- Reference: `APRIL_RATE_BOUNDARY`
- Shown under: "Worth knowing"
- Source: North Tyneside Council, Decision Record: Foster Care, Special Guardianship, Adoption and Child Arrangement Order Allowance Increases (https://northtyneside.gov.uk/sites/default/files/web-page-related-files/20250321%20-%20Decision%20Record%20-%20Fostering%20Allowance.pdf)
- Links to: /guidance/rates

The government sets these rates for a **tax year running 6 April to 5 April**. Most councils put their increase in from **1 April**.

Between 1 and 5 April the two do not line up. We have shown you the new rate, because that is what councils normally pay from 1 April. But if your council follows the tax year, it may still be paying last year's rate for a few more days.

It is worth a few pounds, not a few hundred. If you are checking a backdated claim, it is worth getting right.

### In Wales, under-5s get more than 5 to 15 year olds

- Reference: `WALES_BAND_ORDER_ANOMALY`
- Shown under: "Worth knowing"
- Source: Welsh Government, National Minimum Allowances for foster carers 2024 to 2025, circular of 26 February 2024 (no public link yet)
- Links to: /guidance/rates

The Welsh rates pay **more for a child under 5 than for a child aged 5 to 15**. Everywhere else in the UK the rate rises with age, so this looks like a mistake.

It is not a mistake on this site. That is how the Welsh Government publishes them, and the same pattern appears in other years too.

We have now checked it against the Welsh Government's own circular, which prints the rates that way. We are telling you rather than quietly correcting it.

### Your council may have a savings rule

- Reference: `CAPITAL_RULE_MAY_APPLY`
- Shown under: "Worth knowing"
- Source: DWP, Benefit and pension rates 2026 to 2027 (https://www.gov.uk/government/publications/benefit-and-pension-rates-2026-to-2027/proposed-benefit-and-pension-rates-2026-to-2027)
- Links to: /guidance/how-the-means-test-works

You told us about savings of £7,000. Some councils count savings above a threshold. A common pattern is £6,000, then £1 a week for each £250 above it. But there is no national rule and we do not hold your council's.

We have not applied any savings rule to your estimate. Ask your council whether it has one.

### Your allowance should be reviewed every year

- Reference: `ANNUAL_REVIEW_DUE`
- Shown under: "Worth knowing"
- Source: Special Guardianship Regulations 2005, regs 10-11 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/10)
- Links to: /guidance/annual-reviews

Financial support is reviewed annually. The council should ask you for updated information, tell you what it proposes, and give you a chance to comment before it changes anything.

If you have not had a review in over a year, ask for one. Rates go up every April.

### Which council is responsible

- Reference: `THREE_YEAR_RESPONSIBILITY`
- Shown under: "Worth knowing"
- Source: Special Guardianship Regulations 2005, reg 5 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/5)
- Links to: /guidance/which-council-is-responsible

For three years after the order, the council that looked after the child stays responsible for assessing support needs, even if you have moved away. After three years, responsibility usually passes to the council where you live.

If you have moved recently, it is worth being clear which council you should be asking.

### Check whether the benefit cap affects you

- Reference: `BENEFIT_CAP_RISK`
- Shown under: "Worth knowing"
- Source: DWP, Benefit and pension rates 2026 to 2027 (https://www.gov.uk/government/publications/benefit-and-pension-rates-2026-to-2027/proposed-benefit-and-pension-rates-2026-to-2027)
- Links to: /guidance/benefits-and-your-allowance

Households getting a lot of benefit income can hit the benefit cap. Special guardianship allowance itself is not counted as your income for your own means-tested benefits, and Guardian's Allowance is exempt from the cap.

If your benefits have been reduced without explanation, this is worth checking with an adviser.

### The two-child limit no longer applies

- Reference: `TWO_CHILD_LIMIT_ABOLISHED`
- Shown under: "Worth knowing"
- Source: Universal Credit (Removal of Two Child Limit) Act 2026 c.13 (no public link yet)
- Links to: /guidance/benefits-and-your-allowance

The two-child limit in Universal Credit was removed from April 2026. If you are caring for three or more children and your Universal Credit has not changed, check your award.

### Check whether you can claim Guardian's Allowance

- Reference: `GUARDIANS_ALLOWANCE_CHECK`
- Shown under: "Worth knowing"
- Source: Child Benefit and Guardian's Allowance Up-rating Order 2026 (no public link yet)
- Links to: /guidance/benefits-and-your-allowance

Guardian's Allowance is a weekly payment for someone bringing up a child whose parents have died, or where one has died and the other cannot be traced, is serving a long prison sentence, or cannot be found.

It is tax free, it is ignored for means-tested benefits, and it is exempt from the benefit cap. It is widely missed.

### We do not hold your council's published policy

- Reference: `COUNCIL_POLICY_UNKNOWN`
- Shown under: "Worth knowing"
- Source: DfE, Kinship Care: statutory guidance for local authorities (October 2024) (https://assets.publishing.service.gov.uk/media/670d3ed5e84ae1fd8592f2fa/Kinship_Care_-_statutory_guidance_for_local_authorities__October_2024.pdf)
- Links to: /guidance/asking-for-the-policy

We do not yet hold a sourced, dated copy of [COUNCIL NAME]'s special guardianship financial support policy, so your estimate uses the national minimum figures for your area.

Every council in England has to publish a kinship local offer setting out the support it provides, and most publish a financial support policy as well. Asking for it in writing is a good first step, and it is the document any later challenge rests on.

### This council is rewriting its policy

- Reference: `LA_POLICY_UNDER_REVIEW`
- Shown under: "Worth knowing"
- Source: none cited
- Links to: /guidance/asking-for-the-policy

[The council's own words about its policy being rewritten go here.]

Ask the council for its current position in writing before you rely on any figure here.

### No family should be worse off

- Reference: `SCOTLAND_NO_WORSE_OFF`
- Shown under: "Worth knowing"
- Source: Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026 (https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/)
- Links to: /guidance/scotland-kinship-care

Where you already have an arrangement that pays more than the recommended allowance, the higher amount applies. Moving to the recommended rate should not reduce what you get.
