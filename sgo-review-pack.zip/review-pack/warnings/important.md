# Warnings shown under "Worth raising"

Things a carer should take up, shown in amber. Lower alarm, same need for accuracy.

15 of them.

Square brackets mark text filled in from the carer's own answers.

### Your previous fostering allowance protects your figure for two years

- Reference: `REG7_FLOOR_APPLIED`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 7 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/7)
- Links to: /guidance/former-foster-carers

You fostered this child before the order, and the order was made 18 months ago.

For the first two years, the reward part of what you were paid as a foster carer is protected. We have held your figure at £300 a week rather than showing you a lower one.

The Court of Appeal has held that family foster carers should not be worse off than unrelated foster carers.

### Your two-year protection ends soon

- Reference: `REG7_EXPIRING`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 7 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/7)
- Links to: /guidance/former-foster-carers

The order was made 18 months ago. The two-year protection for the reward part of your former fostering allowance runs out at 24 months.

The council can agree to continue it where the child's needs justify it. Ask now, in writing, rather than after your payments drop.

### You can ask for the two-year protection to be extended

- Reference: `REG7_EXTENSION_AVAILABLE`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 7 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/7)
- Links to: /guidance/former-foster-carers

The two-year continuation of the reward element is not a hard stop. A council can agree to carry on paying it where the child's needs justify it.

Ask in writing, and set out what has changed or what has not.

### Check what your council is tapering

- Reference: `REG7_MISAPPLICATION_WARNING`
- Shown under: "Worth raising"
- Source: LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020) (https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363)
- Links to: /guidance/former-foster-carers

Regulation 7 protects the **reward** part of a former foster carer's allowance for two years. It does not authorise tapering the whole allowance.

The Ombudsman found in 2020 that reducing an entire allowance to 75% and then 50% misapplied that rule. If your payments are being stepped down, ask the council which element it is reducing and why.

### Your assessment is discretionary, not automatic

- Reference: `NOT_LOOKED_AFTER_BEFORE_ORDER`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 6 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/6)
- Links to: /guidance/who-can-get-an-allowance

Because the child was not in the council's care immediately before the order, the council does not have to assess you for financial support. But it can, and you can ask it to.

Put the request in writing and ask for the decision and its reasons in writing too.

### Your council is in the Kinship Zones pilot

- Reference: `KINSHIP_ZONE_ELIGIBLE`
- Shown under: "Worth raising"
- Source: Kinship Zones - kinship allowance pilot (2026-2029) (https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care)
- Links to: /guidance/kinship-zones

Anytown Council is one of seven councils in the Kinship Zones pilot. In the pilot, eligible carers get an allowance equal to the full fostering National Minimum Allowance, and it is **not** means tested.

Ask your council whether you qualify, and ask for the answer in writing.

### The pilot is time-limited and has conditions

- Reference: `KINSHIP_ZONE_PILOT_CAVEAT`
- Shown under: "Worth raising"
- Source: Kinship Zones - kinship allowance pilot (2026-2029) (https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care)
- Links to: /guidance/kinship-zones

Kinship Zones runs from April 2026 to 2029 in seven councils only. It does not change the law anywhere else.

You cannot get the pilot allowance and regulation 6 financial support for the same child at the same time. The scheme may change when it is evaluated.

### You can ask for more because of your child's needs

- Reference: `ENHANCEMENT_AVAILABLE`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 6 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/6)
- Links to: /guidance/enhancements-for-additional-needs

You told us your child has a disability or additional needs. The regulations let a council pay more than the core allowance to meet the consequences of a disability, or of abuse or neglect the child suffered.

There is **no national figure** for this and we have not added one to your estimate. It is decided council by council, on the child's needs. Ask for it, and give specifics: therapy, travel, respite, equipment, extra wear and tear.

### The means test model is not law, and it pre-dates Universal Credit

- Reference: `MEANS_TEST_MODEL_OUTDATED`
- Shown under: "Worth raising"
- Source: CoramBAAF Practice Note 75 - special guardianship financial support (no public link yet)
- Links to: /guidance/how-the-means-test-works

Most English councils use a standard Department for Education spreadsheet model to work out how much of your income to take into account. That model is **not statutory**. No law requires it, and it was written before Universal Credit existed.

Your council may use a different method, and it is entitled to. Treat the figure below as an illustration of how the common model works, not as the answer your council will reach.

### We had to assume how your council reduces the allowance

- Reference: `TAPER_METHOD_ASSUMED`
- Shown under: "Worth raising"
- Source: none cited
- Links to: /guidance/how-the-means-test-works

There is **no published national rule** for how much of your spare income a council takes off the allowance. Policies vary.

We have assumed pound-for-pound, which is the most common approach. Your council may use another. Ask it which it uses.

### Plan now for what happens at 18

- Reference: `AGE_17_TRANSITION`
- Shown under: "Worth raising"
- Source: Special Guardianship Regulations 2005, reg 9 (https://www.legislation.gov.uk/uksi/2005/1109/regulation/9)
- Links to: /guidance/turning-18

Your child is 17. Special guardianship financial support normally stops when they turn 18, unless they stay in full-time education or training, in which case it can continue.

Ask your council now, in writing, what will happen on their eighteenth birthday and what you need to do to keep support going.

### The Scottish Recommended Allowance is a minimum, not a maximum

- Reference: `SCOTLAND_SRA_IS_A_FLOOR`
- Shown under: "Worth raising"
- Source: Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026 (https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/)
- Links to: /guidance/scotland-kinship-care

The Scottish Recommended Allowance is the floor. Your council can pay more, and some do.

If you are being offered less than the recommended allowance, ask why in writing.

### Kinship carers and foster carers get the same recommended rate

- Reference: `SCOTLAND_FOSTER_KINSHIP_PARITY`
- Shown under: "Worth raising"
- Source: Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026 (https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/)
- Links to: /guidance/scotland-kinship-care

Scotland sets one recommended allowance for foster carers and kinship carers alike. If your council pays its foster carers more than it pays you for a child of the same age, ask it to explain the difference.

### The Ombudsman made a finding about a policy this council has since changed

- Reference: `LGSCO_FINDING_FORMER_POLICY`
- Shown under: "Worth raising"
- Source: none cited
- Links to: /guidance/complaining-to-the-ombudsman

[The summary of the published decision about this council goes here.]

The council changed that policy from 1 January 2024.

[The later decision that did not uphold the complaint goes here.]

This is history rather than a live problem, but it is worth knowing. Where a council has been found at fault, the Ombudsman has often asked it to go back and recalculate old awards, so it can still be relevant to an order made some years ago.

### Your council allows a different amount for basic living costs

- Reference: `LA_LIVING_COSTS_VARIATION`
- Shown under: "Worth raising"
- Source: none cited
- Links to: /guidance/how-the-means-test-works

The standardised model most councils use allows basic living costs at 125% of the Income Support rate for a household your size. Anytown Council publishes 100%, and that is the figure used above.

Allowing less for living costs leaves more income counted as spare, which means a larger contribution expected from you and a smaller allowance. It is a local choice, not a national rule.

If the figure matters to you, ask the council to confirm the percentage it applied and why.
