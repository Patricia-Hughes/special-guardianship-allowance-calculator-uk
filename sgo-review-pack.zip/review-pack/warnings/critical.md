# Warnings shown under "Check these first"

The highest risk copy on the site. These appear in red and tell a carer something may be wrong with what their council is doing.

5 of them.

Square brackets mark text filled in from the carer's own answers.

### Taking Child Benefit off your allowance may not be lawful in your case

- Reference: `UNLAWFUL_CB_DEDUCTION_RISK`
- Shown under: "Check these first"
- Source: Special Guardianship Regulations 2005, reg 13(2) (https://www.legislation.gov.uk/uksi/2005/1109/regulation/13)
- Links to: /guidance/child-benefit-deduction

You have told us you get a means-tested benefit **and** that your council takes Child Benefit off your allowance.

The regulations require your council to take account of other benefits available to you, and Child Benefit is one of them. The courts have contemplated it being deducted. What is not allowed is applying the same rule to everybody without looking at individual circumstances.

In 2024 the Local Government and Social Care Ombudsman found a council at fault for deducting Child Benefit from every special guardian on Universal Credit as a blanket policy. That council had to recalculate around 170 carers' allowances and pay refunds. It changed its policy, and a later complaint about the new practice was not upheld.

So the question is not whether your council can deduct Child Benefit. It is whether it decided your case individually, and what its reasons were. Ask for those reasons in writing.

The Ombudsman normally expects a complaint within 12 months of you becoming aware of a problem.

### Your council may be starting from the wrong figure

- Reference: `FIXED_PERCENTAGE_POLICY`
- Shown under: "Check these first"
- Source: Barrett v Kirklees MBC [2010] EWHC 467 (Admin) (https://www.bailii.org/ew/cases/EWHC/Admin/2010/467.html)
- Links to: /guidance/fixed-percentage-policies

[COUNCIL NAME]'s published policy appears to set the allowance at a fixed share of the fostering rate, as we read it on [DATE WE LAST READ THE POLICY].

The courts have held that applying a flat percentage, two-thirds or a third or any other fixed fraction, without looking at the individual case, is an unjustified departure from the guidance. In other words, the council has stepped away from a rule it is supposed to follow without explaining why. The starting point should be the core fostering allowance, and your own circumstances should then be considered.

This does not mean you are owed the full fostering rate. In the Merton case the court also held that a council does not have to pay every special guardian an allowance, and that means testing one is lawful. The problem is the blanket nature of a fixed fraction, not the arithmetic.

Ask for the written policy and for the reasons behind the figure you were given.

### This rate is below the national minimum for fostering

- Reference: `BELOW_NMA`
- Shown under: "Check these first"
- Source: DfE Special Guardianship Guidance (Jan 2017), para 65 (https://www.gov.uk/government/publications/special-guardianship-guidance)
- Links to: /guidance/what-your-council-must-consider

The rate we hold for [COUNCIL NAME] (£120 a week) is below the national minimum fostering allowance for the 5-10 age band in your area (£187 a week).

The statutory guidance says the core fostering allowance is the starting point for a special guardianship allowance. A figure below it needs an explanation.

Two things this does not mean. It is a minimum for fostering allowances, not a floor your own allowance cannot go below. And it is about the figure your council starts from, not the amount you end up with: a lower final figure after a means test can be perfectly proper, while a lower starting figure is the thing worth asking about.

Ask the council to explain in writing how it arrived at the figure and how it compares with what it pays its foster carers.

### The Ombudsman has made a finding about this council

- Reference: `LGSCO_FINDING_AGAINST_LA`
- Shown under: "Check these first"
- Source: none cited
- Links to: /guidance/complaining-to-the-ombudsman

[The summary of the published decision about this council goes here.]

The decision was made on [DECISION DATE]. You can read it here: https://example.invalid/decision

The council changed its policy from [THE DATE THIS COUNCIL CHANGED ITS POLICY].

[The later decision that did not uphold the complaint goes here.]

A published decision about one carer does not automatically apply to you, but it is relevant background if you are asking the council to look at your case again.

### These rates may be out of date

- Reference: `RATES_STALE`
- Shown under: "Check these first"
- Source: none cited
- Links to: /guidance/rates

The rate table we are using ran to 2027-03-31. New rates are normally announced for April and we have not yet published them.

Treat the figures below as last year's. Check the current national minimum allowance before you use them in a letter.
