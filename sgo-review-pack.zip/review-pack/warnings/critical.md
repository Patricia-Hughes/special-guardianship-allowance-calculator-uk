# Warnings shown under "Check these first"

The highest risk copy on the site. These appear in red and tell a carer something may be wrong with what their council is doing.

5 of them.

Square brackets mark text filled in from the carer's own answers.

### Taking Child Benefit off your allowance may not be lawful in your case

- Reference: `UNLAWFUL_CB_DEDUCTION_RISK`
- Shown under: "Check these first"
- Source: LGSCO decision, Devon County Council (23 000 973, 25 January 2024) (https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973)
- Links to: /guidance/child-benefit-deduction

You have told us you get a means-tested benefit **and** that your council takes Child Benefit off your allowance.

In 2024 the Local Government and Social Care Ombudsman found that taking Child Benefit off carers who are on means-tested benefits, as a blanket rule, was wrong. The council involved had to recalculate around 170 carers' allowances and pay refunds.

Ask your council in writing to confirm whether it takes Child Benefit into account for carers on means-tested benefits, and to explain how it decided that in your case.

### A fixed percentage of the fostering rate has been ruled unlawful

- Reference: `FIXED_PERCENTAGE_POLICY`
- Shown under: "Check these first"
- Source: Barrett v Kirklees MBC [2010] EWHC 467 (Admin) (no public link yet)
- Links to: /guidance/fixed-percentage-policies

Anytown Council's published policy appears to set the allowance at a fixed share of the fostering rate.

The courts have repeatedly held that applying a flat percentage, two-thirds, or a third, or any other fixed fraction, is an unjustified departure from the guidance. The starting point is the core fostering allowance, and the council must consider your actual circumstances.

Ask for the written policy and for the reasons behind the figure you were given.

### This rate is below the national minimum for fostering

- Reference: `BELOW_NMA`
- Shown under: "Check these first"
- Source: DfE Special Guardianship Guidance (Jan 2017), para 65 (https://www.gov.uk/government/publications/special-guardianship-guidance)
- Links to: /guidance/what-your-council-must-consider

The rate we hold for Anytown Council (£120 a week) is below the national minimum fostering allowance for the 5-10 age band in your area (£187 a week).

The statutory guidance says the core fostering allowance is the starting point for a special guardianship allowance. A figure below it needs an explanation.

Ask the council to explain in writing how it arrived at the figure and how it compares with what it pays its foster carers.

### The Ombudsman has made a finding about this council

- Reference: `LGSCO_FINDING_AGAINST_LA`
- Shown under: "Check these first"
- Source: none cited
- Links to: /guidance/complaining-to-the-ombudsman

[The summary of the published decision about this council goes here.]

The council changed its policy from 1 January 2024.

[The later decision that did not uphold the complaint goes here.]

A published decision about one carer does not automatically apply to you, but it is relevant background if you are asking the council to look at your case again.

### These rates may be out of date

- Reference: `RATES_STALE`
- Shown under: "Check these first"
- Source: none cited
- Links to: /guidance/rates

The rate table we are using ran to 2027-03-31. New rates take effect on 1 April each year and we have not yet published them.

Treat the figures below as last year's. Check the current national minimum allowance before you use them in a letter.
