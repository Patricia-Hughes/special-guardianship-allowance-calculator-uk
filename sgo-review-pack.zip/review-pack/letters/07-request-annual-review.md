# Letter 7 of 8: Ask for your annual review

| | |
|---|---|
| Reference | `request-annual-review` |
| Offered in position | 7 of 8, when nothing specific has been triggered |
| Brought to the top when | the "Your allowance should be reviewed every year" warning appears, or the "These rates may be out of date" warning appears |
| Linked from | /guidance/annual-reviews |

## What it refers to

- **Special Guardianship Regulations 2005, regs 10-11**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/10

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, annual review, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME]. I currently receive £120 a week.

I understand that financial support should be reviewed each year. I do not think my allowance has been reviewed recently, and the national minimum allowance rates changed in April.

Please could you carry out a review, and let me know what information you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, annual review, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME]. I understand that financial support should be reviewed each year. I do not think my allowance has been reviewed recently, and the national minimum allowance rates changed in April.

Please could you carry out a review, and let me know what information you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
