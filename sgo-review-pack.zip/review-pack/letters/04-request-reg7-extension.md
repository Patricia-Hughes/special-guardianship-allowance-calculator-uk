# Letter 4 of 9: Ask for the reward element to continue past two years

| | |
|---|---|
| Reference | `request-reg7-extension` |
| Offered in position | 4 of 9, when nothing specific has been triggered |
| Brought to the top when | the "The two-year point is coming up" warning appears, or the "You can ask for the reward element to carry on past two years" warning appears, or the "Your council can keep paying your old fostering rate for two years" warning appears |
| Linked from | /guidance/former-foster-carers |

## What it refers to

- **Special Guardianship Regulations 2005, reg 7**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/7
- **R (X) v Tower Hamlets LBC [2013] EWCA Civ 904**
  (no public link yet)

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, continuing the reward element, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made on 2025-03-01. I currently receive £120 a week.

I understand that your council can continue paying the reward element of my former fostering allowance for two years after the order, and for longer where it considers that appropriate.

I would be grateful if you could confirm:

1. the date on which that two-year period ends;
2. how I can ask for the reward element to continue beyond it, and what information would help you decide; and
3. how you would decide that.

[CHILD'S NAME]'s needs have not reduced, and I would like to set out why continuing it would help. Please let me know what you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, continuing the reward element, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made. I understand that your council can continue paying the reward element of my former fostering allowance for two years after the order, and for longer where it considers that appropriate.

I would be grateful if you could confirm:

1. the date on which that two-year period ends;
2. how I can ask for the reward element to continue beyond it, and what information would help you decide; and
3. how you would decide that.

[CHILD'S NAME]'s needs have not reduced, and I would like to set out why continuing it would help. Please let me know what you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
