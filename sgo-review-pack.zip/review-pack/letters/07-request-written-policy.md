# Letter 7 of 9: Ask for your council's written policy

| | |
|---|---|
| Reference | `request-written-policy` |
| Offered in position | 7 of 9, when nothing specific has been triggered |
| Brought to the top when | the "We do not hold your council's published policy" warning appears |
| Linked from | /guidance/asking-for-the-policy |

## What it refers to

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Request for your special guardianship financial support policy, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME].

Please could you send me a copy of your current policy on financial support for special guardians, including:

1. how the starting figure for an allowance is decided;
2. how any means test is applied, and what income is taken into account;
3. whether Child Benefit is taken into account; and
4. how allowances are reviewed each year.

A link to the published version is fine if it is on your website.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Request for your special guardianship financial support policy, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME].

Please could you send me a copy of your current policy on financial support for special guardians, including:

1. how the starting figure for an allowance is decided;
2. how any means test is applied, and what income is taken into account;
3. whether Child Benefit is taken into account; and
4. how allowances are reviewed each year.

A link to the published version is fine if it is on your website.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
