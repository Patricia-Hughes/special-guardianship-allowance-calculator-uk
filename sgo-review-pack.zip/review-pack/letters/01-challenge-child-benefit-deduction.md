# Letter 1 of 9: Ask about Child Benefit being taken off your allowance

| | |
|---|---|
| Reference | `challenge-child-benefit-deduction` |
| Offered in position | 1 of 9, when nothing specific has been triggered |
| Brought to the top when | the "Taking Child Benefit off your allowance may not be lawful in your case" warning appears |
| Linked from | /guidance/child-benefit-deduction |
| Only worth sending after | nothing, it stands on its own |

## What it refers to

- **LGSCO decision, Devon County Council (23 000 973, 25 January 2024)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973
- **Special Guardianship Regulations 2005, reg 13(2)**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/13
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance. Child Benefit deduction, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME]. I currently receive £120 a week.

I understand that Child Benefit is being taken into account when my special guardianship allowance is worked out. I would be grateful if you could confirm in writing:

1. whether Child Benefit is deducted from my allowance, and if so how much;
2. whether your policy deducts Child Benefit from carers who receive means-tested benefits; and
3. how that was decided in my case.

I receive means-tested benefits. In 2024 the Local Government and Social Care Ombudsman found that deducting Child Benefit as a blanket rule from carers in that position was not appropriate, and asked the council concerned to recalculate its awards. I would be grateful if you could confirm how your policy takes that decision into account.

I understand the regulations allow Child Benefit to be taken into account. I am asking how that was decided in my case, rather than whether it is permitted.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance. Child Benefit deduction, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME]. I understand that Child Benefit is being taken into account when my special guardianship allowance is worked out. I would be grateful if you could confirm in writing:

1. whether Child Benefit is deducted from my allowance, and if so how much;
2. whether your policy deducts Child Benefit from carers who receive means-tested benefits; and
3. how that was decided in my case.

I would also be grateful if you could send me the part of your policy that covers this.

I understand the regulations allow Child Benefit to be taken into account. I am asking how that was decided in my case, rather than whether it is permitted.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
