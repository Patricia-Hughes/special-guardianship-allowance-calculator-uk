# Letter 3 of 8: Ask for your two-year former foster carer protection to continue

| | |
|---|---|
| Reference | `request-reg7-extension` |
| Offered in position | 3 of 8, when nothing specific has been triggered |
| Brought to the top when | the "Your two-year protection ends soon" warning appears, or the "You can ask for the two-year protection to be extended" warning appears, or the "Your previous fostering allowance protects your figure for two years" warning appears, or the "Check what your council is tapering" warning appears |
| Linked from | /guidance/former-foster-carers |

## What it refers to

- **Special Guardianship Regulations 2005, reg 7**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/7
- **R (X) v Tower Hamlets LBC [2013] EWCA Civ 904**
  (no public link yet)
- **LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, continuing the reward element, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made on 2025-03-01. I currently receive £120 a week.

I understand that for the first two years after the order, the reward element of my former fostering allowance is protected, and that a council can agree to continue it after that where the child's needs justify it.

I would be grateful if you could confirm:

1. the date on which that two-year period ends;
2. what my allowance will be after that date; and
3. how I can ask for the reward element to continue, and what information would help you decide.

[CHILD'S NAME]'s needs have not reduced, and I would like to set out why continuing it would help. Please let me know what you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, continuing the reward element, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made. I understand that for the first two years after the order, the reward element of my former fostering allowance is protected, and that a council can agree to continue it after that where the child's needs justify it.

I would be grateful if you could confirm:

1. the date on which that two-year period ends;
2. what my allowance will be after that date; and
3. how I can ask for the reward element to continue, and what information would help you decide.

[CHILD'S NAME]'s needs have not reduced, and I would like to set out why continuing it would help. Please let me know what you need from me.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
