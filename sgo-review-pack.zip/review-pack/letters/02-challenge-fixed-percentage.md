# Letter 2 of 9: Ask how your allowance was calculated, where a percentage seems to have been used

| | |
|---|---|
| Reference | `challenge-fixed-percentage` |
| Offered in position | 2 of 9, when nothing specific has been triggered |
| Brought to the top when | the "Your council may be starting from the wrong figure" warning appears, or the "This rate is below the national minimum for fostering" warning appears |
| Linked from | /guidance/fixed-percentage-policies |
| Only worth sending after | nothing, it stands on its own |

## What it refers to

- **Barrett v Kirklees MBC [2010] EWHC 467 (Admin)**
  https://www.bailii.org/ew/cases/EWHC/Admin/2010/467.html
- **R (TT) v Merton LBC [2012] EWHC 2055 (Admin)**
  https://caselaw.nationalarchives.gov.uk/ewhc/admin/2012/2055
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, how my allowance was calculated, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME]. I currently receive £120 a week.

My understanding is that the national minimum fostering allowance published by the Department for Education for a child in the 5-10 age band in the rest of England is £187 a week, and that the statutory guidance treats the core fostering allowance as the starting point for a special guardianship allowance.

Please could you tell me:

1. what figure you used as the starting point for my allowance;
2. whether a fixed percentage or proportion was applied at any stage; and
3. what was taken into account about my circumstances and my child's needs.

I ask because the courts have said that applying a flat percentage of the fostering allowance, without considering the individual case, is a departure from the guidance that needs to be justified. I would like to understand how the figure in my case was reached.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, how my allowance was calculated, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME]. My understanding is that the national minimum fostering allowance published by the Department for Education for a child in the 5-10 age band in the rest of England is £187 a week, and that the statutory guidance treats the core fostering allowance as the starting point for a special guardianship allowance.

Please could you tell me:

1. what figure you used as the starting point for my allowance;
2. whether a fixed percentage or proportion was applied at any stage; and
3. what was taken into account about my circumstances and my child's needs.

I ask because the courts have said that applying a flat percentage of the fostering allowance, without considering the individual case, is a departure from the guidance that needs to be justified. I would like to understand how the figure in my case was reached.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
