# Letter 9 of 9: Make a stage 1 complaint

| | |
|---|---|
| Reference | `formal-complaint-stage-1` |
| Offered in position | 9 of 9, when nothing specific has been triggered |
| Brought to the top when | never promoted; it sits in the standing list |
| Linked from | /guidance/complaining-to-the-ombudsman |

## What it refers to

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Stage 1 complaint, special guardianship allowance, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I would like to make a stage 1 complaint about the way my special guardianship allowance for [CHILD'S NAME] has been handled. I currently receive £120 a week.

What happened:

  • [what you asked for, and when]
  • [what the council did or did not do]
  • [what effect it has had on you and your child]

What I would like to happen:

  • [e.g. a written explanation of how the figure was calculated]
  • [e.g. a reassessment]

[I raised this on [DATE] and have not had a full answer. If you have not raised it before, delete this sentence.]

I am asking for it to be looked at under your complaints procedure. Please confirm you have received this and let me know when I can expect a reply.

If I am not satisfied with the outcome, I understand I can ask the Local Government and Social Care Ombudsman to look at it.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Stage 1 complaint, special guardianship allowance, ref [REFERENCE]

---

Dear Children's Services,

I would like to make a stage 1 complaint about the way my special guardianship allowance for [CHILD'S NAME] has been handled. What happened:

  • [what you asked for, and when]
  • [what the council did or did not do]
  • [what effect it has had on you and your child]

What I would like to happen:

  • [e.g. a written explanation of how the figure was calculated]
  • [e.g. a reassessment]

[I raised this on [DATE] and have not had a full answer. If you have not raised it before, delete this sentence.]

I am asking for it to be looked at under your complaints procedure. Please confirm you have received this and let me know when I can expect a reply.

If I am not satisfied with the outcome, I understand I can ask the Local Government and Social Care Ombudsman to look at it.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
