# Letter 5 of 8: Ask for the arithmetic behind your figure

| | |
|---|---|
| Reference | `request-calculation-breakdown` |
| Offered in position | 5 of 8, when nothing specific has been triggered |
| Brought to the top when | the "The means test model is not law, and it pre-dates Universal Credit" warning appears, or the "We had to assume how your council reduces the allowance" warning appears |
| Linked from | /guidance/how-the-means-test-works, /guidance/what-your-council-must-consider |

## What it refers to

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, request for a breakdown, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME]. I currently receive £120 a week.

I would be grateful for a written breakdown of how that figure was calculated, showing:

1. the starting figure and where it came from;
2. what income was taken into account, and what was disregarded;
3. what outgoings were allowed; and
4. any deductions, and the reason for each.

For reference, the national minimum fostering allowance for the 5-10 age band in the rest of England is £187 a week.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, request for a breakdown, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME]. I would be grateful for a written breakdown of how that figure was calculated, showing:

1. the starting figure and where it came from;
2. what income was taken into account, and what was disregarded;
3. what outgoings were allowed; and
4. any deductions, and the reason for each.

For reference, the national minimum fostering allowance for the 5-10 age band in the rest of England is £187 a week.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
