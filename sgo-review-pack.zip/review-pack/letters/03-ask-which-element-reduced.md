# Letter 3 of 9: Ask which part of your allowance is being reduced

| | |
|---|---|
| Reference | `ask-which-element-reduced` |
| Offered in position | 3 of 9, when nothing specific has been triggered |
| Brought to the top when | the "Check what your council is tapering" warning appears |
| Linked from | not linked from any guidance page |
| Only worth sending after | nothing, it stands on its own |

## What it refers to

- **Special Guardianship Regulations 2005, reg 7**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/7
- **LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, how it is being reduced, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made on 2025-03-01. I currently receive £120 a week.

My payments are being reduced, and I would like to understand exactly what is being reduced and why. Please could you confirm:

1. which element of my allowance is being reduced, and by how much;
2. the basis on which that reduction is being made; and
3. if regulation 7 is being relied on, how it is being applied in my case.

I ask because regulation 7 concerns the reward element of a former foster carer's allowance. The Ombudsman found in 2020 that reducing an entire allowance in stages misapplied that rule. I would like to understand which of these applies to my payments.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, how it is being reduced, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME], and I was [CHILD'S NAME]'s foster carer before the special guardianship order was made. My payments are being reduced, and I would like to understand exactly what is being reduced and why. Please could you confirm:

1. which element of my allowance is being reduced, and by how much;
2. the basis on which that reduction is being made; and
3. if regulation 7 is being relied on, how it is being applied in my case.

I ask because regulation 7 concerns the reward element of a former foster carer's allowance. The Ombudsman found in 2020 that reducing an entire allowance in stages misapplied that rule. I would like to understand which of these applies to my payments.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
