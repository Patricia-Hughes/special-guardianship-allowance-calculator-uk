# Letter 5 of 9: Ask for more because of your child's needs

| | |
|---|---|
| Reference | `request-enhancement-disability` |
| Offered in position | 5 of 9, when nothing specific has been triggered |
| Brought to the top when | the "You can ask for more because of your child's needs" warning appears |
| Linked from | /guidance/enhancements-for-additional-needs |
| Only worth sending after | nothing, it stands on its own |

## What it refers to

- **Special Guardianship Regulations 2005, reg 6(2)(b)**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The letter as a carer receives it

Shown for a carer whose council we know, who is on means-tested benefits, who
fostered the child before the order, and who told us what they are paid. Square
brackets are placeholders the carer fills in.

**Subject:** Special guardianship allowance, request for an enhancement, ref [REFERENCE]

---

Dear Anytown Council Children's Services,

I am the special guardian for [CHILD'S NAME]. I currently receive £120 a week.

The regulations allow financial support to take account of a child's disability or additional needs, including the consequences of any abuse or neglect they experienced before the order.

[CHILD'S NAME] has additional needs which mean extra costs for our household. In particular:

  • [describe the need, e.g. travel to therapy appointments]
  • [describe the cost, e.g. £__ a month]
  • [add as many as apply]

I would be grateful if you could assess whether an enhancement to my allowance would be appropriate, and let me know what evidence would help.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## How it reads for a carer who gave us less

Shown for a carer who did not name their council, is not on means-tested
benefits, and did not tell us what they are paid. The sentences that change are
the ones worth checking, because they are the ones that appear conditionally.

**Subject:** Special guardianship allowance, request for an enhancement, ref [REFERENCE]

---

Dear Children's Services,

I am the special guardian for [CHILD'S NAME]. The regulations allow financial support to take account of a child's disability or additional needs, including the consequences of any abuse or neglect they experienced before the order.

[CHILD'S NAME] has additional needs which mean extra costs for our household. In particular:

  • [describe the need, e.g. travel to therapy appointments]
  • [describe the cost, e.g. £__ a month]
  • [add as many as apply]

I would be grateful if you could assess whether an enhancement to my allowance would be appropriate, and let me know what evidence would help.

Thank you for your help.

Yours sincerely,

[YOUR NAME]
Special guardian for [CHILD'S NAME]
Reference: [REFERENCE]

---

## Questions for the reviewer

1. Could a carer sending this be put in a worse position than by saying nothing?
2. Does it concede anything, or accept a premise the carer might want to contest later?
3. Is it a request throughout, never a demand or a threat?
4. Is the legal reference the right one, and is it stated at the right strength?
5. Is this the right point in the sequence to offer it, given where it is linked from above?
