# The words that leave the site

Exported 2026-09-03.

This is the copy the sixteen guidance pages do not cover: the warnings a carer
sees on their result, and the letters they send to their council. It is the
highest risk writing on the site, because it is what ends up on a council desk.

An earlier pack listed the letters by title only. A title cannot be reviewed.
Whether a letter concedes something, demands rather than asks, or is offered
before the step that should come first, is in its sentences. Everything is set
out in full here.

## The eight letters

Shown in the order a carer is offered them when nothing specific has been
triggered. A letter jumps to the top when its matching warning appears, and
each file says which warning does that.

| Order | Letter | Reference |
|---|---|---|
| 1 | Ask about Child Benefit being taken off your allowance | `challenge-child-benefit-deduction` |
| 2 | Ask how your allowance was calculated, where a percentage seems to have been used | `challenge-fixed-percentage` |
| 3 | Ask which part of your allowance is being reduced | `ask-which-element-reduced` |
| 4 | Ask for the reward element to continue past two years | `request-reg7-extension` |
| 5 | Ask for more because of your child's needs | `request-enhancement-disability` |
| 6 | Ask for the arithmetic behind your figure | `request-calculation-breakdown` |
| 7 | Ask for your council's written policy | `request-written-policy` |
| 8 | Ask for your annual review | `request-annual-review` |
| 9 | Make a stage 1 complaint | `formal-complaint-stage-1` |

Each file also names the guidance pages that link to it, which is where a
sequencing question can be answered.

## The warnings

- **critical**: 5
- **important**: 15
- **info**: 14

Split by how loudly they are shown. The critical ones are the ones to read
first: they tell a carer something may be wrong with what their council is
doing, and they are the closest the site comes to an accusation.

## What this pack still does not cover

The result page itself. The warnings and letters below are its content, but the
page also has wording of its own: the headline above the figure, the "what to do
next" cards, the backdating table's labels. The regulation 7 review found nine
places to change and there were eleven, because two of them were there.

If you are reviewing wording again, ask for those too, or open the calculator
and read a result end to end.

## The house rules these were written to

From the specification, and they matter more than the templating:

- Polite, short, specific. These go to a social worker the carer has an ongoing
  relationship with. An aggressive letter damages that relationship, and the
  child's placement.
- Always request, never demand or threaten.
- Cite the regulation or decision in one line, not a legal essay.
- **Never assert the council has broken the law.** State what the guidance and
  the decisions say, and ask the council to confirm its position.
- Leave the placeholders visible so the carer knows what to fill in.

Please say where the copy falls short of these, as well as where it is wrong.
