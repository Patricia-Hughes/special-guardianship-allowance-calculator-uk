"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [939],
  {
    /***/ 939: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ ADSENSE_PUBLISHER: () => /* binding */ ADSENSE_PUBLISHER,
        /* harmony export */ advertisingStatus: () => /* binding */ advertisingStatus,
        /* harmony export */ editorialPage: () => /* binding */ editorialPage,
        /* harmony export */ openAdvertisingPreferences: () =>
          /* binding */ openAdvertisingPreferences,
        /* harmony export */ startAdvertising: () => /* binding */ startAdvertising,
        /* harmony export */ subscribeAdvertising: () => /* binding */ subscribeAdvertising,
        /* harmony export */
      });
      /** Optional advertising on editorial pages. The calculator never loads this service. */ const ADSENSE_PUBLISHER =
        "ca-pub-4267137695035041";
      const STATUS_EVENT = "sgo-advertising-status";
      let status = "off";
      function advertisingStatus() {
        return status;
      }
      function setStatus(next) {
        status = next;
        window.dispatchEvent(new Event(STATUS_EVENT));
      }
      function subscribeAdvertising(callback) {
        window.addEventListener(STATUS_EVENT, callback);
        return () => window.removeEventListener(STATUS_EVENT, callback);
      }
      function editorialPage(url) {
        return (
          !url.search &&
          !url.hash &&
          (url.pathname === "/rates" ||
            url.pathname === "/guidance" ||
            /^\/guidance\/[a-z0-9-]+$/.test(url.pathname))
        );
      }
      /**
       * This is an additional conservative gate, not a replacement for Google's
       * certified CMP. AdSense itself interprets the CMP's complete TCF signal.
       * Missing, failed or unfinished signals never authorize an ad request.
       */ function mayLoadAds(data, success) {
        return (
          success &&
          data.cmpStatus === "loaded" &&
          ["tcloaded", "useractioncomplete"].includes(data.eventStatus ?? "") &&
          typeof data.gdprApplies === "boolean" &&
          typeof data.tcString === "string" &&
          data.tcString.length > 0 &&
          data.purpose?.consents?.[1] === true &&
          data.vendor?.consents?.[755] === true &&
          data.publisher?.restrictions?.[1]?.[755] !== 0
        );
      }
      function loadAdSense() {
        if (!editorialPage(new URL(window.location.href)) || document.getElementById("sgo-adsense"))
          return;
        const script = document.createElement("script");
        script.id = "sgo-adsense";
        script.async = true;
        script.crossOrigin = "anonymous";
        script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_PUBLISHER}`;
        document.head.appendChild(script);
      }
      function openAdvertisingPreferences() {
        if (status !== "ready" || !window.googlefc?.showRevocationMessage) return false;
        window.googlefc.showRevocationMessage();
        return true;
      }
      /** Start only after the owner has published and verified the certified message. */ function startAdvertising() {
        const url = new URL(window.location.href);
        const privacy = url.pathname === "/privacy" && !url.search && !url.hash;
        if (window.SGO_GOOGLE_CONFIG?.adsenseEnabled !== true) {
          setStatus("off");
          return () => {};
        }
        if (!editorialPage(url) && !privacy) {
          setStatus("unavailable");
          return () => {};
        }
        setStatus("loading");
        let active = true;
        let listenerId;
        let listening = false;
        const onConsent = (data, success) => {
          if (!active) return;
          listenerId = data.listenerId ?? listenerId;
          if (!success || data.cmpStatus === "error") {
            setStatus("unavailable");
            return;
          }
          if (data.cmpStatus !== "loaded") return;
          setStatus(window.googlefc?.showRevocationMessage ? "ready" : "unavailable");
          if (mayLoadAds(data, success) && editorialPage(new URL(window.location.href))) {
            loadAdSense();
          } else if (
            data.eventStatus === "useractioncomplete" &&
            document.getElementById("sgo-adsense")
          ) {
            // Removing a script cannot stop code it already executed. A fresh document
            // rereads the CMP's saved refusal before any ad script can be requested.
            window.location.reload();
          }
        };
        const connect = () => {
          if (!active || listening || !window.__tcfapi) return;
          listening = true;
          try {
            window.__tcfapi("addEventListener", 2, onConsent);
          } catch {
            setStatus("unavailable");
          }
        };
        const interval = window.setInterval(connect, 250);
        const timeout = window.setTimeout(() => {
          window.clearInterval(interval);
          if (status === "loading") setStatus("unavailable");
        }, 30000);
        window.googlefc = window.googlefc ?? {};
        window.googlefc.callbackQueue = window.googlefc.callbackQueue ?? [];
        const readyCallback = {
          CONSENT_API_READY: connect,
        };
        window.googlefc.callbackQueue.push(readyCallback);
        if (!document.getElementById("sgo-certified-cmp")) {
          const script = document.createElement("script");
          script.id = "sgo-certified-cmp";
          script.async = true;
          script.src = "https://fundingchoicesmessages.google.com/i/pub-4267137695035041?ers=1";
          script.onerror = () => {
            if (active) setStatus("unavailable");
          };
          document.head.appendChild(script);
        }
        connect();
        return () => {
          active = false;
          window.clearInterval(interval);
          window.clearTimeout(timeout);
          if (listenerId !== undefined)
            window.__tcfapi?.("removeEventListener", 2, () => {}, listenerId);
          if (window.googlefc?.callbackQueue) {
            window.googlefc.callbackQueue = window.googlefc.callbackQueue.filter(
              (item) => item !== readyCallback,
            );
          }
        };
      }

      /***/
    },
  },
]);
