(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [511],
  {
    /***/ 54: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "shouldHardNavigate", {
        enumerable: true,
        get: function () {
          return shouldHardNavigate;
        },
      });
      const _flightdatahelpers = __webpack_require__(6081);
      const _matchsegments = __webpack_require__(1336);
      function shouldHardNavigate(flightSegmentPath, flightRouterState) {
        const [segment, parallelRoutes] = flightRouterState;
        // TODO-APP: Check if `as` can be replaced.
        const [currentSegment, parallelRouteKey] = flightSegmentPath;
        // Check if current segment matches the existing segment.
        if (!(0, _matchsegments.matchSegment)(currentSegment, segment)) {
          // If dynamic parameter in tree doesn't match up with segment path a hard navigation is triggered.
          if (Array.isArray(currentSegment)) {
            return true;
          }
          // If the existing segment did not match soft navigation is triggered.
          return false;
        }
        const lastSegment = flightSegmentPath.length <= 2;
        if (lastSegment) {
          return false;
        }
        return shouldHardNavigate(
          (0, _flightdatahelpers.getNextFlightSegmentPath)(flightSegmentPath),
          parallelRoutes[parallelRouteKey],
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=should-hard-navigate.js.map

      /***/
    },

    /***/ 207: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      // http://www.cse.yorku.ca/~oz/hash.html
      // More specifically, 32-bit hash via djbxor
      // (ref: https://gist.github.com/eplawless/52813b1d8ad9af510d85?permalink_comment_id=3367765#gistcomment-3367765)
      // This is due to number type differences between rust for turbopack to js number types,
      // where rust does not have easy way to repreesnt js's 53-bit float number type for the matching
      // overflow behavior. This is more `correct` in terms of having canonical hash across different runtime / implementation
      // as can gaurantee determinstic output from 32bit hash.

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        djb2Hash: function () {
          return djb2Hash;
        },
        hexHash: function () {
          return hexHash;
        },
      });
      function djb2Hash(str) {
        let hash = 5381;
        for (let i = 0; i < str.length; i++) {
          const char = str.charCodeAt(i);
          hash = ((hash << 5) + hash + char) & 0xffffffff;
        }
        return hash >>> 0;
      }
      function hexHash(str) {
        return djb2Hash(str).toString(36).slice(0, 5);
      } //# sourceMappingURL=hash.js.map

      /***/
    },

    /***/ 212: /***/ (
      __unused_webpack___webpack_module__,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      "use strict";
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ _: () => /* binding */ _interop_require_wildcard,
        /* harmony export */
      });
      function _getRequireWildcardCache(nodeInterop) {
        if (typeof WeakMap !== "function") return null;

        var cacheBabelInterop = new WeakMap();
        var cacheNodeInterop = new WeakMap();

        return (_getRequireWildcardCache = function (nodeInterop) {
          return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
        })(nodeInterop);
      }
      function _interop_require_wildcard(obj, nodeInterop) {
        if (!nodeInterop && obj && obj.__esModule) return obj;
        if (obj === null || (typeof obj !== "object" && typeof obj !== "function"))
          return { default: obj };

        var cache = _getRequireWildcardCache(nodeInterop);

        if (cache && cache.has(obj)) return cache.get(obj);

        var newObj = { __proto__: null };
        var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

        for (var key in obj) {
          if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) Object.defineProperty(newObj, key, desc);
            else newObj[key] = obj[key];
          }
        }

        newObj.default = obj;

        if (cache) cache.set(obj, newObj);

        return newObj;
      }

      /***/
    },

    /***/ 361: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        abortTask: function () {
          return abortTask;
        },
        listenForDynamicRequest: function () {
          return listenForDynamicRequest;
        },
        startPPRNavigation: function () {
          return startPPRNavigation;
        },
        updateCacheNodeOnPopstateRestoration: function () {
          return updateCacheNodeOnPopstateRestoration;
        },
      });
      const _segment = __webpack_require__(3388);
      const _matchsegments = __webpack_require__(1336);
      const _createroutercachekey = __webpack_require__(6066);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _prefetchcacheutils = __webpack_require__(1991);
      const MPA_NAVIGATION_TASK = {
        route: null,
        node: null,
        dynamicRequestTree: null,
        children: null,
      };
      function startPPRNavigation(
        navigatedAt,
        oldCacheNode,
        oldRouterState,
        newRouterState,
        prefetchData,
        prefetchHead,
        isPrefetchHeadPartial,
        isSamePageNavigation,
        scrollableSegmentsResult,
      ) {
        const segmentPath = [];
        return updateCacheNodeOnNavigation(
          navigatedAt,
          oldCacheNode,
          oldRouterState,
          newRouterState,
          false,
          prefetchData,
          prefetchHead,
          isPrefetchHeadPartial,
          isSamePageNavigation,
          segmentPath,
          scrollableSegmentsResult,
        );
      }
      function updateCacheNodeOnNavigation(
        navigatedAt,
        oldCacheNode,
        oldRouterState,
        newRouterState,
        didFindRootLayout,
        prefetchData,
        prefetchHead,
        isPrefetchHeadPartial,
        isSamePageNavigation,
        segmentPath,
        scrollableSegmentsResult,
      ) {
        // Diff the old and new trees to reuse the shared layouts.
        const oldRouterStateChildren = oldRouterState[1];
        const newRouterStateChildren = newRouterState[1];
        const prefetchDataChildren = prefetchData !== null ? prefetchData[2] : null;
        if (!didFindRootLayout) {
          // We're currently traversing the part of the tree that was also part of
          // the previous route. If we discover a root layout, then we don't need to
          // trigger an MPA navigation. See beginRenderingNewRouteTree for context.
          const isRootLayout = newRouterState[4] === true;
          if (isRootLayout) {
            // Found a matching root layout.
            didFindRootLayout = true;
          }
        }
        const oldParallelRoutes = oldCacheNode.parallelRoutes;
        // Clone the current set of segment children, even if they aren't active in
        // the new tree.
        // TODO: We currently retain all the inactive segments indefinitely, until
        // there's an explicit refresh, or a parent layout is lazily refreshed. We
        // rely on this for popstate navigations, which update the Router State Tree
        // but do not eagerly perform a data fetch, because they expect the segment
        // data to already be in the Cache Node tree. For highly static sites that
        // are mostly read-only, this may happen only rarely, causing memory to
        // leak. We should figure out a better model for the lifetime of inactive
        // segments, so we can maintain instant back/forward navigations without
        // leaking memory indefinitely.
        const prefetchParallelRoutes = new Map(oldParallelRoutes);
        // As we diff the trees, we may sometimes modify (copy-on-write, not mutate)
        // the Route Tree that was returned by the server — for example, in the case
        // of default parallel routes, we preserve the currently active segment. To
        // avoid mutating the original tree, we clone the router state children along
        // the return path.
        let patchedRouterStateChildren = {};
        let taskChildren = null;
        // Most navigations require a request to fetch additional data from the
        // server, either because the data was not already prefetched, or because the
        // target route contains dynamic data that cannot be prefetched.
        //
        // However, if the target route is fully static, and it's already completely
        // loaded into the segment cache, then we can skip the server request.
        //
        // This starts off as `false`, and is set to `true` if any of the child
        // routes requires a dynamic request.
        let needsDynamicRequest = false;
        // As we traverse the children, we'll construct a FlightRouterState that can
        // be sent to the server to request the dynamic data. If it turns out that
        // nothing in the subtree is dynamic (i.e. needsDynamicRequest is false at the
        // end), then this will be discarded.
        // TODO: We can probably optimize the format of this data structure to only
        // include paths that are dynamic. Instead of reusing the
        // FlightRouterState type.
        let dynamicRequestTreeChildren = {};
        for (let parallelRouteKey in newRouterStateChildren) {
          const newRouterStateChild = newRouterStateChildren[parallelRouteKey];
          const oldRouterStateChild = oldRouterStateChildren[parallelRouteKey];
          const oldSegmentMapChild = oldParallelRoutes.get(parallelRouteKey);
          const prefetchDataChild =
            prefetchDataChildren !== null ? prefetchDataChildren[parallelRouteKey] : null;
          const newSegmentChild = newRouterStateChild[0];
          const newSegmentPathChild = segmentPath.concat([parallelRouteKey, newSegmentChild]);
          const newSegmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(
            newSegmentChild,
          );
          const oldSegmentChild =
            oldRouterStateChild !== undefined ? oldRouterStateChild[0] : undefined;
          const oldCacheNodeChild =
            oldSegmentMapChild !== undefined
              ? oldSegmentMapChild.get(newSegmentKeyChild)
              : undefined;
          let taskChild;
          if (newSegmentChild === _segment.DEFAULT_SEGMENT_KEY) {
            // This is another kind of leaf segment — a default route.
            //
            // Default routes have special behavior. When there's no matching segment
            // for a parallel route, Next.js preserves the currently active segment
            // during a client navigation — but not for initial render. The server
            // leaves it to the client to account for this. So we need to handle
            // it here.
            if (oldRouterStateChild !== undefined) {
              // Reuse the existing Router State for this segment. We spawn a "task"
              // just to keep track of the updated router state; unlike most, it's
              // already fulfilled and won't be affected by the dynamic response.
              taskChild = spawnReusedTask(oldRouterStateChild);
            } else {
              // There's no currently active segment. Switch to the "create" path.
              taskChild = beginRenderingNewRouteTree(
                navigatedAt,
                oldRouterStateChild,
                newRouterStateChild,
                oldCacheNodeChild,
                didFindRootLayout,
                prefetchDataChild !== undefined ? prefetchDataChild : null,
                prefetchHead,
                isPrefetchHeadPartial,
                newSegmentPathChild,
                scrollableSegmentsResult,
              );
            }
          } else if (
            isSamePageNavigation && // Check if this is a page segment.
            // TODO: We're not consistent about how we do this check. Some places
            // check if the segment starts with PAGE_SEGMENT_KEY, but most seem to
            // check if there any any children, which is why I'm doing it here. We
            // should probably encode an empty children set as `null` though. Either
            // way, we should update all the checks to be consistent.
            Object.keys(newRouterStateChild[1]).length === 0
          ) {
            // We special case navigations to the exact same URL as the current
            // location. It's a common UI pattern for apps to refresh when you click a
            // link to the current page. So when this happens, we refresh the dynamic
            // data in the page segments.
            //
            // Note that this does not apply if the any part of the hash or search
            // query has changed. This might feel a bit weird but it makes more sense
            // when you consider that the way to trigger this behavior is to click
            // the same link multiple times.
            //
            // TODO: We should probably refresh the *entire* route when this case
            // occurs, not just the page segments. Essentially treating it the same as
            // a refresh() triggered by an action, which is the more explicit way of
            // modeling the UI pattern described above.
            //
            // Also note that this only refreshes the dynamic data, not static/
            // cached data. If the page segment is fully static and prefetched, the
            // request is skipped. (This is also how refresh() works.)
            taskChild = beginRenderingNewRouteTree(
              navigatedAt,
              oldRouterStateChild,
              newRouterStateChild,
              oldCacheNodeChild,
              didFindRootLayout,
              prefetchDataChild !== undefined ? prefetchDataChild : null,
              prefetchHead,
              isPrefetchHeadPartial,
              newSegmentPathChild,
              scrollableSegmentsResult,
            );
          } else if (
            oldRouterStateChild !== undefined &&
            oldSegmentChild !== undefined &&
            (0, _matchsegments.matchSegment)(newSegmentChild, oldSegmentChild)
          ) {
            if (oldCacheNodeChild !== undefined && oldRouterStateChild !== undefined) {
              // This segment exists in both the old and new trees. Recursively update
              // the children.
              taskChild = updateCacheNodeOnNavigation(
                navigatedAt,
                oldCacheNodeChild,
                oldRouterStateChild,
                newRouterStateChild,
                didFindRootLayout,
                prefetchDataChild,
                prefetchHead,
                isPrefetchHeadPartial,
                isSamePageNavigation,
                newSegmentPathChild,
                scrollableSegmentsResult,
              );
            } else {
              // There's no existing Cache Node for this segment. Switch to the
              // "create" path.
              taskChild = beginRenderingNewRouteTree(
                navigatedAt,
                oldRouterStateChild,
                newRouterStateChild,
                oldCacheNodeChild,
                didFindRootLayout,
                prefetchDataChild !== undefined ? prefetchDataChild : null,
                prefetchHead,
                isPrefetchHeadPartial,
                newSegmentPathChild,
                scrollableSegmentsResult,
              );
            }
          } else {
            // This is a new tree. Switch to the "create" path.
            taskChild = beginRenderingNewRouteTree(
              navigatedAt,
              oldRouterStateChild,
              newRouterStateChild,
              oldCacheNodeChild,
              didFindRootLayout,
              prefetchDataChild !== undefined ? prefetchDataChild : null,
              prefetchHead,
              isPrefetchHeadPartial,
              newSegmentPathChild,
              scrollableSegmentsResult,
            );
          }
          if (taskChild !== null) {
            // Recursively propagate up the child tasks.
            if (taskChild.route === null) {
              // One of the child tasks discovered a change to the root layout.
              // Immediately unwind from this recursive traversal.
              return MPA_NAVIGATION_TASK;
            }
            if (taskChildren === null) {
              taskChildren = new Map();
            }
            taskChildren.set(parallelRouteKey, taskChild);
            const newCacheNodeChild = taskChild.node;
            if (newCacheNodeChild !== null) {
              const newSegmentMapChild = new Map(oldSegmentMapChild);
              newSegmentMapChild.set(newSegmentKeyChild, newCacheNodeChild);
              prefetchParallelRoutes.set(parallelRouteKey, newSegmentMapChild);
            }
            // The child tree's route state may be different from the prefetched
            // route sent by the server. We need to clone it as we traverse back up
            // the tree.
            const taskChildRoute = taskChild.route;
            patchedRouterStateChildren[parallelRouteKey] = taskChildRoute;
            const dynamicRequestTreeChild = taskChild.dynamicRequestTree;
            if (dynamicRequestTreeChild !== null) {
              // Something in the child tree is dynamic.
              needsDynamicRequest = true;
              dynamicRequestTreeChildren[parallelRouteKey] = dynamicRequestTreeChild;
            } else {
              dynamicRequestTreeChildren[parallelRouteKey] = taskChildRoute;
            }
          } else {
            // The child didn't change. We can use the prefetched router state.
            patchedRouterStateChildren[parallelRouteKey] = newRouterStateChild;
            dynamicRequestTreeChildren[parallelRouteKey] = newRouterStateChild;
          }
        }
        if (taskChildren === null) {
          // No new tasks were spawned.
          return null;
        }
        const newCacheNode = {
          lazyData: null,
          rsc: oldCacheNode.rsc,
          // We intentionally aren't updating the prefetchRsc field, since this node
          // is already part of the current tree, because it would be weird for
          // prefetch data to be newer than the final data. It probably won't ever be
          // observable anyway, but it could happen if the segment is unmounted then
          // mounted again, because LayoutRouter will momentarily switch to rendering
          // prefetchRsc, via useDeferredValue.
          prefetchRsc: oldCacheNode.prefetchRsc,
          head: oldCacheNode.head,
          prefetchHead: oldCacheNode.prefetchHead,
          loading: oldCacheNode.loading,
          // Everything is cloned except for the children, which we computed above.
          parallelRoutes: prefetchParallelRoutes,
          navigatedAt,
        };
        return {
          // Return a cloned copy of the router state with updated children.
          route: patchRouterStateWithNewChildren(newRouterState, patchedRouterStateChildren),
          node: newCacheNode,
          dynamicRequestTree: needsDynamicRequest
            ? patchRouterStateWithNewChildren(newRouterState, dynamicRequestTreeChildren)
            : null,
          children: taskChildren,
        };
      }
      function beginRenderingNewRouteTree(
        navigatedAt,
        oldRouterState,
        newRouterState,
        existingCacheNode,
        didFindRootLayout,
        prefetchData,
        possiblyPartialPrefetchHead,
        isPrefetchHeadPartial,
        segmentPath,
        scrollableSegmentsResult,
      ) {
        if (!didFindRootLayout) {
          // The route tree changed before we reached a layout. (The highest-level
          // layout in a route tree is referred to as the "root" layout.) This could
          // mean that we're navigating between two different root layouts. When this
          // happens, we perform a full-page (MPA-style) navigation.
          //
          // However, the algorithm for deciding where to start rendering a route
          // (i.e. the one performed in order to reach this function) is stricter
          // than the one used to detect a change in the root layout. So just because
          // we're re-rendering a segment outside of the root layout does not mean we
          // should trigger a full-page navigation.
          //
          // Specifically, we handle dynamic parameters differently: two segments are
          // considered the same even if their parameter values are different.
          //
          // Refer to isNavigatingToNewRootLayout for details.
          //
          // Note that we only have to perform this extra traversal if we didn't
          // already discover a root layout in the part of the tree that is unchanged.
          // In the common case, this branch is skipped completely.
          if (
            oldRouterState === undefined ||
            (0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(
              oldRouterState,
              newRouterState,
            )
          ) {
            // The root layout changed. Perform a full-page navigation.
            return MPA_NAVIGATION_TASK;
          }
        }
        return createCacheNodeOnNavigation(
          navigatedAt,
          newRouterState,
          existingCacheNode,
          prefetchData,
          possiblyPartialPrefetchHead,
          isPrefetchHeadPartial,
          segmentPath,
          scrollableSegmentsResult,
        );
      }
      function createCacheNodeOnNavigation(
        navigatedAt,
        routerState,
        existingCacheNode,
        prefetchData,
        possiblyPartialPrefetchHead,
        isPrefetchHeadPartial,
        segmentPath,
        scrollableSegmentsResult,
      ) {
        // Same traversal as updateCacheNodeNavigation, but we switch to this path
        // once we reach the part of the tree that was not in the previous route. We
        // don't need to diff against the old tree, we just need to create a new one.
        // The head is assigned to every leaf segment delivered by the server. Based
        // on corresponding logic in fill-lazy-items-till-leaf-with-head.ts
        const routerStateChildren = routerState[1];
        const isLeafSegment = Object.keys(routerStateChildren).length === 0;
        // Even we're rendering inside the "new" part of the target tree, we may have
        // a locally cached segment that we can reuse. This may come from either 1)
        // the CacheNode tree, which lives in React state and is populated by previous
        // navigations; or 2) the prefetch cache, which is a separate cache that is
        // populated by prefetches.
        let rsc;
        let loading;
        let head;
        let cacheNodeNavigatedAt;
        if (
          existingCacheNode !== undefined && // DYNAMIC_STALETIME_MS defaults to 0, but it can be increased using
          // the experimental.staleTimes.dynamic config. When set, we'll avoid
          // refetching dynamic data if it was fetched within the given threshold.
          existingCacheNode.navigatedAt + _prefetchcacheutils.DYNAMIC_STALETIME_MS > navigatedAt
        ) {
          // We have an existing CacheNode for this segment, and it's not stale. We
          // should reuse it rather than request a new one.
          rsc = existingCacheNode.rsc;
          loading = existingCacheNode.loading;
          head = existingCacheNode.head;
          // Don't update the navigatedAt timestamp, since we're reusing stale data.
          cacheNodeNavigatedAt = existingCacheNode.navigatedAt;
        } else if (prefetchData !== null) {
          // There's no existing CacheNode for this segment, but we do have prefetch
          // data. If the prefetch data is fully static (i.e. does not contain any
          // dynamic holes), we don't need to request it from the server.
          rsc = prefetchData[1];
          loading = prefetchData[3];
          head = isLeafSegment ? possiblyPartialPrefetchHead : null;
          // Even though we're accessing the data from the prefetch cache, this is
          // conceptually a new segment, not a reused one. So we should update the
          // navigatedAt timestamp.
          cacheNodeNavigatedAt = navigatedAt;
          const isPrefetchRscPartial = prefetchData[4];
          if (
            isPrefetchRscPartial || // Check if the head is partial (only relevant if this is a leaf segment)
            (isPrefetchHeadPartial && isLeafSegment)
          ) {
            // We only have partial data from this segment. Like missing segments, we
            // must request the full data from the server.
            return spawnPendingTask(
              navigatedAt,
              routerState,
              prefetchData,
              possiblyPartialPrefetchHead,
              isPrefetchHeadPartial,
              segmentPath,
              scrollableSegmentsResult,
            );
          } else {
            // The prefetch data is fully static, so we can omit it from the
            // navigation request.
          }
        } else {
          // There's no prefetch for this segment. Everything from this point will be
          // requested from the server, even if there are static children below it.
          // Create a terminal task node that will later be fulfilled by
          // server response.
          return spawnPendingTask(
            navigatedAt,
            routerState,
            null,
            possiblyPartialPrefetchHead,
            isPrefetchHeadPartial,
            segmentPath,
            scrollableSegmentsResult,
          );
        }
        // We already have a full segment we can render, so we don't need to request a
        // new one from the server. Keep traversing down the tree until we reach
        // something that requires a dynamic request.
        const prefetchDataChildren = prefetchData !== null ? prefetchData[2] : null;
        const taskChildren = new Map();
        const existingCacheNodeChildren =
          existingCacheNode !== undefined ? existingCacheNode.parallelRoutes : null;
        const cacheNodeChildren = new Map(existingCacheNodeChildren);
        let dynamicRequestTreeChildren = {};
        let needsDynamicRequest = false;
        if (isLeafSegment) {
          // The segment path of every leaf segment (i.e. page) is collected into
          // a result array. This is used by the LayoutRouter to scroll to ensure that
          // new pages are visible after a navigation.
          // TODO: We should use a string to represent the segment path instead of
          // an array. We already use a string representation for the path when
          // accessing the Segment Cache, so we can use the same one.
          scrollableSegmentsResult.push(segmentPath);
        } else {
          for (let parallelRouteKey in routerStateChildren) {
            const routerStateChild = routerStateChildren[parallelRouteKey];
            const prefetchDataChild =
              prefetchDataChildren !== null ? prefetchDataChildren[parallelRouteKey] : null;
            const existingSegmentMapChild =
              existingCacheNodeChildren !== null
                ? existingCacheNodeChildren.get(parallelRouteKey)
                : undefined;
            const segmentChild = routerStateChild[0];
            const segmentPathChild = segmentPath.concat([parallelRouteKey, segmentChild]);
            const segmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(segmentChild);
            const existingCacheNodeChild =
              existingSegmentMapChild !== undefined
                ? existingSegmentMapChild.get(segmentKeyChild)
                : undefined;
            const taskChild = createCacheNodeOnNavigation(
              navigatedAt,
              routerStateChild,
              existingCacheNodeChild,
              prefetchDataChild,
              possiblyPartialPrefetchHead,
              isPrefetchHeadPartial,
              segmentPathChild,
              scrollableSegmentsResult,
            );
            taskChildren.set(parallelRouteKey, taskChild);
            const dynamicRequestTreeChild = taskChild.dynamicRequestTree;
            if (dynamicRequestTreeChild !== null) {
              // Something in the child tree is dynamic.
              needsDynamicRequest = true;
              dynamicRequestTreeChildren[parallelRouteKey] = dynamicRequestTreeChild;
            } else {
              dynamicRequestTreeChildren[parallelRouteKey] = routerStateChild;
            }
            const newCacheNodeChild = taskChild.node;
            if (newCacheNodeChild !== null) {
              const newSegmentMapChild = new Map();
              newSegmentMapChild.set(segmentKeyChild, newCacheNodeChild);
              cacheNodeChildren.set(parallelRouteKey, newSegmentMapChild);
            }
          }
        }
        return {
          // Since we're inside a new route tree, unlike the
          // `updateCacheNodeOnNavigation` path, the router state on the children
          // tasks is always the same as the router state we pass in. So we don't need
          // to clone/modify it.
          route: routerState,
          node: {
            lazyData: null,
            // Since this segment is already full, we don't need to use the
            // `prefetchRsc` field.
            rsc,
            prefetchRsc: null,
            head,
            prefetchHead: null,
            loading,
            parallelRoutes: cacheNodeChildren,
            navigatedAt: cacheNodeNavigatedAt,
          },
          dynamicRequestTree: needsDynamicRequest
            ? patchRouterStateWithNewChildren(routerState, dynamicRequestTreeChildren)
            : null,
          children: taskChildren,
        };
      }
      function patchRouterStateWithNewChildren(baseRouterState, newChildren) {
        const clone = [baseRouterState[0], newChildren];
        // Based on equivalent logic in apply-router-state-patch-to-tree, but should
        // confirm whether we need to copy all of these fields. Not sure the server
        // ever sends, e.g. the refetch marker.
        if (2 in baseRouterState) {
          clone[2] = baseRouterState[2];
        }
        if (3 in baseRouterState) {
          clone[3] = baseRouterState[3];
        }
        if (4 in baseRouterState) {
          clone[4] = baseRouterState[4];
        }
        return clone;
      }
      function spawnPendingTask(
        navigatedAt,
        routerState,
        prefetchData,
        prefetchHead,
        isPrefetchHeadPartial,
        segmentPath,
        scrollableSegmentsResult,
      ) {
        // Create a task that will later be fulfilled by data from the server.
        // Clone the prefetched route tree and the `refetch` marker to it. We'll send
        // this to the server so it knows where to start rendering.
        const dynamicRequestTree = patchRouterStateWithNewChildren(routerState, routerState[1]);
        dynamicRequestTree[3] = "refetch";
        const newTask = {
          route: routerState,
          // Corresponds to the part of the route that will be rendered on the server.
          node: createPendingCacheNode(
            navigatedAt,
            routerState,
            prefetchData,
            prefetchHead,
            isPrefetchHeadPartial,
            segmentPath,
            scrollableSegmentsResult,
          ),
          // Because this is non-null, and it gets propagated up through the parent
          // tasks, the root task will know that it needs to perform a server request.
          dynamicRequestTree,
          children: null,
        };
        return newTask;
      }
      function spawnReusedTask(reusedRouterState) {
        // Create a task that reuses an existing segment, e.g. when reusing
        // the current active segment in place of a default route.
        return {
          route: reusedRouterState,
          node: null,
          dynamicRequestTree: null,
          children: null,
        };
      }
      function listenForDynamicRequest(task, responsePromise) {
        responsePromise.then(
          (param) => {
            let { flightData } = param;
            if (typeof flightData === "string") {
              // Happens when navigating to page in `pages` from `app`. We shouldn't
              // get here because should have already handled this during
              // the prefetch.
              return;
            }
            for (const normalizedFlightData of flightData) {
              const {
                segmentPath,
                tree: serverRouterState,
                seedData: dynamicData,
                head: dynamicHead,
              } = normalizedFlightData;
              if (!dynamicData) {
                continue;
              }
              writeDynamicDataIntoPendingTask(
                task,
                segmentPath,
                serverRouterState,
                dynamicData,
                dynamicHead,
              );
            }
            // Now that we've exhausted all the data we received from the server, if
            // there are any remaining pending tasks in the tree, abort them now.
            // If there's any missing data, it will trigger a lazy fetch.
            abortTask(task, null);
          },
          (error) => {
            // This will trigger an error during render
            abortTask(task, error);
          },
        );
      }
      function writeDynamicDataIntoPendingTask(
        rootTask,
        segmentPath,
        serverRouterState,
        dynamicData,
        dynamicHead,
      ) {
        // The data sent by the server represents only a subtree of the app. We need
        // to find the part of the task tree that matches the server response, and
        // fulfill it using the dynamic data.
        //
        // segmentPath represents the parent path of subtree. It's a repeating pattern
        // of parallel route key and segment:
        //
        //   [string, Segment, string, Segment, string, Segment, ...]
        //
        // Iterate through the path and finish any tasks that match this payload.
        let task = rootTask;
        for (let i = 0; i < segmentPath.length; i += 2) {
          const parallelRouteKey = segmentPath[i];
          const segment = segmentPath[i + 1];
          const taskChildren = task.children;
          if (taskChildren !== null) {
            const taskChild = taskChildren.get(parallelRouteKey);
            if (taskChild !== undefined) {
              const taskSegment = taskChild.route[0];
              if ((0, _matchsegments.matchSegment)(segment, taskSegment)) {
                // Found a match for this task. Keep traversing down the task tree.
                task = taskChild;
                continue;
              }
            }
          }
          // We didn't find a child task that matches the server data. Exit. We won't
          // abort the task, though, because a different FlightDataPath may be able to
          // fulfill it (see loop in listenForDynamicRequest). We only abort tasks
          // once we've run out of data.
          return;
        }
        finishTaskUsingDynamicDataPayload(task, serverRouterState, dynamicData, dynamicHead);
      }
      function finishTaskUsingDynamicDataPayload(
        task,
        serverRouterState,
        dynamicData,
        dynamicHead,
      ) {
        if (task.dynamicRequestTree === null) {
          // Everything in this subtree is already complete. Bail out.
          return;
        }
        // dynamicData may represent a larger subtree than the task. Before we can
        // finish the task, we need to line them up.
        const taskChildren = task.children;
        const taskNode = task.node;
        if (taskChildren === null) {
          // We've reached the leaf node of the pending task. The server data tree
          // lines up the pending Cache Node tree. We can now switch to the
          // normal algorithm.
          if (taskNode !== null) {
            finishPendingCacheNode(
              taskNode,
              task.route,
              serverRouterState,
              dynamicData,
              dynamicHead,
            );
            // Set this to null to indicate that this task is now complete.
            task.dynamicRequestTree = null;
          }
          return;
        }
        // The server returned more data than we need to finish the task. Skip over
        // the extra segments until we reach the leaf task node.
        const serverChildren = serverRouterState[1];
        const dynamicDataChildren = dynamicData[2];
        for (const parallelRouteKey in serverRouterState) {
          const serverRouterStateChild = serverChildren[parallelRouteKey];
          const dynamicDataChild = dynamicDataChildren[parallelRouteKey];
          const taskChild = taskChildren.get(parallelRouteKey);
          if (taskChild !== undefined) {
            const taskSegment = taskChild.route[0];
            if (
              (0, _matchsegments.matchSegment)(serverRouterStateChild[0], taskSegment) &&
              dynamicDataChild !== null &&
              dynamicDataChild !== undefined
            ) {
              // Found a match for this task. Keep traversing down the task tree.
              return finishTaskUsingDynamicDataPayload(
                taskChild,
                serverRouterStateChild,
                dynamicDataChild,
                dynamicHead,
              );
            }
          }
          // We didn't find a child task that matches the server data. We won't abort
          // the task, though, because a different FlightDataPath may be able to
          // fulfill it (see loop in listenForDynamicRequest). We only abort tasks
          // once we've run out of data.
        }
      }
      function createPendingCacheNode(
        navigatedAt,
        routerState,
        prefetchData,
        prefetchHead,
        isPrefetchHeadPartial,
        segmentPath,
        scrollableSegmentsResult,
      ) {
        const routerStateChildren = routerState[1];
        const prefetchDataChildren = prefetchData !== null ? prefetchData[2] : null;
        const parallelRoutes = new Map();
        for (let parallelRouteKey in routerStateChildren) {
          const routerStateChild = routerStateChildren[parallelRouteKey];
          const prefetchDataChild =
            prefetchDataChildren !== null ? prefetchDataChildren[parallelRouteKey] : null;
          const segmentChild = routerStateChild[0];
          const segmentPathChild = segmentPath.concat([parallelRouteKey, segmentChild]);
          const segmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(segmentChild);
          const newCacheNodeChild = createPendingCacheNode(
            navigatedAt,
            routerStateChild,
            prefetchDataChild === undefined ? null : prefetchDataChild,
            prefetchHead,
            isPrefetchHeadPartial,
            segmentPathChild,
            scrollableSegmentsResult,
          );
          const newSegmentMapChild = new Map();
          newSegmentMapChild.set(segmentKeyChild, newCacheNodeChild);
          parallelRoutes.set(parallelRouteKey, newSegmentMapChild);
        }
        // The head is assigned to every leaf segment delivered by the server. Based
        // on corresponding logic in fill-lazy-items-till-leaf-with-head.ts
        const isLeafSegment = parallelRoutes.size === 0;
        if (isLeafSegment) {
          // The segment path of every leaf segment (i.e. page) is collected into
          // a result array. This is used by the LayoutRouter to scroll to ensure that
          // new pages are visible after a navigation.
          // TODO: We should use a string to represent the segment path instead of
          // an array. We already use a string representation for the path when
          // accessing the Segment Cache, so we can use the same one.
          scrollableSegmentsResult.push(segmentPath);
        }
        const maybePrefetchRsc = prefetchData !== null ? prefetchData[1] : null;
        const maybePrefetchLoading = prefetchData !== null ? prefetchData[3] : null;
        return {
          lazyData: null,
          parallelRoutes: parallelRoutes,
          prefetchRsc: maybePrefetchRsc !== undefined ? maybePrefetchRsc : null,
          prefetchHead: isLeafSegment ? prefetchHead : [null, null],
          // TODO: Technically, a loading boundary could contain dynamic data. We must
          // have separate `loading` and `prefetchLoading` fields to handle this, like
          // we do for the segment data and head.
          loading: maybePrefetchLoading !== undefined ? maybePrefetchLoading : null,
          // Create a deferred promise. This will be fulfilled once the dynamic
          // response is received from the server.
          rsc: createDeferredRsc(),
          head: isLeafSegment ? createDeferredRsc() : null,
          navigatedAt,
        };
      }
      function finishPendingCacheNode(cacheNode, taskState, serverState, dynamicData, dynamicHead) {
        // Writes a dynamic response into an existing Cache Node tree. This does _not_
        // create a new tree, it updates the existing tree in-place. So it must follow
        // the Suspense rules of cache safety — it can resolve pending promises, but
        // it cannot overwrite existing data. It can add segments to the tree (because
        // a missing segment will cause the layout router to suspend).
        // but it cannot delete them.
        //
        // We must resolve every promise in the tree, or else it will suspend
        // indefinitely. If we did not receive data for a segment, we will resolve its
        // data promise to `null` to trigger a lazy fetch during render.
        const taskStateChildren = taskState[1];
        const serverStateChildren = serverState[1];
        const dataChildren = dynamicData[2];
        // The router state that we traverse the tree with (taskState) is the same one
        // that we used to construct the pending Cache Node tree. That way we're sure
        // to resolve all the pending promises.
        const parallelRoutes = cacheNode.parallelRoutes;
        for (let parallelRouteKey in taskStateChildren) {
          const taskStateChild = taskStateChildren[parallelRouteKey];
          const serverStateChild = serverStateChildren[parallelRouteKey];
          const dataChild = dataChildren[parallelRouteKey];
          const segmentMapChild = parallelRoutes.get(parallelRouteKey);
          const taskSegmentChild = taskStateChild[0];
          const taskSegmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(
            taskSegmentChild,
          );
          const cacheNodeChild =
            segmentMapChild !== undefined ? segmentMapChild.get(taskSegmentKeyChild) : undefined;
          if (cacheNodeChild !== undefined) {
            if (
              serverStateChild !== undefined &&
              (0, _matchsegments.matchSegment)(taskSegmentChild, serverStateChild[0])
            ) {
              if (dataChild !== undefined && dataChild !== null) {
                // This is the happy path. Recursively update all the children.
                finishPendingCacheNode(
                  cacheNodeChild,
                  taskStateChild,
                  serverStateChild,
                  dataChild,
                  dynamicHead,
                );
              } else {
                // The server never returned data for this segment. Trigger a lazy
                // fetch during render. This shouldn't happen because the Route Tree
                // and the Seed Data tree sent by the server should always be the same
                // shape when part of the same server response.
                abortPendingCacheNode(taskStateChild, cacheNodeChild, null);
              }
            } else {
              // The server never returned data for this segment. Trigger a lazy
              // fetch during render.
              abortPendingCacheNode(taskStateChild, cacheNodeChild, null);
            }
          } else {
            // The server response matches what was expected to receive, but there's
            // no matching Cache Node in the task tree. This is a bug in the
            // implementation because we should have created a node for every
            // segment in the tree that's associated with this task.
          }
        }
        // Use the dynamic data from the server to fulfill the deferred RSC promise
        // on the Cache Node.
        const rsc = cacheNode.rsc;
        const dynamicSegmentData = dynamicData[1];
        if (rsc === null) {
          // This is a lazy cache node. We can overwrite it. This is only safe
          // because we know that the LayoutRouter suspends if `rsc` is `null`.
          cacheNode.rsc = dynamicSegmentData;
        } else if (isDeferredRsc(rsc)) {
          // This is a deferred RSC promise. We can fulfill it with the data we just
          // received from the server. If it was already resolved by a different
          // navigation, then this does nothing because we can't overwrite data.
          rsc.resolve(dynamicSegmentData);
        } else {
          // This is not a deferred RSC promise, nor is it empty, so it must have
          // been populated by a different navigation. We must not overwrite it.
        }
        // Check if this is a leaf segment. If so, it will have a `head` property with
        // a pending promise that needs to be resolved with the dynamic head from
        // the server.
        const head = cacheNode.head;
        if (isDeferredRsc(head)) {
          head.resolve(dynamicHead);
        }
      }
      function abortTask(task, error) {
        const cacheNode = task.node;
        if (cacheNode === null) {
          // This indicates the task is already complete.
          return;
        }
        const taskChildren = task.children;
        if (taskChildren === null) {
          // Reached the leaf task node. This is the root of a pending cache
          // node tree.
          abortPendingCacheNode(task.route, cacheNode, error);
        } else {
          // This is an intermediate task node. Keep traversing until we reach a
          // task node with no children. That will be the root of the cache node tree
          // that needs to be resolved.
          for (const taskChild of taskChildren.values()) {
            abortTask(taskChild, error);
          }
        }
        // Set this to null to indicate that this task is now complete.
        task.dynamicRequestTree = null;
      }
      function abortPendingCacheNode(routerState, cacheNode, error) {
        // For every pending segment in the tree, resolve its `rsc` promise to `null`
        // to trigger a lazy fetch during render.
        //
        // Or, if an error object is provided, it will error instead.
        const routerStateChildren = routerState[1];
        const parallelRoutes = cacheNode.parallelRoutes;
        for (let parallelRouteKey in routerStateChildren) {
          const routerStateChild = routerStateChildren[parallelRouteKey];
          const segmentMapChild = parallelRoutes.get(parallelRouteKey);
          if (segmentMapChild === undefined) {
            continue;
          }
          const segmentChild = routerStateChild[0];
          const segmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(segmentChild);
          const cacheNodeChild = segmentMapChild.get(segmentKeyChild);
          if (cacheNodeChild !== undefined) {
            abortPendingCacheNode(routerStateChild, cacheNodeChild, error);
          } else {
            // This shouldn't happen because we're traversing the same tree that was
            // used to construct the cache nodes in the first place.
          }
        }
        const rsc = cacheNode.rsc;
        if (isDeferredRsc(rsc)) {
          if (error === null) {
            // This will trigger a lazy fetch during render.
            rsc.resolve(null);
          } else {
            // This will trigger an error during rendering.
            rsc.reject(error);
          }
        }
        // Check if this is a leaf segment. If so, it will have a `head` property with
        // a pending promise that needs to be resolved. If an error was provided, we
        // will not resolve it with an error, since this is rendered at the root of
        // the app. We want the segment to error, not the entire app.
        const head = cacheNode.head;
        if (isDeferredRsc(head)) {
          head.resolve(null);
        }
      }
      function updateCacheNodeOnPopstateRestoration(oldCacheNode, routerState) {
        // A popstate navigation reads data from the local cache. It does not issue
        // new network requests (unless the cache entries have been evicted). So, we
        // update the cache to drop the prefetch data for any segment whose dynamic
        // data was already received. This prevents an unnecessary flash back to PPR
        // state during a back/forward navigation.
        //
        // This function clones the entire cache node tree and sets the `prefetchRsc`
        // field to `null` to prevent it from being rendered. We can't mutate the node
        // in place because this is a concurrent data structure.
        const routerStateChildren = routerState[1];
        const oldParallelRoutes = oldCacheNode.parallelRoutes;
        const newParallelRoutes = new Map(oldParallelRoutes);
        for (let parallelRouteKey in routerStateChildren) {
          const routerStateChild = routerStateChildren[parallelRouteKey];
          const segmentChild = routerStateChild[0];
          const segmentKeyChild = (0, _createroutercachekey.createRouterCacheKey)(segmentChild);
          const oldSegmentMapChild = oldParallelRoutes.get(parallelRouteKey);
          if (oldSegmentMapChild !== undefined) {
            const oldCacheNodeChild = oldSegmentMapChild.get(segmentKeyChild);
            if (oldCacheNodeChild !== undefined) {
              const newCacheNodeChild = updateCacheNodeOnPopstateRestoration(
                oldCacheNodeChild,
                routerStateChild,
              );
              const newSegmentMapChild = new Map(oldSegmentMapChild);
              newSegmentMapChild.set(segmentKeyChild, newCacheNodeChild);
              newParallelRoutes.set(parallelRouteKey, newSegmentMapChild);
            }
          }
        }
        // Only show prefetched data if the dynamic data is still pending.
        //
        // Tehnically, what we're actually checking is whether the dynamic network
        // response was received. But since it's a streaming response, this does not
        // mean that all the dynamic data has fully streamed in. It just means that
        // _some_ of the dynamic data was received. But as a heuristic, we assume that
        // the rest dynamic data will stream in quickly, so it's still better to skip
        // the prefetch state.
        const rsc = oldCacheNode.rsc;
        const shouldUsePrefetch = isDeferredRsc(rsc) && rsc.status === "pending";
        return {
          lazyData: null,
          rsc,
          head: oldCacheNode.head,
          prefetchHead: shouldUsePrefetch ? oldCacheNode.prefetchHead : [null, null],
          prefetchRsc: shouldUsePrefetch ? oldCacheNode.prefetchRsc : null,
          loading: oldCacheNode.loading,
          // These are the cloned children we computed above
          parallelRoutes: newParallelRoutes,
          navigatedAt: oldCacheNode.navigatedAt,
        };
      }
      const DEFERRED = Symbol();
      // This type exists to distinguish a DeferredRsc from a Flight promise. It's a
      // compromise to avoid adding an extra field on every Cache Node, which would be
      // awkward because the pre-PPR parts of codebase would need to account for it,
      // too. We can remove it once type Cache Node type is more settled.
      function isDeferredRsc(value) {
        return value && value.tag === DEFERRED;
      }
      function createDeferredRsc() {
        let resolve;
        let reject;
        const pendingRsc = new Promise((res, rej) => {
          resolve = res;
          reject = rej;
        });
        pendingRsc.status = "pending";
        pendingRsc.resolve = (value) => {
          if (pendingRsc.status === "pending") {
            const fulfilledRsc = pendingRsc;
            fulfilledRsc.status = "fulfilled";
            fulfilledRsc.value = value;
            resolve(value);
          }
        };
        pendingRsc.reject = (error) => {
          if (pendingRsc.status === "pending") {
            const rejectedRsc = pendingRsc;
            rejectedRsc.status = "rejected";
            rejectedRsc.reason = error;
            reject(error);
          }
        };
        pendingRsc.tag = DEFERRED;
        return pendingRsc;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=ppr-navigations.js.map

      /***/
    },

    /***/ 426: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        getRedirectError: function () {
          return getRedirectError;
        },
        getRedirectStatusCodeFromError: function () {
          return getRedirectStatusCodeFromError;
        },
        getRedirectTypeFromError: function () {
          return getRedirectTypeFromError;
        },
        getURLFromRedirectError: function () {
          return getURLFromRedirectError;
        },
        permanentRedirect: function () {
          return permanentRedirect;
        },
        redirect: function () {
          return redirect;
        },
      });
      const _redirectstatuscode = __webpack_require__(7223);
      const _redirecterror = __webpack_require__(9721);
      const actionAsyncStorage = false ? 0 : undefined;
      function getRedirectError(url, type, statusCode) {
        if (statusCode === void 0)
          statusCode = _redirectstatuscode.RedirectStatusCode.TemporaryRedirect;
        const error = Object.defineProperty(
          new Error(_redirecterror.REDIRECT_ERROR_CODE),
          "__NEXT_ERROR_CODE",
          {
            value: "E394",
            enumerable: false,
            configurable: true,
          },
        );
        error.digest =
          _redirecterror.REDIRECT_ERROR_CODE + ";" + type + ";" + url + ";" + statusCode + ";";
        return error;
      }
      function redirect(/** The URL to redirect to */ url, type) {
        var _actionAsyncStorage_getStore;
        type != null
          ? type
          : (type = (
              actionAsyncStorage == null
                ? void 0
                : (_actionAsyncStorage_getStore = actionAsyncStorage.getStore()) == null
                  ? void 0
                  : _actionAsyncStorage_getStore.isAction
            )
              ? _redirecterror.RedirectType.push
              : _redirecterror.RedirectType.replace);
        throw getRedirectError(url, type, _redirectstatuscode.RedirectStatusCode.TemporaryRedirect);
      }
      function permanentRedirect(/** The URL to redirect to */ url, type) {
        if (type === void 0) type = _redirecterror.RedirectType.replace;
        throw getRedirectError(url, type, _redirectstatuscode.RedirectStatusCode.PermanentRedirect);
      }
      function getURLFromRedirectError(error) {
        if (!(0, _redirecterror.isRedirectError)(error)) return null;
        // Slices off the beginning of the digest that contains the code and the
        // separating ';'.
        return error.digest.split(";").slice(2, -2).join(";");
      }
      function getRedirectTypeFromError(error) {
        if (!(0, _redirecterror.isRedirectError)(error)) {
          throw Object.defineProperty(new Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: false,
            configurable: true,
          });
        }
        return error.digest.split(";", 2)[1];
      }
      function getRedirectStatusCodeFromError(error) {
        if (!(0, _redirecterror.isRedirectError)(error)) {
          throw Object.defineProperty(new Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: false,
            configurable: true,
          });
        }
        return Number(error.digest.split(";").at(-2));
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=redirect.js.map

      /***/
    },

    /***/ 533: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * Check to see if a value is Thenable.
       *
       * @param promise the maybe-thenable value
       * @returns true if the value is thenable
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "isThenable", {
        enumerable: true,
        get: function () {
          return isThenable;
        },
      });
      function isThenable(promise) {
        return (
          promise !== null &&
          typeof promise === "object" &&
          "then" in promise &&
          typeof promise.then === "function"
        );
      } //# sourceMappingURL=is-thenable.js.map

      /***/
    },

    /***/ 586: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "useUntrackedPathname", {
        enumerable: true,
        get: function () {
          return useUntrackedPathname;
        },
      });
      const _react = __webpack_require__(5127);
      const _hooksclientcontextsharedruntime = __webpack_require__(4357);
      /**
       * This checks to see if the current render has any unknown route parameters.
       * It's used to trigger a different render path in the error boundary.
       *
       * @returns true if there are any unknown route parameters, false otherwise
       */ function hasFallbackRouteParams() {
        if (false) {
        }
        return false;
      }
      function useUntrackedPathname() {
        // If there are any unknown route parameters we would typically throw
        // an error, but this internal method allows us to return a null value instead
        // for components that do not propagate the pathname to the static shell (like
        // the error boundary).
        if (hasFallbackRouteParams()) {
          return null;
        }
        // This shouldn't cause any issues related to conditional rendering because
        // the environment will be consistent for the render.
        // eslint-disable-next-line react-hooks/rules-of-hooks
        return (0, _react.useContext)(_hooksclientcontextsharedruntime.PathnameContext);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=navigation-untracked.js.map

      /***/
    },

    /***/ 602: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        addSearchParamsToPageSegments: function () {
          return addSearchParamsToPageSegments;
        },
        handleAliasedPrefetchEntry: function () {
          return handleAliasedPrefetchEntry;
        },
      });
      const _segment = __webpack_require__(3388);
      const _approuter = __webpack_require__(9701);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _createhreffromurl = __webpack_require__(8150);
      const _createroutercachekey = __webpack_require__(6066);
      const _fillcachewithnewsubtreedata = __webpack_require__(2611);
      const _handlemutable = __webpack_require__(9466);
      const _navigatereducer = __webpack_require__(5005);
      function handleAliasedPrefetchEntry(navigatedAt, state, flightData, url, mutable) {
        let currentTree = state.tree;
        let currentCache = state.cache;
        const href = (0, _createhreffromurl.createHrefFromUrl)(url);
        let applied;
        let scrollableSegments = [];
        if (typeof flightData === "string") {
          return false;
        }
        for (const normalizedFlightData of flightData) {
          // If the segment doesn't have a loading component, we don't need to do anything.
          if (!hasLoadingComponentInSeedData(normalizedFlightData.seedData)) {
            continue;
          }
          let treePatch = normalizedFlightData.tree;
          // Segments are keyed by searchParams (e.g. __PAGE__?{"foo":"bar"}). We might return a less specific, param-less entry,
          // so we ensure that the final tree contains the correct searchParams (reflected in the URL) are provided in the updated FlightRouterState tree.
          // We only do this on the first read, as otherwise we'd be overwriting the searchParams that may have already been set
          treePatch = addSearchParamsToPageSegments(
            treePatch,
            Object.fromEntries(url.searchParams),
          );
          const { seedData, isRootRender, pathToSegment } = normalizedFlightData;
          // TODO-APP: remove ''
          const flightSegmentPathWithLeadingEmpty = ["", ...pathToSegment];
          // Segments are keyed by searchParams (e.g. __PAGE__?{"foo":"bar"}). We might return a less specific, param-less entry,
          // so we ensure that the final tree contains the correct searchParams (reflected in the URL) are provided in the updated FlightRouterState tree.
          // We only do this on the first read, as otherwise we'd be overwriting the searchParams that may have already been set
          treePatch = addSearchParamsToPageSegments(
            treePatch,
            Object.fromEntries(url.searchParams),
          );
          let newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
            flightSegmentPathWithLeadingEmpty,
            currentTree,
            treePatch,
            href,
          );
          const newCache = (0, _approuter.createEmptyCacheNode)();
          // The prefetch cache entry was aliased -- this signals that we only fill in the cache with the
          // loading state and not the actual parallel route seed data.
          if (isRootRender && seedData) {
            // Fill in the cache with the new loading / rsc data
            const rsc = seedData[1];
            const loading = seedData[3];
            newCache.loading = loading;
            newCache.rsc = rsc;
            // Construct a new tree and apply the aliased loading state for each parallel route
            fillNewTreeWithOnlyLoadingSegments(
              navigatedAt,
              newCache,
              currentCache,
              treePatch,
              seedData,
            );
          } else {
            // Copy rsc for the root node of the cache.
            newCache.rsc = currentCache.rsc;
            newCache.prefetchRsc = currentCache.prefetchRsc;
            newCache.loading = currentCache.loading;
            newCache.parallelRoutes = new Map(currentCache.parallelRoutes);
            // copy the loading state only into the leaf node (the part that changed)
            (0, _fillcachewithnewsubtreedata.fillCacheWithNewSubTreeDataButOnlyLoading)(
              navigatedAt,
              newCache,
              currentCache,
              normalizedFlightData,
            );
          }
          // If we don't have an updated tree, there's no reason to update the cache, as the tree
          // dictates what cache nodes to render.
          if (newTree) {
            currentTree = newTree;
            currentCache = newCache;
            applied = true;
          }
          for (const subSegment of (0, _navigatereducer.generateSegmentsFromPatch)(treePatch)) {
            const scrollableSegmentPath = [...normalizedFlightData.pathToSegment, ...subSegment];
            // Filter out the __DEFAULT__ paths as they shouldn't be scrolled to in this case.
            if (
              scrollableSegmentPath[scrollableSegmentPath.length - 1] !==
              _segment.DEFAULT_SEGMENT_KEY
            ) {
              scrollableSegments.push(scrollableSegmentPath);
            }
          }
        }
        if (!applied) {
          return false;
        }
        mutable.patchedTree = currentTree;
        mutable.cache = currentCache;
        mutable.canonicalUrl = href;
        mutable.hashFragment = url.hash;
        mutable.scrollableSegments = scrollableSegments;
        return (0, _handlemutable.handleMutable)(state, mutable);
      }
      function hasLoadingComponentInSeedData(seedData) {
        if (!seedData) return false;
        const parallelRoutes = seedData[2];
        const loading = seedData[3];
        if (loading) {
          return true;
        }
        for (const key in parallelRoutes) {
          if (hasLoadingComponentInSeedData(parallelRoutes[key])) {
            return true;
          }
        }
        return false;
      }
      function fillNewTreeWithOnlyLoadingSegments(
        navigatedAt,
        newCache,
        existingCache,
        routerState,
        cacheNodeSeedData,
      ) {
        const isLastSegment = Object.keys(routerState[1]).length === 0;
        if (isLastSegment) {
          return;
        }
        for (const key in routerState[1]) {
          const parallelRouteState = routerState[1][key];
          const segmentForParallelRoute = parallelRouteState[0];
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segmentForParallelRoute);
          const parallelSeedData =
            cacheNodeSeedData !== null && cacheNodeSeedData[2][key] !== undefined
              ? cacheNodeSeedData[2][key]
              : null;
          let newCacheNode;
          if (parallelSeedData !== null) {
            // New data was sent from the server.
            const rsc = parallelSeedData[1];
            const loading = parallelSeedData[3];
            newCacheNode = {
              lazyData: null,
              // copy the layout but null the page segment as that's not meant to be used
              rsc: segmentForParallelRoute.includes(_segment.PAGE_SEGMENT_KEY) ? null : rsc,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading,
              navigatedAt,
            };
          } else {
            // No data available for this node. This will trigger a lazy fetch
            // during render.
            newCacheNode = {
              lazyData: null,
              rsc: null,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading: null,
              navigatedAt: -1,
            };
          }
          const existingParallelRoutes = newCache.parallelRoutes.get(key);
          if (existingParallelRoutes) {
            existingParallelRoutes.set(cacheKey, newCacheNode);
          } else {
            newCache.parallelRoutes.set(key, new Map([[cacheKey, newCacheNode]]));
          }
          fillNewTreeWithOnlyLoadingSegments(
            navigatedAt,
            newCacheNode,
            existingCache,
            parallelRouteState,
            parallelSeedData,
          );
        }
      }
      function addSearchParamsToPageSegments(flightRouterState, searchParams) {
        const [segment, parallelRoutes, ...rest] = flightRouterState;
        // If it's a page segment, modify the segment by adding search params
        if (segment.includes(_segment.PAGE_SEGMENT_KEY)) {
          const newSegment = (0, _segment.addSearchParamsIfPageSegment)(segment, searchParams);
          return [newSegment, parallelRoutes, ...rest];
        }
        // Otherwise, recurse through the parallel routes and return a new tree
        const updatedParallelRoutes = {};
        for (const [key, parallelRoute] of Object.entries(parallelRoutes)) {
          updatedParallelRoutes[key] = addSearchParamsToPageSegments(parallelRoute, searchParams);
        }
        return [segment, updatedParallelRoutes, ...rest];
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=aliased-prefetch-navigations.js.map

      /***/
    },

    /***/ 607: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "isNavigatingToNewRootLayout", {
        enumerable: true,
        get: function () {
          return isNavigatingToNewRootLayout;
        },
      });
      function isNavigatingToNewRootLayout(currentTree, nextTree) {
        // Compare segments
        const currentTreeSegment = currentTree[0];
        const nextTreeSegment = nextTree[0];
        // If any segment is different before we find the root layout, the root layout has changed.
        // E.g. /same/(group1)/layout.js -> /same/(group2)/layout.js
        // First segment is 'same' for both, keep looking. (group1) changed to (group2) before the root layout was found, it must have changed.
        if (Array.isArray(currentTreeSegment) && Array.isArray(nextTreeSegment)) {
          // Compare dynamic param name and type but ignore the value, different values would not affect the current root layout
          // /[name] - /slug1 and /slug2, both values (slug1 & slug2) still has the same layout /[name]/layout.js
          if (
            currentTreeSegment[0] !== nextTreeSegment[0] ||
            currentTreeSegment[2] !== nextTreeSegment[2]
          ) {
            return true;
          }
        } else if (currentTreeSegment !== nextTreeSegment) {
          return true;
        }
        // Current tree root layout found
        if (currentTree[4]) {
          // If the next tree doesn't have the root layout flag, it must have changed.
          return !nextTree[4];
        }
        // Current tree didn't have its root layout here, must have changed.
        if (nextTree[4]) {
          return true;
        }
        // We can't assume it's `parallelRoutes.children` here in case the root layout is `app/@something/layout.js`
        // But it's not possible to be more than one parallelRoutes before the root layout is found
        // TODO-APP: change to traverse all parallel routes
        const currentTreeChild = Object.values(currentTree[1])[0];
        const nextTreeChild = Object.values(nextTree[1])[0];
        if (!currentTreeChild || !nextTreeChild) return true;
        return isNavigatingToNewRootLayout(currentTreeChild, nextTreeChild);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=is-navigating-to-new-root-layout.js.map

      /***/
    },

    /***/ 612: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      var _global_process, _global_process1;
      module.exports =
        ((_global_process = __webpack_require__.g.process) == null
          ? void 0
          : _global_process.env) &&
        typeof ((_global_process1 = __webpack_require__.g.process) == null
          ? void 0
          : _global_process1.env) === "object"
          ? __webpack_require__.g.process
          : __webpack_require__(5249);

      //# sourceMappingURL=process.js.map

      /***/
    },

    /***/ 917: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ErrorBoundary: function () {
          return ErrorBoundary;
        },
        ErrorBoundaryHandler: function () {
          return ErrorBoundaryHandler;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(5127));
      const _navigationuntracked = __webpack_require__(586);
      const _isnextroutererror = __webpack_require__(1582);
      const _navfailurehandler = __webpack_require__(6917);
      const _handleisrerror = __webpack_require__(5680);
      const _isbot = __webpack_require__(8245);
      const isBotUserAgent = true && (0, _isbot.isBot)(window.navigator.userAgent);
      class ErrorBoundaryHandler extends _react.default.Component {
        static getDerivedStateFromError(error) {
          if ((0, _isnextroutererror.isNextRouterError)(error)) {
            // Re-throw if an expected internal Next.js router error occurs
            // this means it should be handled by a different boundary (such as a NotFound boundary in a parent segment)
            throw error;
          }
          return {
            error,
          };
        }
        static getDerivedStateFromProps(props, state) {
          const { error } = state;
          // if we encounter an error while
          // a navigation is pending we shouldn't render
          // the error boundary and instead should fallback
          // to a hard navigation to attempt recovering
          if (false) {
          }
          /**
           * Handles reset of the error boundary when a navigation happens.
           * Ensures the error boundary does not stay enabled when navigating to a new page.
           * Approach of setState in render is safe as it checks the previous pathname and then overrides
           * it as outlined in https://react.dev/reference/react/useState#storing-information-from-previous-renders
           */ if (props.pathname !== state.previousPathname && state.error) {
            return {
              error: null,
              previousPathname: props.pathname,
            };
          }
          return {
            error: state.error,
            previousPathname: props.pathname,
          };
        }
        // Explicit type is needed to avoid the generated `.d.ts` having a wide return type that could be specific to the `@types/react` version.
        render() {
          //When it's bot request, segment level error boundary will keep rendering the children,
          // the final error will be caught by the root error boundary and determine wether need to apply graceful degrade.
          if (this.state.error && !isBotUserAgent) {
            return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
              children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)(_handleisrerror.HandleISRError, {
                  error: this.state.error,
                }),
                this.props.errorStyles,
                this.props.errorScripts,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(this.props.errorComponent, {
                  error: this.state.error,
                  reset: this.reset,
                }),
              ],
            });
          }
          return this.props.children;
        }
        constructor(props) {
          (super(props),
            (this.reset = () => {
              this.setState({
                error: null,
              });
            }));
          this.state = {
            error: null,
            previousPathname: this.props.pathname,
          };
        }
      }
      function ErrorBoundary(param) {
        let { errorComponent, errorStyles, errorScripts, children } = param;
        // When we're rendering the missing params shell, this will return null. This
        // is because we won't be rendering any not found boundaries or error
        // boundaries for the missing params shell. When this runs on the client
        // (where these errors can occur), we will get the correct pathname.
        const pathname = (0, _navigationuntracked.useUntrackedPathname)();
        if (errorComponent) {
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(ErrorBoundaryHandler, {
            pathname: pathname,
            errorComponent: errorComponent,
            errorStyles: errorStyles,
            errorScripts: errorScripts,
            children: children,
          });
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
          children: children,
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=error-boundary.js.map

      /***/
    },

    /***/ 937: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      // This regex contains the bots that we need to do a blocking render for and can't safely stream the response
      // due to how they parse the DOM. For example, they might explicitly check for metadata in the `head` tag, so we can't stream metadata tags after the `head` was sent.
      // Note: The pattern [\w-]+-Google captures all Google crawlers with "-Google" suffix (e.g., Mediapartners-Google, AdsBot-Google, Storebot-Google)
      // as well as crawlers starting with "Google-" (e.g., Google-PageRenderer, Google-InspectionTool)

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "HTML_LIMITED_BOT_UA_RE", {
        enumerable: true,
        get: function () {
          return HTML_LIMITED_BOT_UA_RE;
        },
      });
      const HTML_LIMITED_BOT_UA_RE =
        /[\w-]+-Google|Google-[\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight/i; //# sourceMappingURL=html-bots.js.map

      /***/
    },

    /***/ 1106: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      // This regex will have fast negatives meaning valid identifiers may not pass
      // this test. However this is only used during static generation to provide hints
      // about why a page bailed out of some or all prerendering and we can use bracket notation
      // for example while `ಠ_ಠ` is a valid identifier it's ok to print `searchParams['ಠ_ಠ']`
      // even if this would have been fine too `searchParams.ಠ_ಠ`

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        describeHasCheckingStringProperty: function () {
          return describeHasCheckingStringProperty;
        },
        describeStringPropertyAccess: function () {
          return describeStringPropertyAccess;
        },
        wellKnownProperties: function () {
          return wellKnownProperties;
        },
      });
      const isDefinitelyAValidIdentifier = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
      function describeStringPropertyAccess(target, prop) {
        if (isDefinitelyAValidIdentifier.test(prop)) {
          return "`" + target + "." + prop + "`";
        }
        return "`" + target + "[" + JSON.stringify(prop) + "]`";
      }
      function describeHasCheckingStringProperty(target, prop) {
        const stringifiedProp = JSON.stringify(prop);
        return (
          "`Reflect.has(" +
          target +
          ", " +
          stringifiedProp +
          ")`, `" +
          stringifiedProp +
          " in " +
          target +
          "`, or similar"
        );
      }
      const wellKnownProperties = new Set([
        "hasOwnProperty",
        "isPrototypeOf",
        "propertyIsEnumerable",
        "toString",
        "valueOf",
        "toLocaleString",
        // Promise prototype
        // fallthrough
        "then",
        "catch",
        "finally",
        // React Promise extension
        // fallthrough
        "status",
        // React introspection
        "displayName",
        "_debugInfo",
        // Common tested properties
        // fallthrough
        "toJSON",
        "$$typeof",
        "__esModule",
        // Tested by flight when checking for iterables
        "@@iterator",
      ]); //# sourceMappingURL=reflect-utils.js.map

      /***/
    },

    /***/ 1241: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        addRefreshMarkerToActiveParallelSegments: function () {
          return addRefreshMarkerToActiveParallelSegments;
        },
        refreshInactiveParallelSegments: function () {
          return refreshInactiveParallelSegments;
        },
      });
      const _applyflightdata = __webpack_require__(1437);
      const _fetchserverresponse = __webpack_require__(2682);
      const _segment = __webpack_require__(3388);
      async function refreshInactiveParallelSegments(options) {
        const fetchedSegments = new Set();
        await refreshInactiveParallelSegmentsImpl({
          ...options,
          rootTree: options.updatedTree,
          fetchedSegments,
        });
      }
      async function refreshInactiveParallelSegmentsImpl(param) {
        let {
          navigatedAt,
          state,
          updatedTree,
          updatedCache,
          includeNextUrl,
          fetchedSegments,
          rootTree = updatedTree,
          canonicalUrl,
        } = param;
        const [, parallelRoutes, refetchPath, refetchMarker] = updatedTree;
        const fetchPromises = [];
        if (
          refetchPath &&
          refetchPath !== canonicalUrl &&
          refetchMarker === "refresh" && // it's possible for the tree to contain multiple segments that contain data at the same URL
          // we keep track of them so we can dedupe the requests
          !fetchedSegments.has(refetchPath)
        ) {
          fetchedSegments.add(refetchPath); // Mark this URL as fetched
          // Eagerly kick off the fetch for the refetch path & the parallel routes. This should be fine to do as they each operate
          // independently on their own cache nodes, and `applyFlightData` will copy anything it doesn't care about from the existing cache.
          const fetchPromise = (0, _fetchserverresponse.fetchServerResponse)(
            new URL(refetchPath, location.origin),
            {
              // refetch from the root of the updated tree, otherwise it will be scoped to the current segment
              // and might not contain the data we need to patch in interception route data (such as dynamic params from a previous segment)
              flightRouterState: [rootTree[0], rootTree[1], rootTree[2], "refetch"],
              nextUrl: includeNextUrl ? state.nextUrl : null,
            },
          ).then((param) => {
            let { flightData } = param;
            if (typeof flightData !== "string") {
              for (const flightDataPath of flightData) {
                // we only pass the new cache as this function is called after clearing the router cache
                // and filling in the new page data from the server. Meaning the existing cache is actually the cache that's
                // just been created & has been written to, but hasn't been "committed" yet.
                (0, _applyflightdata.applyFlightData)(
                  navigatedAt,
                  updatedCache,
                  updatedCache,
                  flightDataPath,
                );
              }
            } else {
              // When flightData is a string, it suggests that the server response should have triggered an MPA navigation
              // I'm not 100% sure of this decision, but it seems unlikely that we'd want to introduce a redirect side effect
              // when refreshing on-screen data, so handling this has been ommitted.
            }
          });
          fetchPromises.push(fetchPromise);
        }
        for (const key in parallelRoutes) {
          const parallelFetchPromise = refreshInactiveParallelSegmentsImpl({
            navigatedAt,
            state,
            updatedTree: parallelRoutes[key],
            updatedCache,
            includeNextUrl,
            fetchedSegments,
            rootTree,
            canonicalUrl,
          });
          fetchPromises.push(parallelFetchPromise);
        }
        await Promise.all(fetchPromises);
      }
      function addRefreshMarkerToActiveParallelSegments(tree, path) {
        const [segment, parallelRoutes, , refetchMarker] = tree;
        // a page segment might also contain concatenated search params, so we do a partial match on the key
        if (segment.includes(_segment.PAGE_SEGMENT_KEY) && refetchMarker !== "refresh") {
          tree[2] = path;
          tree[3] = "refresh";
        }
        for (const key in parallelRoutes) {
          addRefreshMarkerToActiveParallelSegments(parallelRoutes[key], path);
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=refetch-inactive-parallel-segments.js.map

      /***/
    },

    /***/ 1257: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        normalizeAppPath: function () {
          return normalizeAppPath;
        },
        normalizeRscURL: function () {
          return normalizeRscURL;
        },
      });
      const _ensureleadingslash = __webpack_require__(2720);
      const _segment = __webpack_require__(3388);
      function normalizeAppPath(route) {
        return (0, _ensureleadingslash.ensureLeadingSlash)(
          route.split("/").reduce((pathname, segment, index, segments) => {
            // Empty segments are ignored.
            if (!segment) {
              return pathname;
            }
            // Groups are ignored.
            if ((0, _segment.isGroupSegment)(segment)) {
              return pathname;
            }
            // Parallel segments are ignored.
            if (segment[0] === "@") {
              return pathname;
            }
            // The last segment (if it's a leaf) should be ignored.
            if ((segment === "page" || segment === "route") && index === segments.length - 1) {
              return pathname;
            }
            return pathname + "/" + segment;
          }, ""),
        );
      }
      function normalizeRscURL(url) {
        return url.replace(/\.rsc($|\?)/, "$1");
      } //# sourceMappingURL=app-paths.js.map

      /***/
    },

    /***/ 1306: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ACTION_HEADER: function () {
          return ACTION_HEADER;
        },
        FLIGHT_HEADERS: function () {
          return FLIGHT_HEADERS;
        },
        NEXT_ACTION_NOT_FOUND_HEADER: function () {
          return NEXT_ACTION_NOT_FOUND_HEADER;
        },
        NEXT_DID_POSTPONE_HEADER: function () {
          return NEXT_DID_POSTPONE_HEADER;
        },
        NEXT_HMR_REFRESH_HASH_COOKIE: function () {
          return NEXT_HMR_REFRESH_HASH_COOKIE;
        },
        NEXT_HMR_REFRESH_HEADER: function () {
          return NEXT_HMR_REFRESH_HEADER;
        },
        NEXT_IS_PRERENDER_HEADER: function () {
          return NEXT_IS_PRERENDER_HEADER;
        },
        NEXT_REWRITTEN_PATH_HEADER: function () {
          return NEXT_REWRITTEN_PATH_HEADER;
        },
        NEXT_REWRITTEN_QUERY_HEADER: function () {
          return NEXT_REWRITTEN_QUERY_HEADER;
        },
        NEXT_ROUTER_PREFETCH_HEADER: function () {
          return NEXT_ROUTER_PREFETCH_HEADER;
        },
        NEXT_ROUTER_SEGMENT_PREFETCH_HEADER: function () {
          return NEXT_ROUTER_SEGMENT_PREFETCH_HEADER;
        },
        NEXT_ROUTER_STALE_TIME_HEADER: function () {
          return NEXT_ROUTER_STALE_TIME_HEADER;
        },
        NEXT_ROUTER_STATE_TREE_HEADER: function () {
          return NEXT_ROUTER_STATE_TREE_HEADER;
        },
        NEXT_RSC_UNION_QUERY: function () {
          return NEXT_RSC_UNION_QUERY;
        },
        NEXT_URL: function () {
          return NEXT_URL;
        },
        RSC_CONTENT_TYPE_HEADER: function () {
          return RSC_CONTENT_TYPE_HEADER;
        },
        RSC_HEADER: function () {
          return RSC_HEADER;
        },
      });
      const RSC_HEADER = "rsc";
      const ACTION_HEADER = "next-action";
      const NEXT_ROUTER_STATE_TREE_HEADER = "next-router-state-tree";
      const NEXT_ROUTER_PREFETCH_HEADER = "next-router-prefetch";
      const NEXT_ROUTER_SEGMENT_PREFETCH_HEADER = "next-router-segment-prefetch";
      const NEXT_HMR_REFRESH_HEADER = "next-hmr-refresh";
      const NEXT_HMR_REFRESH_HASH_COOKIE = "__next_hmr_refresh_hash__";
      const NEXT_URL = "next-url";
      const RSC_CONTENT_TYPE_HEADER = "text/x-component";
      const FLIGHT_HEADERS = [
        RSC_HEADER,
        NEXT_ROUTER_STATE_TREE_HEADER,
        NEXT_ROUTER_PREFETCH_HEADER,
        NEXT_HMR_REFRESH_HEADER,
        NEXT_ROUTER_SEGMENT_PREFETCH_HEADER,
      ];
      const NEXT_RSC_UNION_QUERY = "_rsc";
      const NEXT_ROUTER_STALE_TIME_HEADER = "x-nextjs-stale-time";
      const NEXT_DID_POSTPONE_HEADER = "x-nextjs-postponed";
      const NEXT_REWRITTEN_PATH_HEADER = "x-nextjs-rewritten-path";
      const NEXT_REWRITTEN_QUERY_HEADER = "x-nextjs-rewritten-query";
      const NEXT_IS_PRERENDER_HEADER = "x-nextjs-prerender";
      const NEXT_ACTION_NOT_FOUND_HEADER = "x-nextjs-action-not-found";
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-router-headers.js.map

      /***/
    },

    /***/ 1336: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "matchSegment", {
        enumerable: true,
        get: function () {
          return matchSegment;
        },
      });
      const matchSegment = (existingSegment, segment) => {
        // segment is either Array or string
        if (typeof existingSegment === "string") {
          if (typeof segment === "string") {
            // Common case: segment is just a string
            return existingSegment === segment;
          }
          return false;
        }
        if (typeof segment === "string") {
          return false;
        }
        return existingSegment[0] === segment[0] && existingSegment[1] === segment[1];
      };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=match-segments.js.map

      /***/
    },

    /***/ 1362: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "default", {
        enumerable: true,
        get: function () {
          return OuterLayoutRouter;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _routerreducertypes = __webpack_require__(9131);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _reactdom = /*#__PURE__*/ _interop_require_default._(__webpack_require__(8534));
      const _approutercontextsharedruntime = __webpack_require__(6764);
      const _fetchserverresponse = __webpack_require__(2682);
      const _unresolvedthenable = __webpack_require__(2923);
      const _errorboundary = __webpack_require__(917);
      const _matchsegments = __webpack_require__(1336);
      const _disablesmoothscroll = __webpack_require__(7590);
      const _redirectboundary = __webpack_require__(1583);
      const _errorboundary1 = __webpack_require__(9154);
      const _createroutercachekey = __webpack_require__(6066);
      const _hasinterceptionrouteincurrenttree = __webpack_require__(3495);
      const _useactionqueue = __webpack_require__(7964);
      const _bfcache = __webpack_require__(4936);
      const _apppaths = __webpack_require__(1257);
      const Activity = false ? 0 : null;
      /**
       * Add refetch marker to router state at the point of the current layout segment.
       * This ensures the response returned is not further down than the current layout segment.
       */ function walkAddRefetch(segmentPathToWalk, treeToRecreate) {
        if (segmentPathToWalk) {
          const [segment, parallelRouteKey] = segmentPathToWalk;
          const isLast = segmentPathToWalk.length === 2;
          if ((0, _matchsegments.matchSegment)(treeToRecreate[0], segment)) {
            if (treeToRecreate[1].hasOwnProperty(parallelRouteKey)) {
              if (isLast) {
                const subTree = walkAddRefetch(undefined, treeToRecreate[1][parallelRouteKey]);
                return [
                  treeToRecreate[0],
                  {
                    ...treeToRecreate[1],
                    [parallelRouteKey]: [subTree[0], subTree[1], subTree[2], "refetch"],
                  },
                ];
              }
              return [
                treeToRecreate[0],
                {
                  ...treeToRecreate[1],
                  [parallelRouteKey]: walkAddRefetch(
                    segmentPathToWalk.slice(2),
                    treeToRecreate[1][parallelRouteKey],
                  ),
                },
              ];
            }
          }
        }
        return treeToRecreate;
      }
      const __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE =
        _reactdom.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
      // TODO-APP: Replace with new React API for finding dom nodes without a `ref` when available
      /**
       * Wraps ReactDOM.findDOMNode with additional logic to hide React Strict Mode warning
       */ function findDOMNode(instance) {
        // Tree-shake for server bundle
        if (false) {
        }
        // __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE.findDOMNode is null during module init.
        // We need to lazily reference it.
        const internal_reactDOMfindDOMNode =
          __DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE.findDOMNode;
        return internal_reactDOMfindDOMNode(instance);
      }
      const rectProperties = ["bottom", "height", "left", "right", "top", "width", "x", "y"];
      /**
       * Check if a HTMLElement is hidden or fixed/sticky position
       */ function shouldSkipElement(element) {
        // we ignore fixed or sticky positioned elements since they'll likely pass the "in-viewport" check
        // and will result in a situation we bail on scroll because of something like a fixed nav,
        // even though the actual page content is offscreen
        if (["sticky", "fixed"].includes(getComputedStyle(element).position)) {
          if (false) {
          }
          return true;
        }
        // Uses `getBoundingClientRect` to check if the element is hidden instead of `offsetParent`
        // because `offsetParent` doesn't consider document/body
        const rect = element.getBoundingClientRect();
        return rectProperties.every((item) => rect[item] === 0);
      }
      /**
       * Check if the top corner of the HTMLElement is in the viewport.
       */ function topOfElementInViewport(element, viewportHeight) {
        const rect = element.getBoundingClientRect();
        return rect.top >= 0 && rect.top <= viewportHeight;
      }
      /**
       * Find the DOM node for a hash fragment.
       * If `top` the page has to scroll to the top of the page. This mirrors the browser's behavior.
       * If the hash fragment is an id, the page has to scroll to the element with that id.
       * If the hash fragment is a name, the page has to scroll to the first element with that name.
       */ function getHashFragmentDomNode(hashFragment) {
        // If the hash fragment is `top` the page has to scroll to the top of the page.
        if (hashFragment === "top") {
          return document.body;
        }
        var _document_getElementById;
        // If the hash fragment is an id, the page has to scroll to the element with that id.
        return (_document_getElementById = document.getElementById(hashFragment)) != null
          ? _document_getElementById
          : document.getElementsByName(hashFragment)[0];
      }
      class InnerScrollAndFocusHandler extends _react.default.Component {
        componentDidMount() {
          this.handlePotentialScroll();
        }
        componentDidUpdate() {
          // Because this property is overwritten in handlePotentialScroll it's fine to always run it when true as it'll be set to false for subsequent renders.
          if (this.props.focusAndScrollRef.apply) {
            this.handlePotentialScroll();
          }
        }
        render() {
          return this.props.children;
        }
        constructor(...args) {
          (super(...args),
            (this.handlePotentialScroll = () => {
              // Handle scroll and focus, it's only applied once in the first useEffect that triggers that changed.
              const { focusAndScrollRef, segmentPath } = this.props;
              if (focusAndScrollRef.apply) {
                // segmentPaths is an array of segment paths that should be scrolled to
                // if the current segment path is not in the array, the scroll is not applied
                // unless the array is empty, in which case the scroll is always applied
                if (
                  focusAndScrollRef.segmentPaths.length !== 0 &&
                  !focusAndScrollRef.segmentPaths.some((scrollRefSegmentPath) =>
                    segmentPath.every((segment, index) =>
                      (0, _matchsegments.matchSegment)(segment, scrollRefSegmentPath[index]),
                    ),
                  )
                ) {
                  return;
                }
                let domNode = null;
                const hashFragment = focusAndScrollRef.hashFragment;
                if (hashFragment) {
                  domNode = getHashFragmentDomNode(hashFragment);
                }
                // `findDOMNode` is tricky because it returns just the first child if the component is a fragment.
                // This already caused a bug where the first child was a <link/> in head.
                if (!domNode) {
                  domNode = findDOMNode(this);
                }
                // If there is no DOM node this layout-router level is skipped. It'll be handled higher-up in the tree.
                if (!(domNode instanceof Element)) {
                  return;
                }
                // Verify if the element is a HTMLElement and if we want to consider it for scroll behavior.
                // If the element is skipped, try to select the next sibling and try again.
                while (!(domNode instanceof HTMLElement) || shouldSkipElement(domNode)) {
                  if (false) {
                    var _domNode_parentElement;
                  }
                  // No siblings found that match the criteria are found, so handle scroll higher up in the tree instead.
                  if (domNode.nextElementSibling === null) {
                    return;
                  }
                  domNode = domNode.nextElementSibling;
                }
                // State is mutated to ensure that the focus and scroll is applied only once.
                focusAndScrollRef.apply = false;
                focusAndScrollRef.hashFragment = null;
                focusAndScrollRef.segmentPaths = [];
                (0, _disablesmoothscroll.disableSmoothScrollDuringRouteTransition)(
                  () => {
                    // In case of hash scroll, we only need to scroll the element into view
                    if (hashFragment) {
                      domNode.scrollIntoView();
                      return;
                    }
                    // Store the current viewport height because reading `clientHeight` causes a reflow,
                    // and it won't change during this function.
                    const htmlElement = document.documentElement;
                    const viewportHeight = htmlElement.clientHeight;
                    // If the element's top edge is already in the viewport, exit early.
                    if (topOfElementInViewport(domNode, viewportHeight)) {
                      return;
                    }
                    // Otherwise, try scrolling go the top of the document to be backward compatible with pages
                    // scrollIntoView() called on `<html/>` element scrolls horizontally on chrome and firefox (that shouldn't happen)
                    // We could use it to scroll horizontally following RTL but that also seems to be broken - it will always scroll left
                    // scrollLeft = 0 also seems to ignore RTL and manually checking for RTL is too much hassle so we will scroll just vertically
                    htmlElement.scrollTop = 0;
                    // Scroll to domNode if domNode is not in viewport when scrolled to top of document
                    if (!topOfElementInViewport(domNode, viewportHeight)) {
                      // Scroll into view doesn't scroll horizontally by default when not needed
                      domNode.scrollIntoView();
                    }
                  },
                  {
                    // We will force layout by querying domNode position
                    dontForceLayout: true,
                    onlyHashChange: focusAndScrollRef.onlyHashChange,
                  },
                );
                // Mutate after scrolling so that it can be read by `disableSmoothScrollDuringRouteTransition`
                focusAndScrollRef.onlyHashChange = false;
                // Set focus on the element
                domNode.focus();
              }
            }));
        }
      }
      function ScrollAndFocusHandler(param) {
        let { segmentPath, children } = param;
        const context = (0, _react.useContext)(
          _approutercontextsharedruntime.GlobalLayoutRouterContext,
        );
        if (!context) {
          throw Object.defineProperty(
            new Error("invariant global layout router not mounted"),
            "__NEXT_ERROR_CODE",
            {
              value: "E473",
              enumerable: false,
              configurable: true,
            },
          );
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(InnerScrollAndFocusHandler, {
          segmentPath: segmentPath,
          focusAndScrollRef: context.focusAndScrollRef,
          children: children,
        });
      }
      /**
       * InnerLayoutRouter handles rendering the provided segment based on the cache.
       */ function InnerLayoutRouter(param) {
        let { tree, segmentPath, cacheNode, url } = param;
        const context = (0, _react.useContext)(
          _approutercontextsharedruntime.GlobalLayoutRouterContext,
        );
        if (!context) {
          throw Object.defineProperty(
            new Error("invariant global layout router not mounted"),
            "__NEXT_ERROR_CODE",
            {
              value: "E473",
              enumerable: false,
              configurable: true,
            },
          );
        }
        const { tree: fullTree } = context;
        // `rsc` represents the renderable node for this segment.
        // If this segment has a `prefetchRsc`, it's the statically prefetched data.
        // We should use that on initial render instead of `rsc`. Then we'll switch
        // to `rsc` when the dynamic response streams in.
        //
        // If no prefetch data is available, then we go straight to rendering `rsc`.
        const resolvedPrefetchRsc =
          cacheNode.prefetchRsc !== null ? cacheNode.prefetchRsc : cacheNode.rsc;
        // We use `useDeferredValue` to handle switching between the prefetched and
        // final values. The second argument is returned on initial render, then it
        // re-renders with the first argument.
        const rsc = (0, _react.useDeferredValue)(cacheNode.rsc, resolvedPrefetchRsc);
        // `rsc` is either a React node or a promise for a React node, except we
        // special case `null` to represent that this segment's data is missing. If
        // it's a promise, we need to unwrap it so we can determine whether or not the
        // data is missing.
        const resolvedRsc =
          typeof rsc === "object" && rsc !== null && typeof rsc.then === "function"
            ? (0, _react.use)(rsc)
            : rsc;
        if (!resolvedRsc) {
          // The data for this segment is not available, and there's no pending
          // navigation that will be able to fulfill it. We need to fetch more from
          // the server and patch the cache.
          // Check if there's already a pending request.
          let lazyData = cacheNode.lazyData;
          if (lazyData === null) {
            /**
             * Router state with refetch marker added
             */ // TODO-APP: remove ''
            const refetchTree = walkAddRefetch(["", ...segmentPath], fullTree);
            const includeNextUrl = (0,
            _hasinterceptionrouteincurrenttree.hasInterceptionRouteInCurrentTree)(fullTree);
            const navigatedAt = Date.now();
            cacheNode.lazyData = lazyData = (0, _fetchserverresponse.fetchServerResponse)(
              new URL(url, location.origin),
              {
                flightRouterState: refetchTree,
                nextUrl: includeNextUrl ? context.nextUrl : null,
              },
            ).then((serverResponse) => {
              (0, _react.startTransition)(() => {
                (0, _useactionqueue.dispatchAppRouterAction)({
                  type: _routerreducertypes.ACTION_SERVER_PATCH,
                  previousTree: fullTree,
                  serverResponse,
                  navigatedAt,
                });
              });
              return serverResponse;
            });
            // Suspend while waiting for lazyData to resolve
            (0, _react.use)(lazyData);
          }
          // Suspend infinitely as `changeByServerResponse` will cause a different part of the tree to be rendered.
          // A falsey `resolvedRsc` indicates missing data -- we should not commit that branch, and we need to wait for the data to arrive.
          (0, _react.use)(_unresolvedthenable.unresolvedThenable);
        }
        // If we get to this point, then we know we have something we can render.
        const subtree = /*#__PURE__*/ (0, _jsxruntime.jsx)(
          _approutercontextsharedruntime.LayoutRouterContext.Provider,
          {
            value: {
              parentTree: tree,
              parentCacheNode: cacheNode,
              parentSegmentPath: segmentPath,
              // TODO-APP: overriding of url for parallel routes
              url: url,
            },
            children: resolvedRsc,
          },
        );
        // Ensure root layout is not wrapped in a div as the root layout renders `<html>`
        return subtree;
      }
      /**
       * Renders suspense boundary with the provided "loading" property as the fallback.
       * If no loading property is provided it renders the children without a suspense boundary.
       */ function LoadingBoundary(param) {
        let { loading, children } = param;
        // If loading is a promise, unwrap it. This happens in cases where we haven't
        // yet received the loading data from the server — which includes whether or
        // not this layout has a loading component at all.
        //
        // It's OK to suspend here instead of inside the fallback because this
        // promise will resolve simultaneously with the data for the segment itself.
        // So it will never suspend for longer than it would have if we didn't use
        // a Suspense fallback at all.
        let loadingModuleData;
        if (typeof loading === "object" && loading !== null && typeof loading.then === "function") {
          const promiseForLoading = loading;
          loadingModuleData = (0, _react.use)(promiseForLoading);
        } else {
          loadingModuleData = loading;
        }
        if (loadingModuleData) {
          const loadingRsc = loadingModuleData[0];
          const loadingStyles = loadingModuleData[1];
          const loadingScripts = loadingModuleData[2];
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(_react.Suspense, {
            fallback: /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
              children: [loadingStyles, loadingScripts, loadingRsc],
            }),
            children: children,
          });
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
          children: children,
        });
      }
      function OuterLayoutRouter(param) {
        let {
          parallelRouterKey,
          error,
          errorStyles,
          errorScripts,
          templateStyles,
          templateScripts,
          template,
          notFound,
          forbidden,
          unauthorized,
          segmentViewBoundaries,
        } = param;
        const context = (0, _react.useContext)(_approutercontextsharedruntime.LayoutRouterContext);
        if (!context) {
          throw Object.defineProperty(
            new Error("invariant expected layout router to be mounted"),
            "__NEXT_ERROR_CODE",
            {
              value: "E56",
              enumerable: false,
              configurable: true,
            },
          );
        }
        const { parentTree, parentCacheNode, parentSegmentPath, url } = context;
        // Get the CacheNode for this segment by reading it from the parent segment's
        // child map.
        const parentParallelRoutes = parentCacheNode.parallelRoutes;
        let segmentMap = parentParallelRoutes.get(parallelRouterKey);
        // If the parallel router cache node does not exist yet, create it.
        // This writes to the cache when there is no item in the cache yet. It never *overwrites* existing cache items which is why it's safe in concurrent mode.
        if (!segmentMap) {
          segmentMap = new Map();
          parentParallelRoutes.set(parallelRouterKey, segmentMap);
        }
        const parentTreeSegment = parentTree[0];
        const segmentPath =
          parentSegmentPath === null // the code. We should clean this up.
            ? [parallelRouterKey]
            : parentSegmentPath.concat([parentTreeSegment, parallelRouterKey]);
        // The "state" key of a segment is the one passed to React — it represents the
        // identity of the UI tree. Whenever the state key changes, the tree is
        // recreated and the state is reset. In the App Router model, search params do
        // not cause state to be lost, so two segments with the same segment path but
        // different search params should have the same state key.
        //
        // The "cache" key of a segment, however, *does* include the search params, if
        // it's possible that the segment accessed the search params on the server.
        // (This only applies to page segments; layout segments cannot access search
        // params on the server.)
        const activeTree = parentTree[1][parallelRouterKey];
        const activeSegment = activeTree[0];
        const activeStateKey = (0, _createroutercachekey.createRouterCacheKey)(activeSegment, true); // no search params
        // At each level of the route tree, not only do we render the currently
        // active segment — we also render the last N segments that were active at
        // this level inside a hidden <Activity> boundary, to preserve their state
        // if or when the user navigates to them again.
        //
        // bfcacheEntry is a linked list of FlightRouterStates.
        let bfcacheEntry = (0, _bfcache.useRouterBFCache)(activeTree, activeStateKey);
        let children = [];
        do {
          const tree = bfcacheEntry.tree;
          const stateKey = bfcacheEntry.stateKey;
          const segment = tree[0];
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segment);
          // Read segment path from the parallel router cache node.
          let cacheNode = segmentMap.get(cacheKey);
          if (cacheNode === undefined) {
            // When data is not available during rendering client-side we need to fetch
            // it from the server.
            const newLazyCacheNode = {
              lazyData: null,
              rsc: null,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading: null,
              navigatedAt: -1,
            };
            // Flight data fetch kicked off during render and put into the cache.
            cacheNode = newLazyCacheNode;
            segmentMap.set(cacheKey, newLazyCacheNode);
          }
          /*
    - Error boundary
      - Only renders error boundary if error component is provided.
      - Rendered for each segment to ensure they have their own error state.
      - When gracefully degrade for bots, skip rendering error boundary.
    - Loading boundary
      - Only renders suspense boundary if loading components is provided.
      - Rendered for each segment to ensure they have their own loading state.
      - Passed to the router during rendering to ensure it can be immediately rendered when suspending on a Flight fetch.
  */ let segmentBoundaryTriggerNode = null;
          let segmentViewStateNode = null;
          if (false) {
          }
          // TODO: The loading module data for a segment is stored on the parent, then
          // applied to each of that parent segment's parallel route slots. In the
          // simple case where there's only one parallel route (the `children` slot),
          // this is no different from if the loading module data where stored on the
          // child directly. But I'm not sure this actually makes sense when there are
          // multiple parallel routes. It's not a huge issue because you always have
          // the option to define a narrower loading boundary for a particular slot. But
          // this sort of smells like an implementation accident to me.
          const loadingModuleData = parentCacheNode.loading;
          let child = /*#__PURE__*/ (0, _jsxruntime.jsxs)(
            _approutercontextsharedruntime.TemplateContext.Provider,
            {
              value: /*#__PURE__*/ (0, _jsxruntime.jsxs)(ScrollAndFocusHandler, {
                segmentPath: segmentPath,
                children: [
                  /*#__PURE__*/ (0, _jsxruntime.jsx)(_errorboundary.ErrorBoundary, {
                    errorComponent: error,
                    errorStyles: errorStyles,
                    errorScripts: errorScripts,
                    children: /*#__PURE__*/ (0, _jsxruntime.jsx)(LoadingBoundary, {
                      loading: loadingModuleData,
                      children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                        _errorboundary1.HTTPAccessFallbackBoundary,
                        {
                          notFound: notFound,
                          forbidden: forbidden,
                          unauthorized: unauthorized,
                          children: /*#__PURE__*/ (0, _jsxruntime.jsxs)(
                            _redirectboundary.RedirectBoundary,
                            {
                              children: [
                                /*#__PURE__*/ (0, _jsxruntime.jsx)(InnerLayoutRouter, {
                                  url: url,
                                  tree: tree,
                                  cacheNode: cacheNode,
                                  segmentPath: segmentPath,
                                }),
                                segmentBoundaryTriggerNode,
                              ],
                            },
                          ),
                        },
                      ),
                    }),
                  }),
                  segmentViewStateNode,
                ],
              }),
              children: [templateStyles, templateScripts, template],
            },
            stateKey,
          );
          if (false) {
          }
          if (false) {
          }
          children.push(child);
          bfcacheEntry = bfcacheEntry.next;
        } while (bfcacheEntry !== null);
        return children;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=layout-router.js.map

      /***/
    },

    /***/ 1387: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "reportGlobalError", {
        enumerable: true,
        get: function () {
          return reportGlobalError;
        },
      });
      const reportGlobalError =
        typeof reportError === "function"
          ? reportError
          : (error) => {
              // TODO: Dispatch error event
              globalThis.console.error(error);
            };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=report-global-error.js.map

      /***/
    },

    /***/ 1393: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "fillLazyItemsTillLeafWithHead", {
        enumerable: true,
        get: function () {
          return fillLazyItemsTillLeafWithHead;
        },
      });
      const _createroutercachekey = __webpack_require__(6066);
      const _routerreducertypes = __webpack_require__(9131);
      function fillLazyItemsTillLeafWithHead(
        navigatedAt,
        newCache,
        existingCache,
        routerState,
        cacheNodeSeedData,
        head,
        prefetchEntry,
      ) {
        const isLastSegment = Object.keys(routerState[1]).length === 0;
        if (isLastSegment) {
          newCache.head = head;
          return;
        }
        // Remove segment that we got data for so that it is filled in during rendering of rsc.
        for (const key in routerState[1]) {
          const parallelRouteState = routerState[1][key];
          const segmentForParallelRoute = parallelRouteState[0];
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segmentForParallelRoute);
          // TODO: We should traverse the cacheNodeSeedData tree instead of the router
          // state tree. Ideally, they would always be the same shape, but because of
          // the loading.js pattern, cacheNodeSeedData sometimes only represents a
          // partial tree. That's why this node is sometimes null. Once PPR lands,
          // loading.js will no longer have special behavior and we can traverse the
          // data tree instead.
          //
          // We should also consider merging the router state tree and the data tree
          // in the response format, so that we don't have to send the keys twice.
          // Then the client can convert them into separate representations.
          const parallelSeedData =
            cacheNodeSeedData !== null && cacheNodeSeedData[2][key] !== undefined
              ? cacheNodeSeedData[2][key]
              : null;
          if (existingCache) {
            const existingParallelRoutesCacheNode = existingCache.parallelRoutes.get(key);
            if (existingParallelRoutesCacheNode) {
              const hasReusablePrefetch =
                (prefetchEntry == null ? void 0 : prefetchEntry.kind) === "auto" &&
                prefetchEntry.status === _routerreducertypes.PrefetchCacheEntryStatus.reusable;
              let parallelRouteCacheNode = new Map(existingParallelRoutesCacheNode);
              const existingCacheNode = parallelRouteCacheNode.get(cacheKey);
              let newCacheNode;
              if (parallelSeedData !== null) {
                // New data was sent from the server.
                const seedNode = parallelSeedData[1];
                const loading = parallelSeedData[3];
                newCacheNode = {
                  lazyData: null,
                  rsc: seedNode,
                  // This is a PPR-only field. When PPR is enabled, we shouldn't hit
                  // this path during a navigation, but until PPR is fully implemented
                  // yet it's possible the existing node does have a non-null
                  // `prefetchRsc`. As an incremental step, we'll just de-opt to the
                  // old behavior — no PPR value.
                  prefetchRsc: null,
                  head: null,
                  prefetchHead: null,
                  loading,
                  parallelRoutes: new Map(
                    existingCacheNode == null ? void 0 : existingCacheNode.parallelRoutes,
                  ),
                  navigatedAt,
                };
              } else if (hasReusablePrefetch && existingCacheNode) {
                // No new data was sent from the server, but the existing cache node
                // was prefetched, so we should reuse that.
                newCacheNode = {
                  lazyData: existingCacheNode.lazyData,
                  rsc: existingCacheNode.rsc,
                  // This is a PPR-only field. Unlike the previous branch, since we're
                  // just cloning the existing cache node, we might as well keep the
                  // PPR value, if it exists.
                  prefetchRsc: existingCacheNode.prefetchRsc,
                  head: existingCacheNode.head,
                  prefetchHead: existingCacheNode.prefetchHead,
                  parallelRoutes: new Map(existingCacheNode.parallelRoutes),
                  loading: existingCacheNode.loading,
                };
              } else {
                // No data available for this node. This will trigger a lazy fetch
                // during render.
                newCacheNode = {
                  lazyData: null,
                  rsc: null,
                  prefetchRsc: null,
                  head: null,
                  prefetchHead: null,
                  parallelRoutes: new Map(
                    existingCacheNode == null ? void 0 : existingCacheNode.parallelRoutes,
                  ),
                  loading: null,
                  navigatedAt,
                };
              }
              // Overrides the cache key with the new cache node.
              parallelRouteCacheNode.set(cacheKey, newCacheNode);
              // Traverse deeper to apply the head / fill lazy items till the head.
              fillLazyItemsTillLeafWithHead(
                navigatedAt,
                newCacheNode,
                existingCacheNode,
                parallelRouteState,
                parallelSeedData ? parallelSeedData : null,
                head,
                prefetchEntry,
              );
              newCache.parallelRoutes.set(key, parallelRouteCacheNode);
              continue;
            }
          }
          let newCacheNode;
          if (parallelSeedData !== null) {
            // New data was sent from the server.
            const seedNode = parallelSeedData[1];
            const loading = parallelSeedData[3];
            newCacheNode = {
              lazyData: null,
              rsc: seedNode,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading,
              navigatedAt,
            };
          } else {
            // No data available for this node. This will trigger a lazy fetch
            // during render.
            newCacheNode = {
              lazyData: null,
              rsc: null,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading: null,
              navigatedAt,
            };
          }
          const existingParallelRoutes = newCache.parallelRoutes.get(key);
          if (existingParallelRoutes) {
            existingParallelRoutes.set(cacheKey, newCacheNode);
          } else {
            newCache.parallelRoutes.set(key, new Map([[cacheKey, newCacheNode]]));
          }
          fillLazyItemsTillLeafWithHead(
            navigatedAt,
            newCacheNode,
            undefined,
            parallelRouteState,
            parallelSeedData,
            head,
            prefetchEntry,
          );
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=fill-lazy-items-till-leaf-with-head.js.map

      /***/
    },

    /***/ 1437: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "applyFlightData", {
        enumerable: true,
        get: function () {
          return applyFlightData;
        },
      });
      const _filllazyitemstillleafwithhead = __webpack_require__(1393);
      const _fillcachewithnewsubtreedata = __webpack_require__(2611);
      function applyFlightData(navigatedAt, existingCache, cache, flightData, prefetchEntry) {
        // The one before last item is the router state tree patch
        const { tree: treePatch, seedData, head, isRootRender } = flightData;
        // Handles case where prefetch only returns the router tree patch without rendered components.
        if (seedData === null) {
          return false;
        }
        if (isRootRender) {
          const rsc = seedData[1];
          const loading = seedData[3];
          cache.loading = loading;
          cache.rsc = rsc;
          // This is a PPR-only field. When PPR is enabled, we shouldn't hit
          // this path during a navigation, but until PPR is fully implemented
          // yet it's possible the existing node does have a non-null
          // `prefetchRsc`. As an incremental step, we'll just de-opt to the
          // old behavior — no PPR value.
          cache.prefetchRsc = null;
          (0, _filllazyitemstillleafwithhead.fillLazyItemsTillLeafWithHead)(
            navigatedAt,
            cache,
            existingCache,
            treePatch,
            seedData,
            head,
            prefetchEntry,
          );
        } else {
          // Copy rsc for the root node of the cache.
          cache.rsc = existingCache.rsc;
          // This is a PPR-only field. Unlike the previous branch, since we're
          // just cloning the existing cache node, we might as well keep the
          // PPR value, if it exists.
          cache.prefetchRsc = existingCache.prefetchRsc;
          cache.parallelRoutes = new Map(existingCache.parallelRoutes);
          cache.loading = existingCache.loading;
          // Create a copy of the existing cache with the rsc applied.
          (0, _fillcachewithnewsubtreedata.fillCacheWithNewSubTreeData)(
            navigatedAt,
            cache,
            existingCache,
            flightData,
            prefetchEntry,
          );
        }
        return true;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=apply-flight-data.js.map

      /***/
    },

    /***/ 1499: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "refreshReducer", {
        enumerable: true,
        get: function () {
          return refreshReducer;
        },
      });
      const _fetchserverresponse = __webpack_require__(2682);
      const _createhreffromurl = __webpack_require__(8150);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _navigatereducer = __webpack_require__(5005);
      const _handlemutable = __webpack_require__(9466);
      const _filllazyitemstillleafwithhead = __webpack_require__(1393);
      const _approuter = __webpack_require__(9701);
      const _handlesegmentmismatch = __webpack_require__(5912);
      const _hasinterceptionrouteincurrenttree = __webpack_require__(3495);
      const _refetchinactiveparallelsegments = __webpack_require__(1241);
      const _segmentcache = __webpack_require__(5620);
      function refreshReducer(state, action) {
        const { origin } = action;
        const mutable = {};
        const href = state.canonicalUrl;
        let currentTree = state.tree;
        mutable.preserveCustomHistoryState = false;
        const cache = (0, _approuter.createEmptyCacheNode)();
        // If the current tree was intercepted, the nextUrl should be included in the request.
        // This is to ensure that the refresh request doesn't get intercepted, accidentally triggering the interception route.
        const includeNextUrl = (0,
        _hasinterceptionrouteincurrenttree.hasInterceptionRouteInCurrentTree)(state.tree);
        // TODO-APP: verify that `href` is not an external url.
        // Fetch data from the root of the tree.
        cache.lazyData = (0, _fetchserverresponse.fetchServerResponse)(new URL(href, origin), {
          flightRouterState: [currentTree[0], currentTree[1], currentTree[2], "refetch"],
          nextUrl: includeNextUrl ? state.nextUrl : null,
        });
        const navigatedAt = Date.now();
        return cache.lazyData.then(
          async (param) => {
            let { flightData, canonicalUrl: canonicalUrlOverride } = param;
            // Handle case when navigating to page in `pages` from `app`
            if (typeof flightData === "string") {
              return (0, _navigatereducer.handleExternalUrl)(
                state,
                mutable,
                flightData,
                state.pushRef.pendingPush,
              );
            }
            // Remove cache.lazyData as it has been resolved at this point.
            cache.lazyData = null;
            for (const normalizedFlightData of flightData) {
              const {
                tree: treePatch,
                seedData: cacheNodeSeedData,
                head,
                isRootRender,
              } = normalizedFlightData;
              if (!isRootRender) {
                // TODO-APP: handle this case better
                console.log("REFRESH FAILED");
                return state;
              }
              const newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
                [""],
                currentTree,
                treePatch,
                state.canonicalUrl,
              );
              if (newTree === null) {
                return (0, _handlesegmentmismatch.handleSegmentMismatch)(state, action, treePatch);
              }
              if (
                (0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(currentTree, newTree)
              ) {
                return (0, _navigatereducer.handleExternalUrl)(
                  state,
                  mutable,
                  href,
                  state.pushRef.pendingPush,
                );
              }
              const canonicalUrlOverrideHref = canonicalUrlOverride
                ? (0, _createhreffromurl.createHrefFromUrl)(canonicalUrlOverride)
                : undefined;
              if (canonicalUrlOverride) {
                mutable.canonicalUrl = canonicalUrlOverrideHref;
              }
              // Handles case where prefetch only returns the router tree patch without rendered components.
              if (cacheNodeSeedData !== null) {
                const rsc = cacheNodeSeedData[1];
                const loading = cacheNodeSeedData[3];
                cache.rsc = rsc;
                cache.prefetchRsc = null;
                cache.loading = loading;
                (0, _filllazyitemstillleafwithhead.fillLazyItemsTillLeafWithHead)(
                  navigatedAt,
                  cache,
                  undefined,
                  treePatch,
                  cacheNodeSeedData,
                  head,
                  undefined,
                );
                if (false) {
                } else {
                  mutable.prefetchCache = new Map();
                }
              }
              await (0, _refetchinactiveparallelsegments.refreshInactiveParallelSegments)({
                navigatedAt,
                state,
                updatedTree: newTree,
                updatedCache: cache,
                includeNextUrl,
                canonicalUrl: mutable.canonicalUrl || state.canonicalUrl,
              });
              mutable.cache = cache;
              mutable.patchedTree = newTree;
              currentTree = newTree;
            }
            return (0, _handlemutable.handleMutable)(state, mutable);
          },
          () => state,
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=refresh-reducer.js.map

      /***/
    },

    /***/ 1500: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "assignLocation", {
        enumerable: true,
        get: function () {
          return assignLocation;
        },
      });
      const _addbasepath = __webpack_require__(9478);
      function assignLocation(location, url) {
        if (location.startsWith(".")) {
          const urlBase = url.origin + url.pathname;
          return new URL(
            // new URL('./relative', 'https://example.com/subdir').href -> 'https://example.com/relative'
            // new URL('./relative', 'https://example.com/subdir/').href -> 'https://example.com/subdir/relative'
            (urlBase.endsWith("/") ? urlBase : urlBase + "/") + location,
          );
        }
        return new URL((0, _addbasepath.addBasePath)(location), url.href);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=assign-location.js.map

      /***/
    },

    /***/ 1514: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        getObjectClassLabel: function () {
          return getObjectClassLabel;
        },
        isPlainObject: function () {
          return isPlainObject;
        },
      });
      function getObjectClassLabel(value) {
        return Object.prototype.toString.call(value);
      }
      function isPlainObject(value) {
        if (getObjectClassLabel(value) !== "[object Object]") {
          return false;
        }
        const prototype = Object.getPrototypeOf(value);
        /**
         * this used to be previously:
         *
         * `return prototype === null || prototype === Object.prototype`
         *
         * but Edge Runtime expose Object from vm, being that kind of type-checking wrongly fail.
         *
         * It was changed to the current implementation since it's resilient to serialization.
         */ return prototype === null || prototype.hasOwnProperty("isPrototypeOf");
      } //# sourceMappingURL=is-plain-object.js.map

      /***/
    },

    /***/ 1582: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "isNextRouterError", {
        enumerable: true,
        get: function () {
          return isNextRouterError;
        },
      });
      const _httpaccessfallback = __webpack_require__(9028);
      const _redirecterror = __webpack_require__(9721);
      function isNextRouterError(error) {
        return (
          (0, _redirecterror.isRedirectError)(error) ||
          (0, _httpaccessfallback.isHTTPAccessFallbackError)(error)
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=is-next-router-error.js.map

      /***/
    },

    /***/ 1583: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        RedirectBoundary: function () {
          return RedirectBoundary;
        },
        RedirectErrorBoundary: function () {
          return RedirectErrorBoundary;
        },
      });
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _navigation = __webpack_require__(8680);
      const _redirect = __webpack_require__(426);
      const _redirecterror = __webpack_require__(9721);
      function HandleRedirect(param) {
        let { redirect, reset, redirectType } = param;
        const router = (0, _navigation.useRouter)();
        (0, _react.useEffect)(() => {
          _react.default.startTransition(() => {
            if (redirectType === _redirecterror.RedirectType.push) {
              router.push(redirect, {});
            } else {
              router.replace(redirect, {});
            }
            reset();
          });
        }, [redirect, redirectType, reset, router]);
        return null;
      }
      class RedirectErrorBoundary extends _react.default.Component {
        static getDerivedStateFromError(error) {
          if ((0, _redirecterror.isRedirectError)(error)) {
            const url = (0, _redirect.getURLFromRedirectError)(error);
            const redirectType = (0, _redirect.getRedirectTypeFromError)(error);
            return {
              redirect: url,
              redirectType,
            };
          }
          // Re-throw if error is not for redirect
          throw error;
        }
        // Explicit type is needed to avoid the generated `.d.ts` having a wide return type that could be specific to the `@types/react` version.
        render() {
          const { redirect, redirectType } = this.state;
          if (redirect !== null && redirectType !== null) {
            return /*#__PURE__*/ (0, _jsxruntime.jsx)(HandleRedirect, {
              redirect: redirect,
              redirectType: redirectType,
              reset: () =>
                this.setState({
                  redirect: null,
                }),
            });
          }
          return this.props.children;
        }
        constructor(props) {
          super(props);
          this.state = {
            redirect: null,
            redirectType: null,
          };
        }
      }
      function RedirectBoundary(param) {
        let { children } = param;
        const router = (0, _navigation.useRouter)();
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(RedirectErrorBoundary, {
          router: router,
          children: children,
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=redirect-boundary.js.map

      /***/
    },

    /***/ 1601: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "getSegmentValue", {
        enumerable: true,
        get: function () {
          return getSegmentValue;
        },
      });
      function getSegmentValue(segment) {
        return Array.isArray(segment) ? segment[1] : segment;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=get-segment-value.js.map

      /***/
    },

    /***/ 1738: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "AsyncMetadataOutlet", {
        enumerable: true,
        get: function () {
          return AsyncMetadataOutlet;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const _react = __webpack_require__(5127);
      function MetadataOutlet(param) {
        let { promise } = param;
        const { error, digest } = (0, _react.use)(promise);
        if (error) {
          if (digest) {
            // The error will lose its original digest after passing from server layer to client layer；
            // We recover the digest property here to override the React created one if original digest exists.
            error.digest = digest;
          }
          throw error;
        }
        return null;
      }
      function AsyncMetadataOutlet(param) {
        let { promise } = param;
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_react.Suspense, {
          fallback: null,
          children: /*#__PURE__*/ (0, _jsxruntime.jsx)(MetadataOutlet, {
            promise: promise,
          }),
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=async-metadata.js.map

      /***/
    },

    /***/ 1874: /***/ (
      __unused_webpack___webpack_module__,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      "use strict";
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ _: () => /* binding */ _class_private_field_loose_base,
        /* harmony export */
      });
      function _class_private_field_loose_base(receiver, privateKey) {
        if (!Object.prototype.hasOwnProperty.call(receiver, privateKey)) {
          throw new TypeError("attempted to use private field on non-instance");
        }

        return receiver;
      }

      /***/
    },

    /***/ 1915: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        MetadataBoundary: function () {
          return MetadataBoundary;
        },
        OutletBoundary: function () {
          return OutletBoundary;
        },
        RootLayoutBoundary: function () {
          return RootLayoutBoundary;
        },
        ViewportBoundary: function () {
          return ViewportBoundary;
        },
      });
      const _boundaryconstants = __webpack_require__(7708);
      // We use a namespace object to allow us to recover the name of the function
      // at runtime even when production bundling/minification is used.
      const NameSpace = {
        [_boundaryconstants.METADATA_BOUNDARY_NAME]: function ({ children }) {
          return children;
        },
        [_boundaryconstants.VIEWPORT_BOUNDARY_NAME]: function ({ children }) {
          return children;
        },
        [_boundaryconstants.OUTLET_BOUNDARY_NAME]: function ({ children }) {
          return children;
        },
        [_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME]: function ({ children }) {
          return children;
        },
      };
      const MetadataBoundary = // so it retains the name inferred from the namespace object
        NameSpace[_boundaryconstants.METADATA_BOUNDARY_NAME.slice(0)];
      const ViewportBoundary = // so it retains the name inferred from the namespace object
        NameSpace[_boundaryconstants.VIEWPORT_BOUNDARY_NAME.slice(0)];
      const OutletBoundary = // so it retains the name inferred from the namespace object
        NameSpace[_boundaryconstants.OUTLET_BOUNDARY_NAME.slice(0)];
      const RootLayoutBoundary = // so it retains the name inferred from the namespace object
        NameSpace[_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]; //# sourceMappingURL=boundary-components.js.map

      /***/
    },

    /***/ 1991: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        DYNAMIC_STALETIME_MS: function () {
          return DYNAMIC_STALETIME_MS;
        },
        STATIC_STALETIME_MS: function () {
          return STATIC_STALETIME_MS;
        },
        createSeededPrefetchCacheEntry: function () {
          return createSeededPrefetchCacheEntry;
        },
        getOrCreatePrefetchCacheEntry: function () {
          return getOrCreatePrefetchCacheEntry;
        },
        prunePrefetchCache: function () {
          return prunePrefetchCache;
        },
      });
      const _fetchserverresponse = __webpack_require__(2682);
      const _routerreducertypes = __webpack_require__(9131);
      const _prefetchreducer = __webpack_require__(3065);
      const INTERCEPTION_CACHE_KEY_MARKER = "%";
      /**
       * Creates a cache key for the router prefetch cache
       *
       * @param url - The URL being navigated to
       * @param nextUrl - an internal URL, primarily used for handling rewrites. Defaults to '/'.
       * @return The generated prefetch cache key.
       */ function createPrefetchCacheKeyImpl(url, includeSearchParams, prefix) {
        // Initially we only use the pathname as the cache key. We don't want to include
        // search params so that multiple URLs with the same search parameter can re-use
        // loading states.
        let pathnameFromUrl = url.pathname;
        // RSC responses can differ based on search params, specifically in the case where we aren't
        // returning a partial response (ie with `PrefetchKind.AUTO`).
        // In the auto case, since loading.js & layout.js won't have access to search params,
        // we can safely re-use that cache entry. But for full prefetches, we should not
        // re-use the cache entry as the response may differ.
        if (includeSearchParams) {
          // if we have a full prefetch, we can include the search param in the key,
          // as we'll be getting back a full response. The server might have read the search
          // params when generating the full response.
          pathnameFromUrl += url.search;
        }
        if (prefix) {
          return "" + prefix + INTERCEPTION_CACHE_KEY_MARKER + pathnameFromUrl;
        }
        return pathnameFromUrl;
      }
      function createPrefetchCacheKey(url, kind, nextUrl) {
        return createPrefetchCacheKeyImpl(
          url,
          kind === _routerreducertypes.PrefetchKind.FULL,
          nextUrl,
        );
      }
      function getExistingCacheEntry(url, kind, nextUrl, prefetchCache, allowAliasing) {
        if (kind === void 0) kind = _routerreducertypes.PrefetchKind.TEMPORARY;
        // We first check if there's a more specific interception route prefetch entry
        // This is because when we detect a prefetch that corresponds with an interception route, we prefix it with nextUrl (see `createPrefetchCacheKey`)
        // to avoid conflicts with other pages that may have the same URL but render different things depending on the `Next-URL` header.
        for (const maybeNextUrl of [nextUrl, null]) {
          const cacheKeyWithParams = createPrefetchCacheKeyImpl(url, true, maybeNextUrl);
          const cacheKeyWithoutParams = createPrefetchCacheKeyImpl(url, false, maybeNextUrl);
          // First, we check if we have a cache entry that exactly matches the URL
          const cacheKeyToUse = url.search ? cacheKeyWithParams : cacheKeyWithoutParams;
          const existingEntry = prefetchCache.get(cacheKeyToUse);
          if (existingEntry && allowAliasing) {
            // We know we're returning an aliased entry when the pathname matches but the search params don't,
            const isAliased =
              existingEntry.url.pathname === url.pathname &&
              existingEntry.url.search !== url.search;
            if (isAliased) {
              return {
                ...existingEntry,
                aliased: true,
              };
            }
            return existingEntry;
          }
          // If the request contains search params, and we're not doing a full prefetch, we can return the
          // param-less entry if it exists.
          // This is technically covered by the check at the bottom of this function, which iterates over cache entries,
          // but lets us arrive there quicker in the param-full case.
          const entryWithoutParams = prefetchCache.get(cacheKeyWithoutParams);
          if (
            true &&
            allowAliasing &&
            url.search &&
            kind !== _routerreducertypes.PrefetchKind.FULL &&
            entryWithoutParams && // We shouldn't return the aliased entry if it was relocated to a new cache key.
            // Since it's rewritten, it could respond with a completely different loading state.
            !entryWithoutParams.key.includes(INTERCEPTION_CACHE_KEY_MARKER)
          ) {
            return {
              ...entryWithoutParams,
              aliased: true,
            };
          }
        }
        // If we've gotten to this point, we didn't find a specific cache entry that matched
        // the request URL.
        // We attempt a partial match by checking if there's a cache entry with the same pathname.
        // Regardless of what we find, since it doesn't correspond with the requested URL, we'll mark it "aliased".
        // This will signal to the router that it should only apply the loading state on the prefetched data.
        if (true && kind !== _routerreducertypes.PrefetchKind.FULL && allowAliasing) {
          for (const cacheEntry of prefetchCache.values()) {
            if (
              cacheEntry.url.pathname === url.pathname && // We shouldn't return the aliased entry if it was relocated to a new cache key.
              // Since it's rewritten, it could respond with a completely different loading state.
              !cacheEntry.key.includes(INTERCEPTION_CACHE_KEY_MARKER)
            ) {
              return {
                ...cacheEntry,
                aliased: true,
              };
            }
          }
        }
        return undefined;
      }
      function getOrCreatePrefetchCacheEntry(param) {
        let { url, nextUrl, tree, prefetchCache, kind, allowAliasing = true } = param;
        const existingCacheEntry = getExistingCacheEntry(
          url,
          kind,
          nextUrl,
          prefetchCache,
          allowAliasing,
        );
        if (existingCacheEntry) {
          // Grab the latest status of the cache entry and update it
          existingCacheEntry.status = getPrefetchEntryCacheStatus(existingCacheEntry);
          // when `kind` is provided, an explicit prefetch was requested.
          // if the requested prefetch is "full" and the current cache entry wasn't, we want to re-prefetch with the new intent
          const switchedToFullPrefetch =
            existingCacheEntry.kind !== _routerreducertypes.PrefetchKind.FULL &&
            kind === _routerreducertypes.PrefetchKind.FULL;
          if (switchedToFullPrefetch) {
            // If we switched to a full prefetch, validate that the existing cache entry contained partial data.
            // It's possible that the cache entry was seeded with full data but has a cache type of "auto" (ie when cache entries
            // are seeded but without a prefetch intent)
            existingCacheEntry.data.then((prefetchResponse) => {
              const isFullPrefetch =
                Array.isArray(prefetchResponse.flightData) &&
                prefetchResponse.flightData.some((flightData) => {
                  // If we started rendering from the root and we returned RSC data (seedData), we already had a full prefetch.
                  return flightData.isRootRender && flightData.seedData !== null;
                });
              if (!isFullPrefetch) {
                return createLazyPrefetchEntry({
                  tree,
                  url,
                  nextUrl,
                  prefetchCache,
                  // If we didn't get an explicit prefetch kind, we want to set a temporary kind
                  // rather than assuming the same intent as the previous entry, to be consistent with how we
                  // lazily create prefetch entries when intent is left unspecified.
                  kind: kind != null ? kind : _routerreducertypes.PrefetchKind.TEMPORARY,
                });
              }
            });
          }
          // If the existing cache entry was marked as temporary, it means it was lazily created when attempting to get an entry,
          // where we didn't have the prefetch intent. Now that we have the intent (in `kind`), we want to update the entry to the more accurate kind.
          if (kind && existingCacheEntry.kind === _routerreducertypes.PrefetchKind.TEMPORARY) {
            existingCacheEntry.kind = kind;
          }
          // We've determined that the existing entry we found is still valid, so we return it.
          return existingCacheEntry;
        }
        // If we didn't return an entry, create a new one.
        return createLazyPrefetchEntry({
          tree,
          url,
          nextUrl,
          prefetchCache,
          kind: kind || _routerreducertypes.PrefetchKind.TEMPORARY,
        });
      }
      /*
       * Used to take an existing cache entry and prefix it with the nextUrl, if it exists.
       * This ensures that we don't have conflicting cache entries for the same URL (as is the case with route interception).
       */ function prefixExistingPrefetchCacheEntry(param) {
        let { url, nextUrl, prefetchCache, existingCacheKey } = param;
        const existingCacheEntry = prefetchCache.get(existingCacheKey);
        if (!existingCacheEntry) {
          // no-op -- there wasn't an entry to move
          return;
        }
        const newCacheKey = createPrefetchCacheKey(url, existingCacheEntry.kind, nextUrl);
        prefetchCache.set(newCacheKey, {
          ...existingCacheEntry,
          key: newCacheKey,
        });
        prefetchCache.delete(existingCacheKey);
        return newCacheKey;
      }
      function createSeededPrefetchCacheEntry(param) {
        let { nextUrl, tree, prefetchCache, url, data, kind } = param;
        // The initial cache entry technically includes full data, but it isn't explicitly prefetched -- we just seed the
        // prefetch cache so that we can skip an extra prefetch request later, since we already have the data.
        // if the prefetch corresponds with an interception route, we use the nextUrl to prefix the cache key
        const prefetchCacheKey = data.couldBeIntercepted
          ? createPrefetchCacheKey(url, kind, nextUrl)
          : createPrefetchCacheKey(url, kind);
        const prefetchEntry = {
          treeAtTimeOfPrefetch: tree,
          data: Promise.resolve(data),
          kind,
          prefetchTime: Date.now(),
          lastUsedTime: Date.now(),
          staleTime: data.staleTime,
          key: prefetchCacheKey,
          status: _routerreducertypes.PrefetchCacheEntryStatus.fresh,
          url,
        };
        prefetchCache.set(prefetchCacheKey, prefetchEntry);
        return prefetchEntry;
      }
      /**
       * Creates a prefetch entry entry and enqueues a fetch request to retrieve the data.
       */ function createLazyPrefetchEntry(param) {
        let { url, kind, tree, nextUrl, prefetchCache } = param;
        const prefetchCacheKey = createPrefetchCacheKey(url, kind);
        // initiates the fetch request for the prefetch and attaches a listener
        // to the promise to update the prefetch cache entry when the promise resolves (if necessary)
        const data = _prefetchreducer.prefetchQueue.enqueue(() =>
          (0, _fetchserverresponse.fetchServerResponse)(url, {
            flightRouterState: tree,
            nextUrl,
            prefetchKind: kind,
          }).then((prefetchResponse) => {
            // TODO: `fetchServerResponse` should be more tighly coupled to these prefetch cache operations
            // to avoid drift between this cache key prefixing logic
            // (which is currently directly influenced by the server response)
            let newCacheKey;
            if (prefetchResponse.couldBeIntercepted) {
              // Determine if we need to prefix the cache key with the nextUrl
              newCacheKey = prefixExistingPrefetchCacheEntry({
                url,
                existingCacheKey: prefetchCacheKey,
                nextUrl,
                prefetchCache,
              });
            }
            // If the prefetch was a cache hit, we want to update the existing cache entry to reflect that it was a full prefetch.
            // This is because we know that a static response will contain the full RSC payload, and can be updated to respect the `static`
            // staleTime.
            if (prefetchResponse.prerendered) {
              const existingCacheEntry = prefetchCache.get(
                newCacheKey != null ? newCacheKey : prefetchCacheKey,
              );
              if (existingCacheEntry) {
                existingCacheEntry.kind = _routerreducertypes.PrefetchKind.FULL;
                if (prefetchResponse.staleTime !== -1) {
                  // This is the stale time that was collected by the server during
                  // static generation. Use this in place of the default stale time.
                  existingCacheEntry.staleTime = prefetchResponse.staleTime;
                }
              }
            }
            return prefetchResponse;
          }),
        );
        const prefetchEntry = {
          treeAtTimeOfPrefetch: tree,
          data,
          kind,
          prefetchTime: Date.now(),
          lastUsedTime: null,
          staleTime: -1,
          key: prefetchCacheKey,
          status: _routerreducertypes.PrefetchCacheEntryStatus.fresh,
          url,
        };
        prefetchCache.set(prefetchCacheKey, prefetchEntry);
        return prefetchEntry;
      }
      function prunePrefetchCache(prefetchCache) {
        for (const [href, prefetchCacheEntry] of prefetchCache) {
          if (
            getPrefetchEntryCacheStatus(prefetchCacheEntry) ===
            _routerreducertypes.PrefetchCacheEntryStatus.expired
          ) {
            prefetchCache.delete(href);
          }
        }
      }
      const DYNAMIC_STALETIME_MS = Number("0") * 1000;
      const STATIC_STALETIME_MS = Number("300") * 1000;
      function getPrefetchEntryCacheStatus(param) {
        let { kind, prefetchTime, lastUsedTime } = param;
        // We will re-use the cache entry data for up to the `dynamic` staletime window.
        if (
          Date.now() <
          (lastUsedTime != null ? lastUsedTime : prefetchTime) + DYNAMIC_STALETIME_MS
        ) {
          return lastUsedTime
            ? _routerreducertypes.PrefetchCacheEntryStatus.reusable
            : _routerreducertypes.PrefetchCacheEntryStatus.fresh;
        }
        // For "auto" prefetching, we'll re-use only the loading boundary for up to `static` staletime window.
        // A stale entry will only re-use the `loading` boundary, not the full data.
        // This will trigger a "lazy fetch" for the full data.
        if (kind === _routerreducertypes.PrefetchKind.AUTO) {
          if (Date.now() < prefetchTime + STATIC_STALETIME_MS) {
            return _routerreducertypes.PrefetchCacheEntryStatus.stale;
          }
        }
        // for "full" prefetching, we'll re-use the cache entry data for up to `static` staletime window.
        if (kind === _routerreducertypes.PrefetchKind.FULL) {
          if (Date.now() < prefetchTime + STATIC_STALETIME_MS) {
            return _routerreducertypes.PrefetchCacheEntryStatus.reusable;
          }
        }
        return _routerreducertypes.PrefetchCacheEntryStatus.expired;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=prefetch-cache-utils.js.map

      /***/
    },

    /***/ 2003: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "ClientPageRoot", {
        enumerable: true,
        get: function () {
          return ClientPageRoot;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const _invarianterror = __webpack_require__(9042);
      function ClientPageRoot(param) {
        let { Component, searchParams, params, promises } = param;
        if (false) {
        } else {
          const { createRenderSearchParamsFromClient } = __webpack_require__(5090);
          const clientSearchParams = createRenderSearchParamsFromClient(searchParams);
          const { createRenderParamsFromClient } = __webpack_require__(5703);
          const clientParams = createRenderParamsFromClient(params);
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(Component, {
            params: clientParams,
            searchParams: clientSearchParams,
          });
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=client-page.js.map

      /***/
    },

    /***/ 2006: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "pathHasPrefix", {
        enumerable: true,
        get: function () {
          return pathHasPrefix;
        },
      });
      const _parsepath = __webpack_require__(3476);
      function pathHasPrefix(path, prefix) {
        if (typeof path !== "string") {
          return false;
        }
        const { pathname } = (0, _parsepath.parsePath)(path);
        return pathname === prefix || pathname.startsWith(prefix + "/");
      } //# sourceMappingURL=path-has-prefix.js.map

      /***/
    },

    /***/ 2025: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "warnOnce", {
        enumerable: true,
        get: function () {
          return warnOnce;
        },
      });
      let warnOnce = (_) => {};
      if (false) {
      } //# sourceMappingURL=warn-once.js.map

      /***/
    },

    /***/ 2037: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "HeadManagerContext", {
        enumerable: true,
        get: function () {
          return HeadManagerContext;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(5127));
      const HeadManagerContext = _react.default.createContext({});
      if (false) {
      } //# sourceMappingURL=head-manager-context.shared-runtime.js.map

      /***/
    },

    /***/ 2134: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * @license React
       * scheduler.production.js
       *
       * Copyright (c) Meta Platforms, Inc. and affiliates.
       *
       * This source code is licensed under the MIT license found in the
       * LICENSE file in the root directory of this source tree.
       */

      function push(heap, node) {
        var index = heap.length;
        heap.push(node);
        a: for (; 0 < index;) {
          var parentIndex = (index - 1) >>> 1,
            parent = heap[parentIndex];
          if (0 < compare(parent, node))
            ((heap[parentIndex] = node), (heap[index] = parent), (index = parentIndex));
          else break a;
        }
      }
      function peek(heap) {
        return 0 === heap.length ? null : heap[0];
      }
      function pop(heap) {
        if (0 === heap.length) return null;
        var first = heap[0],
          last = heap.pop();
        if (last !== first) {
          heap[0] = last;
          a: for (
            var index = 0, length = heap.length, halfLength = length >>> 1;
            index < halfLength;
          ) {
            var leftIndex = 2 * (index + 1) - 1,
              left = heap[leftIndex],
              rightIndex = leftIndex + 1,
              right = heap[rightIndex];
            if (0 > compare(left, last))
              rightIndex < length && 0 > compare(right, left)
                ? ((heap[index] = right), (heap[rightIndex] = last), (index = rightIndex))
                : ((heap[index] = left), (heap[leftIndex] = last), (index = leftIndex));
            else if (rightIndex < length && 0 > compare(right, last))
              ((heap[index] = right), (heap[rightIndex] = last), (index = rightIndex));
            else break a;
          }
        }
        return first;
      }
      function compare(a, b) {
        var diff = a.sortIndex - b.sortIndex;
        return 0 !== diff ? diff : a.id - b.id;
      }
      exports.unstable_now = void 0;
      if ("object" === typeof performance && "function" === typeof performance.now) {
        var localPerformance = performance;
        exports.unstable_now = function () {
          return localPerformance.now();
        };
      } else {
        var localDate = Date,
          initialTime = localDate.now();
        exports.unstable_now = function () {
          return localDate.now() - initialTime;
        };
      }
      var taskQueue = [],
        timerQueue = [],
        taskIdCounter = 1,
        currentTask = null,
        currentPriorityLevel = 3,
        isPerformingWork = !1,
        isHostCallbackScheduled = !1,
        isHostTimeoutScheduled = !1,
        needsPaint = !1,
        localSetTimeout = "function" === typeof setTimeout ? setTimeout : null,
        localClearTimeout = "function" === typeof clearTimeout ? clearTimeout : null,
        localSetImmediate = "undefined" !== typeof setImmediate ? setImmediate : null;
      function advanceTimers(currentTime) {
        for (var timer = peek(timerQueue); null !== timer;) {
          if (null === timer.callback) pop(timerQueue);
          else if (timer.startTime <= currentTime)
            (pop(timerQueue), (timer.sortIndex = timer.expirationTime), push(taskQueue, timer));
          else break;
          timer = peek(timerQueue);
        }
      }
      function handleTimeout(currentTime) {
        isHostTimeoutScheduled = !1;
        advanceTimers(currentTime);
        if (!isHostCallbackScheduled)
          if (null !== peek(taskQueue))
            ((isHostCallbackScheduled = !0),
              isMessageLoopRunning ||
                ((isMessageLoopRunning = !0), schedulePerformWorkUntilDeadline()));
          else {
            var firstTimer = peek(timerQueue);
            null !== firstTimer &&
              requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
          }
      }
      var isMessageLoopRunning = !1,
        taskTimeoutID = -1,
        frameInterval = 5,
        startTime = -1;
      function shouldYieldToHost() {
        return needsPaint ? !0 : exports.unstable_now() - startTime < frameInterval ? !1 : !0;
      }
      function performWorkUntilDeadline() {
        needsPaint = !1;
        if (isMessageLoopRunning) {
          var currentTime = exports.unstable_now();
          startTime = currentTime;
          var hasMoreWork = !0;
          try {
            a: {
              isHostCallbackScheduled = !1;
              isHostTimeoutScheduled &&
                ((isHostTimeoutScheduled = !1),
                localClearTimeout(taskTimeoutID),
                (taskTimeoutID = -1));
              isPerformingWork = !0;
              var previousPriorityLevel = currentPriorityLevel;
              try {
                b: {
                  advanceTimers(currentTime);
                  for (
                    currentTask = peek(taskQueue);
                    null !== currentTask &&
                    !(currentTask.expirationTime > currentTime && shouldYieldToHost());
                  ) {
                    var callback = currentTask.callback;
                    if ("function" === typeof callback) {
                      currentTask.callback = null;
                      currentPriorityLevel = currentTask.priorityLevel;
                      var continuationCallback = callback(
                        currentTask.expirationTime <= currentTime,
                      );
                      currentTime = exports.unstable_now();
                      if ("function" === typeof continuationCallback) {
                        currentTask.callback = continuationCallback;
                        advanceTimers(currentTime);
                        hasMoreWork = !0;
                        break b;
                      }
                      currentTask === peek(taskQueue) && pop(taskQueue);
                      advanceTimers(currentTime);
                    } else pop(taskQueue);
                    currentTask = peek(taskQueue);
                  }
                  if (null !== currentTask) hasMoreWork = !0;
                  else {
                    var firstTimer = peek(timerQueue);
                    null !== firstTimer &&
                      requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
                    hasMoreWork = !1;
                  }
                }
                break a;
              } finally {
                ((currentTask = null),
                  (currentPriorityLevel = previousPriorityLevel),
                  (isPerformingWork = !1));
              }
              hasMoreWork = void 0;
            }
          } finally {
            hasMoreWork ? schedulePerformWorkUntilDeadline() : (isMessageLoopRunning = !1);
          }
        }
      }
      var schedulePerformWorkUntilDeadline;
      if ("function" === typeof localSetImmediate)
        schedulePerformWorkUntilDeadline = function () {
          localSetImmediate(performWorkUntilDeadline);
        };
      else if ("undefined" !== typeof MessageChannel) {
        var channel = new MessageChannel(),
          port = channel.port2;
        channel.port1.onmessage = performWorkUntilDeadline;
        schedulePerformWorkUntilDeadline = function () {
          port.postMessage(null);
        };
      } else
        schedulePerformWorkUntilDeadline = function () {
          localSetTimeout(performWorkUntilDeadline, 0);
        };
      function requestHostTimeout(callback, ms) {
        taskTimeoutID = localSetTimeout(function () {
          callback(exports.unstable_now());
        }, ms);
      }
      exports.unstable_IdlePriority = 5;
      exports.unstable_ImmediatePriority = 1;
      exports.unstable_LowPriority = 4;
      exports.unstable_NormalPriority = 3;
      exports.unstable_Profiling = null;
      exports.unstable_UserBlockingPriority = 2;
      exports.unstable_cancelCallback = function (task) {
        task.callback = null;
      };
      exports.unstable_forceFrameRate = function (fps) {
        0 > fps || 125 < fps
          ? console.error(
              "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
            )
          : (frameInterval = 0 < fps ? Math.floor(1e3 / fps) : 5);
      };
      exports.unstable_getCurrentPriorityLevel = function () {
        return currentPriorityLevel;
      };
      exports.unstable_next = function (eventHandler) {
        switch (currentPriorityLevel) {
          case 1:
          case 2:
          case 3:
            var priorityLevel = 3;
            break;
          default:
            priorityLevel = currentPriorityLevel;
        }
        var previousPriorityLevel = currentPriorityLevel;
        currentPriorityLevel = priorityLevel;
        try {
          return eventHandler();
        } finally {
          currentPriorityLevel = previousPriorityLevel;
        }
      };
      exports.unstable_requestPaint = function () {
        needsPaint = !0;
      };
      exports.unstable_runWithPriority = function (priorityLevel, eventHandler) {
        switch (priorityLevel) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            priorityLevel = 3;
        }
        var previousPriorityLevel = currentPriorityLevel;
        currentPriorityLevel = priorityLevel;
        try {
          return eventHandler();
        } finally {
          currentPriorityLevel = previousPriorityLevel;
        }
      };
      exports.unstable_scheduleCallback = function (priorityLevel, callback, options) {
        var currentTime = exports.unstable_now();
        "object" === typeof options && null !== options
          ? ((options = options.delay),
            (options =
              "number" === typeof options && 0 < options ? currentTime + options : currentTime))
          : (options = currentTime);
        switch (priorityLevel) {
          case 1:
            var timeout = -1;
            break;
          case 2:
            timeout = 250;
            break;
          case 5:
            timeout = 1073741823;
            break;
          case 4:
            timeout = 1e4;
            break;
          default:
            timeout = 5e3;
        }
        timeout = options + timeout;
        priorityLevel = {
          id: taskIdCounter++,
          callback: callback,
          priorityLevel: priorityLevel,
          startTime: options,
          expirationTime: timeout,
          sortIndex: -1,
        };
        options > currentTime
          ? ((priorityLevel.sortIndex = options),
            push(timerQueue, priorityLevel),
            null === peek(taskQueue) &&
              priorityLevel === peek(timerQueue) &&
              (isHostTimeoutScheduled
                ? (localClearTimeout(taskTimeoutID), (taskTimeoutID = -1))
                : (isHostTimeoutScheduled = !0),
              requestHostTimeout(handleTimeout, options - currentTime)))
          : ((priorityLevel.sortIndex = timeout),
            push(taskQueue, priorityLevel),
            isHostCallbackScheduled ||
              isPerformingWork ||
              ((isHostCallbackScheduled = !0),
              isMessageLoopRunning ||
                ((isMessageLoopRunning = !0), schedulePerformWorkUntilDeadline())));
        return priorityLevel;
      };
      exports.unstable_shouldYield = shouldYieldToHost;
      exports.unstable_wrapCallback = function (callback) {
        var parentPriorityLevel = currentPriorityLevel;
        return function () {
          var previousPriorityLevel = currentPriorityLevel;
          currentPriorityLevel = parentPriorityLevel;
          try {
            return callback.apply(this, arguments);
          } finally {
            currentPriorityLevel = previousPriorityLevel;
          }
        };
      };

      /***/
    },

    /***/ 2322: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      // Override chunk URL mapping in the webpack runtime
      // https://github.com/webpack/webpack/blob/2738eebc7880835d88c727d364ad37f3ec557593/lib/RuntimeGlobals.js#L204

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      const _deploymentid = __webpack_require__(7161);
      const _encodeuripath = __webpack_require__(7122);
      // If we have a deployment ID, we need to append it to the webpack chunk names
      // I am keeping the process check explicit so this can be statically optimized
      if (false) {
      } else {
        // eslint-disable-next-line no-undef
        const getChunkScriptFilename = __webpack_require__.u;
        // eslint-disable-next-line no-undef
        __webpack_require__.u = function () {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return (
            // filename path.
            (0, _encodeuripath.encodeURIPath)(getChunkScriptFilename(...args))
          );
        };
        // We don't need to override __webpack_require__.k because we don't modify
        // the css chunk name when not using deployment id suffixes
        // WE don't need to override __webpack_require__.miniCssF because we don't modify
        // the mini css chunk name when not using deployment id suffixes
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-webpack.js.map

      /***/
    },

    /***/ 2578: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "IconMark", {
        enumerable: true,
        get: function () {
          return IconMark;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const IconMark = () => {
        if (true) {
          return null;
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)("meta", {
          name: "\xabnxt-icon\xbb",
        });
      }; //# sourceMappingURL=icon-mark.js.map

      /***/
    },

    /***/ 2601: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "ClientSegmentRoot", {
        enumerable: true,
        get: function () {
          return ClientSegmentRoot;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const _invarianterror = __webpack_require__(9042);
      function ClientSegmentRoot(param) {
        let { Component, slots, params, promise } = param;
        if (false) {
        } else {
          const { createRenderParamsFromClient } = __webpack_require__(5703);
          const clientParams = createRenderParamsFromClient(params);
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(Component, {
            ...slots,
            params: clientParams,
          });
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=client-segment.js.map

      /***/
    },

    /***/ 2611: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        fillCacheWithNewSubTreeData: function () {
          return fillCacheWithNewSubTreeData;
        },
        fillCacheWithNewSubTreeDataButOnlyLoading: function () {
          return fillCacheWithNewSubTreeDataButOnlyLoading;
        },
      });
      const _invalidatecachebyrouterstate = __webpack_require__(6861);
      const _filllazyitemstillleafwithhead = __webpack_require__(1393);
      const _createroutercachekey = __webpack_require__(6066);
      const _segment = __webpack_require__(3388);
      /**
       * Common logic for filling cache with new sub tree data.
       */ function fillCacheHelper(
        navigatedAt,
        newCache,
        existingCache,
        flightData,
        prefetchEntry,
        fillLazyItems,
      ) {
        const { segmentPath, seedData: cacheNodeSeedData, tree: treePatch, head } = flightData;
        let newCacheNode = newCache;
        let existingCacheNode = existingCache;
        for (let i = 0; i < segmentPath.length; i += 2) {
          const parallelRouteKey = segmentPath[i];
          const segment = segmentPath[i + 1];
          // segmentPath is a repeating tuple of parallelRouteKey and segment
          // we know we've hit the last entry we've reached our final pair
          const isLastEntry = i === segmentPath.length - 2;
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segment);
          const existingChildSegmentMap = existingCacheNode.parallelRoutes.get(parallelRouteKey);
          if (!existingChildSegmentMap) {
            continue;
          }
          let childSegmentMap = newCacheNode.parallelRoutes.get(parallelRouteKey);
          if (!childSegmentMap || childSegmentMap === existingChildSegmentMap) {
            childSegmentMap = new Map(existingChildSegmentMap);
            newCacheNode.parallelRoutes.set(parallelRouteKey, childSegmentMap);
          }
          const existingChildCacheNode = existingChildSegmentMap.get(cacheKey);
          let childCacheNode = childSegmentMap.get(cacheKey);
          if (isLastEntry) {
            if (
              cacheNodeSeedData &&
              (!childCacheNode ||
                !childCacheNode.lazyData ||
                childCacheNode === existingChildCacheNode)
            ) {
              const incomingSegment = cacheNodeSeedData[0];
              const rsc = cacheNodeSeedData[1];
              const loading = cacheNodeSeedData[3];
              childCacheNode = {
                lazyData: null,
                // When `fillLazyItems` is false, we only want to fill the RSC data for the layout,
                // not the page segment.
                rsc: fillLazyItems || incomingSegment !== _segment.PAGE_SEGMENT_KEY ? rsc : null,
                prefetchRsc: null,
                head: null,
                prefetchHead: null,
                loading,
                parallelRoutes:
                  fillLazyItems && existingChildCacheNode
                    ? new Map(existingChildCacheNode.parallelRoutes)
                    : new Map(),
                navigatedAt,
              };
              if (existingChildCacheNode && fillLazyItems) {
                (0, _invalidatecachebyrouterstate.invalidateCacheByRouterState)(
                  childCacheNode,
                  existingChildCacheNode,
                  treePatch,
                );
              }
              if (fillLazyItems) {
                (0, _filllazyitemstillleafwithhead.fillLazyItemsTillLeafWithHead)(
                  navigatedAt,
                  childCacheNode,
                  existingChildCacheNode,
                  treePatch,
                  cacheNodeSeedData,
                  head,
                  prefetchEntry,
                );
              }
              childSegmentMap.set(cacheKey, childCacheNode);
            }
            continue;
          }
          if (!childCacheNode || !existingChildCacheNode) {
            continue;
          }
          if (childCacheNode === existingChildCacheNode) {
            childCacheNode = {
              lazyData: childCacheNode.lazyData,
              rsc: childCacheNode.rsc,
              prefetchRsc: childCacheNode.prefetchRsc,
              head: childCacheNode.head,
              prefetchHead: childCacheNode.prefetchHead,
              parallelRoutes: new Map(childCacheNode.parallelRoutes),
              loading: childCacheNode.loading,
            };
            childSegmentMap.set(cacheKey, childCacheNode);
          }
          // Move deeper into the cache nodes
          newCacheNode = childCacheNode;
          existingCacheNode = existingChildCacheNode;
        }
      }
      function fillCacheWithNewSubTreeData(
        navigatedAt,
        newCache,
        existingCache,
        flightData,
        prefetchEntry,
      ) {
        fillCacheHelper(navigatedAt, newCache, existingCache, flightData, prefetchEntry, true);
      }
      function fillCacheWithNewSubTreeDataButOnlyLoading(
        navigatedAt,
        newCache,
        existingCache,
        flightData,
        prefetchEntry,
      ) {
        fillCacheHelper(navigatedAt, newCache, existingCache, flightData, prefetchEntry, false);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=fill-cache-with-new-subtree-data.js.map

      /***/
    },

    /***/ 2635: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        SERVER_REFERENCE_ID_LENGTH: function () {
          return SERVER_REFERENCE_ID_LENGTH;
        },
        extractInfoFromServerReferenceId: function () {
          return extractInfoFromServerReferenceId;
        },
        mightBeServerReferenceId: function () {
          return mightBeServerReferenceId;
        },
        omitUnusedArgs: function () {
          return omitUnusedArgs;
        },
      });
      const SERVER_REFERENCE_ID_LENGTH = 42;
      function mightBeServerReferenceId(id) {
        return id.length === SERVER_REFERENCE_ID_LENGTH;
      }
      function extractInfoFromServerReferenceId(id) {
        const infoByte = parseInt(id.slice(0, 2), 16);
        const typeBit = (infoByte >> 7) & 0x1;
        const argMask = (infoByte >> 1) & 0x3f;
        const restArgs = infoByte & 0x1;
        const usedArgs = Array(6);
        for (let index = 0; index < 6; index++) {
          const bitPosition = 5 - index;
          const bit = (argMask >> bitPosition) & 0x1;
          usedArgs[index] = bit === 1;
        }
        return {
          type: typeBit === 1 ? "use-cache" : "server-action",
          usedArgs: usedArgs,
          hasRestArgs: restArgs === 1,
        };
      }
      function omitUnusedArgs(args, info) {
        const filteredArgs = new Array(args.length);
        for (let index = 0; index < args.length; index++) {
          if (
            (index < 6 && info.usedArgs[index]) || // This assumes that the server reference info byte has the restArgs bit
            // set to 1 if there are more than 6 args.
            (index >= 6 && info.hasRestArgs)
          ) {
            filteredArgs[index] = args[index];
          }
        }
        return filteredArgs;
      } //# sourceMappingURL=server-reference-info.js.map

      /***/
    },

    /***/ 2682: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        createFetch: function () {
          return createFetch;
        },
        createFromNextReadableStream: function () {
          return createFromNextReadableStream;
        },
        fetchServerResponse: function () {
          return fetchServerResponse;
        },
      });
      const _client = __webpack_require__(9169);
      const _approuterheaders = __webpack_require__(1306);
      const _appcallserver = __webpack_require__(9837);
      const _appfindsourcemapurl = __webpack_require__(8213);
      const _routerreducertypes = __webpack_require__(9131);
      const _flightdatahelpers = __webpack_require__(6081);
      const _appbuildid = __webpack_require__(8021);
      const _setcachebustingsearchparam = __webpack_require__(8760);
      const _routeparams = __webpack_require__(7963);
      const createFromReadableStream = _client.createFromReadableStream;
      function doMpaNavigation(url) {
        return {
          flightData: (0, _routeparams.urlToUrlWithoutFlightMarker)(
            new URL(url, location.origin),
          ).toString(),
          canonicalUrl: undefined,
          couldBeIntercepted: false,
          prerendered: false,
          postponed: false,
          staleTime: -1,
        };
      }
      let abortController = new AbortController();
      if (true) {
        // Abort any in-flight requests when the page is unloaded, e.g. due to
        // reloading the page or performing hard navigations. This allows us to ignore
        // what would otherwise be a thrown TypeError when the browser cancels the
        // requests.
        window.addEventListener("pagehide", () => {
          abortController.abort();
        });
        // Use a fresh AbortController instance on pageshow, e.g. when navigating back
        // and the JavaScript execution context is restored by the browser.
        window.addEventListener("pageshow", () => {
          abortController = new AbortController();
        });
      }
      async function fetchServerResponse(url, options) {
        const { flightRouterState, nextUrl, prefetchKind } = options;
        const headers = {
          // Enable flight response
          [_approuterheaders.RSC_HEADER]: "1",
          // Provide the current router state
          [_approuterheaders.NEXT_ROUTER_STATE_TREE_HEADER]: (0,
          _flightdatahelpers.prepareFlightRouterStateForRequest)(
            flightRouterState,
            options.isHmrRefresh,
          ),
        };
        /**
         * Three cases:
         * - `prefetchKind` is `undefined`, it means it's a normal navigation, so we want to prefetch the page data fully
         * - `prefetchKind` is `full` - we want to prefetch the whole page so same as above
         * - `prefetchKind` is `auto` - if the page is dynamic, prefetch the page data partially, if static prefetch the page data fully
         */ if (prefetchKind === _routerreducertypes.PrefetchKind.AUTO) {
          headers[_approuterheaders.NEXT_ROUTER_PREFETCH_HEADER] = "1";
        }
        if (false) {
        }
        if (nextUrl) {
          headers[_approuterheaders.NEXT_URL] = nextUrl;
        }
        try {
          var _res_headers_get;
          // When creating a "temporary" prefetch (the "on-demand" prefetch that gets created on navigation, if one doesn't exist)
          // we send the request with a "high" priority as it's in response to a user interaction that could be blocking a transition.
          // Otherwise, all other prefetches are sent with a "low" priority.
          // We use "auto" for in all other cases to match the existing default, as this function is shared outside of prefetching.
          const fetchPriority = prefetchKind
            ? prefetchKind === _routerreducertypes.PrefetchKind.TEMPORARY
              ? "high"
              : "low"
            : "auto";
          if (true) {
            if (true) {
              // In "output: export" mode, we can't rely on headers to distinguish
              // between HTML and RSC requests. Instead, we append an extra prefix
              // to the request.
              url = new URL(url);
              if (url.pathname.endsWith("/")) {
                url.pathname += "index.txt";
              } else {
                url.pathname += ".txt";
              }
            }
          }
          const res = await createFetch(url, headers, fetchPriority, abortController.signal);
          const responseUrl = (0, _routeparams.urlToUrlWithoutFlightMarker)(new URL(res.url));
          const canonicalUrl = res.redirected ? responseUrl : undefined;
          const contentType = res.headers.get("content-type") || "";
          const interception = !!((_res_headers_get = res.headers.get("vary")) == null
            ? void 0
            : _res_headers_get.includes(_approuterheaders.NEXT_URL));
          const postponed = !!res.headers.get(_approuterheaders.NEXT_DID_POSTPONE_HEADER);
          const staleTimeHeaderSeconds = res.headers.get(
            _approuterheaders.NEXT_ROUTER_STALE_TIME_HEADER,
          );
          const staleTime =
            staleTimeHeaderSeconds !== null ? parseInt(staleTimeHeaderSeconds, 10) * 1000 : -1;
          let isFlightResponse = contentType.startsWith(_approuterheaders.RSC_CONTENT_TYPE_HEADER);
          if (true) {
            if (true) {
              if (!isFlightResponse) {
                isFlightResponse = contentType.startsWith("text/plain");
              }
            }
          }
          // If fetch returns something different than flight response handle it like a mpa navigation
          // If the fetch was not 200, we also handle it like a mpa navigation
          if (!isFlightResponse || !res.ok || !res.body) {
            // in case the original URL came with a hash, preserve it before redirecting to the new URL
            if (url.hash) {
              responseUrl.hash = url.hash;
            }
            return doMpaNavigation(responseUrl.toString());
          }
          // We may navigate to a page that requires a different Webpack runtime.
          // In prod, every page will have the same Webpack runtime.
          // In dev, the Webpack runtime is minimal for each page.
          // We need to ensure the Webpack runtime is updated before executing client-side JS of the new page.
          if (false) {
          }
          // Handle the `fetch` readable stream that can be unwrapped by `React.use`.
          const flightStream = postponed ? createUnclosingPrefetchStream(res.body) : res.body;
          const response = await createFromNextReadableStream(flightStream);
          if ((0, _appbuildid.getAppBuildId)() !== response.b) {
            return doMpaNavigation(res.url);
          }
          return {
            flightData: (0, _flightdatahelpers.normalizeFlightData)(response.f),
            canonicalUrl: canonicalUrl,
            couldBeIntercepted: interception,
            prerendered: response.S,
            postponed,
            staleTime,
          };
        } catch (err) {
          if (!abortController.signal.aborted) {
            console.error(
              "Failed to fetch RSC payload for " + url + ". Falling back to browser navigation.",
              err,
            );
          }
          // If fetch fails handle it like a mpa navigation
          // TODO-APP: Add a test for the case where a CORS request fails, e.g. external url redirect coming from the response.
          // See https://github.com/vercel/next.js/issues/43605#issuecomment-1451617521 for a reproduction.
          return {
            flightData: url.toString(),
            canonicalUrl: undefined,
            couldBeIntercepted: false,
            prerendered: false,
            postponed: false,
            staleTime: -1,
          };
        }
      }
      async function createFetch(url, headers, fetchPriority, signal) {
        // TODO: In output: "export" mode, the headers do nothing. Omit them (and the
        // cache busting search param) from the request so they're
        // maximally cacheable.
        if (false) {
        }
        if (false) {
        }
        const fetchOptions = {
          // Backwards compat for older browsers. `same-origin` is the default in modern browsers.
          credentials: "same-origin",
          headers,
          priority: fetchPriority || undefined,
          signal,
        };
        // `fetchUrl` is slightly different from `url` because we add a cache-busting
        // search param to it. This should not leak outside of this function, so we
        // track them separately.
        let fetchUrl = new URL(url);
        await (0, _setcachebustingsearchparam.setCacheBustingSearchParam)(fetchUrl, headers);
        let browserResponse = await fetch(fetchUrl, fetchOptions);
        // If the server responds with a redirect (e.g. 307), and the redirected
        // location does not contain the cache busting search param set in the
        // original request, the response is likely invalid — when following the
        // redirect, the browser forwards the request headers, but since the cache
        // busting search param is missing, the server will reject the request due to
        // a mismatch.
        //
        // Ideally, we would be able to intercept the redirect response and perform it
        // manually, instead of letting the browser automatically follow it, but this
        // is not allowed by the fetch API.
        //
        // So instead, we must "replay" the redirect by fetching the new location
        // again, but this time we'll append the cache busting search param to prevent
        // a mismatch.
        //
        // TODO: We can optimize Next.js's built-in middleware APIs by returning a
        // custom status code, to prevent the browser from automatically following it.
        //
        // This does not affect Server Action-based redirects; those are encoded
        // differently, as part of the Flight body. It only affects redirects that
        // occur in a middleware or a third-party proxy.
        let redirected = browserResponse.redirected;
        if (false) {
        }
        // Remove the cache busting search param from the response URL, to prevent it
        // from leaking outside of this function.
        const responseUrl = new URL(browserResponse.url, fetchUrl);
        responseUrl.searchParams.delete(_approuterheaders.NEXT_RSC_UNION_QUERY);
        const rscResponse = {
          url: responseUrl.href,
          // This is true if any redirects occurred, either automatically by the
          // browser, or manually by us. So it's different from
          // `browserResponse.redirected`, which only tells us whether the browser
          // followed a redirect, and only for the last response in the chain.
          redirected,
          // These can be copied from the last browser response we received. We
          // intentionally only expose the subset of fields that are actually used
          // elsewhere in the codebase.
          ok: browserResponse.ok,
          headers: browserResponse.headers,
          body: browserResponse.body,
          status: browserResponse.status,
        };
        return rscResponse;
      }
      function createFromNextReadableStream(flightStream) {
        return createFromReadableStream(flightStream, {
          callServer: _appcallserver.callServer,
          findSourceMapURL: _appfindsourcemapurl.findSourceMapURL,
        });
      }
      function createUnclosingPrefetchStream(originalFlightStream) {
        // When PPR is enabled, prefetch streams may contain references that never
        // resolve, because that's how we encode dynamic data access. In the decoded
        // object returned by the Flight client, these are reified into hanging
        // promises that suspend during render, which is effectively what we want.
        // The UI resolves when it switches to the dynamic data stream
        // (via useDeferredValue(dynamic, static)).
        //
        // However, the Flight implementation currently errors if the server closes
        // the response before all the references are resolved. As a cheat to work
        // around this, we wrap the original stream in a new stream that never closes,
        // and therefore doesn't error.
        const reader = originalFlightStream.getReader();
        return new ReadableStream({
          async pull(controller) {
            while (true) {
              const { done, value } = await reader.read();
              if (!done) {
                // Pass to the target stream and keep consuming the Flight response
                // from the server.
                controller.enqueue(value);
                continue;
              }
              // The server stream has closed. Exit, but intentionally do not close
              // the target stream.
              return;
            }
          },
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=fetch-server-response.js.map

      /***/
    },

    /***/ 2720: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * For a given page path, this function ensures that there is a leading slash.
       * If there is not a leading slash, one is added, otherwise it is noop.
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "ensureLeadingSlash", {
        enumerable: true,
        get: function () {
          return ensureLeadingSlash;
        },
      });
      function ensureLeadingSlash(path) {
        return path.startsWith("/") ? path : "/" + path;
      } //# sourceMappingURL=ensure-leading-slash.js.map

      /***/
    },

    /***/ 2767: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        IDLE_LINK_STATUS: function () {
          return IDLE_LINK_STATUS;
        },
        PENDING_LINK_STATUS: function () {
          return PENDING_LINK_STATUS;
        },
        mountFormInstance: function () {
          return mountFormInstance;
        },
        mountLinkInstance: function () {
          return mountLinkInstance;
        },
        onLinkVisibilityChanged: function () {
          return onLinkVisibilityChanged;
        },
        onNavigationIntent: function () {
          return onNavigationIntent;
        },
        pingVisibleLinks: function () {
          return pingVisibleLinks;
        },
        setLinkForCurrentNavigation: function () {
          return setLinkForCurrentNavigation;
        },
        unmountLinkForCurrentNavigation: function () {
          return unmountLinkForCurrentNavigation;
        },
        unmountPrefetchableInstance: function () {
          return unmountPrefetchableInstance;
        },
      });
      const _approuterinstance = __webpack_require__(7267);
      const _approuter = __webpack_require__(9701);
      const _segmentcache = __webpack_require__(5620);
      const _react = __webpack_require__(5127);
      const _routerreducertypes = __webpack_require__(9131);
      const _invarianterror = __webpack_require__(9042);
      // Tracks the most recently navigated link instance. When null, indicates
      // the current navigation was not initiated by a link click.
      let linkForMostRecentNavigation = null;
      const PENDING_LINK_STATUS = {
        pending: true,
      };
      const IDLE_LINK_STATUS = {
        pending: false,
      };
      function setLinkForCurrentNavigation(link) {
        (0, _react.startTransition)(() => {
          linkForMostRecentNavigation == null
            ? void 0
            : linkForMostRecentNavigation.setOptimisticLinkStatus(IDLE_LINK_STATUS);
          link == null ? void 0 : link.setOptimisticLinkStatus(PENDING_LINK_STATUS);
          linkForMostRecentNavigation = link;
        });
      }
      function unmountLinkForCurrentNavigation(link) {
        if (linkForMostRecentNavigation === link) {
          linkForMostRecentNavigation = null;
        }
      }
      // Use a WeakMap to associate a Link instance with its DOM element. This is
      // used by the IntersectionObserver to track the link's visibility.
      const prefetchable = typeof WeakMap === "function" ? new WeakMap() : new Map();
      // A Set of the currently visible links. We re-prefetch visible links after a
      // cache invalidation, or when the current URL changes. It's a separate data
      // structure from the WeakMap above because only the visible links need to
      // be enumerated.
      const prefetchableAndVisible = new Set();
      // A single IntersectionObserver instance shared by all <Link> components.
      const observer =
        typeof IntersectionObserver === "function"
          ? new IntersectionObserver(handleIntersect, {
              rootMargin: "200px",
            })
          : null;
      function observeVisibility(element, instance) {
        const existingInstance = prefetchable.get(element);
        if (existingInstance !== undefined) {
          // This shouldn't happen because each <Link> component should have its own
          // anchor tag instance, but it's defensive coding to avoid a memory leak in
          // case there's a logical error somewhere else.
          unmountPrefetchableInstance(element);
        }
        // Only track prefetchable links that have a valid prefetch URL
        prefetchable.set(element, instance);
        if (observer !== null) {
          observer.observe(element);
        }
      }
      function coercePrefetchableUrl(href) {
        try {
          return (0, _approuter.createPrefetchURL)(href);
        } catch (e) {
          // createPrefetchURL sometimes throws an error if an invalid URL is
          // provided, though I'm not sure if it's actually necessary.
          // TODO: Consider removing the throw from the inner function, or change it
          // to reportError. Or maybe the error isn't even necessary for automatic
          // prefetches, just navigations.
          const reportErrorFn = typeof reportError === "function" ? reportError : console.error;
          reportErrorFn("Cannot prefetch '" + href + "' because it cannot be converted to a URL.");
          return null;
        }
      }
      function mountLinkInstance(
        element,
        href,
        router,
        fetchStrategy,
        prefetchEnabled,
        setOptimisticLinkStatus,
      ) {
        if (prefetchEnabled) {
          const prefetchURL = coercePrefetchableUrl(href);
          if (prefetchURL !== null) {
            const instance = {
              router,
              fetchStrategy,
              isVisible: false,
              prefetchTask: null,
              prefetchHref: prefetchURL.href,
              setOptimisticLinkStatus,
            };
            // We only observe the link's visibility if it's prefetchable. For
            // example, this excludes links to external URLs.
            observeVisibility(element, instance);
            return instance;
          }
        }
        // If the link is not prefetchable, we still create an instance so we can
        // track its optimistic state (i.e. useLinkStatus).
        const instance = {
          router,
          fetchStrategy,
          isVisible: false,
          prefetchTask: null,
          prefetchHref: null,
          setOptimisticLinkStatus,
        };
        return instance;
      }
      function mountFormInstance(element, href, router, fetchStrategy) {
        const prefetchURL = coercePrefetchableUrl(href);
        if (prefetchURL === null) {
          // This href is not prefetchable, so we don't track it.
          // TODO: We currently observe/unobserve a form every time its href changes.
          // For Links, this isn't a big deal because the href doesn't usually change,
          // but for forms it's extremely common. We should optimize this.
          return;
        }
        const instance = {
          router,
          fetchStrategy,
          isVisible: false,
          prefetchTask: null,
          prefetchHref: prefetchURL.href,
          setOptimisticLinkStatus: null,
        };
        observeVisibility(element, instance);
      }
      function unmountPrefetchableInstance(element) {
        const instance = prefetchable.get(element);
        if (instance !== undefined) {
          prefetchable.delete(element);
          prefetchableAndVisible.delete(instance);
          const prefetchTask = instance.prefetchTask;
          if (prefetchTask !== null) {
            (0, _segmentcache.cancelPrefetchTask)(prefetchTask);
          }
        }
        if (observer !== null) {
          observer.unobserve(element);
        }
      }
      function handleIntersect(entries) {
        for (const entry of entries) {
          // Some extremely old browsers or polyfills don't reliably support
          // isIntersecting so we check intersectionRatio instead. (Do we care? Not
          // really. But whatever this is fine.)
          const isVisible = entry.intersectionRatio > 0;
          onLinkVisibilityChanged(entry.target, isVisible);
        }
      }
      function onLinkVisibilityChanged(element, isVisible) {
        if (false) {
        }
        const instance = prefetchable.get(element);
        if (instance === undefined) {
          return;
        }
        instance.isVisible = isVisible;
        if (isVisible) {
          prefetchableAndVisible.add(instance);
        } else {
          prefetchableAndVisible.delete(instance);
        }
        rescheduleLinkPrefetch(instance, _segmentcache.PrefetchPriority.Default);
      }
      function onNavigationIntent(element, unstable_upgradeToDynamicPrefetch) {
        const instance = prefetchable.get(element);
        if (instance === undefined) {
          return;
        }
        // Prefetch the link on hover/touchstart.
        if (instance !== undefined) {
          if (false) {
          }
          rescheduleLinkPrefetch(instance, _segmentcache.PrefetchPriority.Intent);
        }
      }
      function rescheduleLinkPrefetch(instance, priority) {
        const existingPrefetchTask = instance.prefetchTask;
        if (!instance.isVisible) {
          // Cancel any in-progress prefetch task. (If it already finished then this
          // is a no-op.)
          if (existingPrefetchTask !== null) {
            (0, _segmentcache.cancelPrefetchTask)(existingPrefetchTask);
          }
          // We don't need to reset the prefetchTask to null upon cancellation; an
          // old task object can be rescheduled with reschedulePrefetchTask. This is a
          // micro-optimization but also makes the code simpler (don't need to
          // worry about whether an old task object is stale).
          return;
        }
        if (true) {
          // The old prefetch implementation does not have different priority levels.
          // Just schedule a new prefetch task.
          prefetchWithOldCacheImplementation(instance);
          return;
        }
        const appRouterState = (0, _approuterinstance.getCurrentAppRouterState)();
        if (appRouterState !== null) {
          const treeAtTimeOfPrefetch = appRouterState.tree;
          if (existingPrefetchTask === null) {
            // Initiate a prefetch task.
            const nextUrl = appRouterState.nextUrl;
            const cacheKey = (0, _segmentcache.createCacheKey)(instance.prefetchHref, nextUrl);
            instance.prefetchTask = (0, _segmentcache.schedulePrefetchTask)(
              cacheKey,
              treeAtTimeOfPrefetch,
              instance.fetchStrategy,
              priority,
              null,
            );
          } else {
            // We already have an old task object that we can reschedule. This is
            // effectively the same as canceling the old task and creating a new one.
            (0, _segmentcache.reschedulePrefetchTask)(
              existingPrefetchTask,
              treeAtTimeOfPrefetch,
              instance.fetchStrategy,
              priority,
            );
          }
        }
      }
      function pingVisibleLinks(nextUrl, tree) {
        // For each currently visible link, cancel the existing prefetch task (if it
        // exists) and schedule a new one. This is effectively the same as if all the
        // visible links left and then re-entered the viewport.
        //
        // This is called when the Next-Url or the base tree changes, since those
        // may affect the result of a prefetch task. It's also called after a
        // cache invalidation.
        for (const instance of prefetchableAndVisible) {
          const task = instance.prefetchTask;
          if (task !== null && !(0, _segmentcache.isPrefetchTaskDirty)(task, nextUrl, tree)) {
            continue;
          }
          // Something changed. Cancel the existing prefetch task and schedule a
          // new one.
          if (task !== null) {
            (0, _segmentcache.cancelPrefetchTask)(task);
          }
          const cacheKey = (0, _segmentcache.createCacheKey)(instance.prefetchHref, nextUrl);
          instance.prefetchTask = (0, _segmentcache.schedulePrefetchTask)(
            cacheKey,
            tree,
            instance.fetchStrategy,
            _segmentcache.PrefetchPriority.Default,
            null,
          );
        }
      }
      function prefetchWithOldCacheImplementation(instance) {
        // This is the path used when the Segment Cache is not enabled.
        if (false) {
        }
        const doPrefetch = async () => {
          // note that `appRouter.prefetch()` is currently sync,
          // so we have to wrap this call in an async function to be able to catch() errors below.
          let prefetchKind;
          switch (instance.fetchStrategy) {
            case _segmentcache.FetchStrategy.PPR: {
              prefetchKind = _routerreducertypes.PrefetchKind.AUTO;
              break;
            }
            case _segmentcache.FetchStrategy.Full: {
              prefetchKind = _routerreducertypes.PrefetchKind.FULL;
              break;
            }
            case _segmentcache.FetchStrategy.PPRRuntime: {
              // We can only get here if Client Segment Cache is off, and in that case
              // it shouldn't be possible for a link to request a runtime prefetch.
              throw Object.defineProperty(
                new _invarianterror.InvariantError(
                  "FetchStrategy.PPRRuntime should never be used when `experimental.clientSegmentCache` is disabled",
                ),
                "__NEXT_ERROR_CODE",
                {
                  value: "E772",
                  enumerable: false,
                  configurable: true,
                },
              );
            }
            default: {
              instance.fetchStrategy;
              // Unreachable, but otherwise typescript will consider the variable unassigned
              prefetchKind = undefined;
            }
          }
          return instance.router.prefetch(instance.prefetchHref, {
            kind: prefetchKind,
          });
        };
        // Prefetch the page if asked (only in the client)
        // We need to handle a prefetch error here since we may be
        // loading with priority which can reject but we don't
        // want to force navigation since this is only a prefetch
        doPrefetch().catch((err) => {
          if (false) {
          }
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=links.js.map

      /***/
    },

    /***/ 2826: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        INTERCEPTION_ROUTE_MARKERS: function () {
          return INTERCEPTION_ROUTE_MARKERS;
        },
        extractInterceptionRouteInformation: function () {
          return extractInterceptionRouteInformation;
        },
        isInterceptionRouteAppPath: function () {
          return isInterceptionRouteAppPath;
        },
      });
      const _apppaths = __webpack_require__(1257);
      const INTERCEPTION_ROUTE_MARKERS = ["(..)(..)", "(.)", "(..)", "(...)"];
      function isInterceptionRouteAppPath(path) {
        // TODO-APP: add more serious validation
        return (
          path
            .split("/")
            .find((segment) => INTERCEPTION_ROUTE_MARKERS.find((m) => segment.startsWith(m))) !==
          undefined
        );
      }
      function extractInterceptionRouteInformation(path) {
        let interceptingRoute, marker, interceptedRoute;
        for (const segment of path.split("/")) {
          marker = INTERCEPTION_ROUTE_MARKERS.find((m) => segment.startsWith(m));
          if (marker) {
            [interceptingRoute, interceptedRoute] = path.split(marker, 2);
            break;
          }
        }
        if (!interceptingRoute || !marker || !interceptedRoute) {
          throw Object.defineProperty(
            new Error(
              "Invalid interception route: " +
                path +
                ". Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>",
            ),
            "__NEXT_ERROR_CODE",
            {
              value: "E269",
              enumerable: false,
              configurable: true,
            },
          );
        }
        interceptingRoute = (0, _apppaths.normalizeAppPath)(interceptingRoute); // normalize the path, e.g. /(blog)/feed -> /feed
        switch (marker) {
          case "(.)":
            // (.) indicates that we should match with sibling routes, so we just need to append the intercepted route to the intercepting route
            if (interceptingRoute === "/") {
              interceptedRoute = "/" + interceptedRoute;
            } else {
              interceptedRoute = interceptingRoute + "/" + interceptedRoute;
            }
            break;
          case "(..)":
            // (..) indicates that we should match at one level up, so we need to remove the last segment of the intercepting route
            if (interceptingRoute === "/") {
              throw Object.defineProperty(
                new Error(
                  "Invalid interception route: " +
                    path +
                    ". Cannot use (..) marker at the root level, use (.) instead.",
                ),
                "__NEXT_ERROR_CODE",
                {
                  value: "E207",
                  enumerable: false,
                  configurable: true,
                },
              );
            }
            interceptedRoute = interceptingRoute
              .split("/")
              .slice(0, -1)
              .concat(interceptedRoute)
              .join("/");
            break;
          case "(...)":
            // (...) will match the route segment in the root directory, so we need to use the root directory to prepend the intercepted route
            interceptedRoute = "/" + interceptedRoute;
            break;
          case "(..)(..)":
            // (..)(..) indicates that we should match at two levels up, so we need to remove the last two segments of the intercepting route
            const splitInterceptingRoute = interceptingRoute.split("/");
            if (splitInterceptingRoute.length <= 2) {
              throw Object.defineProperty(
                new Error(
                  "Invalid interception route: " +
                    path +
                    ". Cannot use (..)(..) marker at the root level or one level up.",
                ),
                "__NEXT_ERROR_CODE",
                {
                  value: "E486",
                  enumerable: false,
                  configurable: true,
                },
              );
            }
            interceptedRoute = splitInterceptingRoute
              .slice(0, -2)
              .concat(interceptedRoute)
              .join("/");
            break;
          default:
            throw Object.defineProperty(
              new Error("Invariant: unexpected marker"),
              "__NEXT_ERROR_CODE",
              {
                value: "E112",
                enumerable: false,
                configurable: true,
              },
            );
        }
        return {
          interceptingRoute,
          interceptedRoute,
        };
      } //# sourceMappingURL=interception-routes.js.map

      /***/
    },

    /***/ 2829: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "hmrRefreshReducer", {
        enumerable: true,
        get: function () {
          return hmrRefreshReducer;
        },
      });
      const _fetchserverresponse = __webpack_require__(2682);
      const _createhreffromurl = __webpack_require__(8150);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _navigatereducer = __webpack_require__(5005);
      const _handlemutable = __webpack_require__(9466);
      const _applyflightdata = __webpack_require__(1437);
      const _approuter = __webpack_require__(9701);
      const _handlesegmentmismatch = __webpack_require__(5912);
      const _hasinterceptionrouteincurrenttree = __webpack_require__(3495);
      // A version of refresh reducer that keeps the cache around instead of wiping all of it.
      function hmrRefreshReducerImpl(state, action) {
        const { origin } = action;
        const mutable = {};
        const href = state.canonicalUrl;
        mutable.preserveCustomHistoryState = false;
        const cache = (0, _approuter.createEmptyCacheNode)();
        // If the current tree was intercepted, the nextUrl should be included in the request.
        // This is to ensure that the refresh request doesn't get intercepted, accidentally triggering the interception route.
        const includeNextUrl = (0,
        _hasinterceptionrouteincurrenttree.hasInterceptionRouteInCurrentTree)(state.tree);
        // TODO-APP: verify that `href` is not an external url.
        // Fetch data from the root of the tree.
        const navigatedAt = Date.now();
        cache.lazyData = (0, _fetchserverresponse.fetchServerResponse)(new URL(href, origin), {
          flightRouterState: [state.tree[0], state.tree[1], state.tree[2], "refetch"],
          nextUrl: includeNextUrl ? state.nextUrl : null,
          isHmrRefresh: true,
        });
        return cache.lazyData.then(
          (param) => {
            let { flightData, canonicalUrl: canonicalUrlOverride } = param;
            // Handle case when navigating to page in `pages` from `app`
            if (typeof flightData === "string") {
              return (0, _navigatereducer.handleExternalUrl)(
                state,
                mutable,
                flightData,
                state.pushRef.pendingPush,
              );
            }
            // Remove cache.lazyData as it has been resolved at this point.
            cache.lazyData = null;
            let currentTree = state.tree;
            let currentCache = state.cache;
            for (const normalizedFlightData of flightData) {
              const { tree: treePatch, isRootRender } = normalizedFlightData;
              if (!isRootRender) {
                // TODO-APP: handle this case better
                console.log("REFRESH FAILED");
                return state;
              }
              const newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
                [""],
                currentTree,
                treePatch,
                state.canonicalUrl,
              );
              if (newTree === null) {
                return (0, _handlesegmentmismatch.handleSegmentMismatch)(state, action, treePatch);
              }
              if (
                (0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(currentTree, newTree)
              ) {
                return (0, _navigatereducer.handleExternalUrl)(
                  state,
                  mutable,
                  href,
                  state.pushRef.pendingPush,
                );
              }
              const canonicalUrlOverrideHref = canonicalUrlOverride
                ? (0, _createhreffromurl.createHrefFromUrl)(canonicalUrlOverride)
                : undefined;
              if (canonicalUrlOverride) {
                mutable.canonicalUrl = canonicalUrlOverrideHref;
              }
              const applied = (0, _applyflightdata.applyFlightData)(
                navigatedAt,
                currentCache,
                cache,
                normalizedFlightData,
              );
              if (applied) {
                mutable.cache = cache;
                currentCache = cache;
              }
              mutable.patchedTree = newTree;
              mutable.canonicalUrl = href;
              currentTree = newTree;
            }
            return (0, _handlemutable.handleMutable)(state, mutable);
          },
          () => state,
        );
      }
      function hmrRefreshReducerNoop(state, _action) {
        return state;
      }
      const hmrRefreshReducer = true ? hmrRefreshReducerNoop : 0;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=hmr-refresh-reducer.js.map

      /***/
    },

    /***/ 2857: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        UnrecognizedActionError: function () {
          return UnrecognizedActionError;
        },
        unstable_isUnrecognizedActionError: function () {
          return unstable_isUnrecognizedActionError;
        },
      });
      class UnrecognizedActionError extends Error {
        constructor(...args) {
          super(...args);
          this.name = "UnrecognizedActionError";
        }
      }
      function unstable_isUnrecognizedActionError(error) {
        return !!(error && typeof error === "object" && error instanceof UnrecognizedActionError);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=unrecognized-action-error.js.map

      /***/
    },

    /***/ 2923: /***/ (module, exports) => {
      "use strict";
      /**
       * Create a "Thenable" that does not resolve. This is used to suspend indefinitely when data is not available yet.
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "unresolvedThenable", {
        enumerable: true,
        get: function () {
          return unresolvedThenable;
        },
      });
      const unresolvedThenable = {
        then: () => {},
      };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=unresolved-thenable.js.map

      /***/
    },

    /***/ 2950: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      // This import must go first because it needs to patch webpack chunk loading
      // before React patches chunk loading.

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      __webpack_require__(2322);
      const _appbootstrap = __webpack_require__(5299);
      const instrumentationHooks = __webpack_require__(6287);
      (0, _appbootstrap.appBootstrap)(() => {
        const { hydrate } = __webpack_require__(6257);
        // Include app-router and layout-router in the main chunk
        // eslint-disable-next-line @next/internal/typechecked-require -- Why not relative imports?
        __webpack_require__(9701);
        // eslint-disable-next-line @next/internal/typechecked-require -- Why not relative imports?
        __webpack_require__(1362);
        hydrate(instrumentationHooks);
      });
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-next.js.map

      /***/
    },

    /***/ 2997: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      // This has to be a shared module which is shared between client component error boundary and dynamic component

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        BailoutToCSRError: function () {
          return BailoutToCSRError;
        },
        isBailoutToCSRError: function () {
          return isBailoutToCSRError;
        },
      });
      const BAILOUT_TO_CSR = "BAILOUT_TO_CLIENT_SIDE_RENDERING";
      class BailoutToCSRError extends Error {
        constructor(reason) {
          (super("Bail out to client-side rendering: " + reason),
            (this.reason = reason),
            (this.digest = BAILOUT_TO_CSR));
        }
      }
      function isBailoutToCSRError(err) {
        if (typeof err !== "object" || err === null || !("digest" in err)) {
          return false;
        }
        return err.digest === BAILOUT_TO_CSR;
      } //# sourceMappingURL=bailout-to-csr.js.map

      /***/
    },

    /***/ 3065: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        prefetchQueue: function () {
          return prefetchQueue;
        },
        prefetchReducer: function () {
          return prefetchReducer;
        },
      });
      const _promisequeue = __webpack_require__(4741);
      const _prefetchcacheutils = __webpack_require__(1991);
      const prefetchQueue = new _promisequeue.PromiseQueue(5);
      const prefetchReducer = false ? 0 : prefetchReducerImpl;
      function identityReducerWhenSegmentCacheIsEnabled(state) {
        // Unlike the old implementation, the Segment Cache doesn't store its data in
        // the router reducer state.
        //
        // This shouldn't be reachable because we wrap the prefetch API in a check,
        // too, which prevents the action from being dispatched. But it's here for
        // clarity + code elimination.
        return state;
      }
      function prefetchReducerImpl(state, action) {
        // let's prune the prefetch cache before we do anything else
        (0, _prefetchcacheutils.prunePrefetchCache)(state.prefetchCache);
        const { url } = action;
        (0, _prefetchcacheutils.getOrCreatePrefetchCacheEntry)({
          url,
          nextUrl: state.nextUrl,
          prefetchCache: state.prefetchCache,
          kind: action.kind,
          tree: state.tree,
          allowAliasing: true,
        });
        return state;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=prefetch-reducer.js.map

      /***/
    },

    /***/ 3070: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "unstable_rethrow", {
        enumerable: true,
        get: function () {
          return unstable_rethrow;
        },
      });
      const _bailouttocsr = __webpack_require__(2997);
      const _isnextroutererror = __webpack_require__(1582);
      function unstable_rethrow(error) {
        if (
          (0, _isnextroutererror.isNextRouterError)(error) ||
          (0, _bailouttocsr.isBailoutToCSRError)(error)
        ) {
          throw error;
        }
        if (error instanceof Error && "cause" in error) {
          unstable_rethrow(error.cause);
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=unstable-rethrow.browser.js.map

      /***/
    },

    /***/ 3179: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "addPathPrefix", {
        enumerable: true,
        get: function () {
          return addPathPrefix;
        },
      });
      const _parsepath = __webpack_require__(3476);
      function addPathPrefix(path, prefix) {
        if (!path.startsWith("/") || !prefix) {
          return path;
        }
        const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
        return "" + prefix + pathname + query + hash;
      } //# sourceMappingURL=add-path-prefix.js.map

      /***/
    },

    /***/ 3240: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        /**
         * Checks whether the given value is a NextError.
         * This can be used to print a more detailed error message with properties like `code` & `digest`.
         */ default: function () {
          return isError;
        },
        getProperError: function () {
          return getProperError;
        },
      });
      const _isplainobject = __webpack_require__(1514);
      function isError(err) {
        return typeof err === "object" && err !== null && "name" in err && "message" in err;
      }
      function safeStringify(obj) {
        const seen = new WeakSet();
        return JSON.stringify(obj, (_key, value) => {
          // If value is an object and already seen, replace with "[Circular]"
          if (typeof value === "object" && value !== null) {
            if (seen.has(value)) {
              return "[Circular]";
            }
            seen.add(value);
          }
          return value;
        });
      }
      function getProperError(err) {
        if (isError(err)) {
          return err;
        }
        if (false) {
        }
        return Object.defineProperty(
          new Error((0, _isplainobject.isPlainObject)(err) ? safeStringify(err) : err + ""),
          "__NEXT_ERROR_CODE",
          {
            value: "E394",
            enumerable: false,
            configurable: true,
          },
        );
      }

      //# sourceMappingURL=is-error.js.map

      /***/
    },

    /***/ 3388: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        DEFAULT_SEGMENT_KEY: function () {
          return DEFAULT_SEGMENT_KEY;
        },
        PAGE_SEGMENT_KEY: function () {
          return PAGE_SEGMENT_KEY;
        },
        addSearchParamsIfPageSegment: function () {
          return addSearchParamsIfPageSegment;
        },
        isGroupSegment: function () {
          return isGroupSegment;
        },
        isParallelRouteSegment: function () {
          return isParallelRouteSegment;
        },
      });
      function isGroupSegment(segment) {
        // Use array[0] for performant purpose
        return segment[0] === "(" && segment.endsWith(")");
      }
      function isParallelRouteSegment(segment) {
        return segment.startsWith("@") && segment !== "@children";
      }
      function addSearchParamsIfPageSegment(segment, searchParams) {
        const isPageSegment = segment.includes(PAGE_SEGMENT_KEY);
        if (isPageSegment) {
          const stringifiedQuery = JSON.stringify(searchParams);
          return stringifiedQuery !== "{}"
            ? PAGE_SEGMENT_KEY + "?" + stringifiedQuery
            : PAGE_SEGMENT_KEY;
        }
        return segment;
      }
      const PAGE_SEGMENT_KEY = "__PAGE__";
      const DEFAULT_SEGMENT_KEY = "__DEFAULT__"; //# sourceMappingURL=segment.js.map

      /***/
    },

    /***/ 3476: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * Given a path this function will find the pathname, query and hash and return
       * them. This is useful to parse full paths on the client side.
       * @param path A path to parse e.g. /foo/bar?id=1#hash
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "parsePath", {
        enumerable: true,
        get: function () {
          return parsePath;
        },
      });
      function parsePath(path) {
        const hashIndex = path.indexOf("#");
        const queryIndex = path.indexOf("?");
        const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
        if (hasQuery || hashIndex > -1) {
          return {
            pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
            query: hasQuery
              ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : undefined)
              : "",
            hash: hashIndex > -1 ? path.slice(hashIndex) : "",
          };
        }
        return {
          pathname: path,
          query: "",
          hash: "",
        };
      } //# sourceMappingURL=parse-path.js.map

      /***/
    },

    /***/ 3495: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "hasInterceptionRouteInCurrentTree", {
        enumerable: true,
        get: function () {
          return hasInterceptionRouteInCurrentTree;
        },
      });
      const _interceptionroutes = __webpack_require__(2826);
      function hasInterceptionRouteInCurrentTree(param) {
        let [segment, parallelRoutes] = param;
        // If we have a dynamic segment, it's marked as an interception route by the presence of the `i` suffix.
        if (Array.isArray(segment) && (segment[2] === "di" || segment[2] === "ci")) {
          return true;
        }
        // If segment is not an array, apply the existing string-based check
        if (
          typeof segment === "string" &&
          (0, _interceptionroutes.isInterceptionRouteAppPath)(segment)
        ) {
          return true;
        }
        // Iterate through parallelRoutes if they exist
        if (parallelRoutes) {
          for (const key in parallelRoutes) {
            if (hasInterceptionRouteInCurrentTree(parallelRoutes[key])) {
              return true;
            }
          }
        }
        return false;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=has-interception-route-in-current-tree.js.map

      /***/
    },

    /***/ 3957: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "clearCacheNodeDataForSegmentPath", {
        enumerable: true,
        get: function () {
          return clearCacheNodeDataForSegmentPath;
        },
      });
      const _flightdatahelpers = __webpack_require__(6081);
      const _createroutercachekey = __webpack_require__(6066);
      function clearCacheNodeDataForSegmentPath(newCache, existingCache, flightSegmentPath) {
        const isLastEntry = flightSegmentPath.length <= 2;
        const [parallelRouteKey, segment] = flightSegmentPath;
        const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segment);
        const existingChildSegmentMap = existingCache.parallelRoutes.get(parallelRouteKey);
        let childSegmentMap = newCache.parallelRoutes.get(parallelRouteKey);
        if (!childSegmentMap || childSegmentMap === existingChildSegmentMap) {
          childSegmentMap = new Map(existingChildSegmentMap);
          newCache.parallelRoutes.set(parallelRouteKey, childSegmentMap);
        }
        const existingChildCacheNode =
          existingChildSegmentMap == null ? void 0 : existingChildSegmentMap.get(cacheKey);
        let childCacheNode = childSegmentMap.get(cacheKey);
        // In case of last segment start off the fetch at this level and don't copy further down.
        if (isLastEntry) {
          if (
            !childCacheNode ||
            !childCacheNode.lazyData ||
            childCacheNode === existingChildCacheNode
          ) {
            childSegmentMap.set(cacheKey, {
              lazyData: null,
              rsc: null,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading: null,
              navigatedAt: -1,
            });
          }
          return;
        }
        if (!childCacheNode || !existingChildCacheNode) {
          // Start fetch in the place where the existing cache doesn't have the data yet.
          if (!childCacheNode) {
            childSegmentMap.set(cacheKey, {
              lazyData: null,
              rsc: null,
              prefetchRsc: null,
              head: null,
              prefetchHead: null,
              parallelRoutes: new Map(),
              loading: null,
              navigatedAt: -1,
            });
          }
          return;
        }
        if (childCacheNode === existingChildCacheNode) {
          childCacheNode = {
            lazyData: childCacheNode.lazyData,
            rsc: childCacheNode.rsc,
            prefetchRsc: childCacheNode.prefetchRsc,
            head: childCacheNode.head,
            prefetchHead: childCacheNode.prefetchHead,
            parallelRoutes: new Map(childCacheNode.parallelRoutes),
            loading: childCacheNode.loading,
          };
          childSegmentMap.set(cacheKey, childCacheNode);
        }
        return clearCacheNodeDataForSegmentPath(
          childCacheNode,
          existingChildCacheNode,
          (0, _flightdatahelpers.getNextFlightSegmentPath)(flightSegmentPath),
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=clear-cache-node-data-for-segment-path.js.map

      /***/
    },

    /***/ 4357: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        PathParamsContext: function () {
          return PathParamsContext;
        },
        PathnameContext: function () {
          return PathnameContext;
        },
        SearchParamsContext: function () {
          return SearchParamsContext;
        },
      });
      const _react = __webpack_require__(5127);
      const SearchParamsContext = (0, _react.createContext)(null);
      const PathnameContext = (0, _react.createContext)(null);
      const PathParamsContext = (0, _react.createContext)(null);
      if (false) {
      } //# sourceMappingURL=hooks-client-context.shared-runtime.js.map

      /***/
    },

    /***/ 4585: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "invalidateCacheBelowFlightSegmentPath", {
        enumerable: true,
        get: function () {
          return invalidateCacheBelowFlightSegmentPath;
        },
      });
      const _createroutercachekey = __webpack_require__(6066);
      const _flightdatahelpers = __webpack_require__(6081);
      function invalidateCacheBelowFlightSegmentPath(newCache, existingCache, flightSegmentPath) {
        const isLastEntry = flightSegmentPath.length <= 2;
        const [parallelRouteKey, segment] = flightSegmentPath;
        const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segment);
        const existingChildSegmentMap = existingCache.parallelRoutes.get(parallelRouteKey);
        if (!existingChildSegmentMap) {
          // Bailout because the existing cache does not have the path to the leaf node
          // Will trigger lazy fetch in layout-router because of missing segment
          return;
        }
        let childSegmentMap = newCache.parallelRoutes.get(parallelRouteKey);
        if (!childSegmentMap || childSegmentMap === existingChildSegmentMap) {
          childSegmentMap = new Map(existingChildSegmentMap);
          newCache.parallelRoutes.set(parallelRouteKey, childSegmentMap);
        }
        // In case of last entry don't copy further down.
        if (isLastEntry) {
          childSegmentMap.delete(cacheKey);
          return;
        }
        const existingChildCacheNode = existingChildSegmentMap.get(cacheKey);
        let childCacheNode = childSegmentMap.get(cacheKey);
        if (!childCacheNode || !existingChildCacheNode) {
          // Bailout because the existing cache does not have the path to the leaf node
          // Will trigger lazy fetch in layout-router because of missing segment
          return;
        }
        if (childCacheNode === existingChildCacheNode) {
          childCacheNode = {
            lazyData: childCacheNode.lazyData,
            rsc: childCacheNode.rsc,
            prefetchRsc: childCacheNode.prefetchRsc,
            head: childCacheNode.head,
            prefetchHead: childCacheNode.prefetchHead,
            parallelRoutes: new Map(childCacheNode.parallelRoutes),
          };
          childSegmentMap.set(cacheKey, childCacheNode);
        }
        invalidateCacheBelowFlightSegmentPath(
          childCacheNode,
          existingChildCacheNode,
          (0, _flightdatahelpers.getNextFlightSegmentPath)(flightSegmentPath),
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=invalidate-cache-below-flight-segmentpath.js.map

      /***/
    },

    /***/ 4741: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /*
    This is a simple promise queue that allows you to limit the number of concurrent promises
    that are running at any given time. It's used to limit the number of concurrent
    prefetch requests that are being made to the server but could be used for other
    things as well.
*/
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "PromiseQueue", {
        enumerable: true,
        get: function () {
          return PromiseQueue;
        },
      });
      const _class_private_field_loose_base = __webpack_require__(1874);
      const _class_private_field_loose_key = __webpack_require__(8374);
      var _maxConcurrency = /*#__PURE__*/ _class_private_field_loose_key._("_maxConcurrency"),
        _runningCount = /*#__PURE__*/ _class_private_field_loose_key._("_runningCount"),
        _queue = /*#__PURE__*/ _class_private_field_loose_key._("_queue"),
        _processNext = /*#__PURE__*/ _class_private_field_loose_key._("_processNext");
      class PromiseQueue {
        enqueue(promiseFn) {
          let taskResolve;
          let taskReject;
          const taskPromise = new Promise((resolve, reject) => {
            taskResolve = resolve;
            taskReject = reject;
          });
          const task = async () => {
            try {
              _class_private_field_loose_base._(this, _runningCount)[_runningCount]++;
              const result = await promiseFn();
              taskResolve(result);
            } catch (error) {
              taskReject(error);
            } finally {
              _class_private_field_loose_base._(this, _runningCount)[_runningCount]--;
              _class_private_field_loose_base._(this, _processNext)[_processNext]();
            }
          };
          const enqueueResult = {
            promiseFn: taskPromise,
            task,
          };
          // wonder if we should take a LIFO approach here
          _class_private_field_loose_base._(this, _queue)[_queue].push(enqueueResult);
          _class_private_field_loose_base._(this, _processNext)[_processNext]();
          return taskPromise;
        }
        bump(promiseFn) {
          const index = _class_private_field_loose_base
            ._(this, _queue)
            [_queue].findIndex((item) => item.promiseFn === promiseFn);
          if (index > -1) {
            const bumpedItem = _class_private_field_loose_base
              ._(this, _queue)
              [_queue].splice(index, 1)[0];
            _class_private_field_loose_base._(this, _queue)[_queue].unshift(bumpedItem);
            _class_private_field_loose_base._(this, _processNext)[_processNext](true);
          }
        }
        constructor(maxConcurrency = 5) {
          Object.defineProperty(this, _processNext, {
            value: processNext,
          });
          Object.defineProperty(this, _maxConcurrency, {
            writable: true,
            value: void 0,
          });
          Object.defineProperty(this, _runningCount, {
            writable: true,
            value: void 0,
          });
          Object.defineProperty(this, _queue, {
            writable: true,
            value: void 0,
          });
          _class_private_field_loose_base._(this, _maxConcurrency)[_maxConcurrency] =
            maxConcurrency;
          _class_private_field_loose_base._(this, _runningCount)[_runningCount] = 0;
          _class_private_field_loose_base._(this, _queue)[_queue] = [];
        }
      }
      function processNext(forced) {
        if (forced === void 0) forced = false;
        if (
          (_class_private_field_loose_base._(this, _runningCount)[_runningCount] <
            _class_private_field_loose_base._(this, _maxConcurrency)[_maxConcurrency] ||
            forced) &&
          _class_private_field_loose_base._(this, _queue)[_queue].length > 0
        ) {
          var _class_private_field_loose_base__queue_shift;
          (_class_private_field_loose_base__queue_shift = _class_private_field_loose_base
            ._(this, _queue)
            [_queue].shift()) == null
            ? void 0
            : _class_private_field_loose_base__queue_shift.task();
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=promise-queue.js.map

      /***/
    },

    /***/ 4936: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "useRouterBFCache", {
        enumerable: true,
        get: function () {
          return useRouterBFCache;
        },
      });
      const _react = __webpack_require__(5127);
      // When the flag is disabled, only track the currently active tree
      const MAX_BF_CACHE_ENTRIES = false ? 0 : 1;
      function useRouterBFCache(activeTree, activeStateKey) {
        // The currently active entry. The entries form a linked list, sorted in
        // order of most recently active. This allows us to reuse parts of the list
        // without cloning, unless there's a reordering or removal.
        // TODO: Once we start tracking back/forward history at each route level,
        // we should use the history order instead. In other words, when traversing
        // to an existing entry as a result of a popstate event, we should maintain
        // the existing order instead of moving it to the front of the list. I think
        // an initial implementation of this could be to pass an incrementing id
        // to history.pushState/replaceState, then use that here for ordering.
        const [prevActiveEntry, setPrevActiveEntry] = (0, _react.useState)(() => {
          const initialEntry = {
            tree: activeTree,
            stateKey: activeStateKey,
            next: null,
          };
          return initialEntry;
        });
        if (prevActiveEntry.tree === activeTree) {
          // Fast path. The active tree hasn't changed, so we can reuse the
          // existing state.
          return prevActiveEntry;
        }
        // The route tree changed. Note that this doesn't mean that the tree changed
        // *at this level* — the change may be due to a child route. Either way, we
        // need to either add or update the router tree in the bfcache.
        //
        // The rest of the code looks more complicated than it actually is because we
        // can't mutate the state in place; we have to copy-on-write.
        // Create a new entry for the active cache key. This is the head of the new
        // linked list.
        const newActiveEntry = {
          tree: activeTree,
          stateKey: activeStateKey,
          next: null,
        };
        // We need to append the old list onto the new list. If the head of the new
        // list was already present in the cache, then we'll need to clone everything
        // that came before it. Then we can reuse the rest.
        let n = 1;
        let oldEntry = prevActiveEntry;
        let clonedEntry = newActiveEntry;
        while (oldEntry !== null && n < MAX_BF_CACHE_ENTRIES) {
          if (oldEntry.stateKey === activeStateKey) {
            // Fast path. This entry in the old list that corresponds to the key that
            // is now active. We've already placed a clone of this entry at the front
            // of the new list. We can reuse the rest of the old list without cloning.
            // NOTE: We don't need to worry about eviction in this case because we
            // haven't increased the size of the cache, and we assume the max size
            // is constant across renders. If we were to change it to a dynamic limit,
            // then the implementation would need to account for that.
            clonedEntry.next = oldEntry.next;
            break;
          } else {
            // Clone the entry and append it to the list.
            n++;
            const entry = {
              tree: oldEntry.tree,
              stateKey: oldEntry.stateKey,
              next: null,
            };
            clonedEntry.next = entry;
            clonedEntry = entry;
          }
          oldEntry = oldEntry.next;
        }
        setPrevActiveEntry(newActiveEntry);
        return newActiveEntry;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=bfcache.js.map

      /***/
    },

    /***/ 5003: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "applyRouterStatePatchToTree", {
        enumerable: true,
        get: function () {
          return applyRouterStatePatchToTree;
        },
      });
      const _segment = __webpack_require__(3388);
      const _flightdatahelpers = __webpack_require__(6081);
      const _matchsegments = __webpack_require__(1336);
      const _refetchinactiveparallelsegments = __webpack_require__(1241);
      /**
       * Deep merge of the two router states. Parallel route keys are preserved if the patch doesn't have them.
       */ function applyPatch(initialTree, patchTree) {
        const [initialSegment, initialParallelRoutes] = initialTree;
        const [patchSegment, patchParallelRoutes] = patchTree;
        // if the applied patch segment is __DEFAULT__ then it can be ignored in favor of the initial tree
        // this is because the __DEFAULT__ segment is used as a placeholder on navigation
        if (
          patchSegment === _segment.DEFAULT_SEGMENT_KEY &&
          initialSegment !== _segment.DEFAULT_SEGMENT_KEY
        ) {
          return initialTree;
        }
        if ((0, _matchsegments.matchSegment)(initialSegment, patchSegment)) {
          const newParallelRoutes = {};
          for (const key in initialParallelRoutes) {
            const isInPatchTreeParallelRoutes = typeof patchParallelRoutes[key] !== "undefined";
            if (isInPatchTreeParallelRoutes) {
              newParallelRoutes[key] = applyPatch(
                initialParallelRoutes[key],
                patchParallelRoutes[key],
              );
            } else {
              newParallelRoutes[key] = initialParallelRoutes[key];
            }
          }
          for (const key in patchParallelRoutes) {
            if (newParallelRoutes[key]) {
              continue;
            }
            newParallelRoutes[key] = patchParallelRoutes[key];
          }
          const tree = [initialSegment, newParallelRoutes];
          // Copy over the existing tree
          if (initialTree[2]) {
            tree[2] = initialTree[2];
          }
          if (initialTree[3]) {
            tree[3] = initialTree[3];
          }
          if (initialTree[4]) {
            tree[4] = initialTree[4];
          }
          return tree;
        }
        return patchTree;
      }
      function applyRouterStatePatchToTree(flightSegmentPath, flightRouterState, treePatch, path) {
        const [segment, parallelRoutes, url, refetch, isRootLayout] = flightRouterState;
        // Root refresh
        if (flightSegmentPath.length === 1) {
          const tree = applyPatch(flightRouterState, treePatch);
          (0, _refetchinactiveparallelsegments.addRefreshMarkerToActiveParallelSegments)(
            tree,
            path,
          );
          return tree;
        }
        const [currentSegment, parallelRouteKey] = flightSegmentPath;
        // Tree path returned from the server should always match up with the current tree in the browser
        if (!(0, _matchsegments.matchSegment)(currentSegment, segment)) {
          return null;
        }
        const lastSegment = flightSegmentPath.length === 2;
        let parallelRoutePatch;
        if (lastSegment) {
          parallelRoutePatch = applyPatch(parallelRoutes[parallelRouteKey], treePatch);
        } else {
          parallelRoutePatch = applyRouterStatePatchToTree(
            (0, _flightdatahelpers.getNextFlightSegmentPath)(flightSegmentPath),
            parallelRoutes[parallelRouteKey],
            treePatch,
            path,
          );
          if (parallelRoutePatch === null) {
            return null;
          }
        }
        const tree = [
          flightSegmentPath[0],
          {
            ...parallelRoutes,
            [parallelRouteKey]: parallelRoutePatch,
          },
          url,
          refetch,
        ];
        // Current segment is the root layout
        if (isRootLayout) {
          tree[4] = true;
        }
        (0, _refetchinactiveparallelsegments.addRefreshMarkerToActiveParallelSegments)(tree, path);
        return tree;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=apply-router-state-patch-to-tree.js.map

      /***/
    },

    /***/ 5005: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        generateSegmentsFromPatch: function () {
          return generateSegmentsFromPatch;
        },
        handleExternalUrl: function () {
          return handleExternalUrl;
        },
        navigateReducer: function () {
          return navigateReducer;
        },
      });
      const _fetchserverresponse = __webpack_require__(2682);
      const _createhreffromurl = __webpack_require__(8150);
      const _invalidatecachebelowflightsegmentpath = __webpack_require__(4585);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _shouldhardnavigate = __webpack_require__(54);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _routerreducertypes = __webpack_require__(9131);
      const _handlemutable = __webpack_require__(9466);
      const _applyflightdata = __webpack_require__(1437);
      const _prefetchreducer = __webpack_require__(3065);
      const _approuter = __webpack_require__(9701);
      const _segment = __webpack_require__(3388);
      const _pprnavigations = __webpack_require__(361);
      const _prefetchcacheutils = __webpack_require__(1991);
      const _clearcachenodedataforsegmentpath = __webpack_require__(3957);
      const _aliasedprefetchnavigations = __webpack_require__(602);
      const _segmentcache = __webpack_require__(5620);
      function handleExternalUrl(state, mutable, url, pendingPush) {
        mutable.mpaNavigation = true;
        mutable.canonicalUrl = url;
        mutable.pendingPush = pendingPush;
        mutable.scrollableSegments = undefined;
        return (0, _handlemutable.handleMutable)(state, mutable);
      }
      function generateSegmentsFromPatch(flightRouterPatch) {
        const segments = [];
        const [segment, parallelRoutes] = flightRouterPatch;
        if (Object.keys(parallelRoutes).length === 0) {
          return [[segment]];
        }
        for (const [parallelRouteKey, parallelRoute] of Object.entries(parallelRoutes)) {
          for (const childSegment of generateSegmentsFromPatch(parallelRoute)) {
            // If the segment is empty, it means we are at the root of the tree
            if (segment === "") {
              segments.push([parallelRouteKey, ...childSegment]);
            } else {
              segments.push([segment, parallelRouteKey, ...childSegment]);
            }
          }
        }
        return segments;
      }
      function triggerLazyFetchForLeafSegments(
        newCache,
        currentCache,
        flightSegmentPath,
        treePatch,
      ) {
        let appliedPatch = false;
        newCache.rsc = currentCache.rsc;
        newCache.prefetchRsc = currentCache.prefetchRsc;
        newCache.loading = currentCache.loading;
        newCache.parallelRoutes = new Map(currentCache.parallelRoutes);
        const segmentPathsToFill = generateSegmentsFromPatch(treePatch).map((segment) => [
          ...flightSegmentPath,
          ...segment,
        ]);
        for (const segmentPaths of segmentPathsToFill) {
          (0, _clearcachenodedataforsegmentpath.clearCacheNodeDataForSegmentPath)(
            newCache,
            currentCache,
            segmentPaths,
          );
          appliedPatch = true;
        }
        return appliedPatch;
      }
      function handleNavigationResult(url, state, mutable, pendingPush, result) {
        switch (result.tag) {
          case _segmentcache.NavigationResultTag.MPA: {
            // Perform an MPA navigation.
            const newUrl = result.data;
            return handleExternalUrl(state, mutable, newUrl, pendingPush);
          }
          case _segmentcache.NavigationResultTag.NoOp: {
            // The server responded with no change to the current page. However, if
            // the URL changed, we still need to update that.
            const newCanonicalUrl = result.data.canonicalUrl;
            mutable.canonicalUrl = newCanonicalUrl;
            // Check if the only thing that changed was the hash fragment.
            const oldUrl = new URL(state.canonicalUrl, url);
            const onlyHashChange = // navigations are always same-origin.
              url.pathname === oldUrl.pathname &&
              url.search === oldUrl.search &&
              url.hash !== oldUrl.hash;
            if (onlyHashChange) {
              // The only updated part of the URL is the hash.
              mutable.onlyHashChange = true;
              mutable.shouldScroll = result.data.shouldScroll;
              mutable.hashFragment = url.hash;
              // Setting this to an empty array triggers a scroll for all new and
              // updated segments. See `ScrollAndFocusHandler` for more details.
              mutable.scrollableSegments = [];
            }
            return (0, _handlemutable.handleMutable)(state, mutable);
          }
          case _segmentcache.NavigationResultTag.Success: {
            // Received a new result.
            mutable.cache = result.data.cacheNode;
            mutable.patchedTree = result.data.flightRouterState;
            mutable.canonicalUrl = result.data.canonicalUrl;
            mutable.scrollableSegments = result.data.scrollableSegments;
            mutable.shouldScroll = result.data.shouldScroll;
            mutable.hashFragment = result.data.hash;
            return (0, _handlemutable.handleMutable)(state, mutable);
          }
          case _segmentcache.NavigationResultTag.Async: {
            return result.data.then(
              (asyncResult) =>
                handleNavigationResult(url, state, mutable, pendingPush, asyncResult), // TODO: This matches the current behavior but we need to do something
              // better here if the network fails.
              () => {
                return state;
              },
            );
          }
          default: {
            result;
            return state;
          }
        }
      }
      function navigateReducer(state, action) {
        const { url, isExternalUrl, navigateType, shouldScroll, allowAliasing } = action;
        const mutable = {};
        const { hash } = url;
        const href = (0, _createhreffromurl.createHrefFromUrl)(url);
        const pendingPush = navigateType === "push";
        // we want to prune the prefetch cache on every navigation to avoid it growing too large
        (0, _prefetchcacheutils.prunePrefetchCache)(state.prefetchCache);
        mutable.preserveCustomHistoryState = false;
        mutable.pendingPush = pendingPush;
        if (isExternalUrl) {
          return handleExternalUrl(state, mutable, url.toString(), pendingPush);
        }
        // Handles case where `<meta http-equiv="refresh">` tag is present,
        // which will trigger an MPA navigation.
        if (document.getElementById("__next-page-redirect")) {
          return handleExternalUrl(state, mutable, href, pendingPush);
        }
        if (false) {
        }
        const prefetchValues = (0, _prefetchcacheutils.getOrCreatePrefetchCacheEntry)({
          url,
          nextUrl: state.nextUrl,
          tree: state.tree,
          prefetchCache: state.prefetchCache,
          allowAliasing,
        });
        const { treeAtTimeOfPrefetch, data } = prefetchValues;
        _prefetchreducer.prefetchQueue.bump(data);
        return data.then(
          (param) => {
            let { flightData, canonicalUrl: canonicalUrlOverride, postponed } = param;
            const navigatedAt = Date.now();
            let isFirstRead = false;
            // we only want to mark this once
            if (!prefetchValues.lastUsedTime) {
              // important: we should only mark the cache node as dirty after we unsuspend from the call above
              prefetchValues.lastUsedTime = navigatedAt;
              isFirstRead = true;
            }
            if (prefetchValues.aliased) {
              // When alias is enabled, search param may not be included in the canonicalUrl.
              // But we want to set url to canonicalUrl so that we use redirected path for fetching dynamic data.
              const urlWithCanonicalPathname = new URL(url.href);
              if (canonicalUrlOverride) {
                urlWithCanonicalPathname.pathname = canonicalUrlOverride.pathname;
              }
              const result = (0, _aliasedprefetchnavigations.handleAliasedPrefetchEntry)(
                navigatedAt,
                state,
                flightData,
                urlWithCanonicalPathname,
                mutable,
              );
              // We didn't return new router state because we didn't apply the aliased entry for some reason.
              // We'll re-invoke the navigation handler but ensure that we don't attempt to use the aliased entry. This
              // will create an on-demand prefetch entry.
              if (result === false) {
                return navigateReducer(state, {
                  ...action,
                  allowAliasing: false,
                });
              }
              return result;
            }
            // Handle case when navigating to page in `pages` from `app`
            if (typeof flightData === "string") {
              return handleExternalUrl(state, mutable, flightData, pendingPush);
            }
            const updatedCanonicalUrl = canonicalUrlOverride
              ? (0, _createhreffromurl.createHrefFromUrl)(canonicalUrlOverride)
              : href;
            const onlyHashChange =
              !!hash &&
              state.canonicalUrl.split("#", 1)[0] === updatedCanonicalUrl.split("#", 1)[0];
            // If only the hash has changed, the server hasn't sent us any new data. We can just update
            // the mutable properties responsible for URL and scroll handling and return early.
            if (onlyHashChange) {
              mutable.onlyHashChange = true;
              mutable.canonicalUrl = updatedCanonicalUrl;
              mutable.shouldScroll = shouldScroll;
              mutable.hashFragment = hash;
              mutable.scrollableSegments = [];
              return (0, _handlemutable.handleMutable)(state, mutable);
            }
            let currentTree = state.tree;
            let currentCache = state.cache;
            let scrollableSegments = [];
            for (const normalizedFlightData of flightData) {
              const {
                pathToSegment: flightSegmentPath,
                seedData,
                head,
                isHeadPartial,
                isRootRender,
              } = normalizedFlightData;
              let treePatch = normalizedFlightData.tree;
              // TODO-APP: remove ''
              const flightSegmentPathWithLeadingEmpty = ["", ...flightSegmentPath];
              // Create new tree based on the flightSegmentPath and router state patch
              let newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
                flightSegmentPathWithLeadingEmpty,
                currentTree,
                treePatch,
                href,
              );
              // If the tree patch can't be applied to the current tree then we use the tree at time of prefetch
              // TODO-APP: This should instead fill in the missing pieces in `currentTree` with the data from `treeAtTimeOfPrefetch`, then apply the patch.
              if (newTree === null) {
                newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
                  flightSegmentPathWithLeadingEmpty,
                  treeAtTimeOfPrefetch,
                  treePatch,
                  href,
                );
              }
              if (newTree !== null) {
                if (
                  // will send back a static response that's rendered from
                  // the root. If for some reason it doesn't, we fall back to the
                  // non-PPR implementation.
                  // TODO: We should get rid of the else branch and do all navigations
                  // via startPPRNavigation. The current structure is just
                  // an incremental step.
                  seedData &&
                  isRootRender &&
                  postponed
                ) {
                  const task = (0, _pprnavigations.startPPRNavigation)(
                    navigatedAt,
                    currentCache,
                    currentTree,
                    treePatch,
                    seedData,
                    head,
                    isHeadPartial,
                    false,
                    scrollableSegments,
                  );
                  if (task !== null) {
                    if (task.route === null) {
                      // Detected a change to the root layout. Perform an full-
                      // page navigation.
                      return handleExternalUrl(state, mutable, href, pendingPush);
                    }
                    // Use the tree computed by startPPRNavigation instead
                    // of the one computed by applyRouterStatePatchToTree.
                    // TODO: We should remove applyRouterStatePatchToTree
                    // from the PPR path entirely.
                    const patchedRouterState = task.route;
                    newTree = patchedRouterState;
                    const newCache = task.node;
                    if (newCache !== null) {
                      // We've created a new Cache Node tree that contains a prefetched
                      // version of the next page. This can be rendered instantly.
                      mutable.cache = newCache;
                    }
                    const dynamicRequestTree = task.dynamicRequestTree;
                    if (dynamicRequestTree !== null) {
                      // The prefetched tree has dynamic holes in it. We initiate a
                      // dynamic request to fill them in.
                      //
                      // Do not block on the result. We'll immediately render the Cache
                      // Node tree and suspend on the dynamic parts. When the request
                      // comes in, we'll fill in missing data and ping React to
                      // re-render. Unlike the lazy fetching model in the non-PPR
                      // implementation, this is modeled as a single React update +
                      // streaming, rather than multiple top-level updates. (However,
                      // even in the new model, we'll still need to sometimes update the
                      // root multiple times per navigation, like if the server sends us
                      // a different response than we expected. For now, we revert back
                      // to the lazy fetching mechanism in that case.)
                      const dynamicRequest = (0, _fetchserverresponse.fetchServerResponse)(
                        new URL(updatedCanonicalUrl, url.origin),
                        {
                          flightRouterState: dynamicRequestTree,
                          nextUrl: state.nextUrl,
                        },
                      );
                      (0, _pprnavigations.listenForDynamicRequest)(task, dynamicRequest);
                      // We store the dynamic request on the `lazyData` property of the CacheNode
                      // because we're not going to await the dynamic request here. Since we're not blocking
                      // on the dynamic request, `layout-router` will
                      // task.node.lazyData = dynamicRequest
                    } else {
                      // The prefetched tree does not contain dynamic holes — it's
                      // fully static. We can skip the dynamic request.
                    }
                  } else {
                    // Nothing changed, so reuse the old cache.
                    // TODO: What if the head changed but not any of the segment data?
                    // Is that possible? If so, we should clone the whole tree and
                    // update the head.
                    newTree = treePatch;
                  }
                } else {
                  // The static response does not include any dynamic holes, so
                  // there's no need to do a second request.
                  // TODO: As an incremental step this just reverts back to the
                  // non-PPR implementation. We can simplify this branch further,
                  // given that PPR prefetches are always static and return the whole
                  // tree. Or in the meantime we could factor it out into a
                  // separate function.
                  if (
                    (0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(
                      currentTree,
                      newTree,
                    )
                  ) {
                    return handleExternalUrl(state, mutable, href, pendingPush);
                  }
                  const cache = (0, _approuter.createEmptyCacheNode)();
                  let applied = false;
                  if (
                    prefetchValues.status === _routerreducertypes.PrefetchCacheEntryStatus.stale &&
                    !isFirstRead
                  ) {
                    // When we have a stale prefetch entry, we only want to re-use the loading state of the route we're navigating to, to support instant loading navigations
                    // this will trigger a lazy fetch for the actual page data by nulling the `rsc` and `prefetchRsc` values for page data,
                    // while copying over the `loading` for the segment that contains the page data.
                    // We only do this on subsequent reads, as otherwise there'd be no loading data to re-use.
                    // We skip this branch if only the hash fragment has changed, as we don't want to trigger a lazy fetch in that case
                    applied = triggerLazyFetchForLeafSegments(
                      cache,
                      currentCache,
                      flightSegmentPath,
                      treePatch,
                    );
                    // since we re-used the stale cache's loading state & refreshed the data,
                    // update the `lastUsedTime` so that it can continue to be re-used for the next 30s
                    prefetchValues.lastUsedTime = navigatedAt;
                  } else {
                    applied = (0, _applyflightdata.applyFlightData)(
                      navigatedAt,
                      currentCache,
                      cache,
                      normalizedFlightData,
                      prefetchValues,
                    );
                  }
                  const hardNavigate = (0, _shouldhardnavigate.shouldHardNavigate)(
                    flightSegmentPathWithLeadingEmpty,
                    currentTree,
                  );
                  if (hardNavigate) {
                    // Copy rsc for the root node of the cache.
                    cache.rsc = currentCache.rsc;
                    cache.prefetchRsc = currentCache.prefetchRsc;
                    (0,
                    _invalidatecachebelowflightsegmentpath.invalidateCacheBelowFlightSegmentPath)(
                      cache,
                      currentCache,
                      flightSegmentPath,
                    );
                    // Ensure the existing cache value is used when the cache was not invalidated.
                    mutable.cache = cache;
                  } else if (applied) {
                    mutable.cache = cache;
                    // If we applied the cache, we update the "current cache" value so any other
                    // segments in the FlightDataPath will be able to reference the updated cache.
                    currentCache = cache;
                  }
                  for (const subSegment of generateSegmentsFromPatch(treePatch)) {
                    const scrollableSegmentPath = [...flightSegmentPath, ...subSegment];
                    // Filter out the __DEFAULT__ paths as they shouldn't be scrolled to in this case.
                    if (
                      scrollableSegmentPath[scrollableSegmentPath.length - 1] !==
                      _segment.DEFAULT_SEGMENT_KEY
                    ) {
                      scrollableSegments.push(scrollableSegmentPath);
                    }
                  }
                }
                currentTree = newTree;
              }
            }
            mutable.patchedTree = currentTree;
            mutable.canonicalUrl = updatedCanonicalUrl;
            mutable.scrollableSegments = scrollableSegments;
            mutable.hashFragment = hash;
            mutable.shouldScroll = shouldScroll;
            return (0, _handlemutable.handleMutable)(state, mutable);
          },
          () => state,
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=navigate-reducer.js.map

      /***/
    },

    /***/ 5090: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createRenderSearchParamsFromClient", {
        enumerable: true,
        get: function () {
          return createRenderSearchParamsFromClient;
        },
      });
      const createRenderSearchParamsFromClient = false
        ? 0
        : __webpack_require__(6977).createRenderSearchParamsFromClient;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=search-params.browser.js.map

      /***/
    },

    /***/ 5127: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      if (true) {
        module.exports = __webpack_require__(7030);
      } else {
      }

      /***/
    },

    /***/ 5216: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * Removes the trailing slash for a given route or page path. Preserves the
       * root page. Examples:
       *   - `/foo/bar/` -> `/foo/bar`
       *   - `/foo/bar` -> `/foo/bar`
       *   - `/` -> `/`
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "removeTrailingSlash", {
        enumerable: true,
        get: function () {
          return removeTrailingSlash;
        },
      });
      function removeTrailingSlash(route) {
        return route.replace(/\/$/, "") || "/";
      } //# sourceMappingURL=remove-trailing-slash.js.map

      /***/
    },

    /***/ 5249: /***/ (module) => {
      var __dirname = "/";
      (function () {
        var e = {
          229: function (e) {
            var t = (e.exports = {});
            var r;
            var n;
            function defaultSetTimout() {
              throw new Error("setTimeout has not been defined");
            }
            function defaultClearTimeout() {
              throw new Error("clearTimeout has not been defined");
            }
            (function () {
              try {
                if (typeof setTimeout === "function") {
                  r = setTimeout;
                } else {
                  r = defaultSetTimout;
                }
              } catch (e) {
                r = defaultSetTimout;
              }
              try {
                if (typeof clearTimeout === "function") {
                  n = clearTimeout;
                } else {
                  n = defaultClearTimeout;
                }
              } catch (e) {
                n = defaultClearTimeout;
              }
            })();
            function runTimeout(e) {
              if (r === setTimeout) {
                return setTimeout(e, 0);
              }
              if ((r === defaultSetTimout || !r) && setTimeout) {
                r = setTimeout;
                return setTimeout(e, 0);
              }
              try {
                return r(e, 0);
              } catch (t) {
                try {
                  return r.call(null, e, 0);
                } catch (t) {
                  return r.call(this, e, 0);
                }
              }
            }
            function runClearTimeout(e) {
              if (n === clearTimeout) {
                return clearTimeout(e);
              }
              if ((n === defaultClearTimeout || !n) && clearTimeout) {
                n = clearTimeout;
                return clearTimeout(e);
              }
              try {
                return n(e);
              } catch (t) {
                try {
                  return n.call(null, e);
                } catch (t) {
                  return n.call(this, e);
                }
              }
            }
            var i = [];
            var o = false;
            var u;
            var a = -1;
            function cleanUpNextTick() {
              if (!o || !u) {
                return;
              }
              o = false;
              if (u.length) {
                i = u.concat(i);
              } else {
                a = -1;
              }
              if (i.length) {
                drainQueue();
              }
            }
            function drainQueue() {
              if (o) {
                return;
              }
              var e = runTimeout(cleanUpNextTick);
              o = true;
              var t = i.length;
              while (t) {
                u = i;
                i = [];
                while (++a < t) {
                  if (u) {
                    u[a].run();
                  }
                }
                a = -1;
                t = i.length;
              }
              u = null;
              o = false;
              runClearTimeout(e);
            }
            t.nextTick = function (e) {
              var t = new Array(arguments.length - 1);
              if (arguments.length > 1) {
                for (var r = 1; r < arguments.length; r++) {
                  t[r - 1] = arguments[r];
                }
              }
              i.push(new Item(e, t));
              if (i.length === 1 && !o) {
                runTimeout(drainQueue);
              }
            };
            function Item(e, t) {
              this.fun = e;
              this.array = t;
            }
            Item.prototype.run = function () {
              this.fun.apply(null, this.array);
            };
            t.title = "browser";
            t.browser = true;
            t.env = {};
            t.argv = [];
            t.version = "";
            t.versions = {};
            function noop() {}
            t.on = noop;
            t.addListener = noop;
            t.once = noop;
            t.off = noop;
            t.removeListener = noop;
            t.removeAllListeners = noop;
            t.emit = noop;
            t.prependListener = noop;
            t.prependOnceListener = noop;
            t.listeners = function (e) {
              return [];
            };
            t.binding = function (e) {
              throw new Error("process.binding is not supported");
            };
            t.cwd = function () {
              return "/";
            };
            t.chdir = function (e) {
              throw new Error("process.chdir is not supported");
            };
            t.umask = function () {
              return 0;
            };
          },
        };
        var t = {};
        function __nccwpck_require__(r) {
          var n = t[r];
          if (n !== undefined) {
            return n.exports;
          }
          var i = (t[r] = { exports: {} });
          var o = true;
          try {
            e[r](i, i.exports, __nccwpck_require__);
            o = false;
          } finally {
            if (o) delete t[r];
          }
          return i.exports;
        }
        if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = __dirname + "/";
        var r = __nccwpck_require__(229);
        module.exports = r;
      })();

      /***/
    },

    /***/ 5299: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /**
       * Before starting the Next.js runtime and requiring any module, we need to make
       * sure the following scripts are executed in the correct order:
       * - Polyfills
       * - next/script with `beforeInteractive` strategy
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "appBootstrap", {
        enumerable: true,
        get: function () {
          return appBootstrap;
        },
      });
      const _setattributesfromprops = __webpack_require__(7637);
      const version = "15.5.24";
      window.next = {
        version,
        appDir: true,
      };
      function loadScriptsInSequence(scripts, hydrate) {
        if (!scripts || !scripts.length) {
          return hydrate();
        }
        return scripts
          .reduce((promise, param) => {
            let [src, props] = param;
            return promise.then(() => {
              return new Promise((resolve, reject) => {
                const el = document.createElement("script");
                if (props) {
                  (0, _setattributesfromprops.setAttributesFromProps)(el, props);
                }
                if (src) {
                  el.src = src;
                  el.onload = () => resolve();
                  el.onerror = reject;
                } else if (props) {
                  el.innerHTML = props.children;
                  setTimeout(resolve);
                }
                document.head.appendChild(el);
              });
            });
          }, Promise.resolve())
          .catch((err) => {
            console.error(err);
            // Still try to hydrate even if there's an error.
          })
          .then(() => {
            hydrate();
          });
      }
      function appBootstrap(hydrate) {
        loadScriptsInSequence(self.__next_s, () => {
          // If the static shell is being debugged, skip hydration if the
          // `__nextppronly` query is present. This is only enabled when the
          // environment variable `__NEXT_EXPERIMENTAL_STATIC_SHELL_DEBUGGING` is
          // set to `1`. Otherwise the following is optimized out.
          if (false) {
          }
          hydrate();
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-bootstrap.js.map

      /***/
    },

    /***/ 5410: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "serverPatchReducer", {
        enumerable: true,
        get: function () {
          return serverPatchReducer;
        },
      });
      const _createhreffromurl = __webpack_require__(8150);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _navigatereducer = __webpack_require__(5005);
      const _applyflightdata = __webpack_require__(1437);
      const _handlemutable = __webpack_require__(9466);
      const _approuter = __webpack_require__(9701);
      function serverPatchReducer(state, action) {
        const {
          serverResponse: { flightData, canonicalUrl: canonicalUrlOverride },
          navigatedAt,
        } = action;
        const mutable = {};
        mutable.preserveCustomHistoryState = false;
        // Handle case when navigating to page in `pages` from `app`
        if (typeof flightData === "string") {
          return (0, _navigatereducer.handleExternalUrl)(
            state,
            mutable,
            flightData,
            state.pushRef.pendingPush,
          );
        }
        let currentTree = state.tree;
        let currentCache = state.cache;
        for (const normalizedFlightData of flightData) {
          const { segmentPath: flightSegmentPath, tree: treePatch } = normalizedFlightData;
          const newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
            ["", ...flightSegmentPath],
            currentTree,
            treePatch,
            state.canonicalUrl,
          );
          // `applyRouterStatePatchToTree` returns `null` when it determined that the server response is not applicable to the current tree.
          // In other words, the server responded with a tree that doesn't match what the client is currently rendering.
          // This can happen if the server patch action took longer to resolve than a subsequent navigation which would have changed the tree.
          // Previously this case triggered an MPA navigation but it should be safe to simply discard the server response rather than forcing
          // the entire page to reload.
          if (newTree === null) {
            return state;
          }
          if ((0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(currentTree, newTree)) {
            return (0, _navigatereducer.handleExternalUrl)(
              state,
              mutable,
              state.canonicalUrl,
              state.pushRef.pendingPush,
            );
          }
          const canonicalUrlOverrideHref = canonicalUrlOverride
            ? (0, _createhreffromurl.createHrefFromUrl)(canonicalUrlOverride)
            : undefined;
          if (canonicalUrlOverrideHref) {
            mutable.canonicalUrl = canonicalUrlOverrideHref;
          }
          const cache = (0, _approuter.createEmptyCacheNode)();
          (0, _applyflightdata.applyFlightData)(
            navigatedAt,
            currentCache,
            cache,
            normalizedFlightData,
          );
          mutable.patchedTree = newTree;
          mutable.cache = cache;
          currentCache = cache;
          currentTree = newTree;
        }
        return (0, _handlemutable.handleMutable)(state, mutable);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=server-patch-reducer.js.map

      /***/
    },

    /***/ 5475: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        GracefulDegradeBoundary: function () {
          return GracefulDegradeBoundary;
        },
        default: function () {
          return _default;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const _react = __webpack_require__(5127);
      function getDomNodeAttributes(node) {
        const result = {};
        for (let i = 0; i < node.attributes.length; i++) {
          const attr = node.attributes[i];
          result[attr.name] = attr.value;
        }
        return result;
      }
      class GracefulDegradeBoundary extends _react.Component {
        static getDerivedStateFromError(_) {
          return {
            hasError: true,
          };
        }
        componentDidMount() {
          const htmlNode = this.htmlRef.current;
          if (this.state.hasError && htmlNode) {
            // Reapply the cached HTML attributes to the root element
            Object.entries(this.htmlAttributes).forEach((param) => {
              let [key, value] = param;
              htmlNode.setAttribute(key, value);
            });
          }
        }
        render() {
          const { hasError } = this.state;
          // Cache the root HTML content on the first render
          if (true && !this.rootHtml) {
            this.rootHtml = document.documentElement.innerHTML;
            this.htmlAttributes = getDomNodeAttributes(document.documentElement);
          }
          if (hasError) {
            // Render the current HTML content without hydration
            return /*#__PURE__*/ (0, _jsxruntime.jsx)("html", {
              ref: this.htmlRef,
              suppressHydrationWarning: true,
              dangerouslySetInnerHTML: {
                __html: this.rootHtml,
              },
            });
          }
          return this.props.children;
        }
        constructor(props) {
          super(props);
          this.state = {
            hasError: false,
          };
          this.rootHtml = "";
          this.htmlAttributes = {};
          this.htmlRef = /*#__PURE__*/ (0, _react.createRef)();
        }
      }
      const _default = GracefulDegradeBoundary;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=graceful-degrade-boundary.js.map

      /***/
    },

    /***/ 5493: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      // imports polyfill from `@next/polyfill-module` after build.

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      __webpack_require__(6787);
      // Only setup devtools in development
      if (false) {
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-globals.js.map

      /***/
    },

    /***/ 5557: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ROOT_SEGMENT_CACHE_KEY: function () {
          return ROOT_SEGMENT_CACHE_KEY;
        },
        ROOT_SEGMENT_REQUEST_KEY: function () {
          return ROOT_SEGMENT_REQUEST_KEY;
        },
        appendSegmentCacheKeyPart: function () {
          return appendSegmentCacheKeyPart;
        },
        appendSegmentRequestKeyPart: function () {
          return appendSegmentRequestKeyPart;
        },
        convertSegmentPathToStaticExportFilename: function () {
          return convertSegmentPathToStaticExportFilename;
        },
        createSegmentCacheKeyPart: function () {
          return createSegmentCacheKeyPart;
        },
        createSegmentRequestKeyPart: function () {
          return createSegmentRequestKeyPart;
        },
      });
      const _segment = __webpack_require__(3388);
      const ROOT_SEGMENT_REQUEST_KEY = "";
      const ROOT_SEGMENT_CACHE_KEY = "";
      function createSegmentRequestKeyPart(segment) {
        if (typeof segment === "string") {
          if (segment.startsWith(_segment.PAGE_SEGMENT_KEY)) {
            // The Flight Router State type sometimes includes the search params in
            // the page segment. However, the Segment Cache tracks this as a separate
            // key. So, we strip the search params here, and then add them back when
            // the cache entry is turned back into a FlightRouterState. This is an
            // unfortunate consequence of the FlightRouteState being used both as a
            // transport type and as a cache key; we'll address this once more of the
            // Segment Cache implementation has settled.
            // TODO: We should hoist the search params out of the FlightRouterState
            // type entirely, This is our plan for dynamic route params, too.
            return _segment.PAGE_SEGMENT_KEY;
          }
          const safeName = // But params typically don't include the leading slash. We should use
            // a different encoding to avoid this special case.
            segment === "/_not-found" ? "_not-found" : encodeToFilesystemAndURLSafeString(segment);
          // Since this is not a dynamic segment, it's fully encoded. It does not
          // need to be "hydrated" with a param value.
          return safeName;
        }
        const name = segment[0];
        const paramType = segment[2];
        const safeName = encodeToFilesystemAndURLSafeString(name);
        const encodedName = "$" + paramType + "$" + safeName;
        return encodedName;
      }
      function appendSegmentRequestKeyPart(
        parentRequestKey,
        parallelRouteKey,
        childRequestKeyPart,
      ) {
        // Aside from being filesystem safe, segment keys are also designed so that
        // each segment and parallel route creates its own subdirectory. Roughly in
        // the same shape as the source app directory. This is mostly just for easier
        // debugging (you can open up the build folder and navigate the output); if
        // we wanted to do we could just use a flat structure.
        // Omit the parallel route key for children, since this is the most
        // common case. Saves some bytes (and it's what the app directory does).
        const slotKey =
          parallelRouteKey === "children"
            ? childRequestKeyPart
            : "@" +
              encodeToFilesystemAndURLSafeString(parallelRouteKey) +
              "/" +
              childRequestKeyPart;
        return parentRequestKey + "/" + slotKey;
      }
      function createSegmentCacheKeyPart(requestKeyPart, segment) {
        if (typeof segment === "string") {
          return requestKeyPart;
        }
        const paramValue = segment[1];
        const safeValue = encodeToFilesystemAndURLSafeString(paramValue);
        return requestKeyPart + "$" + safeValue;
      }
      function appendSegmentCacheKeyPart(parentSegmentKey, parallelRouteKey, childCacheKeyPart) {
        const slotKey =
          parallelRouteKey === "children"
            ? childCacheKeyPart
            : "@" + encodeToFilesystemAndURLSafeString(parallelRouteKey) + "/" + childCacheKeyPart;
        return parentSegmentKey + "/" + slotKey;
      }
      // Define a regex pattern to match the most common characters found in a route
      // param. It excludes anything that might not be cross-platform filesystem
      // compatible, like |. It does not need to be precise because the fallback is to
      // just base64url-encode the whole parameter, which is fine; we just don't do it
      // by default for compactness, and for easier debugging.
      const simpleParamValueRegex = /^[a-zA-Z0-9\-_@]+$/;
      function encodeToFilesystemAndURLSafeString(value) {
        if (simpleParamValueRegex.test(value)) {
          return value;
        }
        // If there are any unsafe characters, base64url-encode the entire value.
        // We also add a ! prefix so it doesn't collide with the simple case.
        const base64url = btoa(value)
          .replace(/\+/g, "-") // Replace '+' with '-'
          .replace(/\//g, "_") // Replace '/' with '_'
          .replace(/=+$/, ""); // Remove trailing '='
        return "!" + base64url;
      }
      function convertSegmentPathToStaticExportFilename(segmentPath) {
        return "__next" + segmentPath.replace(/\//g, ".") + ".txt";
      } //# sourceMappingURL=segment-value-encoding.js.map

      /***/
    },

    /***/ 5617: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        computeCacheBustingSearchParam: function () {
          return computeCacheBustingSearchParam;
        },
        computeLegacyCacheBustingSearchParam: function () {
          return computeLegacyCacheBustingSearchParam;
        },
      });
      const _hash = __webpack_require__(207);
      const CACHE_BUSTING_SEARCH_PARAM_DIGEST_BYTES = 12;
      const textEncoder = new TextEncoder();
      function encodeCacheBustingSearchParam(bytes) {
        let binary = "";
        for (let i = 0; i < bytes.length; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
      }
      function normalizeCacheBustingInput(value) {
        if (value === undefined) {
          return "0";
        }
        return Array.isArray(value) ? value.join(",") : value;
      }
      function createCacheBustingSearchParamInput(
        prefetchHeader,
        segmentPrefetchHeader,
        stateTreeHeader,
        nextUrlHeader,
      ) {
        if (
          (prefetchHeader === undefined || prefetchHeader === "0") &&
          segmentPrefetchHeader === undefined &&
          stateTreeHeader === undefined &&
          nextUrlHeader === undefined
        ) {
          return null;
        }
        return [
          prefetchHeader != null ? prefetchHeader : "0",
          normalizeCacheBustingInput(segmentPrefetchHeader),
          normalizeCacheBustingInput(stateTreeHeader),
          normalizeCacheBustingInput(nextUrlHeader),
        ].join(",");
      }
      async function computeCacheBustingSearchParamFromInput(input) {
        // Truncate SHA-256 to 96 bits to keep `_rsc` compact
        const digest = await globalThis.crypto.subtle.digest("SHA-256", textEncoder.encode(input));
        return encodeCacheBustingSearchParam(
          new Uint8Array(digest).subarray(0, CACHE_BUSTING_SEARCH_PARAM_DIGEST_BYTES),
        );
      }
      async function computeCacheBustingSearchParam(
        prefetchHeader,
        segmentPrefetchHeader,
        stateTreeHeader,
        nextUrlHeader,
      ) {
        const input = createCacheBustingSearchParamInput(
          prefetchHeader,
          segmentPrefetchHeader,
          stateTreeHeader,
          nextUrlHeader,
        );
        if (input === null) {
          return "";
        }
        return computeCacheBustingSearchParamFromInput(input);
      }
      function computeLegacyCacheBustingSearchParam(
        prefetchHeader,
        segmentPrefetchHeader,
        stateTreeHeader,
        nextUrlHeader,
      ) {
        const input = createCacheBustingSearchParamInput(
          prefetchHeader,
          segmentPrefetchHeader,
          stateTreeHeader,
          nextUrlHeader,
        );
        if (input === null) {
          return "";
        }
        return (0, _hash.hexHash)(input);
      } //# sourceMappingURL=cache-busting-search-param.js.map

      /***/
    },

    /***/ 5620: /***/ (module, exports) => {
      "use strict";
      /**
       * Entry point to the Segment Cache implementation.
       *
       * All code related to the Segment Cache lives `segment-cache-impl` directory.
       * Callers access it through this indirection.
       *
       * This is to ensure the code is dead code eliminated from the bundle if the
       * flag is disabled.
       *
       * TODO: This is super tedious. Since experimental flags are an essential part
       * of our workflow, we should establish a better pattern for dead code
       * elimination. Ideally it would be done at the bundler level, like how React's
       * build process works. In the React repo, you don't even need to add any extra
       * configuration per experiment — if the code is not reachable, it gets stripped
       * from the build automatically by Rollup. Or, shorter term, we could stub out
       * experimental modules at build time by updating the build config, i.e. a more
       * automated version of what I'm doing manually in this file.
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        FetchStrategy: function () {
          return FetchStrategy;
        },
        NavigationResultTag: function () {
          return NavigationResultTag;
        },
        PrefetchPriority: function () {
          return PrefetchPriority;
        },
        cancelPrefetchTask: function () {
          return cancelPrefetchTask;
        },
        createCacheKey: function () {
          return createCacheKey;
        },
        getCurrentCacheVersion: function () {
          return getCurrentCacheVersion;
        },
        isPrefetchTaskDirty: function () {
          return isPrefetchTaskDirty;
        },
        navigate: function () {
          return navigate;
        },
        prefetch: function () {
          return prefetch;
        },
        reschedulePrefetchTask: function () {
          return reschedulePrefetchTask;
        },
        revalidateEntireCache: function () {
          return revalidateEntireCache;
        },
        schedulePrefetchTask: function () {
          return schedulePrefetchTask;
        },
      });
      const notEnabled = () => {
        throw Object.defineProperty(
          new Error("Segment Cache experiment is not enabled. This is a bug in Next.js."),
          "__NEXT_ERROR_CODE",
          {
            value: "E654",
            enumerable: false,
            configurable: true,
          },
        );
      };
      const prefetch = false ? 0 : notEnabled;
      const navigate = false ? 0 : notEnabled;
      const revalidateEntireCache = false ? 0 : notEnabled;
      const getCurrentCacheVersion = false ? 0 : notEnabled;
      const schedulePrefetchTask = false ? 0 : notEnabled;
      const cancelPrefetchTask = false ? 0 : notEnabled;
      const reschedulePrefetchTask = false ? 0 : notEnabled;
      const isPrefetchTaskDirty = false ? 0 : notEnabled;
      const createCacheKey = false ? 0 : notEnabled;
      var NavigationResultTag = /*#__PURE__*/ (function (NavigationResultTag) {
        NavigationResultTag[(NavigationResultTag["MPA"] = 0)] = "MPA";
        NavigationResultTag[(NavigationResultTag["Success"] = 1)] = "Success";
        NavigationResultTag[(NavigationResultTag["NoOp"] = 2)] = "NoOp";
        NavigationResultTag[(NavigationResultTag["Async"] = 3)] = "Async";
        return NavigationResultTag;
      })({});
      var PrefetchPriority = /*#__PURE__*/ (function (PrefetchPriority) {
        /**
         * Assigned to the most recently hovered/touched link. Special network
         * bandwidth is reserved for this task only. There's only ever one Intent-
         * priority task at a time; when a new Intent task is scheduled, the previous
         * one is bumped down to Default.
         */ PrefetchPriority[(PrefetchPriority["Intent"] = 2)] = "Intent";
        /**
         * The default priority for prefetch tasks.
         */ PrefetchPriority[(PrefetchPriority["Default"] = 1)] = "Default";
        /**
         * Assigned to tasks when they spawn non-blocking background work, like
         * revalidating a partially cached entry to see if more data is available.
         */ PrefetchPriority[(PrefetchPriority["Background"] = 0)] = "Background";
        return PrefetchPriority;
      })({});
      var FetchStrategy = /*#__PURE__*/ (function (FetchStrategy) {
        // Deliberately ordered so we can easily compare two segments
        // and determine if one segment is "more specific" than another
        // (i.e. if it's likely that it contains more data)
        FetchStrategy[(FetchStrategy["LoadingBoundary"] = 0)] = "LoadingBoundary";
        FetchStrategy[(FetchStrategy["PPR"] = 1)] = "PPR";
        FetchStrategy[(FetchStrategy["PPRRuntime"] = 2)] = "PPRRuntime";
        FetchStrategy[(FetchStrategy["Full"] = 3)] = "Full";
        return FetchStrategy;
      })({});
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=segment-cache.js.map

      /***/
    },

    /***/ 5680: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "HandleISRError", {
        enumerable: true,
        get: function () {
          return HandleISRError;
        },
      });
      const workAsyncStorage = false ? 0 : undefined;
      function HandleISRError(param) {
        let { error } = param;
        if (workAsyncStorage) {
          const store = workAsyncStorage.getStore();
          if (
            (store == null ? void 0 : store.isRevalidate) ||
            (store == null ? void 0 : store.isStaticGeneration)
          ) {
            console.error(error);
            throw error;
          }
        }
        return null;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=handle-isr-error.js.map

      /***/
    },

    /***/ 5703: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createRenderParamsFromClient", {
        enumerable: true,
        get: function () {
          return createRenderParamsFromClient;
        },
      });
      const createRenderParamsFromClient = false
        ? 0
        : __webpack_require__(8734).createRenderParamsFromClient;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=params.browser.js.map

      /***/
    },

    /***/ 5826: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "restoreReducer", {
        enumerable: true,
        get: function () {
          return restoreReducer;
        },
      });
      const _createhreffromurl = __webpack_require__(8150);
      const _computechangedpath = __webpack_require__(6107);
      const _pprnavigations = __webpack_require__(361);
      function restoreReducer(state, action) {
        const { url, tree } = action;
        const href = (0, _createhreffromurl.createHrefFromUrl)(url);
        // This action is used to restore the router state from the history state.
        // However, it's possible that the history state no longer contains the `FlightRouterState`.
        // We will copy over the internal state on pushState/replaceState events, but if a history entry
        // occurred before hydration, or if the user navigated to a hash using a regular anchor link,
        // the history state will not contain the `FlightRouterState`.
        // In this case, we'll continue to use the existing tree so the router doesn't get into an invalid state.
        const treeToRestore = tree || state.tree;
        const oldCache = state.cache;
        const newCache = false // prevents an unnecessary flash back to PPR state during a
          ? // back/forward navigation.
            0
          : oldCache;
        var _extractPathFromFlightRouterState;
        return {
          // Set canonical url
          canonicalUrl: href,
          pushRef: {
            pendingPush: false,
            mpaNavigation: false,
            // Ensures that the custom history state that was set is preserved when applying this update.
            preserveCustomHistoryState: true,
          },
          focusAndScrollRef: state.focusAndScrollRef,
          cache: newCache,
          prefetchCache: state.prefetchCache,
          // Restore provided tree
          tree: treeToRestore,
          nextUrl:
            (_extractPathFromFlightRouterState = (0,
            _computechangedpath.extractPathFromFlightRouterState)(treeToRestore)) != null
              ? _extractPathFromFlightRouterState
              : url.pathname,
        };
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=restore-reducer.js.map

      /***/
    },

    /***/ 5830: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "default", {
        enumerable: true,
        get: function () {
          return RootErrorBoundary;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(5127));
      const _gracefuldegradeboundary = /*#__PURE__*/ _interop_require_default._(
        __webpack_require__(5475),
      );
      const _errorboundary = __webpack_require__(917);
      const _isbot = __webpack_require__(8245);
      const isBotUserAgent = true && (0, _isbot.isBot)(window.navigator.userAgent);
      function RootErrorBoundary(param) {
        let { children, errorComponent, errorStyles, errorScripts } = param;
        if (isBotUserAgent) {
          // Preserve existing DOM/HTML for bots to avoid replacing content with an error UI
          // and to keep the original SSR output intact.
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(_gracefuldegradeboundary.default, {
            children: children,
          });
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_errorboundary.ErrorBoundary, {
          errorComponent: errorComponent,
          errorStyles: errorStyles,
          errorScripts: errorScripts,
          children: children,
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=root-error-boundary.js.map

      /***/
    },

    /***/ 5912: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "handleSegmentMismatch", {
        enumerable: true,
        get: function () {
          return handleSegmentMismatch;
        },
      });
      const _navigatereducer = __webpack_require__(5005);
      function handleSegmentMismatch(state, action, treePatch) {
        if (false) {
        }
        return (0, _navigatereducer.handleExternalUrl)(state, {}, state.canonicalUrl, true);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=handle-segment-mismatch.js.map

      /***/
    },

    /***/ 6066: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createRouterCacheKey", {
        enumerable: true,
        get: function () {
          return createRouterCacheKey;
        },
      });
      const _segment = __webpack_require__(3388);
      function createRouterCacheKey(segment, withoutSearchParameters) {
        if (withoutSearchParameters === void 0) withoutSearchParameters = false;
        // if the segment is an array, it means it's a dynamic segment
        // for example, ['lang', 'en', 'd']. We need to convert it to a string to store it as a cache node key.
        if (Array.isArray(segment)) {
          return segment[0] + "|" + segment[1] + "|" + segment[2];
        }
        // Page segments might have search parameters, ie __PAGE__?foo=bar
        // When `withoutSearchParameters` is true, we only want to return the page segment
        if (withoutSearchParameters && segment.startsWith(_segment.PAGE_SEGMENT_KEY)) {
          return _segment.PAGE_SEGMENT_KEY;
        }
        return segment;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=create-router-cache-key.js.map

      /***/
    },

    /***/ 6081: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        getFlightDataPartsFromPath: function () {
          return getFlightDataPartsFromPath;
        },
        getNextFlightSegmentPath: function () {
          return getNextFlightSegmentPath;
        },
        normalizeFlightData: function () {
          return normalizeFlightData;
        },
        prepareFlightRouterStateForRequest: function () {
          return prepareFlightRouterStateForRequest;
        },
      });
      const _segment = __webpack_require__(3388);
      function getFlightDataPartsFromPath(flightDataPath) {
        // Pick the last 4 items from the `FlightDataPath` to get the [tree, seedData, viewport, isHeadPartial].
        const flightDataPathLength = 4;
        // tree, seedData, and head are *always* the last three items in the `FlightDataPath`.
        const [tree, seedData, head, isHeadPartial] = flightDataPath.slice(-flightDataPathLength);
        // The `FlightSegmentPath` is everything except the last three items. For a root render, it won't be present.
        const segmentPath = flightDataPath.slice(0, -flightDataPathLength);
        var _segmentPath_;
        return {
          // TODO: Unify these two segment path helpers. We are inconsistently pushing an empty segment ("")
          // to the start of the segment path in some places which makes it hard to use solely the segment path.
          // Look for "// TODO-APP: remove ''" in the codebase.
          pathToSegment: segmentPath.slice(0, -1),
          segmentPath,
          // if the `FlightDataPath` corresponds with the root, there'll be no segment path,
          // in which case we default to ''.
          segment:
            (_segmentPath_ = segmentPath[segmentPath.length - 1]) != null ? _segmentPath_ : "",
          tree,
          seedData,
          head,
          isHeadPartial,
          isRootRender: flightDataPath.length === flightDataPathLength,
        };
      }
      function getNextFlightSegmentPath(flightSegmentPath) {
        // Since `FlightSegmentPath` is a repeated tuple of `Segment` and `ParallelRouteKey`, we slice off two items
        // to get the next segment path.
        return flightSegmentPath.slice(2);
      }
      function normalizeFlightData(flightData) {
        // FlightData can be a string when the server didn't respond with a proper flight response,
        // or when a redirect happens, to signal to the client that it needs to perform an MPA navigation.
        if (typeof flightData === "string") {
          return flightData;
        }
        return flightData.map((flightDataPath) => getFlightDataPartsFromPath(flightDataPath));
      }
      function prepareFlightRouterStateForRequest(flightRouterState, isHmrRefresh) {
        // HMR requests need the complete, unmodified state for proper functionality
        if (isHmrRefresh) {
          return encodeURIComponent(JSON.stringify(flightRouterState));
        }
        return encodeURIComponent(
          JSON.stringify(stripClientOnlyDataFromFlightRouterState(flightRouterState)),
        );
      }
      /**
       * Recursively strips client-only data from FlightRouterState while preserving
       * server-needed information for proper rendering decisions.
       */ function stripClientOnlyDataFromFlightRouterState(flightRouterState) {
        const [segment, parallelRoutes, _url, refreshMarker, isRootLayout, hasLoadingBoundary] =
          flightRouterState;
        // __PAGE__ segments are always fetched from the server, so there's
        // no need to send them up
        const cleanedSegment = stripSearchParamsFromPageSegment(segment);
        // Recursively process parallel routes
        const cleanedParallelRoutes = {};
        for (const [key, childState] of Object.entries(parallelRoutes)) {
          cleanedParallelRoutes[key] = stripClientOnlyDataFromFlightRouterState(childState);
        }
        const result = [
          cleanedSegment,
          cleanedParallelRoutes,
          null,
          shouldPreserveRefreshMarker(refreshMarker) ? refreshMarker : null,
        ];
        // Append optional fields if present
        if (isRootLayout !== undefined) {
          result[4] = isRootLayout;
        }
        if (hasLoadingBoundary !== undefined) {
          result[5] = hasLoadingBoundary;
        }
        return result;
      }
      /**
       * Strips search parameters from __PAGE__ segments to prevent sensitive
       * client-side data from being sent to the server.
       */ function stripSearchParamsFromPageSegment(segment) {
        if (typeof segment === "string" && segment.startsWith(_segment.PAGE_SEGMENT_KEY + "?")) {
          return _segment.PAGE_SEGMENT_KEY;
        }
        return segment;
      }
      /**
       * Determines whether the refresh marker should be sent to the server
       * Client-only markers like 'refresh' are stripped, while server-needed markers
       * like 'refetch' and 'inside-shared-layout' are preserved.
       */ function shouldPreserveRefreshMarker(refreshMarker) {
        return Boolean(refreshMarker && refreshMarker !== "refresh");
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=flight-data-helpers.js.map

      /***/
    },

    /***/ 6107: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        computeChangedPath: function () {
          return computeChangedPath;
        },
        extractPathFromFlightRouterState: function () {
          return extractPathFromFlightRouterState;
        },
        getSelectedParams: function () {
          return getSelectedParams;
        },
      });
      const _interceptionroutes = __webpack_require__(2826);
      const _segment = __webpack_require__(3388);
      const _matchsegments = __webpack_require__(1336);
      const removeLeadingSlash = (segment) => {
        return segment[0] === "/" ? segment.slice(1) : segment;
      };
      const segmentToPathname = (segment) => {
        if (typeof segment === "string") {
          // 'children' is not a valid path -- it's technically a parallel route that corresponds with the current segment's page
          // if we don't skip it, then the computed pathname might be something like `/children` which doesn't make sense.
          if (segment === "children") return "";
          return segment;
        }
        return segment[1];
      };
      function normalizeSegments(segments) {
        return (
          segments.reduce((acc, segment) => {
            segment = removeLeadingSlash(segment);
            if (segment === "" || (0, _segment.isGroupSegment)(segment)) {
              return acc;
            }
            return acc + "/" + segment;
          }, "") || "/"
        );
      }
      function extractPathFromFlightRouterState(flightRouterState) {
        const segment = Array.isArray(flightRouterState[0])
          ? flightRouterState[0][1]
          : flightRouterState[0];
        if (
          segment === _segment.DEFAULT_SEGMENT_KEY ||
          _interceptionroutes.INTERCEPTION_ROUTE_MARKERS.some((m) => segment.startsWith(m))
        )
          return undefined;
        if (segment.startsWith(_segment.PAGE_SEGMENT_KEY)) return "";
        const segments = [segmentToPathname(segment)];
        var _flightRouterState_;
        const parallelRoutes =
          (_flightRouterState_ = flightRouterState[1]) != null ? _flightRouterState_ : {};
        const childrenPath = parallelRoutes.children
          ? extractPathFromFlightRouterState(parallelRoutes.children)
          : undefined;
        if (childrenPath !== undefined) {
          segments.push(childrenPath);
        } else {
          for (const [key, value] of Object.entries(parallelRoutes)) {
            if (key === "children") continue;
            const childPath = extractPathFromFlightRouterState(value);
            if (childPath !== undefined) {
              segments.push(childPath);
            }
          }
        }
        return normalizeSegments(segments);
      }
      function computeChangedPathImpl(treeA, treeB) {
        const [segmentA, parallelRoutesA] = treeA;
        const [segmentB, parallelRoutesB] = treeB;
        const normalizedSegmentA = segmentToPathname(segmentA);
        const normalizedSegmentB = segmentToPathname(segmentB);
        if (
          _interceptionroutes.INTERCEPTION_ROUTE_MARKERS.some(
            (m) => normalizedSegmentA.startsWith(m) || normalizedSegmentB.startsWith(m),
          )
        ) {
          return "";
        }
        if (!(0, _matchsegments.matchSegment)(segmentA, segmentB)) {
          var _extractPathFromFlightRouterState;
          // once we find where the tree changed, we compute the rest of the path by traversing the tree
          return (_extractPathFromFlightRouterState = extractPathFromFlightRouterState(treeB)) !=
            null
            ? _extractPathFromFlightRouterState
            : "";
        }
        for (const parallelRouterKey in parallelRoutesA) {
          if (parallelRoutesB[parallelRouterKey]) {
            const changedPath = computeChangedPathImpl(
              parallelRoutesA[parallelRouterKey],
              parallelRoutesB[parallelRouterKey],
            );
            if (changedPath !== null) {
              return segmentToPathname(segmentB) + "/" + changedPath;
            }
          }
        }
        return null;
      }
      function computeChangedPath(treeA, treeB) {
        const changedPath = computeChangedPathImpl(treeA, treeB);
        if (changedPath == null || changedPath === "/") {
          return changedPath;
        }
        // lightweight normalization to remove route groups
        return normalizeSegments(changedPath.split("/"));
      }
      function getSelectedParams(currentTree, params) {
        if (params === void 0) params = {};
        const parallelRoutes = currentTree[1];
        for (const parallelRoute of Object.values(parallelRoutes)) {
          const segment = parallelRoute[0];
          const isDynamicParameter = Array.isArray(segment);
          const segmentValue = isDynamicParameter ? segment[1] : segment;
          if (!segmentValue || segmentValue.startsWith(_segment.PAGE_SEGMENT_KEY)) continue;
          // Ensure catchAll and optional catchall are turned into an array
          const isCatchAll = isDynamicParameter && (segment[2] === "c" || segment[2] === "oc");
          if (isCatchAll) {
            params[segment[0]] = segment[1].split("/");
          } else if (isDynamicParameter) {
            params[segment[0]] = segment[1];
          }
          params = getSelectedParams(parallelRoute, params);
        }
        return params;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=compute-changed-path.js.map

      /***/
    },

    /***/ 6257: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "hydrate", {
        enumerable: true,
        get: function () {
          return hydrate;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      __webpack_require__(5493);
      const _client = /*#__PURE__*/ _interop_require_default._(__webpack_require__(6673));
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _client1 = __webpack_require__(9169);
      const _headmanagercontextsharedruntime = __webpack_require__(2037);
      const _onrecoverableerror = __webpack_require__(9825);
      const _errorboundarycallbacks = __webpack_require__(7448);
      const _appcallserver = __webpack_require__(9837);
      const _appfindsourcemapurl = __webpack_require__(8213);
      const _approuterinstance = __webpack_require__(7267);
      const _approuter = /*#__PURE__*/ _interop_require_default._(__webpack_require__(9701));
      const _createinitialrouterstate = __webpack_require__(8732);
      const _approutercontextsharedruntime = __webpack_require__(6764);
      const _appbuildid = __webpack_require__(8021);
      /// <reference types="react-dom/experimental" />
      const createFromReadableStream = _client1.createFromReadableStream;
      const appElement = document;
      const encoder = new TextEncoder();
      let initialServerDataBuffer = undefined;
      let initialServerDataWriter = undefined;
      let initialServerDataLoaded = false;
      let initialServerDataFlushed = false;
      let initialFormStateData = null;
      function nextServerDataCallback(seg) {
        if (seg[0] === 0) {
          initialServerDataBuffer = [];
        } else if (seg[0] === 1) {
          if (!initialServerDataBuffer)
            throw Object.defineProperty(
              new Error("Unexpected server data: missing bootstrap script."),
              "__NEXT_ERROR_CODE",
              {
                value: "E18",
                enumerable: false,
                configurable: true,
              },
            );
          if (initialServerDataWriter) {
            initialServerDataWriter.enqueue(encoder.encode(seg[1]));
          } else {
            initialServerDataBuffer.push(seg[1]);
          }
        } else if (seg[0] === 2) {
          initialFormStateData = seg[1];
        } else if (seg[0] === 3) {
          if (!initialServerDataBuffer)
            throw Object.defineProperty(
              new Error("Unexpected server data: missing bootstrap script."),
              "__NEXT_ERROR_CODE",
              {
                value: "E18",
                enumerable: false,
                configurable: true,
              },
            );
          // Decode the base64 string back to binary data.
          const binaryString = atob(seg[1]);
          const decodedChunk = new Uint8Array(binaryString.length);
          for (var i = 0; i < binaryString.length; i++) {
            decodedChunk[i] = binaryString.charCodeAt(i);
          }
          if (initialServerDataWriter) {
            initialServerDataWriter.enqueue(decodedChunk);
          } else {
            initialServerDataBuffer.push(decodedChunk);
          }
        }
      }
      function isStreamErrorOrUnfinished(ctr) {
        // If `desiredSize` is null, it means the stream is closed or errored. If it is lower than 0, the stream is still unfinished.
        return ctr.desiredSize === null || ctr.desiredSize < 0;
      }
      // There might be race conditions between `nextServerDataRegisterWriter` and
      // `DOMContentLoaded`. The former will be called when React starts to hydrate
      // the root, the latter will be called when the DOM is fully loaded.
      // For streaming, the former is called first due to partial hydration.
      // For non-streaming, the latter can be called first.
      // Hence, we use two variables `initialServerDataLoaded` and
      // `initialServerDataFlushed` to make sure the writer will be closed and
      // `initialServerDataBuffer` will be cleared in the right time.
      function nextServerDataRegisterWriter(ctr) {
        if (initialServerDataBuffer) {
          initialServerDataBuffer.forEach((val) => {
            ctr.enqueue(typeof val === "string" ? encoder.encode(val) : val);
          });
          if (initialServerDataLoaded && !initialServerDataFlushed) {
            if (isStreamErrorOrUnfinished(ctr)) {
              ctr.error(
                Object.defineProperty(
                  new Error(
                    "The connection to the page was unexpectedly closed, possibly due to the stop button being clicked, loss of Wi-Fi, or an unstable internet connection.",
                  ),
                  "__NEXT_ERROR_CODE",
                  {
                    value: "E117",
                    enumerable: false,
                    configurable: true,
                  },
                ),
              );
            } else {
              ctr.close();
            }
            initialServerDataFlushed = true;
            initialServerDataBuffer = undefined;
          }
        }
        initialServerDataWriter = ctr;
      }
      // When `DOMContentLoaded`, we can close all pending writers to finish hydration.
      const DOMContentLoaded = function () {
        if (initialServerDataWriter && !initialServerDataFlushed) {
          initialServerDataWriter.close();
          initialServerDataFlushed = true;
          initialServerDataBuffer = undefined;
        }
        initialServerDataLoaded = true;
      };
      // It's possible that the DOM is already loaded.
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", DOMContentLoaded, false);
      } else {
        // Delayed in marco task to ensure it's executed later than hydration
        setTimeout(DOMContentLoaded);
      }
      const nextServerDataLoadingGlobal = (self.__next_f = self.__next_f || []);
      nextServerDataLoadingGlobal.forEach(nextServerDataCallback);
      nextServerDataLoadingGlobal.push = nextServerDataCallback;
      const readable = new ReadableStream({
        start(controller) {
          nextServerDataRegisterWriter(controller);
        },
      });
      const initialServerResponse = createFromReadableStream(readable, {
        callServer: _appcallserver.callServer,
        findSourceMapURL: _appfindsourcemapurl.findSourceMapURL,
      });
      function ServerRoot(param) {
        let { pendingActionQueue } = param;
        const initialRSCPayload = (0, _react.use)(initialServerResponse);
        const actionQueue = (0, _react.use)(pendingActionQueue);
        const router = /*#__PURE__*/ (0, _jsxruntime.jsx)(_approuter.default, {
          actionQueue: actionQueue,
          globalErrorState: initialRSCPayload.G,
          assetPrefix: initialRSCPayload.p,
        });
        if (false) {
        }
        return router;
      }
      const StrictModeIfEnabled = true ? _react.default.StrictMode : 0;
      function Root(param) {
        let { children } = param;
        if (false) {
        }
        return children;
      }
      function onDefaultTransitionIndicator() {
        // TODO: Compose default with user-configureable (e.g. nprogress)
        // TODO: Use React's default once we figure out hanging indicators: https://codesandbox.io/p/sandbox/charming-moon-hktkp6?file=%2Fsrc%2Findex.js%3A106%2C30
        return () => {};
      }
      const reactRootOptions = {
        onDefaultTransitionIndicator: onDefaultTransitionIndicator,
        onRecoverableError: _onrecoverableerror.onRecoverableError,
        onCaughtError: _errorboundarycallbacks.onCaughtError,
        onUncaughtError: _errorboundarycallbacks.onUncaughtError,
      };
      function hydrate(instrumentationHooks) {
        // React overrides `.then` and doesn't return a new promise chain,
        // so we wrap the action queue in a promise to ensure that its value
        // is defined when the promise resolves.
        // https://github.com/facebook/react/blob/163365a07872337e04826c4f501565d43dbd2fd4/packages/react-client/src/ReactFlightClient.js#L189-L190
        const pendingActionQueue = new Promise((resolve, reject) => {
          initialServerResponse.then(
            (initialRSCPayload) => {
              // setAppBuildId should be called only once, during JS initialization
              // and before any components have hydrated.
              (0, _appbuildid.setAppBuildId)(initialRSCPayload.b);
              const initialTimestamp = Date.now();
              resolve(
                (0, _approuterinstance.createMutableActionQueue)(
                  (0, _createinitialrouterstate.createInitialRouterState)({
                    navigatedAt: initialTimestamp,
                    initialFlightData: initialRSCPayload.f,
                    initialCanonicalUrlParts: initialRSCPayload.c,
                    initialParallelRoutes: new Map(),
                    location: window.location,
                    couldBeIntercepted: initialRSCPayload.i,
                    postponed: initialRSCPayload.s,
                    prerendered: initialRSCPayload.S,
                  }),
                  instrumentationHooks,
                ),
              );
            },
            (err) => reject(err),
          );
        });
        const reactEl = /*#__PURE__*/ (0, _jsxruntime.jsx)(StrictModeIfEnabled, {
          children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
            _headmanagercontextsharedruntime.HeadManagerContext.Provider,
            {
              value: {
                appDir: true,
              },
              children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Root, {
                children: /*#__PURE__*/ (0, _jsxruntime.jsx)(ServerRoot, {
                  pendingActionQueue: pendingActionQueue,
                }),
              }),
            },
          ),
        });
        if (document.documentElement.id === "__next_error__") {
          let element = reactEl;
          // Server rendering failed, fall back to client-side rendering
          if (false) {
          }
          _client.default.createRoot(appElement, reactRootOptions).render(element);
        } else {
          _react.default.startTransition(() => {
            _client.default.hydrateRoot(appElement, reactEl, {
              ...reactRootOptions,
              formState: initialFormStateData,
            });
          });
        }
        // TODO-APP: Remove this logic when Float has GC built-in in development.
        if (false) {
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-index.js.map

      /***/
    },

    /***/ 6287: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";
      /**
       * This module imports the client instrumentation hook from the project root.
       *
       * The `private-next-instrumentation-client` module is automatically aliased to
       * the `instrumentation-client.ts` file in the project root by webpack or turbopack.
       */
      if (false) {
      } else {
        // eslint-disable-next-line @next/internal/typechecked-require -- Not a module.
        module.exports = __webpack_require__(5657);
      }

      //# sourceMappingURL=require-instrumentation-client.js.map

      /***/
    },

    /***/ 6568: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "findHeadInCache", {
        enumerable: true,
        get: function () {
          return findHeadInCache;
        },
      });
      const _segment = __webpack_require__(3388);
      const _createroutercachekey = __webpack_require__(6066);
      function findHeadInCache(cache, parallelRoutes) {
        return findHeadInCacheImpl(cache, parallelRoutes, "", "");
      }
      function findHeadInCacheImpl(cache, parallelRoutes, keyPrefix, keyPrefixWithoutSearchParams) {
        const isLastItem = Object.keys(parallelRoutes).length === 0;
        if (isLastItem) {
          // Returns the entire Cache Node of the segment whose head we will render.
          return [cache, keyPrefix, keyPrefixWithoutSearchParams];
        }
        // First try the 'children' parallel route if it exists
        // when starting from the "root", this corresponds with the main page component
        const parallelRoutesKeys = Object.keys(parallelRoutes).filter((key) => key !== "children");
        // if we are at the root, we need to check the children slot first
        if ("children" in parallelRoutes) {
          parallelRoutesKeys.unshift("children");
        }
        for (const key of parallelRoutesKeys) {
          const [segment, childParallelRoutes] = parallelRoutes[key];
          // If the parallel is not matched and using the default segment,
          // skip searching the head from it.
          if (segment === _segment.DEFAULT_SEGMENT_KEY) {
            continue;
          }
          const childSegmentMap = cache.parallelRoutes.get(key);
          if (!childSegmentMap) {
            continue;
          }
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segment);
          const cacheKeyWithoutSearchParams = (0, _createroutercachekey.createRouterCacheKey)(
            segment,
            true,
          );
          const cacheNode = childSegmentMap.get(cacheKey);
          if (!cacheNode) {
            continue;
          }
          const item = findHeadInCacheImpl(
            cacheNode,
            childParallelRoutes,
            keyPrefix + "/" + cacheKey,
            keyPrefix + "/" + cacheKeyWithoutSearchParams,
          );
          if (item) {
            return item;
          }
        }
        return null;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=find-head-in-cache.js.map

      /***/
    },

    /***/ 6634: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "default", {
        enumerable: true,
        get: function () {
          return _default;
        },
      });
      const _jsxruntime = __webpack_require__(8767);
      const _handleisrerror = __webpack_require__(5680);
      const styles = {
        error: {
          // https://github.com/sindresorhus/modern-normalize/blob/main/modern-normalize.css#L38-L52
          fontFamily:
            'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
          height: "100vh",
          textAlign: "center",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        },
        text: {
          fontSize: "14px",
          fontWeight: 400,
          lineHeight: "28px",
          margin: "0 8px",
        },
      };
      function DefaultGlobalError(param) {
        let { error } = param;
        const digest = error == null ? void 0 : error.digest;
        return /*#__PURE__*/ (0, _jsxruntime.jsxs)("html", {
          id: "__next_error__",
          children: [
            /*#__PURE__*/ (0, _jsxruntime.jsx)("head", {}),
            /*#__PURE__*/ (0, _jsxruntime.jsxs)("body", {
              children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)(_handleisrerror.HandleISRError, {
                  error: error,
                }),
                /*#__PURE__*/ (0, _jsxruntime.jsx)("div", {
                  style: styles.error,
                  children: /*#__PURE__*/ (0, _jsxruntime.jsxs)("div", {
                    children: [
                      /*#__PURE__*/ (0, _jsxruntime.jsxs)("h2", {
                        style: styles.text,
                        children: [
                          "Application error: a ",
                          digest ? "server" : "client",
                          "-side exception has occurred while loading ",
                          window.location.hostname,
                          " (see the",
                          " ",
                          digest ? "server logs" : "browser console",
                          " for more information).",
                        ],
                      }),
                      digest
                        ? /*#__PURE__*/ (0, _jsxruntime.jsx)("p", {
                            style: styles.text,
                            children: "Digest: " + digest,
                          })
                        : null,
                    ],
                  }),
                }),
              ],
            }),
          ],
        });
      }
      const _default = DefaultGlobalError;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=global-error.js.map

      /***/
    },

    /***/ 6669: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "hasBasePath", {
        enumerable: true,
        get: function () {
          return hasBasePath;
        },
      });
      const _pathhasprefix = __webpack_require__(2006);
      const basePath = false || "";
      function hasBasePath(path) {
        return (0, _pathhasprefix.pathHasPrefix)(path, basePath);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=has-base-path.js.map

      /***/
    },

    /***/ 6673: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      function checkDCE() {
        /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
        if (
          typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" ||
          typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function"
        ) {
          return;
        }
        if (false) {
        }
        try {
          // Verify that the code above has been dead code eliminated (DCE'd).
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
        } catch (err) {
          // DevTools shouldn't crash React, no matter what.
          // We should still report in case we break this code.
          console.error(err);
        }
      }

      if (true) {
        // DCE check should happen before ReactDOM bundle executes so that
        // DevTools can report bad minification during injection.
        checkDCE();
        module.exports = __webpack_require__(7156);
      } else {
      }

      /***/
    },

    /***/ 6764: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        AppRouterContext: function () {
          return AppRouterContext;
        },
        GlobalLayoutRouterContext: function () {
          return GlobalLayoutRouterContext;
        },
        LayoutRouterContext: function () {
          return LayoutRouterContext;
        },
        MissingSlotContext: function () {
          return MissingSlotContext;
        },
        TemplateContext: function () {
          return TemplateContext;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(5127));
      const AppRouterContext = _react.default.createContext(null);
      const LayoutRouterContext = _react.default.createContext(null);
      const GlobalLayoutRouterContext = _react.default.createContext(null);
      const TemplateContext = _react.default.createContext(null);
      if (false) {
      }
      const MissingSlotContext = _react.default.createContext(new Set()); //# sourceMappingURL=app-router-context.shared-runtime.js.map

      /***/
    },

    /***/ 6784: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "default", {
        enumerable: true,
        get: function () {
          return RenderFromTemplateContext;
        },
      });
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _approutercontextsharedruntime = __webpack_require__(6764);
      function RenderFromTemplateContext() {
        const children = (0, _react.useContext)(_approutercontextsharedruntime.TemplateContext);
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
          children: children,
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=render-from-template-context.js.map

      /***/
    },

    /***/ 6787: /***/ () => {
      ("trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft),
        "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight),
        "description" in Symbol.prototype ||
          Object.defineProperty(Symbol.prototype, "description", {
            configurable: !0,
            get: function () {
              var t = /\((.*)\)/.exec(this.toString());
              return t ? t[1] : void 0;
            },
          }),
        Array.prototype.flat ||
          ((Array.prototype.flat = function (t, r) {
            return (
              (r = this.concat.apply([], this)),
              t > 1 && r.some(Array.isArray) ? r.flat(t - 1) : r
            );
          }),
          (Array.prototype.flatMap = function (t, r) {
            return this.map(t, r).flat();
          })),
        Promise.prototype.finally ||
          (Promise.prototype.finally = function (t) {
            if ("function" != typeof t) return this.then(t, t);
            var r = this.constructor || Promise;
            return this.then(
              function (n) {
                return r.resolve(t()).then(function () {
                  return n;
                });
              },
              function (n) {
                return r.resolve(t()).then(function () {
                  throw n;
                });
              },
            );
          }),
        Object.fromEntries ||
          (Object.fromEntries = function (t) {
            return Array.from(t).reduce(function (t, r) {
              return ((t[r[0]] = r[1]), t);
            }, {});
          }),
        Array.prototype.at ||
          (Array.prototype.at = function (t) {
            var r = Math.trunc(t) || 0;
            if ((r < 0 && (r += this.length), !(r < 0 || r >= this.length))) return this[r];
          }),
        Object.hasOwn ||
          (Object.hasOwn = function (t, r) {
            if (null == t) throw new TypeError("Cannot convert undefined or null to object");
            return Object.prototype.hasOwnProperty.call(Object(t), r);
          }),
        "canParse" in URL ||
          (URL.canParse = function (t, r) {
            try {
              return !!new URL(t, r);
            } catch (t) {
              return !1;
            }
          }));

      /***/
    },

    /***/ 6861: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "invalidateCacheByRouterState", {
        enumerable: true,
        get: function () {
          return invalidateCacheByRouterState;
        },
      });
      const _createroutercachekey = __webpack_require__(6066);
      function invalidateCacheByRouterState(newCache, existingCache, routerState) {
        // Remove segment that we got data for so that it is filled in during rendering of rsc.
        for (const key in routerState[1]) {
          const segmentForParallelRoute = routerState[1][key][0];
          const cacheKey = (0, _createroutercachekey.createRouterCacheKey)(segmentForParallelRoute);
          const existingParallelRoutesCacheNode = existingCache.parallelRoutes.get(key);
          if (existingParallelRoutesCacheNode) {
            let parallelRouteCacheNode = new Map(existingParallelRoutesCacheNode);
            parallelRouteCacheNode.delete(cacheKey);
            newCache.parallelRoutes.set(key, parallelRouteCacheNode);
          }
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=invalidate-cache-by-router-state.js.map

      /***/
    },

    /***/ 6917: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        handleHardNavError: function () {
          return handleHardNavError;
        },
        useNavFailureHandler: function () {
          return useNavFailureHandler;
        },
      });
      const _react = __webpack_require__(5127);
      const _createhreffromurl = __webpack_require__(8150);
      function handleHardNavError(error) {
        if (
          error &&
          "object" !== "undefined" &&
          window.next.__pendingUrl &&
          (0, _createhreffromurl.createHrefFromUrl)(new URL(window.location.href)) !==
            (0, _createhreffromurl.createHrefFromUrl)(window.next.__pendingUrl)
        ) {
          console.error("Error occurred during navigation, falling back to hard navigation", error);
          window.location.href = window.next.__pendingUrl.toString();
          return true;
        }
        return false;
      }
      function useNavFailureHandler() {
        if (false) {
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=nav-failure-handler.js.map

      /***/
    },

    /***/ 6977: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createRenderSearchParamsFromClient", {
        enumerable: true,
        get: function () {
          return createRenderSearchParamsFromClient;
        },
      });
      const _reflectutils = __webpack_require__(1106);
      const CachedSearchParams = new WeakMap();
      function makeUntrackedExoticSearchParams(underlyingSearchParams) {
        const cachedSearchParams = CachedSearchParams.get(underlyingSearchParams);
        if (cachedSearchParams) {
          return cachedSearchParams;
        }
        // We don't use makeResolvedReactPromise here because searchParams
        // supports copying with spread and we don't want to unnecessarily
        // instrument the promise with spreadable properties of ReactPromise.
        const promise = Promise.resolve(underlyingSearchParams);
        CachedSearchParams.set(underlyingSearchParams, promise);
        Object.keys(underlyingSearchParams).forEach((prop) => {
          if (_reflectutils.wellKnownProperties.has(prop)) {
            // These properties cannot be shadowed because they need to be the
            // true underlying value for Promises to work correctly at runtime
          } else {
            promise[prop] = underlyingSearchParams[prop];
          }
        });
        return promise;
      }
      function makeUntrackedSearchParams(underlyingSearchParams) {
        const cachedSearchParams = CachedSearchParams.get(underlyingSearchParams);
        if (cachedSearchParams) {
          return cachedSearchParams;
        }
        const promise = Promise.resolve(underlyingSearchParams);
        CachedSearchParams.set(underlyingSearchParams, promise);
        return promise;
      }
      function createRenderSearchParamsFromClient(underlyingSearchParams) {
        if (false) {
        }
        return makeUntrackedExoticSearchParams(underlyingSearchParams);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=search-params.browser.prod.js.map

      /***/
    },

    /***/ 6992: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "serverActionReducer", {
        enumerable: true,
        get: function () {
          return serverActionReducer;
        },
      });
      const _appcallserver = __webpack_require__(9837);
      const _appfindsourcemapurl = __webpack_require__(8213);
      const _approuterheaders = __webpack_require__(1306);
      const _unrecognizedactionerror = __webpack_require__(2857);
      const _client = __webpack_require__(9169);
      const _routerreducertypes = __webpack_require__(9131);
      const _assignlocation = __webpack_require__(1500);
      const _createhreffromurl = __webpack_require__(8150);
      const _navigatereducer = __webpack_require__(5005);
      const _applyrouterstatepatchtotree = __webpack_require__(5003);
      const _isnavigatingtonewrootlayout = __webpack_require__(607);
      const _handlemutable = __webpack_require__(9466);
      const _filllazyitemstillleafwithhead = __webpack_require__(1393);
      const _approuter = __webpack_require__(9701);
      const _hasinterceptionrouteincurrenttree = __webpack_require__(3495);
      const _handlesegmentmismatch = __webpack_require__(5912);
      const _refetchinactiveparallelsegments = __webpack_require__(1241);
      const _flightdatahelpers = __webpack_require__(6081);
      const _redirect = __webpack_require__(426);
      const _redirecterror = __webpack_require__(9721);
      const _prefetchcacheutils = __webpack_require__(1991);
      const _removebasepath = __webpack_require__(8103);
      const _hasbasepath = __webpack_require__(6669);
      const _serverreferenceinfo = __webpack_require__(2635);
      const _segmentcache = __webpack_require__(5620);
      const createFromFetch = _client.createFromFetch;
      async function fetchServerAction(state, nextUrl, param) {
        let { actionId, actionArgs } = param;
        const temporaryReferences = (0, _client.createTemporaryReferenceSet)();
        const info = (0, _serverreferenceinfo.extractInfoFromServerReferenceId)(actionId);
        // TODO: Currently, we're only omitting unused args for the experimental "use
        // cache" functions. Once the server reference info byte feature is stable, we
        // should apply this to server actions as well.
        const usedArgs =
          info.type === "use-cache"
            ? (0, _serverreferenceinfo.omitUnusedArgs)(actionArgs, info)
            : actionArgs;
        const body = await (0, _client.encodeReply)(usedArgs, {
          temporaryReferences,
        });
        const res = await fetch(state.canonicalUrl, {
          method: "POST",
          headers: {
            Accept: _approuterheaders.RSC_CONTENT_TYPE_HEADER,
            [_approuterheaders.ACTION_HEADER]: actionId,
            [_approuterheaders.NEXT_ROUTER_STATE_TREE_HEADER]: (0,
            _flightdatahelpers.prepareFlightRouterStateForRequest)(state.tree),
            ...(false ? 0 : {}),
            ...(nextUrl
              ? {
                  [_approuterheaders.NEXT_URL]: nextUrl,
                }
              : {}),
          },
          body,
        });
        // Handle server actions that the server didn't recognize.
        const unrecognizedActionHeader = res.headers.get(
          _approuterheaders.NEXT_ACTION_NOT_FOUND_HEADER,
        );
        if (unrecognizedActionHeader === "1") {
          throw Object.defineProperty(
            new _unrecognizedactionerror.UnrecognizedActionError(
              'Server Action "' +
                actionId +
                '" was not found on the server. \nRead more: https://nextjs.org/docs/messages/failed-to-find-server-action',
            ),
            "__NEXT_ERROR_CODE",
            {
              value: "E715",
              enumerable: false,
              configurable: true,
            },
          );
        }
        const redirectHeader = res.headers.get("x-action-redirect");
        const [location, _redirectType] =
          (redirectHeader == null ? void 0 : redirectHeader.split(";")) || [];
        let redirectType;
        switch (_redirectType) {
          case "push":
            redirectType = _redirecterror.RedirectType.push;
            break;
          case "replace":
            redirectType = _redirecterror.RedirectType.replace;
            break;
          default:
            redirectType = undefined;
        }
        const isPrerender = !!res.headers.get(_approuterheaders.NEXT_IS_PRERENDER_HEADER);
        let revalidatedParts;
        try {
          const revalidatedHeader = JSON.parse(
            res.headers.get("x-action-revalidated") || "[[],0,0]",
          );
          revalidatedParts = {
            paths: revalidatedHeader[0] || [],
            tag: !!revalidatedHeader[1],
            cookie: revalidatedHeader[2],
          };
        } catch (e) {
          revalidatedParts = NO_REVALIDATED_PARTS;
        }
        const redirectLocation = location
          ? (0, _assignlocation.assignLocation)(
              location,
              new URL(state.canonicalUrl, window.location.href),
            )
          : undefined;
        const contentType = res.headers.get("content-type");
        const isRscResponse = !!(
          contentType && contentType.startsWith(_approuterheaders.RSC_CONTENT_TYPE_HEADER)
        );
        // Handle invalid server action responses.
        // A valid response must have `content-type: text/x-component`, unless it's an external redirect.
        // (external redirects have an 'x-action-redirect' header, but the body is an empty 'text/plain')
        if (!isRscResponse && !redirectLocation) {
          // The server can respond with a text/plain error message, but we'll fallback to something generic
          // if there isn't one.
          const message =
            res.status >= 400 && contentType === "text/plain"
              ? await res.text()
              : "An unexpected response was received from the server.";
          throw Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true,
          });
        }
        let actionResult;
        let actionFlightData;
        if (isRscResponse) {
          const response = await createFromFetch(Promise.resolve(res), {
            callServer: _appcallserver.callServer,
            findSourceMapURL: _appfindsourcemapurl.findSourceMapURL,
            temporaryReferences,
          });
          // An internal redirect can send an RSC response, but does not have a useful `actionResult`.
          actionResult = redirectLocation ? undefined : response.a;
          actionFlightData = (0, _flightdatahelpers.normalizeFlightData)(response.f);
        } else {
          // An external redirect doesn't contain RSC data.
          actionResult = undefined;
          actionFlightData = undefined;
        }
        return {
          actionResult,
          actionFlightData,
          redirectLocation,
          redirectType,
          revalidatedParts,
          isPrerender,
        };
      }
      const NO_REVALIDATED_PARTS = {
        paths: [],
        tag: false,
        cookie: false,
      };
      function serverActionReducer(state, action) {
        const { resolve, reject } = action;
        const mutable = {};
        let currentTree = state.tree;
        mutable.preserveCustomHistoryState = false;
        // only pass along the `nextUrl` param (used for interception routes) if the current route was intercepted.
        // If the route has been intercepted, the action should be as well.
        // Otherwise the server action might be intercepted with the wrong action id
        // (ie, one that corresponds with the intercepted route)
        const nextUrl =
          state.nextUrl &&
          (0, _hasinterceptionrouteincurrenttree.hasInterceptionRouteInCurrentTree)(state.tree)
            ? state.nextUrl
            : null;
        const navigatedAt = Date.now();
        return fetchServerAction(state, nextUrl, action).then(
          async (param) => {
            let {
              actionResult,
              actionFlightData: flightData,
              redirectLocation,
              redirectType,
              isPrerender,
              revalidatedParts,
            } = param;
            let redirectHref;
            // honor the redirect type instead of defaulting to push in case of server actions.
            if (redirectLocation) {
              if (redirectType === _redirecterror.RedirectType.replace) {
                state.pushRef.pendingPush = false;
                mutable.pendingPush = false;
              } else {
                state.pushRef.pendingPush = true;
                mutable.pendingPush = true;
              }
              redirectHref = (0, _createhreffromurl.createHrefFromUrl)(redirectLocation, false);
              mutable.canonicalUrl = redirectHref;
            }
            if (!flightData) {
              resolve(actionResult);
              // If there is a redirect but no flight data we need to do a mpaNavigation.
              if (redirectLocation) {
                return (0, _navigatereducer.handleExternalUrl)(
                  state,
                  mutable,
                  redirectLocation.href,
                  state.pushRef.pendingPush,
                );
              }
              return state;
            }
            if (typeof flightData === "string") {
              // Handle case when navigating to page in `pages` from `app`
              resolve(actionResult);
              return (0, _navigatereducer.handleExternalUrl)(
                state,
                mutable,
                flightData,
                state.pushRef.pendingPush,
              );
            }
            const actionRevalidated =
              revalidatedParts.paths.length > 0 || revalidatedParts.tag || revalidatedParts.cookie;
            for (const normalizedFlightData of flightData) {
              const {
                tree: treePatch,
                seedData: cacheNodeSeedData,
                head,
                isRootRender,
              } = normalizedFlightData;
              if (!isRootRender) {
                // TODO-APP: handle this case better
                console.log("SERVER ACTION APPLY FAILED");
                resolve(actionResult);
                return state;
              }
              // Given the path can only have two items the items are only the router state and rsc for the root.
              const newTree = (0, _applyrouterstatepatchtotree.applyRouterStatePatchToTree)(
                [""],
                currentTree,
                treePatch,
                redirectHref ? redirectHref : state.canonicalUrl,
              );
              if (newTree === null) {
                resolve(actionResult);
                return (0, _handlesegmentmismatch.handleSegmentMismatch)(state, action, treePatch);
              }
              if (
                (0, _isnavigatingtonewrootlayout.isNavigatingToNewRootLayout)(currentTree, newTree)
              ) {
                resolve(actionResult);
                return (0, _navigatereducer.handleExternalUrl)(
                  state,
                  mutable,
                  redirectHref || state.canonicalUrl,
                  state.pushRef.pendingPush,
                );
              }
              // The server sent back RSC data for the server action, so we need to apply it to the cache.
              if (cacheNodeSeedData !== null) {
                const rsc = cacheNodeSeedData[1];
                const cache = (0, _approuter.createEmptyCacheNode)();
                cache.rsc = rsc;
                cache.prefetchRsc = null;
                cache.loading = cacheNodeSeedData[3];
                (0, _filllazyitemstillleafwithhead.fillLazyItemsTillLeafWithHead)(
                  navigatedAt,
                  cache,
                  undefined,
                  treePatch,
                  cacheNodeSeedData,
                  head,
                  undefined,
                );
                mutable.cache = cache;
                if (false) {
                } else {
                  mutable.prefetchCache = new Map();
                }
                if (actionRevalidated) {
                  await (0, _refetchinactiveparallelsegments.refreshInactiveParallelSegments)({
                    navigatedAt,
                    state,
                    updatedTree: newTree,
                    updatedCache: cache,
                    includeNextUrl: Boolean(nextUrl),
                    canonicalUrl: mutable.canonicalUrl || state.canonicalUrl,
                  });
                }
              }
              mutable.patchedTree = newTree;
              currentTree = newTree;
            }
            if (redirectLocation && redirectHref) {
              if (true && !actionRevalidated) {
                // Because the RedirectBoundary will trigger a navigation, we need to seed the prefetch cache
                // with the FlightData that we got from the server action for the target page, so that it's
                // available when the page is navigated to and doesn't need to be re-fetched.
                // We only do this if the server action didn't revalidate any data, as in that case the
                // client cache will be cleared and the data will be re-fetched anyway.
                // NOTE: We don't do this in the Segment Cache implementation.
                // Dynamic data should never be placed into the cache, unless it's
                // "converted" to static data using <Link prefetch={true}>. What we
                // do instead is re-prefetch links and forms whenever the cache is
                // invalidated.
                (0, _prefetchcacheutils.createSeededPrefetchCacheEntry)({
                  url: redirectLocation,
                  data: {
                    flightData,
                    canonicalUrl: undefined,
                    couldBeIntercepted: false,
                    prerendered: false,
                    postponed: false,
                    // TODO: We should be able to set this if the server action
                    // returned a fully static response.
                    staleTime: -1,
                  },
                  tree: state.tree,
                  prefetchCache: state.prefetchCache,
                  nextUrl: state.nextUrl,
                  kind: isPrerender
                    ? _routerreducertypes.PrefetchKind.FULL
                    : _routerreducertypes.PrefetchKind.AUTO,
                });
                mutable.prefetchCache = state.prefetchCache;
              }
              // If the action triggered a redirect, the action promise will be rejected with
              // a redirect so that it's handled by RedirectBoundary as we won't have a valid
              // action result to resolve the promise with. This will effectively reset the state of
              // the component that called the action as the error boundary will remount the tree.
              // The status code doesn't matter here as the action handler will have already sent
              // a response with the correct status code.
              reject(
                (0, _redirect.getRedirectError)(
                  (0, _hasbasepath.hasBasePath)(redirectHref)
                    ? (0, _removebasepath.removeBasePath)(redirectHref)
                    : redirectHref,
                  redirectType || _redirecterror.RedirectType.push,
                ),
              );
            } else {
              resolve(actionResult);
            }
            return (0, _handlemutable.handleMutable)(state, mutable);
          },
          (e) => {
            // When the server action is rejected we don't update the state and instead call the reject handler of the promise.
            reject(e);
            return state;
          },
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=server-action-reducer.js.map

      /***/
    },

    /***/ 7030: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* provided dependency */ var process = __webpack_require__(612);
      /**
       * @license React
       * react.production.js
       *
       * Copyright (c) Meta Platforms, Inc. and affiliates.
       *
       * This source code is licensed under the MIT license found in the
       * LICENSE file in the root directory of this source tree.
       */

      var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
        REACT_PORTAL_TYPE = Symbol.for("react.portal"),
        REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
        REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
        REACT_PROFILER_TYPE = Symbol.for("react.profiler"),
        REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
        REACT_CONTEXT_TYPE = Symbol.for("react.context"),
        REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
        REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
        REACT_MEMO_TYPE = Symbol.for("react.memo"),
        REACT_LAZY_TYPE = Symbol.for("react.lazy"),
        MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
      function getIteratorFn(maybeIterable) {
        if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
        maybeIterable =
          (MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL]) ||
          maybeIterable["@@iterator"];
        return "function" === typeof maybeIterable ? maybeIterable : null;
      }
      var ReactNoopUpdateQueue = {
          isMounted: function () {
            return !1;
          },
          enqueueForceUpdate: function () {},
          enqueueReplaceState: function () {},
          enqueueSetState: function () {},
        },
        assign = Object.assign,
        emptyObject = {};
      function Component(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      Component.prototype.isReactComponent = {};
      Component.prototype.setState = function (partialState, callback) {
        if (
          "object" !== typeof partialState &&
          "function" !== typeof partialState &&
          null != partialState
        )
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables.",
          );
        this.updater.enqueueSetState(this, partialState, callback, "setState");
      };
      Component.prototype.forceUpdate = function (callback) {
        this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
      };
      function ComponentDummy() {}
      ComponentDummy.prototype = Component.prototype;
      function PureComponent(props, context, updater) {
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
      }
      var pureComponentPrototype = (PureComponent.prototype = new ComponentDummy());
      pureComponentPrototype.constructor = PureComponent;
      assign(pureComponentPrototype, Component.prototype);
      pureComponentPrototype.isPureReactComponent = !0;
      var isArrayImpl = Array.isArray;
      function noop() {}
      var ReactSharedInternals = { H: null, A: null, T: null, S: null },
        hasOwnProperty = Object.prototype.hasOwnProperty;
      function ReactElement(type, key, props) {
        var refProp = props.ref;
        return {
          $$typeof: REACT_ELEMENT_TYPE,
          type: type,
          key: key,
          ref: void 0 !== refProp ? refProp : null,
          props: props,
        };
      }
      function cloneAndReplaceKey(oldElement, newKey) {
        return ReactElement(oldElement.type, newKey, oldElement.props);
      }
      function isValidElement(object) {
        return (
          "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE
        );
      }
      function escape(key) {
        var escaperLookup = { "=": "=0", ":": "=2" };
        return (
          "$" +
          key.replace(/[=:]/g, function (match) {
            return escaperLookup[match];
          })
        );
      }
      var userProvidedKeyEscapeRegex = /\/+/g;
      function getElementKey(element, index) {
        return "object" === typeof element && null !== element && null != element.key
          ? escape("" + element.key)
          : index.toString(36);
      }
      function resolveThenable(thenable) {
        switch (thenable.status) {
          case "fulfilled":
            return thenable.value;
          case "rejected":
            throw thenable.reason;
          default:
            switch (
              ("string" === typeof thenable.status
                ? thenable.then(noop, noop)
                : ((thenable.status = "pending"),
                  thenable.then(
                    function (fulfilledValue) {
                      "pending" === thenable.status &&
                        ((thenable.status = "fulfilled"), (thenable.value = fulfilledValue));
                    },
                    function (error) {
                      "pending" === thenable.status &&
                        ((thenable.status = "rejected"), (thenable.reason = error));
                    },
                  )),
              thenable.status)
            ) {
              case "fulfilled":
                return thenable.value;
              case "rejected":
                throw thenable.reason;
            }
        }
        throw thenable;
      }
      function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
        var type = typeof children;
        if ("undefined" === type || "boolean" === type) children = null;
        var invokeCallback = !1;
        if (null === children) invokeCallback = !0;
        else
          switch (type) {
            case "bigint":
            case "string":
            case "number":
              invokeCallback = !0;
              break;
            case "object":
              switch (children.$$typeof) {
                case REACT_ELEMENT_TYPE:
                case REACT_PORTAL_TYPE:
                  invokeCallback = !0;
                  break;
                case REACT_LAZY_TYPE:
                  return (
                    (invokeCallback = children._init),
                    mapIntoArray(
                      invokeCallback(children._payload),
                      array,
                      escapedPrefix,
                      nameSoFar,
                      callback,
                    )
                  );
              }
          }
        if (invokeCallback)
          return (
            (callback = callback(children)),
            (invokeCallback = "" === nameSoFar ? "." + getElementKey(children, 0) : nameSoFar),
            isArrayImpl(callback)
              ? ((escapedPrefix = ""),
                null != invokeCallback &&
                  (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"),
                mapIntoArray(callback, array, escapedPrefix, "", function (c) {
                  return c;
                }))
              : null != callback &&
                (isValidElement(callback) &&
                  (callback = cloneAndReplaceKey(
                    callback,
                    escapedPrefix +
                      (null == callback.key || (children && children.key === callback.key)
                        ? ""
                        : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") +
                      invokeCallback,
                  )),
                array.push(callback)),
            1
          );
        invokeCallback = 0;
        var nextNamePrefix = "" === nameSoFar ? "." : nameSoFar + ":";
        if (isArrayImpl(children))
          for (var i = 0; i < children.length; i++)
            ((nameSoFar = children[i]),
              (type = nextNamePrefix + getElementKey(nameSoFar, i)),
              (invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback)));
        else if (((i = getIteratorFn(children)), "function" === typeof i))
          for (children = i.call(children), i = 0; !(nameSoFar = children.next()).done;)
            ((nameSoFar = nameSoFar.value),
              (type = nextNamePrefix + getElementKey(nameSoFar, i++)),
              (invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback)));
        else if ("object" === type) {
          if ("function" === typeof children.then)
            return mapIntoArray(
              resolveThenable(children),
              array,
              escapedPrefix,
              nameSoFar,
              callback,
            );
          array = String(children);
          throw Error(
            "Objects are not valid as a React child (found: " +
              ("[object Object]" === array
                ? "object with keys {" + Object.keys(children).join(", ") + "}"
                : array) +
              "). If you meant to render a collection of children, use an array instead.",
          );
        }
        return invokeCallback;
      }
      function mapChildren(children, func, context) {
        if (null == children) return children;
        var result = [],
          count = 0;
        mapIntoArray(children, result, "", "", function (child) {
          return func.call(context, child, count++);
        });
        return result;
      }
      function lazyInitializer(payload) {
        if (-1 === payload._status) {
          var ctor = payload._result;
          ctor = ctor();
          ctor.then(
            function (moduleObject) {
              if (0 === payload._status || -1 === payload._status)
                ((payload._status = 1), (payload._result = moduleObject));
            },
            function (error) {
              if (0 === payload._status || -1 === payload._status)
                ((payload._status = 2), (payload._result = error));
            },
          );
          -1 === payload._status && ((payload._status = 0), (payload._result = ctor));
        }
        if (1 === payload._status) return payload._result.default;
        throw payload._result;
      }
      var reportGlobalError =
        "function" === typeof reportError
          ? reportError
          : function (error) {
              if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
                var event = new window.ErrorEvent("error", {
                  bubbles: !0,
                  cancelable: !0,
                  message:
                    "object" === typeof error && null !== error && "string" === typeof error.message
                      ? String(error.message)
                      : String(error),
                  error: error,
                });
                if (!window.dispatchEvent(event)) return;
              } else if ("object" === typeof process && "function" === typeof process.emit) {
                process.emit("uncaughtException", error);
                return;
              }
              console.error(error);
            };
      exports.Children = {
        map: mapChildren,
        forEach: function (children, forEachFunc, forEachContext) {
          mapChildren(
            children,
            function () {
              forEachFunc.apply(this, arguments);
            },
            forEachContext,
          );
        },
        count: function (children) {
          var n = 0;
          mapChildren(children, function () {
            n++;
          });
          return n;
        },
        toArray: function (children) {
          return (
            mapChildren(children, function (child) {
              return child;
            }) || []
          );
        },
        only: function (children) {
          if (!isValidElement(children))
            throw Error("React.Children.only expected to receive a single React element child.");
          return children;
        },
      };
      exports.Component = Component;
      exports.Fragment = REACT_FRAGMENT_TYPE;
      exports.Profiler = REACT_PROFILER_TYPE;
      exports.PureComponent = PureComponent;
      exports.StrictMode = REACT_STRICT_MODE_TYPE;
      exports.Suspense = REACT_SUSPENSE_TYPE;
      exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE =
        ReactSharedInternals;
      exports.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function (size) {
          return ReactSharedInternals.H.useMemoCache(size);
        },
      };
      exports.cache = function (fn) {
        return function () {
          return fn.apply(null, arguments);
        };
      };
      exports.cacheSignal = function () {
        return null;
      };
      exports.cloneElement = function (element, config, children) {
        if (null === element || void 0 === element)
          throw Error("The argument must be a React element, but you passed " + element + ".");
        var props = assign({}, element.props),
          key = element.key;
        if (null != config)
          for (propName in (void 0 !== config.key && (key = "" + config.key), config))
            !hasOwnProperty.call(config, propName) ||
              "key" === propName ||
              "__self" === propName ||
              "__source" === propName ||
              ("ref" === propName && void 0 === config.ref) ||
              (props[propName] = config[propName]);
        var propName = arguments.length - 2;
        if (1 === propName) props.children = children;
        else if (1 < propName) {
          for (var childArray = Array(propName), i = 0; i < propName; i++)
            childArray[i] = arguments[i + 2];
          props.children = childArray;
        }
        return ReactElement(element.type, key, props);
      };
      exports.createContext = function (defaultValue) {
        defaultValue = {
          $$typeof: REACT_CONTEXT_TYPE,
          _currentValue: defaultValue,
          _currentValue2: defaultValue,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
        };
        defaultValue.Provider = defaultValue;
        defaultValue.Consumer = {
          $$typeof: REACT_CONSUMER_TYPE,
          _context: defaultValue,
        };
        return defaultValue;
      };
      exports.createElement = function (type, config, children) {
        var propName,
          props = {},
          key = null;
        if (null != config)
          for (propName in (void 0 !== config.key && (key = "" + config.key), config))
            hasOwnProperty.call(config, propName) &&
              "key" !== propName &&
              "__self" !== propName &&
              "__source" !== propName &&
              (props[propName] = config[propName]);
        var childrenLength = arguments.length - 2;
        if (1 === childrenLength) props.children = children;
        else if (1 < childrenLength) {
          for (var childArray = Array(childrenLength), i = 0; i < childrenLength; i++)
            childArray[i] = arguments[i + 2];
          props.children = childArray;
        }
        if (type && type.defaultProps)
          for (propName in ((childrenLength = type.defaultProps), childrenLength))
            void 0 === props[propName] && (props[propName] = childrenLength[propName]);
        return ReactElement(type, key, props);
      };
      exports.createRef = function () {
        return { current: null };
      };
      exports.forwardRef = function (render) {
        return { $$typeof: REACT_FORWARD_REF_TYPE, render: render };
      };
      exports.isValidElement = isValidElement;
      exports.lazy = function (ctor) {
        return {
          $$typeof: REACT_LAZY_TYPE,
          _payload: { _status: -1, _result: ctor },
          _init: lazyInitializer,
        };
      };
      exports.memo = function (type, compare) {
        return {
          $$typeof: REACT_MEMO_TYPE,
          type: type,
          compare: void 0 === compare ? null : compare,
        };
      };
      exports.startTransition = function (scope) {
        var prevTransition = ReactSharedInternals.T,
          currentTransition = {};
        ReactSharedInternals.T = currentTransition;
        try {
          var returnValue = scope(),
            onStartTransitionFinish = ReactSharedInternals.S;
          null !== onStartTransitionFinish &&
            onStartTransitionFinish(currentTransition, returnValue);
          "object" === typeof returnValue &&
            null !== returnValue &&
            "function" === typeof returnValue.then &&
            returnValue.then(noop, reportGlobalError);
        } catch (error) {
          reportGlobalError(error);
        } finally {
          (null !== prevTransition &&
            null !== currentTransition.types &&
            (prevTransition.types = currentTransition.types),
            (ReactSharedInternals.T = prevTransition));
        }
      };
      exports.unstable_useCacheRefresh = function () {
        return ReactSharedInternals.H.useCacheRefresh();
      };
      exports.use = function (usable) {
        return ReactSharedInternals.H.use(usable);
      };
      exports.useActionState = function (action, initialState, permalink) {
        return ReactSharedInternals.H.useActionState(action, initialState, permalink);
      };
      exports.useCallback = function (callback, deps) {
        return ReactSharedInternals.H.useCallback(callback, deps);
      };
      exports.useContext = function (Context) {
        return ReactSharedInternals.H.useContext(Context);
      };
      exports.useDebugValue = function () {};
      exports.useDeferredValue = function (value, initialValue) {
        return ReactSharedInternals.H.useDeferredValue(value, initialValue);
      };
      exports.useEffect = function (create, deps) {
        return ReactSharedInternals.H.useEffect(create, deps);
      };
      exports.useId = function () {
        return ReactSharedInternals.H.useId();
      };
      exports.useImperativeHandle = function (ref, create, deps) {
        return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
      };
      exports.useInsertionEffect = function (create, deps) {
        return ReactSharedInternals.H.useInsertionEffect(create, deps);
      };
      exports.useLayoutEffect = function (create, deps) {
        return ReactSharedInternals.H.useLayoutEffect(create, deps);
      };
      exports.useMemo = function (create, deps) {
        return ReactSharedInternals.H.useMemo(create, deps);
      };
      exports.useOptimistic = function (passthrough, reducer) {
        return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
      };
      exports.useReducer = function (reducer, initialArg, init) {
        return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
      };
      exports.useRef = function (initialValue) {
        return ReactSharedInternals.H.useRef(initialValue);
      };
      exports.useState = function (initialState) {
        return ReactSharedInternals.H.useState(initialState);
      };
      exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
        return ReactSharedInternals.H.useSyncExternalStore(
          subscribe,
          getSnapshot,
          getServerSnapshot,
        );
      };
      exports.useTransition = function () {
        return ReactSharedInternals.H.useTransition();
      };
      exports.version = "19.2.0-canary-0bdb9206-20250818";

      /***/
    },

    /***/ 7122: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "encodeURIPath", {
        enumerable: true,
        get: function () {
          return encodeURIPath;
        },
      });
      function encodeURIPath(file) {
        return file
          .split("/")
          .map((p) => encodeURIComponent(p))
          .join("/");
      } //# sourceMappingURL=encode-uri-path.js.map

      /***/
    },

    /***/ 7161: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "getDeploymentIdQueryOrEmptyString", {
        enumerable: true,
        get: function () {
          return getDeploymentIdQueryOrEmptyString;
        },
      });
      function getDeploymentIdQueryOrEmptyString() {
        if (false) {
        }
        return "";
      }

      //# sourceMappingURL=deployment-id.js.map

      /***/
    },

    /***/ 7223: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "RedirectStatusCode", {
        enumerable: true,
        get: function () {
          return RedirectStatusCode;
        },
      });
      var RedirectStatusCode = /*#__PURE__*/ (function (RedirectStatusCode) {
        RedirectStatusCode[(RedirectStatusCode["SeeOther"] = 303)] = "SeeOther";
        RedirectStatusCode[(RedirectStatusCode["TemporaryRedirect"] = 307)] = "TemporaryRedirect";
        RedirectStatusCode[(RedirectStatusCode["PermanentRedirect"] = 308)] = "PermanentRedirect";
        return RedirectStatusCode;
      })({});
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=redirect-status-code.js.map

      /***/
    },

    /***/ 7267: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        createMutableActionQueue: function () {
          return createMutableActionQueue;
        },
        dispatchNavigateAction: function () {
          return dispatchNavigateAction;
        },
        dispatchTraverseAction: function () {
          return dispatchTraverseAction;
        },
        getCurrentAppRouterState: function () {
          return getCurrentAppRouterState;
        },
        publicAppRouterInstance: function () {
          return publicAppRouterInstance;
        },
      });
      const _routerreducertypes = __webpack_require__(9131);
      const _routerreducer = __webpack_require__(9439);
      const _react = __webpack_require__(5127);
      const _isthenable = __webpack_require__(533);
      const _segmentcache = __webpack_require__(5620);
      const _useactionqueue = __webpack_require__(7964);
      const _addbasepath = __webpack_require__(9478);
      const _approuter = __webpack_require__(9701);
      const _prefetchreducer = __webpack_require__(3065);
      const _links = __webpack_require__(2767);
      function runRemainingActions(actionQueue, setState) {
        if (actionQueue.pending !== null) {
          actionQueue.pending = actionQueue.pending.next;
          if (actionQueue.pending !== null) {
            // eslint-disable-next-line @typescript-eslint/no-use-before-define
            runAction({
              actionQueue,
              action: actionQueue.pending,
              setState,
            });
          } else {
            // No more actions are pending, check if a refresh is needed
            if (actionQueue.needsRefresh) {
              actionQueue.needsRefresh = false;
              actionQueue.dispatch(
                {
                  type: _routerreducertypes.ACTION_REFRESH,
                  origin: window.location.origin,
                },
                setState,
              );
            }
          }
        }
      }
      async function runAction(param) {
        let { actionQueue, action, setState } = param;
        const prevState = actionQueue.state;
        actionQueue.pending = action;
        const payload = action.payload;
        const actionResult = actionQueue.action(prevState, payload);
        function handleResult(nextState) {
          // if we discarded this action, the state should also be discarded
          if (action.discarded) {
            return;
          }
          actionQueue.state = nextState;
          runRemainingActions(actionQueue, setState);
          action.resolve(nextState);
        }
        // if the action is a promise, set up a callback to resolve it
        if ((0, _isthenable.isThenable)(actionResult)) {
          actionResult.then(handleResult, (err) => {
            runRemainingActions(actionQueue, setState);
            action.reject(err);
          });
        } else {
          handleResult(actionResult);
        }
      }
      function dispatchAction(actionQueue, payload, setState) {
        let resolvers = {
          resolve: setState,
          reject: () => {},
        };
        // most of the action types are async with the exception of restore
        // it's important that restore is handled quickly since it's fired on the popstate event
        // and we don't want to add any delay on a back/forward nav
        // this only creates a promise for the async actions
        if (payload.type !== _routerreducertypes.ACTION_RESTORE) {
          // Create the promise and assign the resolvers to the object.
          const deferredPromise = new Promise((resolve, reject) => {
            resolvers = {
              resolve,
              reject,
            };
          });
          (0, _react.startTransition)(() => {
            // we immediately notify React of the pending promise -- the resolver is attached to the action node
            // and will be called when the associated action promise resolves
            setState(deferredPromise);
          });
        }
        const newAction = {
          payload,
          next: null,
          resolve: resolvers.resolve,
          reject: resolvers.reject,
        };
        // Check if the queue is empty
        if (actionQueue.pending === null) {
          // The queue is empty, so add the action and start it immediately
          // Mark this action as the last in the queue
          actionQueue.last = newAction;
          runAction({
            actionQueue,
            action: newAction,
            setState,
          });
        } else if (
          payload.type === _routerreducertypes.ACTION_NAVIGATE ||
          payload.type === _routerreducertypes.ACTION_RESTORE
        ) {
          // Navigations (including back/forward) take priority over any pending actions.
          // Mark the pending action as discarded (so the state is never applied) and start the navigation action immediately.
          actionQueue.pending.discarded = true;
          // The rest of the current queue should still execute after this navigation.
          // (Note that it can't contain any earlier navigations, because we always put those into `actionQueue.pending` by calling `runAction`)
          newAction.next = actionQueue.pending.next;
          // if the pending action was a server action, mark the queue as needing a refresh once events are processed
          if (actionQueue.pending.payload.type === _routerreducertypes.ACTION_SERVER_ACTION) {
            actionQueue.needsRefresh = true;
          }
          runAction({
            actionQueue,
            action: newAction,
            setState,
          });
        } else {
          // The queue is not empty, so add the action to the end of the queue
          // It will be started by runRemainingActions after the previous action finishes
          if (actionQueue.last !== null) {
            actionQueue.last.next = newAction;
          }
          actionQueue.last = newAction;
        }
      }
      let globalActionQueue = null;
      function createMutableActionQueue(initialState, instrumentationHooks) {
        const actionQueue = {
          state: initialState,
          dispatch: (payload, setState) => dispatchAction(actionQueue, payload, setState),
          action: async (state, action) => {
            const result = (0, _routerreducer.reducer)(state, action);
            return result;
          },
          pending: null,
          last: null,
          onRouterTransitionStart:
            instrumentationHooks !== null &&
            typeof instrumentationHooks.onRouterTransitionStart === "function"
              ? instrumentationHooks.onRouterTransitionStart
              : null,
        };
        if (true) {
          // The action queue is lazily created on hydration, but after that point
          // it doesn't change. So we can store it in a global rather than pass
          // it around everywhere via props/context.
          if (globalActionQueue !== null) {
            throw Object.defineProperty(
              new Error(
                "Internal Next.js Error: createMutableActionQueue was called more " + "than once",
              ),
              "__NEXT_ERROR_CODE",
              {
                value: "E624",
                enumerable: false,
                configurable: true,
              },
            );
          }
          globalActionQueue = actionQueue;
        }
        return actionQueue;
      }
      function getCurrentAppRouterState() {
        return globalActionQueue !== null ? globalActionQueue.state : null;
      }
      function getAppRouterActionQueue() {
        if (globalActionQueue === null) {
          throw Object.defineProperty(
            new Error("Internal Next.js error: Router action dispatched before initialization."),
            "__NEXT_ERROR_CODE",
            {
              value: "E668",
              enumerable: false,
              configurable: true,
            },
          );
        }
        return globalActionQueue;
      }
      function getProfilingHookForOnNavigationStart() {
        if (globalActionQueue !== null) {
          return globalActionQueue.onRouterTransitionStart;
        }
        return null;
      }
      function dispatchNavigateAction(href, navigateType, shouldScroll, linkInstanceRef) {
        // TODO: This stuff could just go into the reducer. Leaving as-is for now
        // since we're about to rewrite all the router reducer stuff anyway.
        const url = new URL((0, _addbasepath.addBasePath)(href), location.href);
        if (false) {
        }
        (0, _links.setLinkForCurrentNavigation)(linkInstanceRef);
        const onRouterTransitionStart = getProfilingHookForOnNavigationStart();
        if (onRouterTransitionStart !== null) {
          onRouterTransitionStart(href, navigateType);
        }
        (0, _useactionqueue.dispatchAppRouterAction)({
          type: _routerreducertypes.ACTION_NAVIGATE,
          url,
          isExternalUrl: (0, _approuter.isExternalURL)(url),
          locationSearch: location.search,
          shouldScroll,
          navigateType,
          allowAliasing: true,
        });
      }
      function dispatchTraverseAction(href, tree) {
        const onRouterTransitionStart = getProfilingHookForOnNavigationStart();
        if (onRouterTransitionStart !== null) {
          onRouterTransitionStart(href, "traverse");
        }
        (0, _useactionqueue.dispatchAppRouterAction)({
          type: _routerreducertypes.ACTION_RESTORE,
          url: new URL(href),
          tree,
        });
      }
      const publicAppRouterInstance = {
        back: () => window.history.back(),
        forward: () => window.history.forward(),
        prefetch: false // cache. So we don't need to dispatch an action.
          ? 0
          : (href, options) => {
              // Use the old prefetch implementation.
              const actionQueue = getAppRouterActionQueue();
              const url = (0, _approuter.createPrefetchURL)(href);
              if (url !== null) {
                var _options_kind;
                // The prefetch reducer doesn't actually update any state or
                // trigger a rerender. It just writes to a mutable cache. So we
                // shouldn't bother calling setState/dispatch; we can just re-run
                // the reducer directly using the current state.
                // TODO: Refactor this away from a "reducer" so it's
                // less confusing.
                (0, _prefetchreducer.prefetchReducer)(actionQueue.state, {
                  type: _routerreducertypes.ACTION_PREFETCH,
                  url,
                  kind:
                    (_options_kind = options == null ? void 0 : options.kind) != null
                      ? _options_kind
                      : _routerreducertypes.PrefetchKind.FULL,
                });
              }
            },
        replace: (href, options) => {
          (0, _react.startTransition)(() => {
            var _options_scroll;
            dispatchNavigateAction(
              href,
              "replace",
              (_options_scroll = options == null ? void 0 : options.scroll) != null
                ? _options_scroll
                : true,
              null,
            );
          });
        },
        push: (href, options) => {
          (0, _react.startTransition)(() => {
            var _options_scroll;
            dispatchNavigateAction(
              href,
              "push",
              (_options_scroll = options == null ? void 0 : options.scroll) != null
                ? _options_scroll
                : true,
              null,
            );
          });
        },
        refresh: () => {
          (0, _react.startTransition)(() => {
            (0, _useactionqueue.dispatchAppRouterAction)({
              type: _routerreducertypes.ACTION_REFRESH,
              origin: window.location.origin,
            });
          });
        },
        hmrRefresh: () => {
          if (true) {
            throw Object.defineProperty(
              new Error(
                "hmrRefresh can only be used in development mode. Please use refresh instead.",
              ),
              "__NEXT_ERROR_CODE",
              {
                value: "E485",
                enumerable: false,
                configurable: true,
              },
            );
          } else {
          }
        },
      };
      // Exists for debugging purposes. Don't use in application code.
      if (true && window.next) {
        window.next.router = publicAppRouterInstance;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-router-instance.js.map

      /***/
    },

    /***/ 7328: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /**
       * This function should be used to rethrow internal Next.js errors so that they can be handled by the framework.
       * When wrapping an API that uses errors to interrupt control flow, you should use this function before you do any error handling.
       * This function will rethrow the error if it is a Next.js error so it can be handled, otherwise it will do nothing.
       *
       * Read more: [Next.js Docs: `unstable_rethrow`](https://nextjs.org/docs/app/api-reference/functions/unstable_rethrow)
       */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "unstable_rethrow", {
        enumerable: true,
        get: function () {
          return unstable_rethrow;
        },
      });
      const unstable_rethrow = false ? 0 : __webpack_require__(3070).unstable_rethrow;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=unstable-rethrow.js.map

      /***/
    },

    /***/ 7448: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      // This file is only used in app router due to the specific error state handling.

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        onCaughtError: function () {
          return onCaughtError;
        },
        onUncaughtError: function () {
          return onUncaughtError;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _isnextroutererror = __webpack_require__(1582);
      const _bailouttocsr = __webpack_require__(2997);
      const _reportglobalerror = __webpack_require__(1387);
      const _errorboundary = __webpack_require__(917);
      const _globalerror = /*#__PURE__*/ _interop_require_default._(__webpack_require__(6634));
      const devToolErrorMod = false
        ? 0
        : {
            decorateDevError: (error) => error,
            handleClientError: () => {},
            originConsoleError: console.error.bind(console),
          };
      function onCaughtError(thrownValue, errorInfo) {
        var _errorInfo_errorBoundary;
        const errorBoundaryComponent =
          (_errorInfo_errorBoundary = errorInfo.errorBoundary) == null
            ? void 0
            : _errorInfo_errorBoundary.constructor;
        let isImplicitErrorBoundary;
        if (false) {
        }
        isImplicitErrorBoundary =
          isImplicitErrorBoundary ||
          (errorBoundaryComponent === _errorboundary.ErrorBoundaryHandler &&
            errorInfo.errorBoundary.props.errorComponent === _globalerror.default);
        // Skip the segment explorer triggered error
        if (false) {
        }
        if (isImplicitErrorBoundary) {
          // We don't consider errors caught unless they're caught by an explicit error
          // boundary. The built-in ones are considered implicit.
          // This mimics how the same app would behave without Next.js.
          return onUncaughtError(thrownValue);
        }
        // Skip certain custom errors which are not expected to be reported on client
        if (
          (0, _bailouttocsr.isBailoutToCSRError)(thrownValue) ||
          (0, _isnextroutererror.isNextRouterError)(thrownValue)
        )
          return;
        if (false) {
          var _componentThatErroredFrame_match, _errorInfo_componentStack;
        } else {
          devToolErrorMod.originConsoleError(thrownValue);
        }
      }
      function onUncaughtError(thrownValue) {
        // Skip certain custom errors which are not expected to be reported on client
        if (
          (0, _bailouttocsr.isBailoutToCSRError)(thrownValue) ||
          (0, _isnextroutererror.isNextRouterError)(thrownValue)
        )
          return;
        if (false) {
        } else {
          (0, _reportglobalerror.reportGlobalError)(thrownValue);
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=error-boundary-callbacks.js.map

      /***/
    },

    /***/ 7535: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "forbidden", {
        enumerable: true,
        get: function () {
          return forbidden;
        },
      });
      const _httpaccessfallback = __webpack_require__(9028);
      // TODO: Add `forbidden` docs
      /**
       * @experimental
       * This function allows you to render the [forbidden.js file](https://nextjs.org/docs/app/api-reference/file-conventions/forbidden)
       * within a route segment as well as inject a tag.
       *
       * `forbidden()` can be used in
       * [Server Components](https://nextjs.org/docs/app/building-your-application/rendering/server-components),
       * [Route Handlers](https://nextjs.org/docs/app/building-your-application/routing/route-handlers), and
       * [Server Actions](https://nextjs.org/docs/app/building-your-application/data-fetching/server-actions-and-mutations).
       *
       * Read more: [Next.js Docs: `forbidden`](https://nextjs.org/docs/app/api-reference/functions/forbidden)
       */ const DIGEST = "" + _httpaccessfallback.HTTP_ERROR_FALLBACK_ERROR_CODE + ";403";
      function forbidden() {
        if (true) {
          throw Object.defineProperty(
            new Error(
              "`forbidden()` is experimental and only allowed to be enabled when `experimental.authInterrupts` is enabled.",
            ),
            "__NEXT_ERROR_CODE",
            {
              value: "E488",
              enumerable: false,
              configurable: true,
            },
          );
        }
        // eslint-disable-next-line no-throw-literal
        const error = Object.defineProperty(new Error(DIGEST), "__NEXT_ERROR_CODE", {
          value: "E394",
          enumerable: false,
          configurable: true,
        });
        error.digest = DIGEST;
        throw error;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=forbidden.js.map

      /***/
    },

    /***/ 7543: /***/ (
      __unused_webpack___webpack_module__,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      "use strict";
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ _: () => /* binding */ _interop_require_default,
        /* harmony export */
      });
      function _interop_require_default(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }

      /***/
    },

    /***/ 7590: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "disableSmoothScrollDuringRouteTransition", {
        enumerable: true,
        get: function () {
          return disableSmoothScrollDuringRouteTransition;
        },
      });
      const _warnonce = __webpack_require__(2025);
      function disableSmoothScrollDuringRouteTransition(fn, options) {
        if (options === void 0) options = {};
        // if only the hash is changed, we don't need to disable smooth scrolling
        // we only care to prevent smooth scrolling when navigating to a new page to avoid jarring UX
        if (options.onlyHashChange) {
          fn();
          return;
        }
        const htmlElement = document.documentElement;
        const hasDataAttribute = htmlElement.dataset.scrollBehavior === "smooth";
        // Since this is a breaking change, this is temporarily flagged
        // and will be false by default.
        // In the next major (v16), this will be automatically enabled
        if (false) {
        } else {
          // Old behavior: always manipulate styles, but warn about upcoming change
          // Warn if smooth scrolling is detected but no data attribute is present
          if (false) {
          }
        }
        // Proceed with temporarily disabling smooth scrolling
        const existing = htmlElement.style.scrollBehavior;
        htmlElement.style.scrollBehavior = "auto";
        if (!options.dontForceLayout) {
          // In Chrome-based browsers we need to force reflow before calling `scrollTo`.
          // Otherwise it will not pickup the change in scrollBehavior
          // More info here: https://github.com/vercel/next.js/issues/40719#issuecomment-1336248042
          htmlElement.getClientRects();
        }
        fn();
        htmlElement.style.scrollBehavior = existing;
      } //# sourceMappingURL=disable-smooth-scroll.js.map

      /***/
    },

    /***/ 7637: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "setAttributesFromProps", {
        enumerable: true,
        get: function () {
          return setAttributesFromProps;
        },
      });
      const DOMAttributeNames = {
        acceptCharset: "accept-charset",
        className: "class",
        htmlFor: "for",
        httpEquiv: "http-equiv",
        noModule: "noModule",
      };
      const ignoreProps = [
        "onLoad",
        "onReady",
        "dangerouslySetInnerHTML",
        "children",
        "onError",
        "strategy",
        "stylesheets",
      ];
      function isBooleanScriptAttribute(attr) {
        return ["async", "defer", "noModule"].includes(attr);
      }
      function setAttributesFromProps(el, props) {
        for (const [p, value] of Object.entries(props)) {
          if (!props.hasOwnProperty(p)) continue;
          if (ignoreProps.includes(p)) continue;
          // we don't render undefined props to the DOM
          if (value === undefined) {
            continue;
          }
          const attr = DOMAttributeNames[p] || p.toLowerCase();
          if (el.tagName === "SCRIPT" && isBooleanScriptAttribute(attr)) {
            // Correctly assign boolean script attributes
            // https://github.com/vercel/next.js/pull/20748
            el[attr] = !!value;
          } else {
            el.setAttribute(attr, String(value));
          }
          // Remove falsy non-zero boolean attributes so they are correctly interpreted
          // (e.g. if we set them to false, this coerces to the string "false", which the browser interprets as true)
          if (
            value === false ||
            (el.tagName === "SCRIPT" &&
              isBooleanScriptAttribute(attr) &&
              (!value || value === "false"))
          ) {
            // Call setAttribute before, as we need to set and unset the attribute to override force async:
            // https://html.spec.whatwg.org/multipage/scripting.html#script-force-async
            el.setAttribute(attr, "");
            el.removeAttribute(attr);
          }
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=set-attributes-from-props.js.map

      /***/
    },

    /***/ 7658: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "notFound", {
        enumerable: true,
        get: function () {
          return notFound;
        },
      });
      const _httpaccessfallback = __webpack_require__(9028);
      /**
       * This function allows you to render the [not-found.js file](https://nextjs.org/docs/app/api-reference/file-conventions/not-found)
       * within a route segment as well as inject a tag.
       *
       * `notFound()` can be used in
       * [Server Components](https://nextjs.org/docs/app/building-your-application/rendering/server-components),
       * [Route Handlers](https://nextjs.org/docs/app/building-your-application/routing/route-handlers), and
       * [Server Actions](https://nextjs.org/docs/app/building-your-application/data-fetching/server-actions-and-mutations).
       *
       * - In a Server Component, this will insert a `<meta name="robots" content="noindex" />` meta tag and set the status code to 404.
       * - In a Route Handler or Server Action, it will serve a 404 to the caller.
       *
       * Read more: [Next.js Docs: `notFound`](https://nextjs.org/docs/app/api-reference/functions/not-found)
       */ const DIGEST = "" + _httpaccessfallback.HTTP_ERROR_FALLBACK_ERROR_CODE + ";404";
      function notFound() {
        // eslint-disable-next-line no-throw-literal
        const error = Object.defineProperty(new Error(DIGEST), "__NEXT_ERROR_CODE", {
          value: "E394",
          enumerable: false,
          configurable: true,
        });
        error.digest = DIGEST;
        throw error;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=not-found.js.map

      /***/
    },

    /***/ 7708: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        METADATA_BOUNDARY_NAME: function () {
          return METADATA_BOUNDARY_NAME;
        },
        OUTLET_BOUNDARY_NAME: function () {
          return OUTLET_BOUNDARY_NAME;
        },
        ROOT_LAYOUT_BOUNDARY_NAME: function () {
          return ROOT_LAYOUT_BOUNDARY_NAME;
        },
        VIEWPORT_BOUNDARY_NAME: function () {
          return VIEWPORT_BOUNDARY_NAME;
        },
      });
      const METADATA_BOUNDARY_NAME = "__next_metadata_boundary__";
      const VIEWPORT_BOUNDARY_NAME = "__next_viewport_boundary__";
      const OUTLET_BOUNDARY_NAME = "__next_outlet_boundary__";
      const ROOT_LAYOUT_BOUNDARY_NAME = "__next_root_layout_boundary__";

      //# sourceMappingURL=boundary-constants.js.map

      /***/
    },

    /***/ 7963: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        doesStaticSegmentAppearInURL: function () {
          return doesStaticSegmentAppearInURL;
        },
        getCacheKeyForDynamicParam: function () {
          return getCacheKeyForDynamicParam;
        },
        getParamValueFromCacheKey: function () {
          return getParamValueFromCacheKey;
        },
        getRenderedPathname: function () {
          return getRenderedPathname;
        },
        getRenderedSearch: function () {
          return getRenderedSearch;
        },
        parseDynamicParamFromURLPart: function () {
          return parseDynamicParamFromURLPart;
        },
        urlToUrlWithoutFlightMarker: function () {
          return urlToUrlWithoutFlightMarker;
        },
      });
      const _segment = __webpack_require__(3388);
      const _segmentvalueencoding = __webpack_require__(5557);
      const _approuterheaders = __webpack_require__(1306);
      function getRenderedSearch(response) {
        // If the server performed a rewrite, the search params used to render the
        // page will be different from the params in the request URL. In this case,
        // the response will include a header that gives the rewritten search query.
        const rewrittenQuery = response.headers.get(_approuterheaders.NEXT_REWRITTEN_QUERY_HEADER);
        if (rewrittenQuery !== null) {
          return rewrittenQuery === "" ? "" : "?" + rewrittenQuery;
        }
        // If the header is not present, there was no rewrite, so we use the search
        // query of the response URL.
        return urlToUrlWithoutFlightMarker(new URL(response.url)).search;
      }
      function getRenderedPathname(response) {
        // If the server performed a rewrite, the pathname used to render the
        // page will be different from the pathname in the request URL. In this case,
        // the response will include a header that gives the rewritten pathname.
        const rewrittenPath = response.headers.get(_approuterheaders.NEXT_REWRITTEN_PATH_HEADER);
        return rewrittenPath != null
          ? rewrittenPath
          : urlToUrlWithoutFlightMarker(new URL(response.url)).pathname;
      }
      function parseDynamicParamFromURLPart(paramType, pathnameParts, partIndex) {
        // This needs to match the behavior in get-dynamic-param.ts.
        switch (paramType) {
          // Catchalls
          case "c":
          case "ci": {
            // Catchalls receive all the remaining URL parts. If there are no
            // remaining pathname parts, return an empty array.
            return partIndex < pathnameParts.length
              ? pathnameParts.slice(partIndex).map((s) => encodeURIComponent(s))
              : [];
          }
          // Optional catchalls
          case "oc": {
            // Optional catchalls receive all the remaining URL parts, unless this is
            // the end of the pathname, in which case they return null.
            return partIndex < pathnameParts.length
              ? pathnameParts.slice(partIndex).map((s) => encodeURIComponent(s))
              : null;
          }
          // Dynamic
          case "d":
          case "di": {
            if (partIndex >= pathnameParts.length) {
              // The route tree expected there to be more parts in the URL than there
              // actually are. This could happen if the x-nextjs-rewritten-path header
              // is incorrectly set, or potentially due to bug in Next.js. TODO:
              // Should this be a hard error? During a prefetch, we can just abort.
              // During a client navigation, we could trigger a hard refresh. But if
              // it happens during initial render, we don't really have any
              // recovery options.
              return "";
            }
            return encodeURIComponent(pathnameParts[partIndex]);
          }
          default:
            paramType;
            return "";
        }
      }
      function doesStaticSegmentAppearInURL(segment) {
        // This is not a parameterized segment; however, we need to determine
        // whether or not this segment appears in the URL. For example, this route
        // groups do not appear in the URL, so they should be skipped. Any other
        // special cases must be handled here.
        // TODO: Consider encoding this directly into the router tree instead of
        // inferring it on the client based on the segment type. Something like
        // a `doesAppearInURL` flag in FlightRouterState.
        if (
          segment === _segmentvalueencoding.ROOT_SEGMENT_REQUEST_KEY || // For some reason, the loader tree sometimes includes extra __PAGE__
          // "layouts" when part of a parallel route. But it's not a leaf node.
          // Otherwise, we wouldn't need this special case because pages are
          // always leaf nodes.
          // TODO: Investigate why the loader produces these fake page segments.
          segment.startsWith(_segment.PAGE_SEGMENT_KEY) || // Route groups.
          (segment[0] === "(" && segment.endsWith(")")) ||
          segment === _segment.DEFAULT_SEGMENT_KEY ||
          segment === "/_not-found"
        ) {
          return false;
        } else {
          // All other segment types appear in the URL
          return true;
        }
      }
      function getCacheKeyForDynamicParam(paramValue, renderedSearch) {
        // This needs to match the logic in get-dynamic-param.ts, until we're able to
        // unify the various implementations so that these are always computed on
        // the client.
        if (typeof paramValue === "string") {
          // TODO: Refactor or remove this helper function to accept a string rather
          // than the whole segment type. Also we can probably just append the
          // search string instead of turning it into JSON.
          const pageSegmentWithSearchParams = (0, _segment.addSearchParamsIfPageSegment)(
            paramValue,
            Object.fromEntries(new URLSearchParams(renderedSearch)),
          );
          return pageSegmentWithSearchParams;
        } else if (paramValue === null) {
          return "";
        } else {
          return paramValue.join("/");
        }
      }
      function urlToUrlWithoutFlightMarker(url) {
        const urlWithoutFlightParameters = new URL(url);
        urlWithoutFlightParameters.searchParams.delete(_approuterheaders.NEXT_RSC_UNION_QUERY);
        if (true) {
          if (true && urlWithoutFlightParameters.pathname.endsWith(".txt")) {
            const { pathname } = urlWithoutFlightParameters;
            const length = pathname.endsWith("/index.txt") ? 10 : 4;
            // Slice off `/index.txt` or `.txt` from the end of the pathname
            urlWithoutFlightParameters.pathname = pathname.slice(0, -length);
          }
        }
        return urlWithoutFlightParameters;
      }
      function getParamValueFromCacheKey(paramCacheKey, paramType) {
        // Turn the cache key string sent by the server (as part of FlightRouterState)
        // into a value that can be passed to `useParams` and client components.
        const isCatchAll = paramType === "c" || paramType === "oc";
        if (isCatchAll) {
          // Catch-all param keys are a concatenation of the path segments.
          // See equivalent logic in `getSelectedParams`.
          // TODO: We should just pass the array directly, rather than concatenate
          // it to a string and then split it back to an array. It needs to be an
          // array in some places, like when passing a key React, but we can convert
          // it at runtime in those places.
          return paramCacheKey.split("/");
        }
        return paramCacheKey;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=route-params.js.map

      /***/
    },

    /***/ 7964: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        dispatchAppRouterAction: function () {
          return dispatchAppRouterAction;
        },
        useActionQueue: function () {
          return useActionQueue;
        },
      });
      const _interop_require_wildcard = __webpack_require__(212);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _isthenable = __webpack_require__(533);
      // The app router state lives outside of React, so we can import the dispatch
      // method directly wherever we need it, rather than passing it around via props
      // or context.
      let dispatch = null;
      function dispatchAppRouterAction(action) {
        if (dispatch === null) {
          throw Object.defineProperty(
            new Error("Internal Next.js error: Router action dispatched before initialization."),
            "__NEXT_ERROR_CODE",
            {
              value: "E668",
              enumerable: false,
              configurable: true,
            },
          );
        }
        dispatch(action);
      }
      function useActionQueue(actionQueue) {
        const [state, setState] = _react.default.useState(actionQueue.state);
        // Because of a known issue that requires to decode Flight streams inside the
        // render phase, we have to be a bit clever and assign the dispatch method to
        // a module-level variable upon initialization. The useState hook in this
        // module only exists to synchronize state that lives outside of React.
        // Ideally, what we'd do instead is pass the state as a prop to root.render;
        // this is conceptually how we're modeling the app router state, despite the
        // weird implementation details.
        if (false) {
        } else {
          dispatch = (action) => actionQueue.dispatch(action, setState);
        }
        return (0, _isthenable.isThenable)(state) ? (0, _react.use)(state) : state;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=use-action-queue.js.map

      /***/
    },

    /***/ 8021: /***/ (module, exports) => {
      "use strict";
      // This gets assigned as a side-effect during app initialization. Because it
      // represents the build used to create the JS bundle, it should never change
      // after being set, so we store it in a global variable.
      //
      // When performing RSC requests, if the incoming data has a different build ID,
      // we perform an MPA navigation/refresh to load the updated build and ensure
      // that the client and server in sync.
      // Starts as an empty string. In practice, because setAppBuildId is called
      // during initialization before hydration starts, this will always get
      // reassigned to the actual build ID before it's ever needed by a navigation.
      // If for some reasons it didn't, due to a bug or race condition, then on
      // navigation the build comparision would fail and trigger an MPA navigation.

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        getAppBuildId: function () {
          return getAppBuildId;
        },
        setAppBuildId: function () {
          return setAppBuildId;
        },
      });
      let globalBuildId = "";
      function setAppBuildId(buildId) {
        globalBuildId = buildId;
      }
      function getAppBuildId() {
        return globalBuildId;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-build-id.js.map

      /***/
    },

    /***/ 8103: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "removeBasePath", {
        enumerable: true,
        get: function () {
          return removeBasePath;
        },
      });
      const _hasbasepath = __webpack_require__(6669);
      const basePath = false || "";
      function removeBasePath(path) {
        if (false) {
        }
        // Can't trim the basePath if it has zero length!
        if (basePath.length === 0) return path;
        path = path.slice(basePath.length);
        if (!path.startsWith("/")) path = "/" + path;
        return path;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=remove-base-path.js.map

      /***/
    },

    /***/ 8150: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createHrefFromUrl", {
        enumerable: true,
        get: function () {
          return createHrefFromUrl;
        },
      });
      function createHrefFromUrl(url, includeHash) {
        if (includeHash === void 0) includeHash = true;
        return url.pathname + url.search + (includeHash ? url.hash : "");
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=create-href-from-url.js.map

      /***/
    },

    /***/ 8213: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "findSourceMapURL", {
        enumerable: true,
        get: function () {
          return findSourceMapURL;
        },
      });
      const basePath = false || "";
      const pathname = "" + basePath + "/__nextjs_source-map";
      const findSourceMapURL = false ? 0 : undefined;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-find-source-map-url.js.map

      /***/
    },

    /***/ 8245: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        HTML_LIMITED_BOT_UA_RE: function () {
          return _htmlbots.HTML_LIMITED_BOT_UA_RE;
        },
        HTML_LIMITED_BOT_UA_RE_STRING: function () {
          return HTML_LIMITED_BOT_UA_RE_STRING;
        },
        getBotType: function () {
          return getBotType;
        },
        isBot: function () {
          return isBot;
        },
      });
      const _htmlbots = __webpack_require__(937);
      // Bot crawler that will spin up a headless browser and execute JS.
      // Only the main Googlebot search crawler executes JavaScript, not other Google crawlers.
      // x-ref: https://developers.google.com/search/docs/crawling-indexing/google-common-crawlers
      // This regex specifically matches "Googlebot" but NOT "Mediapartners-Google", "AdsBot-Google", etc.
      const HEADLESS_BROWSER_BOT_UA_RE = /Googlebot(?!-)|Googlebot$/i;
      const HTML_LIMITED_BOT_UA_RE_STRING = _htmlbots.HTML_LIMITED_BOT_UA_RE.source;
      function isDomBotUA(userAgent) {
        return HEADLESS_BROWSER_BOT_UA_RE.test(userAgent);
      }
      function isHtmlLimitedBotUA(userAgent) {
        return _htmlbots.HTML_LIMITED_BOT_UA_RE.test(userAgent);
      }
      function isBot(userAgent) {
        return isDomBotUA(userAgent) || isHtmlLimitedBotUA(userAgent);
      }
      function getBotType(userAgent) {
        if (isDomBotUA(userAgent)) {
          return "dom";
        }
        if (isHtmlLimitedBotUA(userAgent)) {
          return "html";
        }
        return undefined;
      } //# sourceMappingURL=is-bot.js.map

      /***/
    },

    /***/ 8374: /***/ (
      __unused_webpack___webpack_module__,
      __webpack_exports__,
      __webpack_require__,
    ) => {
      "use strict";
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ _: () => /* binding */ _class_private_field_loose_key,
        /* harmony export */
      });
      var id = 0;

      function _class_private_field_loose_key(name) {
        return "__private_" + id++ + "_" + name;
      }

      /***/
    },

    /***/ 8381: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      /**
       * @license React
       * react-jsx-runtime.production.js
       *
       * Copyright (c) Meta Platforms, Inc. and affiliates.
       *
       * This source code is licensed under the MIT license found in the
       * LICENSE file in the root directory of this source tree.
       */

      var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
        REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
      function jsxProd(type, config, maybeKey) {
        var key = null;
        void 0 !== maybeKey && (key = "" + maybeKey);
        void 0 !== config.key && (key = "" + config.key);
        if ("key" in config) {
          maybeKey = {};
          for (var propName in config)
            "key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        config = maybeKey.ref;
        return {
          $$typeof: REACT_ELEMENT_TYPE,
          type: type,
          key: key,
          ref: void 0 !== config ? config : null,
          props: maybeKey,
        };
      }
      exports.Fragment = REACT_FRAGMENT_TYPE;
      exports.jsx = jsxProd;
      exports.jsxs = jsxProd;

      /***/
    },

    /***/ 8462: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /**
       * @license React
       * react-dom.production.js
       *
       * Copyright (c) Meta Platforms, Inc. and affiliates.
       *
       * This source code is licensed under the MIT license found in the
       * LICENSE file in the root directory of this source tree.
       */

      var React = __webpack_require__(5127);
      function formatProdErrorMessage(code) {
        var url = "https://react.dev/errors/" + code;
        if (1 < arguments.length) {
          url += "?args[]=" + encodeURIComponent(arguments[1]);
          for (var i = 2; i < arguments.length; i++)
            url += "&args[]=" + encodeURIComponent(arguments[i]);
        }
        return (
          "Minified React error #" +
          code +
          "; visit " +
          url +
          " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
        );
      }
      function noop() {}
      var Internals = {
          d: {
            f: noop,
            r: function () {
              throw Error(formatProdErrorMessage(522));
            },
            D: noop,
            C: noop,
            L: noop,
            m: noop,
            X: noop,
            S: noop,
            M: noop,
          },
          p: 0,
          findDOMNode: null,
        },
        REACT_PORTAL_TYPE = Symbol.for("react.portal");
      function createPortal$1(children, containerInfo, implementation) {
        var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
        return {
          $$typeof: REACT_PORTAL_TYPE,
          key: null == key ? null : "" + key,
          children: children,
          containerInfo: containerInfo,
          implementation: implementation,
        };
      }
      var ReactSharedInternals =
        React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
      function getCrossOriginStringAs(as, input) {
        if ("font" === as) return "";
        if ("string" === typeof input) return "use-credentials" === input ? input : "";
      }
      exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
      exports.createPortal = function (children, container) {
        var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
        if (
          !container ||
          (1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType)
        )
          throw Error(formatProdErrorMessage(299));
        return createPortal$1(children, container, null, key);
      };
      exports.flushSync = function (fn) {
        var previousTransition = ReactSharedInternals.T,
          previousUpdatePriority = Internals.p;
        try {
          if (((ReactSharedInternals.T = null), (Internals.p = 2), fn)) return fn();
        } finally {
          ((ReactSharedInternals.T = previousTransition),
            (Internals.p = previousUpdatePriority),
            Internals.d.f());
        }
      };
      exports.preconnect = function (href, options) {
        "string" === typeof href &&
          (options
            ? ((options = options.crossOrigin),
              (options =
                "string" === typeof options
                  ? "use-credentials" === options
                    ? options
                    : ""
                  : void 0))
            : (options = null),
          Internals.d.C(href, options));
      };
      exports.prefetchDNS = function (href) {
        "string" === typeof href && Internals.d.D(href);
      };
      exports.preinit = function (href, options) {
        if ("string" === typeof href && options && "string" === typeof options.as) {
          var as = options.as,
            crossOrigin = getCrossOriginStringAs(as, options.crossOrigin),
            integrity = "string" === typeof options.integrity ? options.integrity : void 0,
            fetchPriority =
              "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
          "style" === as
            ? Internals.d.S(
                href,
                "string" === typeof options.precedence ? options.precedence : void 0,
                {
                  crossOrigin: crossOrigin,
                  integrity: integrity,
                  fetchPriority: fetchPriority,
                },
              )
            : "script" === as &&
              Internals.d.X(href, {
                crossOrigin: crossOrigin,
                integrity: integrity,
                fetchPriority: fetchPriority,
                nonce: "string" === typeof options.nonce ? options.nonce : void 0,
              });
        }
      };
      exports.preinitModule = function (href, options) {
        if ("string" === typeof href)
          if ("object" === typeof options && null !== options) {
            if (null == options.as || "script" === options.as) {
              var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
              Internals.d.M(href, {
                crossOrigin: crossOrigin,
                integrity: "string" === typeof options.integrity ? options.integrity : void 0,
                nonce: "string" === typeof options.nonce ? options.nonce : void 0,
              });
            }
          } else null == options && Internals.d.M(href);
      };
      exports.preload = function (href, options) {
        if (
          "string" === typeof href &&
          "object" === typeof options &&
          null !== options &&
          "string" === typeof options.as
        ) {
          var as = options.as,
            crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
          Internals.d.L(href, as, {
            crossOrigin: crossOrigin,
            integrity: "string" === typeof options.integrity ? options.integrity : void 0,
            nonce: "string" === typeof options.nonce ? options.nonce : void 0,
            type: "string" === typeof options.type ? options.type : void 0,
            fetchPriority:
              "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
            referrerPolicy:
              "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
            imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
            imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
            media: "string" === typeof options.media ? options.media : void 0,
          });
        }
      };
      exports.preloadModule = function (href, options) {
        if ("string" === typeof href)
          if (options) {
            var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
            Internals.d.m(href, {
              as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
              crossOrigin: crossOrigin,
              integrity: "string" === typeof options.integrity ? options.integrity : void 0,
            });
          } else Internals.d.m(href);
      };
      exports.requestFormReset = function (form) {
        Internals.d.r(form);
      };
      exports.unstable_batchedUpdates = function (fn, a) {
        return fn(a);
      };
      exports.useFormState = function (action, initialState, permalink) {
        return ReactSharedInternals.H.useFormState(action, initialState, permalink);
      };
      exports.useFormStatus = function () {
        return ReactSharedInternals.H.useHostTransitionStatus();
      };
      exports.version = "19.2.0-canary-0bdb9206-20250818";

      /***/
    },

    /***/ 8483: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ServerInsertedHTMLContext: function () {
          return ServerInsertedHTMLContext;
        },
        useServerInsertedHTML: function () {
          return useServerInsertedHTML;
        },
      });
      const _interop_require_wildcard = __webpack_require__(212);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const ServerInsertedHTMLContext = /*#__PURE__*/ _react.default.createContext(null);
      function useServerInsertedHTML(callback) {
        const addInsertedServerHTMLCallback = (0, _react.useContext)(ServerInsertedHTMLContext);
        // Should have no effects on client where there's no flush effects provider
        if (addInsertedServerHTMLCallback) {
          addInsertedServerHTMLCallback(callback);
        }
      } //# sourceMappingURL=server-inserted-html.shared-runtime.js.map

      /***/
    },

    /***/ 8534: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      function checkDCE() {
        /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
        if (
          typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" ||
          typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function"
        ) {
          return;
        }
        if (false) {
        }
        try {
          // Verify that the code above has been dead code eliminated (DCE'd).
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
        } catch (err) {
          // DevTools shouldn't crash React, no matter what.
          // We should still report in case we break this code.
          console.error(err);
        }
      }

      if (true) {
        // DCE check should happen before ReactDOM bundle executes so that
        // DevTools can report bad minification during injection.
        checkDCE();
        module.exports = __webpack_require__(8462);
      } else {
      }

      /***/
    },

    /***/ 8669: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      if (true) {
        module.exports = __webpack_require__(2134);
      } else {
      }

      /***/
    },

    /***/ 8680: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ReadonlyURLSearchParams: function () {
          return _navigationreactserver.ReadonlyURLSearchParams;
        },
        RedirectType: function () {
          return _navigationreactserver.RedirectType;
        },
        ServerInsertedHTMLContext: function () {
          return _serverinsertedhtmlsharedruntime.ServerInsertedHTMLContext;
        },
        forbidden: function () {
          return _navigationreactserver.forbidden;
        },
        notFound: function () {
          return _navigationreactserver.notFound;
        },
        permanentRedirect: function () {
          return _navigationreactserver.permanentRedirect;
        },
        redirect: function () {
          return _navigationreactserver.redirect;
        },
        unauthorized: function () {
          return _navigationreactserver.unauthorized;
        },
        unstable_isUnrecognizedActionError: function () {
          return _unrecognizedactionerror.unstable_isUnrecognizedActionError;
        },
        unstable_rethrow: function () {
          return _navigationreactserver.unstable_rethrow;
        },
        useParams: function () {
          return useParams;
        },
        usePathname: function () {
          return usePathname;
        },
        useRouter: function () {
          return useRouter;
        },
        useSearchParams: function () {
          return useSearchParams;
        },
        useSelectedLayoutSegment: function () {
          return useSelectedLayoutSegment;
        },
        useSelectedLayoutSegments: function () {
          return useSelectedLayoutSegments;
        },
        useServerInsertedHTML: function () {
          return _serverinsertedhtmlsharedruntime.useServerInsertedHTML;
        },
      });
      const _react = __webpack_require__(5127);
      const _approutercontextsharedruntime = __webpack_require__(6764);
      const _hooksclientcontextsharedruntime = __webpack_require__(4357);
      const _getsegmentvalue = __webpack_require__(1601);
      const _segment = __webpack_require__(3388);
      const _navigationreactserver = __webpack_require__(9643);
      const _serverinsertedhtmlsharedruntime = __webpack_require__(8483);
      const _unrecognizedactionerror = __webpack_require__(2857);
      const useDynamicRouteParams = false ? 0 : undefined;
      function useSearchParams() {
        const searchParams = (0, _react.useContext)(
          _hooksclientcontextsharedruntime.SearchParamsContext,
        );
        // In the case where this is `null`, the compat types added in
        // `next-env.d.ts` will add a new overload that changes the return type to
        // include `null`.
        const readonlySearchParams = (0, _react.useMemo)(() => {
          if (!searchParams) {
            // When the router is not ready in pages, we won't have the search params
            // available.
            return null;
          }
          return new _navigationreactserver.ReadonlyURLSearchParams(searchParams);
        }, [searchParams]);
        if (false) {
        }
        return readonlySearchParams;
      }
      function usePathname() {
        useDynamicRouteParams == null ? void 0 : useDynamicRouteParams("usePathname()");
        // In the case where this is `null`, the compat types added in `next-env.d.ts`
        // will add a new overload that changes the return type to include `null`.
        return (0, _react.useContext)(_hooksclientcontextsharedruntime.PathnameContext);
      }
      function useRouter() {
        const router = (0, _react.useContext)(_approutercontextsharedruntime.AppRouterContext);
        if (router === null) {
          throw Object.defineProperty(
            new Error("invariant expected app router to be mounted"),
            "__NEXT_ERROR_CODE",
            {
              value: "E238",
              enumerable: false,
              configurable: true,
            },
          );
        }
        return router;
      }
      function useParams() {
        useDynamicRouteParams == null ? void 0 : useDynamicRouteParams("useParams()");
        return (0, _react.useContext)(_hooksclientcontextsharedruntime.PathParamsContext);
      }
      /** Get the canonical parameters from the current level to the leaf node. */ // Client components API
      function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first, segmentPath) {
        if (first === void 0) first = true;
        if (segmentPath === void 0) segmentPath = [];
        let node;
        if (first) {
          // Use the provided parallel route key on the first parallel route
          node = tree[1][parallelRouteKey];
        } else {
          // After first parallel route prefer children, if there's no children pick the first parallel route.
          const parallelRoutes = tree[1];
          var _parallelRoutes_children;
          node =
            (_parallelRoutes_children = parallelRoutes.children) != null
              ? _parallelRoutes_children
              : Object.values(parallelRoutes)[0];
        }
        if (!node) return segmentPath;
        const segment = node[0];
        let segmentValue = (0, _getsegmentvalue.getSegmentValue)(segment);
        if (!segmentValue || segmentValue.startsWith(_segment.PAGE_SEGMENT_KEY)) {
          return segmentPath;
        }
        segmentPath.push(segmentValue);
        return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
      }
      function useSelectedLayoutSegments(parallelRouteKey) {
        if (parallelRouteKey === void 0) parallelRouteKey = "children";
        useDynamicRouteParams == null
          ? void 0
          : useDynamicRouteParams("useSelectedLayoutSegments()");
        const context = (0, _react.useContext)(_approutercontextsharedruntime.LayoutRouterContext);
        // @ts-expect-error This only happens in `pages`. Type is overwritten in navigation.d.ts
        if (!context) return null;
        return getSelectedLayoutSegmentPath(context.parentTree, parallelRouteKey);
      }
      function useSelectedLayoutSegment(parallelRouteKey) {
        if (parallelRouteKey === void 0) parallelRouteKey = "children";
        useDynamicRouteParams == null
          ? void 0
          : useDynamicRouteParams("useSelectedLayoutSegment()");
        const selectedLayoutSegments = useSelectedLayoutSegments(parallelRouteKey);
        if (!selectedLayoutSegments || selectedLayoutSegments.length === 0) {
          return null;
        }
        const selectedLayoutSegment =
          parallelRouteKey === "children"
            ? selectedLayoutSegments[0]
            : selectedLayoutSegments[selectedLayoutSegments.length - 1];
        // if the default slot is showing, we return null since it's not technically "selected" (it's a fallback)
        // and returning an internal value like `__DEFAULT__` would be confusing.
        return selectedLayoutSegment === _segment.DEFAULT_SEGMENT_KEY
          ? null
          : selectedLayoutSegment;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=navigation.js.map

      /***/
    },

    /***/ 8732: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createInitialRouterState", {
        enumerable: true,
        get: function () {
          return createInitialRouterState;
        },
      });
      const _createhreffromurl = __webpack_require__(8150);
      const _filllazyitemstillleafwithhead = __webpack_require__(1393);
      const _computechangedpath = __webpack_require__(6107);
      const _prefetchcacheutils = __webpack_require__(1991);
      const _routerreducertypes = __webpack_require__(9131);
      const _refetchinactiveparallelsegments = __webpack_require__(1241);
      const _flightdatahelpers = __webpack_require__(6081);
      function createInitialRouterState(param) {
        let {
          navigatedAt,
          initialFlightData,
          initialCanonicalUrlParts,
          initialParallelRoutes,
          location,
          couldBeIntercepted,
          postponed,
          prerendered,
        } = param;
        // When initialized on the server, the canonical URL is provided as an array of parts.
        // This is to ensure that when the RSC payload streamed to the client, crawlers don't interpret it
        // as a URL that should be crawled.
        const initialCanonicalUrl = initialCanonicalUrlParts.join("/");
        const normalizedFlightData = (0, _flightdatahelpers.getFlightDataPartsFromPath)(
          initialFlightData[0],
        );
        const {
          tree: initialTree,
          seedData: initialSeedData,
          head: initialHead,
        } = normalizedFlightData;
        // For the SSR render, seed data should always be available (we only send back a `null` response
        // in the case of a `loading` segment, pre-PPR.)
        const rsc = initialSeedData == null ? void 0 : initialSeedData[1];
        var _initialSeedData_;
        const loading =
          (_initialSeedData_ = initialSeedData == null ? void 0 : initialSeedData[3]) != null
            ? _initialSeedData_
            : null;
        const cache = {
          lazyData: null,
          rsc,
          prefetchRsc: null,
          head: null,
          prefetchHead: null,
          // The cache gets seeded during the first render. `initialParallelRoutes` ensures the cache from the first render is there during the second render.
          parallelRoutes: initialParallelRoutes,
          loading,
          navigatedAt,
        };
        const canonicalUrl = // This is safe to do as canonicalUrl can't be rendered, it's only used to control the history updates in the useEffect further down in this file.
          location ? (0, _createhreffromurl.createHrefFromUrl)(location) : initialCanonicalUrl;
        (0, _refetchinactiveparallelsegments.addRefreshMarkerToActiveParallelSegments)(
          initialTree,
          canonicalUrl,
        );
        const prefetchCache = new Map();
        // When the cache hasn't been seeded yet we fill the cache with the head.
        if (initialParallelRoutes === null || initialParallelRoutes.size === 0) {
          (0, _filllazyitemstillleafwithhead.fillLazyItemsTillLeafWithHead)(
            navigatedAt,
            cache,
            undefined,
            initialTree,
            initialSeedData,
            initialHead,
            undefined,
          );
        }
        var _ref;
        const initialState = {
          tree: initialTree,
          cache,
          prefetchCache,
          pushRef: {
            pendingPush: false,
            mpaNavigation: false,
            // First render needs to preserve the previous window.history.state
            // to avoid it being overwritten on navigation back/forward with MPA Navigation.
            preserveCustomHistoryState: true,
          },
          focusAndScrollRef: {
            apply: false,
            onlyHashChange: false,
            hashFragment: null,
            segmentPaths: [],
          },
          canonicalUrl,
          nextUrl:
            (_ref =
              (0, _computechangedpath.extractPathFromFlightRouterState)(initialTree) ||
              (location == null ? void 0 : location.pathname)) != null
              ? _ref
              : null,
        };
        if (true && location) {
          // Seed the prefetch cache with this page's data.
          // This is to prevent needlessly re-prefetching a page that is already reusable,
          // and will avoid triggering a loading state/data fetch stall when navigating back to the page.
          // We don't currently do this in development because links aren't prefetched in development
          // so having a mismatch between prefetch/no prefetch provides inconsistent behavior based on which page
          // was loaded first.
          const url = new URL("" + location.pathname + location.search, location.origin);
          (0, _prefetchcacheutils.createSeededPrefetchCacheEntry)({
            url,
            data: {
              flightData: [normalizedFlightData],
              canonicalUrl: undefined,
              couldBeIntercepted: !!couldBeIntercepted,
              prerendered,
              postponed,
              // TODO: The initial RSC payload includes both static and dynamic data
              // in the same response, even if PPR is enabled. So if there's any
              // dynamic data at all, we can't set a stale time. In the future we may
              // add a way to split a single Flight stream into static and dynamic
              // parts. But in the meantime we should at least make this work for
              // fully static pages.
              // As an abundance of caution, this will only set the initial staleTime to the configured value
              staleTime:
                // if we're not leveraging the segment cache, which has its own prefetching semantics.
                prerendered && !false ? _prefetchcacheutils.STATIC_STALETIME_MS : -1,
            },
            tree: initialState.tree,
            prefetchCache: initialState.prefetchCache,
            nextUrl: initialState.nextUrl,
            kind: prerendered
              ? _routerreducertypes.PrefetchKind.FULL
              : _routerreducertypes.PrefetchKind.AUTO,
          });
        }
        return initialState;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=create-initial-router-state.js.map

      /***/
    },

    /***/ 8734: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "createRenderParamsFromClient", {
        enumerable: true,
        get: function () {
          return createRenderParamsFromClient;
        },
      });
      const _reflectutils = __webpack_require__(1106);
      const CachedParams = new WeakMap();
      function makeUntrackedExoticParams(underlyingParams) {
        const cachedParams = CachedParams.get(underlyingParams);
        if (cachedParams) {
          return cachedParams;
        }
        const promise = Promise.resolve(underlyingParams);
        CachedParams.set(underlyingParams, promise);
        Object.keys(underlyingParams).forEach((prop) => {
          if (_reflectutils.wellKnownProperties.has(prop)) {
            // These properties cannot be shadowed because they need to be the
            // true underlying value for Promises to work correctly at runtime
          } else {
            promise[prop] = underlyingParams[prop];
          }
        });
        return promise;
      }
      function makeUntrackedParams(underlyingParams) {
        const cachedParams = CachedParams.get(underlyingParams);
        if (cachedParams) {
          return cachedParams;
        }
        const promise = Promise.resolve(underlyingParams);
        CachedParams.set(underlyingParams, promise);
        return promise;
      }
      function createRenderParamsFromClient(clientParams) {
        if (false) {
        }
        return makeUntrackedExoticParams(clientParams);
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=params.browser.prod.js.map

      /***/
    },

    /***/ 8760: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        setCacheBustingSearchParam: function () {
          return setCacheBustingSearchParam;
        },
        setCacheBustingSearchParamWithHash: function () {
          return setCacheBustingSearchParamWithHash;
        },
      });
      const _cachebustingsearchparam = __webpack_require__(5617);
      const _approuterheaders = __webpack_require__(1306);
      async function computeClientCacheBustingSearchParam(headers) {
        var _globalThis_crypto_subtle, _globalThis_crypto;
        if (
          typeof ((_globalThis_crypto = globalThis.crypto) == null
            ? void 0
            : (_globalThis_crypto_subtle = _globalThis_crypto.subtle) == null
              ? void 0
              : _globalThis_crypto_subtle.digest) === "function"
        ) {
          return (0, _cachebustingsearchparam.computeCacheBustingSearchParam)(
            headers[_approuterheaders.NEXT_ROUTER_PREFETCH_HEADER],
            headers[_approuterheaders.NEXT_ROUTER_SEGMENT_PREFETCH_HEADER],
            headers[_approuterheaders.NEXT_ROUTER_STATE_TREE_HEADER],
            headers[_approuterheaders.NEXT_URL],
          );
        }
        return (0, _cachebustingsearchparam.computeLegacyCacheBustingSearchParam)(
          headers[_approuterheaders.NEXT_ROUTER_PREFETCH_HEADER],
          headers[_approuterheaders.NEXT_ROUTER_SEGMENT_PREFETCH_HEADER],
          headers[_approuterheaders.NEXT_ROUTER_STATE_TREE_HEADER],
          headers[_approuterheaders.NEXT_URL],
        );
      }
      const setCacheBustingSearchParam = async (url, headers) => {
        const uniqueCacheKey = await computeClientCacheBustingSearchParam(headers);
        setCacheBustingSearchParamWithHash(url, uniqueCacheKey);
      };
      const setCacheBustingSearchParamWithHash = (url, hash) => {
        /**
         * Note that we intentionally do not use `url.searchParams.set` here:
         *
         * const url = new URL('https://example.com/search?q=custom%20spacing');
         * url.searchParams.set('_rsc', 'abc123');
         * console.log(url.toString()); // Outputs: https://example.com/search?q=custom+spacing&_rsc=abc123
         *                                                                             ^ <--- this is causing confusion
         * This is in fact intended based on https://url.spec.whatwg.org/#interface-urlsearchparams, but
         * we want to preserve the %20 as %20 if that's what the user passed in, hence the custom
         * logic below.
         */ const existingSearch = url.search;
        const rawQuery = existingSearch.startsWith("?") ? existingSearch.slice(1) : existingSearch;
        // Always remove any existing cache busting param and add a fresh one to ensure
        // we have the correct value based on current request headers
        const pairs = rawQuery
          .split("&")
          .filter(
            (pair) => pair && !pair.startsWith("" + _approuterheaders.NEXT_RSC_UNION_QUERY + "="),
          );
        if (hash.length > 0) {
          pairs.push(_approuterheaders.NEXT_RSC_UNION_QUERY + "=" + hash);
        } else {
          pairs.push("" + _approuterheaders.NEXT_RSC_UNION_QUERY);
        }
        url.search = pairs.length ? "?" + pairs.join("&") : "";
      };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=set-cache-busting-search-param.js.map

      /***/
    },

    /***/ 8767: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      if (true) {
        module.exports = __webpack_require__(8381);
      } else {
      }

      /***/
    },

    /***/ 8815: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "AppRouterAnnouncer", {
        enumerable: true,
        get: function () {
          return AppRouterAnnouncer;
        },
      });
      const _react = __webpack_require__(5127);
      const _reactdom = __webpack_require__(8534);
      const ANNOUNCER_TYPE = "next-route-announcer";
      const ANNOUNCER_ID = "__next-route-announcer__";
      function getAnnouncerNode() {
        var _existingAnnouncer_shadowRoot;
        const existingAnnouncer = document.getElementsByName(ANNOUNCER_TYPE)[0];
        if (
          existingAnnouncer == null
            ? void 0
            : (_existingAnnouncer_shadowRoot = existingAnnouncer.shadowRoot) == null
              ? void 0
              : _existingAnnouncer_shadowRoot.childNodes[0]
        ) {
          return existingAnnouncer.shadowRoot.childNodes[0];
        } else {
          const container = document.createElement(ANNOUNCER_TYPE);
          container.style.cssText = "position:absolute";
          const announcer = document.createElement("div");
          announcer.ariaLive = "assertive";
          announcer.id = ANNOUNCER_ID;
          announcer.role = "alert";
          announcer.style.cssText =
            "position:absolute;border:0;height:1px;margin:-1px;padding:0;width:1px;clip:rect(0 0 0 0);overflow:hidden;white-space:nowrap;word-wrap:normal";
          // Use shadow DOM here to avoid any potential CSS bleed
          const shadow = container.attachShadow({
            mode: "open",
          });
          shadow.appendChild(announcer);
          document.body.appendChild(container);
          return announcer;
        }
      }
      function AppRouterAnnouncer(param) {
        let { tree } = param;
        const [portalNode, setPortalNode] = (0, _react.useState)(null);
        (0, _react.useEffect)(() => {
          const announcer = getAnnouncerNode();
          setPortalNode(announcer);
          return () => {
            const container = document.getElementsByTagName(ANNOUNCER_TYPE)[0];
            if (container == null ? void 0 : container.isConnected) {
              document.body.removeChild(container);
            }
          };
        }, []);
        const [routeAnnouncement, setRouteAnnouncement] = (0, _react.useState)("");
        const previousTitle = (0, _react.useRef)(undefined);
        (0, _react.useEffect)(() => {
          let currentTitle = "";
          if (document.title) {
            currentTitle = document.title;
          } else {
            const pageHeader = document.querySelector("h1");
            if (pageHeader) {
              currentTitle = pageHeader.innerText || pageHeader.textContent || "";
            }
          }
          // Only announce the title change, but not for the first load because screen
          // readers do that automatically.
          if (previousTitle.current !== undefined && previousTitle.current !== currentTitle) {
            setRouteAnnouncement(currentTitle);
          }
          previousTitle.current = currentTitle;
        }, [tree]);
        return portalNode
          ? /*#__PURE__*/ (0, _reactdom.createPortal)(routeAnnouncement, portalNode)
          : null;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-router-announcer.js.map

      /***/
    },

    /***/ 9028: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        HTTPAccessErrorStatus: function () {
          return HTTPAccessErrorStatus;
        },
        HTTP_ERROR_FALLBACK_ERROR_CODE: function () {
          return HTTP_ERROR_FALLBACK_ERROR_CODE;
        },
        getAccessFallbackErrorTypeByStatus: function () {
          return getAccessFallbackErrorTypeByStatus;
        },
        getAccessFallbackHTTPStatus: function () {
          return getAccessFallbackHTTPStatus;
        },
        isHTTPAccessFallbackError: function () {
          return isHTTPAccessFallbackError;
        },
      });
      const HTTPAccessErrorStatus = {
        NOT_FOUND: 404,
        FORBIDDEN: 403,
        UNAUTHORIZED: 401,
      };
      const ALLOWED_CODES = new Set(Object.values(HTTPAccessErrorStatus));
      const HTTP_ERROR_FALLBACK_ERROR_CODE = "NEXT_HTTP_ERROR_FALLBACK";
      function isHTTPAccessFallbackError(error) {
        if (
          typeof error !== "object" ||
          error === null ||
          !("digest" in error) ||
          typeof error.digest !== "string"
        ) {
          return false;
        }
        const [prefix, httpStatus] = error.digest.split(";");
        return prefix === HTTP_ERROR_FALLBACK_ERROR_CODE && ALLOWED_CODES.has(Number(httpStatus));
      }
      function getAccessFallbackHTTPStatus(error) {
        const httpStatus = error.digest.split(";")[1];
        return Number(httpStatus);
      }
      function getAccessFallbackErrorTypeByStatus(status) {
        switch (status) {
          case 401:
            return "unauthorized";
          case 403:
            return "forbidden";
          case 404:
            return "not-found";
          default:
            return;
        }
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=http-access-fallback.js.map

      /***/
    },

    /***/ 9042: /***/ (__unused_webpack_module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "InvariantError", {
        enumerable: true,
        get: function () {
          return InvariantError;
        },
      });
      class InvariantError extends Error {
        constructor(message, options) {
          super(
            "Invariant: " +
              (message.endsWith(".") ? message : message + ".") +
              " This is a bug in Next.js.",
            options,
          );
          this.name = "InvariantError";
        }
      } //# sourceMappingURL=invariant-error.js.map

      /***/
    },

    /***/ 9131: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ACTION_HMR_REFRESH: function () {
          return ACTION_HMR_REFRESH;
        },
        ACTION_NAVIGATE: function () {
          return ACTION_NAVIGATE;
        },
        ACTION_PREFETCH: function () {
          return ACTION_PREFETCH;
        },
        ACTION_REFRESH: function () {
          return ACTION_REFRESH;
        },
        ACTION_RESTORE: function () {
          return ACTION_RESTORE;
        },
        ACTION_SERVER_ACTION: function () {
          return ACTION_SERVER_ACTION;
        },
        ACTION_SERVER_PATCH: function () {
          return ACTION_SERVER_PATCH;
        },
        PrefetchCacheEntryStatus: function () {
          return PrefetchCacheEntryStatus;
        },
        PrefetchKind: function () {
          return PrefetchKind;
        },
      });
      const ACTION_REFRESH = "refresh";
      const ACTION_NAVIGATE = "navigate";
      const ACTION_RESTORE = "restore";
      const ACTION_SERVER_PATCH = "server-patch";
      const ACTION_PREFETCH = "prefetch";
      const ACTION_HMR_REFRESH = "hmr-refresh";
      const ACTION_SERVER_ACTION = "server-action";
      var PrefetchKind = /*#__PURE__*/ (function (PrefetchKind) {
        PrefetchKind["AUTO"] = "auto";
        PrefetchKind["FULL"] = "full";
        PrefetchKind["TEMPORARY"] = "temporary";
        return PrefetchKind;
      })({});
      var PrefetchCacheEntryStatus = /*#__PURE__*/ (function (PrefetchCacheEntryStatus) {
        PrefetchCacheEntryStatus["fresh"] = "fresh";
        PrefetchCacheEntryStatus["reusable"] = "reusable";
        PrefetchCacheEntryStatus["expired"] = "expired";
        PrefetchCacheEntryStatus["stale"] = "stale";
        return PrefetchCacheEntryStatus;
      })({});
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=router-reducer-types.js.map

      /***/
    },

    /***/ 9154: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "HTTPAccessFallbackBoundary", {
        enumerable: true,
        get: function () {
          return HTTPAccessFallbackBoundary;
        },
      });
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _navigationuntracked = __webpack_require__(586);
      const _httpaccessfallback = __webpack_require__(9028);
      const _warnonce = __webpack_require__(2025);
      const _approutercontextsharedruntime = __webpack_require__(6764);
      class HTTPAccessFallbackErrorBoundary extends _react.default.Component {
        componentDidCatch() {
          if (false) {
          }
        }
        static getDerivedStateFromError(error) {
          if ((0, _httpaccessfallback.isHTTPAccessFallbackError)(error)) {
            const httpStatus = (0, _httpaccessfallback.getAccessFallbackHTTPStatus)(error);
            return {
              triggeredStatus: httpStatus,
            };
          }
          // Re-throw if error is not for 404
          throw error;
        }
        static getDerivedStateFromProps(props, state) {
          /**
           * Handles reset of the error boundary when a navigation happens.
           * Ensures the error boundary does not stay enabled when navigating to a new page.
           * Approach of setState in render is safe as it checks the previous pathname and then overrides
           * it as outlined in https://react.dev/reference/react/useState#storing-information-from-previous-renders
           */ if (props.pathname !== state.previousPathname && state.triggeredStatus) {
            return {
              triggeredStatus: undefined,
              previousPathname: props.pathname,
            };
          }
          return {
            triggeredStatus: state.triggeredStatus,
            previousPathname: props.pathname,
          };
        }
        render() {
          const { notFound, forbidden, unauthorized, children } = this.props;
          const { triggeredStatus } = this.state;
          const errorComponents = {
            [_httpaccessfallback.HTTPAccessErrorStatus.NOT_FOUND]: notFound,
            [_httpaccessfallback.HTTPAccessErrorStatus.FORBIDDEN]: forbidden,
            [_httpaccessfallback.HTTPAccessErrorStatus.UNAUTHORIZED]: unauthorized,
          };
          if (triggeredStatus) {
            const isNotFound =
              triggeredStatus === _httpaccessfallback.HTTPAccessErrorStatus.NOT_FOUND && notFound;
            const isForbidden =
              triggeredStatus === _httpaccessfallback.HTTPAccessErrorStatus.FORBIDDEN && forbidden;
            const isUnauthorized =
              triggeredStatus === _httpaccessfallback.HTTPAccessErrorStatus.UNAUTHORIZED &&
              unauthorized;
            // If there's no matched boundary in this layer, keep throwing the error by rendering the children
            if (!(isNotFound || isForbidden || isUnauthorized)) {
              return children;
            }
            return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
              children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)("meta", {
                  name: "robots",
                  content: "noindex",
                }),
                false && /*#__PURE__*/ 0,
                errorComponents[triggeredStatus],
              ],
            });
          }
          return children;
        }
        constructor(props) {
          super(props);
          this.state = {
            triggeredStatus: undefined,
            previousPathname: props.pathname,
          };
        }
      }
      function HTTPAccessFallbackBoundary(param) {
        let { notFound, forbidden, unauthorized, children } = param;
        // When we're rendering the missing params shell, this will return null. This
        // is because we won't be rendering any not found boundaries or error
        // boundaries for the missing params shell. When this runs on the client
        // (where these error can occur), we will get the correct pathname.
        const pathname = (0, _navigationuntracked.useUntrackedPathname)();
        const missingSlots = (0, _react.useContext)(
          _approutercontextsharedruntime.MissingSlotContext,
        );
        const hasErrorFallback = !!(notFound || forbidden || unauthorized);
        if (hasErrorFallback) {
          return /*#__PURE__*/ (0, _jsxruntime.jsx)(HTTPAccessFallbackErrorBoundary, {
            pathname: pathname,
            notFound: notFound,
            forbidden: forbidden,
            unauthorized: unauthorized,
            missingSlots: missingSlots,
            children: children,
          });
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
          children: children,
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=error-boundary.js.map

      /***/
    },

    /***/ 9169: /***/ (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";

      if (true) {
        module.exports = __webpack_require__(9322);
      } else {
      }

      /***/
    },

    /***/ 9291: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "normalizePathTrailingSlash", {
        enumerable: true,
        get: function () {
          return normalizePathTrailingSlash;
        },
      });
      const _removetrailingslash = __webpack_require__(5216);
      const _parsepath = __webpack_require__(3476);
      const normalizePathTrailingSlash = (path) => {
        if (!path.startsWith("/") || undefined) {
          return path;
        }
        const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
        if (false) {
        }
        return "" + (0, _removetrailingslash.removeTrailingSlash)(pathname) + query + hash;
      };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=normalize-trailing-slash.js.map

      /***/
    },

    /***/ 9322: /***/ (__unused_webpack_module, exports, __webpack_require__) => {
      "use strict";
      /**
       * @license React
       * react-server-dom-webpack-client.browser.production.js
       *
       * Copyright (c) Meta Platforms, Inc. and affiliates.
       *
       * This source code is licensed under the MIT license found in the
       * LICENSE file in the root directory of this source tree.
       */

      var ReactDOM = __webpack_require__(8534),
        decoderOptions = { stream: !0 },
        hasOwnProperty = Object.prototype.hasOwnProperty;
      function resolveClientReference(bundlerConfig, metadata) {
        if (bundlerConfig) {
          var moduleExports = bundlerConfig[metadata[0]];
          if ((bundlerConfig = moduleExports && moduleExports[metadata[2]]))
            moduleExports = bundlerConfig.name;
          else {
            bundlerConfig = moduleExports && moduleExports["*"];
            if (!bundlerConfig)
              throw Error(
                'Could not find the module "' +
                  metadata[0] +
                  '" in the React Server Consumer Manifest. This is probably a bug in the React Server Components bundler.',
              );
            moduleExports = metadata[2];
          }
          return 4 === metadata.length
            ? [bundlerConfig.id, bundlerConfig.chunks, moduleExports, 1]
            : [bundlerConfig.id, bundlerConfig.chunks, moduleExports];
        }
        return metadata;
      }
      function resolveServerReference(bundlerConfig, id) {
        var name = "",
          resolvedModuleData = bundlerConfig[id];
        if (resolvedModuleData) name = resolvedModuleData.name;
        else {
          var idx = id.lastIndexOf("#");
          -1 !== idx &&
            ((name = id.slice(idx + 1)), (resolvedModuleData = bundlerConfig[id.slice(0, idx)]));
          if (!resolvedModuleData)
            throw Error(
              'Could not find the module "' +
                id +
                '" in the React Server Manifest. This is probably a bug in the React Server Components bundler.',
            );
        }
        return resolvedModuleData.async
          ? [resolvedModuleData.id, resolvedModuleData.chunks, name, 1]
          : [resolvedModuleData.id, resolvedModuleData.chunks, name];
      }
      var chunkCache = new Map();
      function requireAsyncModule(id) {
        var promise = __webpack_require__(id);
        if ("function" !== typeof promise.then || "fulfilled" === promise.status) return null;
        promise.then(
          function (value) {
            promise.status = "fulfilled";
            promise.value = value;
          },
          function (reason) {
            promise.status = "rejected";
            promise.reason = reason;
          },
        );
        return promise;
      }
      function ignoreReject() {}
      function preloadModule(metadata) {
        for (var chunks = metadata[1], promises = [], i = 0; i < chunks.length;) {
          var chunkId = chunks[i++],
            chunkFilename = chunks[i++],
            entry = chunkCache.get(chunkId);
          void 0 === entry
            ? (chunkMap.set(chunkId, chunkFilename),
              (chunkFilename = __webpack_require__.e(chunkId)),
              promises.push(chunkFilename),
              (entry = chunkCache.set.bind(chunkCache, chunkId, null)),
              chunkFilename.then(entry, ignoreReject),
              chunkCache.set(chunkId, chunkFilename))
            : null !== entry && promises.push(entry);
        }
        return 4 === metadata.length
          ? 0 === promises.length
            ? requireAsyncModule(metadata[0])
            : Promise.all(promises).then(function () {
                return requireAsyncModule(metadata[0]);
              })
          : 0 < promises.length
            ? Promise.all(promises)
            : null;
      }
      function requireModule(metadata) {
        var moduleExports = __webpack_require__(metadata[0]);
        if (4 === metadata.length && "function" === typeof moduleExports.then)
          if ("fulfilled" === moduleExports.status) moduleExports = moduleExports.value;
          else throw moduleExports.reason;
        if ("*" === metadata[2]) return moduleExports;
        if ("" === metadata[2])
          return moduleExports.__esModule ? moduleExports.default : moduleExports;
        if (hasOwnProperty.call(moduleExports, metadata[2])) return moduleExports[metadata[2]];
      }
      var chunkMap = new Map(),
        webpackGetChunkFilename = __webpack_require__.u;
      __webpack_require__.u = function (chunkId) {
        var flightChunk = chunkMap.get(chunkId);
        return void 0 !== flightChunk ? flightChunk : webpackGetChunkFilename(chunkId);
      };
      var ReactDOMSharedInternals =
          ReactDOM.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
        REACT_LAZY_TYPE = Symbol.for("react.lazy"),
        MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
      function getIteratorFn(maybeIterable) {
        if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
        maybeIterable =
          (MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL]) ||
          maybeIterable["@@iterator"];
        return "function" === typeof maybeIterable ? maybeIterable : null;
      }
      var ASYNC_ITERATOR = Symbol.asyncIterator,
        isArrayImpl = Array.isArray,
        getPrototypeOf = Object.getPrototypeOf,
        ObjectPrototype$1 = Object.prototype,
        knownServerReferences = new WeakMap();
      function serializeNumber(number) {
        return Number.isFinite(number)
          ? 0 === number && -Infinity === 1 / number
            ? "$-0"
            : number
          : Infinity === number
            ? "$Infinity"
            : -Infinity === number
              ? "$-Infinity"
              : "$NaN";
      }
      function processReply(root, formFieldPrefix, temporaryReferences, resolve, reject) {
        function serializeTypedArray(tag, typedArray) {
          typedArray = new Blob([
            new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength),
          ]);
          var blobId = nextPartId++;
          null === formData && (formData = new FormData());
          formData.append(formFieldPrefix + blobId, typedArray);
          return "$" + tag + blobId.toString(16);
        }
        function serializeBinaryReader(reader) {
          function progress(entry) {
            entry.done
              ? ((entry = nextPartId++),
                data.append(formFieldPrefix + entry, new Blob(buffer)),
                data.append(formFieldPrefix + streamId, '"$o' + entry.toString(16) + '"'),
                data.append(formFieldPrefix + streamId, "C"),
                pendingParts--,
                0 === pendingParts && resolve(data))
              : (buffer.push(entry.value),
                reader.read(new Uint8Array(1024)).then(progress, reject));
          }
          null === formData && (formData = new FormData());
          var data = formData;
          pendingParts++;
          var streamId = nextPartId++,
            buffer = [];
          reader.read(new Uint8Array(1024)).then(progress, reject);
          return "$r" + streamId.toString(16);
        }
        function serializeReader(reader) {
          function progress(entry) {
            if (entry.done)
              (data.append(formFieldPrefix + streamId, "C"),
                pendingParts--,
                0 === pendingParts && resolve(data));
            else
              try {
                var partJSON = JSON.stringify(entry.value, resolveToJSON);
                data.append(formFieldPrefix + streamId, partJSON);
                reader.read().then(progress, reject);
              } catch (x) {
                reject(x);
              }
          }
          null === formData && (formData = new FormData());
          var data = formData;
          pendingParts++;
          var streamId = nextPartId++;
          reader.read().then(progress, reject);
          return "$R" + streamId.toString(16);
        }
        function serializeReadableStream(stream) {
          try {
            var binaryReader = stream.getReader({ mode: "byob" });
          } catch (x) {
            return serializeReader(stream.getReader());
          }
          return serializeBinaryReader(binaryReader);
        }
        function serializeAsyncIterable(iterable, iterator) {
          function progress(entry) {
            if (entry.done) {
              if (void 0 === entry.value) data.append(formFieldPrefix + streamId, "C");
              else
                try {
                  var partJSON = JSON.stringify(entry.value, resolveToJSON);
                  data.append(formFieldPrefix + streamId, "C" + partJSON);
                } catch (x) {
                  reject(x);
                  return;
                }
              pendingParts--;
              0 === pendingParts && resolve(data);
            } else
              try {
                var partJSON$21 = JSON.stringify(entry.value, resolveToJSON);
                data.append(formFieldPrefix + streamId, partJSON$21);
                iterator.next().then(progress, reject);
              } catch (x$22) {
                reject(x$22);
              }
          }
          null === formData && (formData = new FormData());
          var data = formData;
          pendingParts++;
          var streamId = nextPartId++;
          iterable = iterable === iterator;
          iterator.next().then(progress, reject);
          return "$" + (iterable ? "x" : "X") + streamId.toString(16);
        }
        function resolveToJSON(key, value) {
          if (null === value) return null;
          if ("object" === typeof value) {
            switch (value.$$typeof) {
              case REACT_ELEMENT_TYPE:
                if (void 0 !== temporaryReferences && -1 === key.indexOf(":")) {
                  var parentReference = writtenObjects.get(this);
                  if (void 0 !== parentReference)
                    return (temporaryReferences.set(parentReference + ":" + key, value), "$T");
                }
                throw Error(
                  "React Element cannot be passed to Server Functions from the Client without a temporary reference set. Pass a TemporaryReferenceSet to the options.",
                );
              case REACT_LAZY_TYPE:
                parentReference = value._payload;
                var init = value._init;
                null === formData && (formData = new FormData());
                pendingParts++;
                try {
                  var resolvedModel = init(parentReference),
                    lazyId = nextPartId++,
                    partJSON = serializeModel(resolvedModel, lazyId);
                  formData.append(formFieldPrefix + lazyId, partJSON);
                  return "$" + lazyId.toString(16);
                } catch (x) {
                  if ("object" === typeof x && null !== x && "function" === typeof x.then) {
                    pendingParts++;
                    var lazyId$23 = nextPartId++;
                    parentReference = function () {
                      try {
                        var partJSON$24 = serializeModel(value, lazyId$23),
                          data$25 = formData;
                        data$25.append(formFieldPrefix + lazyId$23, partJSON$24);
                        pendingParts--;
                        0 === pendingParts && resolve(data$25);
                      } catch (reason) {
                        reject(reason);
                      }
                    };
                    x.then(parentReference, parentReference);
                    return "$" + lazyId$23.toString(16);
                  }
                  reject(x);
                  return null;
                } finally {
                  pendingParts--;
                }
            }
            parentReference = writtenObjects.get(value);
            if ("function" === typeof value.then) {
              if (void 0 !== parentReference)
                if (modelRoot === value) modelRoot = null;
                else return parentReference;
              null === formData && (formData = new FormData());
              pendingParts++;
              var promiseId = nextPartId++;
              key = "$@" + promiseId.toString(16);
              writtenObjects.set(value, key);
              value.then(function (partValue) {
                try {
                  var previousReference = writtenObjects.get(partValue);
                  var partJSON$27 =
                    void 0 !== previousReference
                      ? JSON.stringify(previousReference)
                      : serializeModel(partValue, promiseId);
                  partValue = formData;
                  partValue.append(formFieldPrefix + promiseId, partJSON$27);
                  pendingParts--;
                  0 === pendingParts && resolve(partValue);
                } catch (reason) {
                  reject(reason);
                }
              }, reject);
              return key;
            }
            if (void 0 !== parentReference)
              if (modelRoot === value) modelRoot = null;
              else return parentReference;
            else
              -1 === key.indexOf(":") &&
                ((parentReference = writtenObjects.get(this)),
                void 0 !== parentReference &&
                  ((key = parentReference + ":" + key),
                  writtenObjects.set(value, key),
                  void 0 !== temporaryReferences && temporaryReferences.set(key, value)));
            if (isArrayImpl(value)) return value;
            if (value instanceof FormData) {
              null === formData && (formData = new FormData());
              var data$31 = formData;
              key = nextPartId++;
              var prefix = formFieldPrefix + "_" + key + "_";
              value.forEach(function (originalValue, originalKey) {
                data$31.append(prefix + originalKey, originalValue);
              });
              return "$K" + key.toString(16);
            }
            if (value instanceof Map)
              return (
                (key = nextPartId++),
                (parentReference = serializeModel(Array.from(value), key)),
                null === formData && (formData = new FormData()),
                formData.append(formFieldPrefix + key, parentReference),
                "$Q" + key.toString(16)
              );
            if (value instanceof Set)
              return (
                (key = nextPartId++),
                (parentReference = serializeModel(Array.from(value), key)),
                null === formData && (formData = new FormData()),
                formData.append(formFieldPrefix + key, parentReference),
                "$W" + key.toString(16)
              );
            if (value instanceof ArrayBuffer)
              return (
                (key = new Blob([value])),
                (parentReference = nextPartId++),
                null === formData && (formData = new FormData()),
                formData.append(formFieldPrefix + parentReference, key),
                "$A" + parentReference.toString(16)
              );
            if (value instanceof Int8Array) return serializeTypedArray("O", value);
            if (value instanceof Uint8Array) return serializeTypedArray("o", value);
            if (value instanceof Uint8ClampedArray) return serializeTypedArray("U", value);
            if (value instanceof Int16Array) return serializeTypedArray("S", value);
            if (value instanceof Uint16Array) return serializeTypedArray("s", value);
            if (value instanceof Int32Array) return serializeTypedArray("L", value);
            if (value instanceof Uint32Array) return serializeTypedArray("l", value);
            if (value instanceof Float32Array) return serializeTypedArray("G", value);
            if (value instanceof Float64Array) return serializeTypedArray("g", value);
            if (value instanceof BigInt64Array) return serializeTypedArray("M", value);
            if (value instanceof BigUint64Array) return serializeTypedArray("m", value);
            if (value instanceof DataView) return serializeTypedArray("V", value);
            if ("function" === typeof Blob && value instanceof Blob)
              return (
                null === formData && (formData = new FormData()),
                (key = nextPartId++),
                formData.append(formFieldPrefix + key, value),
                "$B" + key.toString(16)
              );
            if ((key = getIteratorFn(value)))
              return (
                (parentReference = key.call(value)),
                parentReference === value
                  ? ((key = nextPartId++),
                    (parentReference = serializeModel(Array.from(parentReference), key)),
                    null === formData && (formData = new FormData()),
                    formData.append(formFieldPrefix + key, parentReference),
                    "$i" + key.toString(16))
                  : Array.from(parentReference)
              );
            if ("function" === typeof ReadableStream && value instanceof ReadableStream)
              return serializeReadableStream(value);
            key = value[ASYNC_ITERATOR];
            if ("function" === typeof key) return serializeAsyncIterable(value, key.call(value));
            key = getPrototypeOf(value);
            if (key !== ObjectPrototype$1 && (null === key || null !== getPrototypeOf(key))) {
              if (void 0 === temporaryReferences)
                throw Error(
                  "Only plain objects, and a few built-ins, can be passed to Server Functions. Classes or null prototypes are not supported.",
                );
              return "$T";
            }
            return value;
          }
          if ("string" === typeof value) {
            if ("Z" === value[value.length - 1] && this[key] instanceof Date) return "$D" + value;
            key = "$" === value[0] ? "$" + value : value;
            return key;
          }
          if ("boolean" === typeof value) return value;
          if ("number" === typeof value) return serializeNumber(value);
          if ("undefined" === typeof value) return "$undefined";
          if ("function" === typeof value) {
            parentReference = knownServerReferences.get(value);
            if (void 0 !== parentReference) {
              key = writtenObjects.get(value);
              if (void 0 !== key) return key;
              key = JSON.stringify(
                { id: parentReference.id, bound: parentReference.bound },
                resolveToJSON,
              );
              null === formData && (formData = new FormData());
              parentReference = nextPartId++;
              formData.set(formFieldPrefix + parentReference, key);
              key = "$h" + parentReference.toString(16);
              writtenObjects.set(value, key);
              return key;
            }
            if (
              void 0 !== temporaryReferences &&
              -1 === key.indexOf(":") &&
              ((parentReference = writtenObjects.get(this)), void 0 !== parentReference)
            )
              return (temporaryReferences.set(parentReference + ":" + key, value), "$T");
            throw Error(
              "Client Functions cannot be passed directly to Server Functions. Only Functions passed from the Server can be passed back again.",
            );
          }
          if ("symbol" === typeof value) {
            if (
              void 0 !== temporaryReferences &&
              -1 === key.indexOf(":") &&
              ((parentReference = writtenObjects.get(this)), void 0 !== parentReference)
            )
              return (temporaryReferences.set(parentReference + ":" + key, value), "$T");
            throw Error(
              "Symbols cannot be passed to a Server Function without a temporary reference set. Pass a TemporaryReferenceSet to the options.",
            );
          }
          if ("bigint" === typeof value) return "$n" + value.toString(10);
          throw Error(
            "Type " + typeof value + " is not supported as an argument to a Server Function.",
          );
        }
        function serializeModel(model, id) {
          "object" === typeof model &&
            null !== model &&
            ((id = "$" + id.toString(16)),
            writtenObjects.set(model, id),
            void 0 !== temporaryReferences && temporaryReferences.set(id, model));
          modelRoot = model;
          return JSON.stringify(model, resolveToJSON);
        }
        var nextPartId = 1,
          pendingParts = 0,
          formData = null,
          writtenObjects = new WeakMap(),
          modelRoot = root,
          json = serializeModel(root, 0);
        null === formData
          ? resolve(json)
          : (formData.set(formFieldPrefix + "0", json), 0 === pendingParts && resolve(formData));
        return function () {
          0 < pendingParts &&
            ((pendingParts = 0), null === formData ? resolve(json) : resolve(formData));
        };
      }
      function registerBoundServerReference(reference, id, bound) {
        knownServerReferences.has(reference) ||
          knownServerReferences.set(reference, {
            id: id,
            originalBind: reference.bind,
            bound: bound,
          });
      }
      function createBoundServerReference(metaData, callServer) {
        function action() {
          var args = Array.prototype.slice.call(arguments);
          return bound
            ? "fulfilled" === bound.status
              ? callServer(id, bound.value.concat(args))
              : Promise.resolve(bound).then(function (boundArgs) {
                  return callServer(id, boundArgs.concat(args));
                })
            : callServer(id, args);
        }
        var id = metaData.id,
          bound = metaData.bound;
        registerBoundServerReference(action, id, bound);
        return action;
      }
      var ObjectPrototype = Object.prototype,
        ArrayPrototype = Array.prototype;
      function ReactPromise(status, value, reason) {
        this.status = status;
        this.value = value;
        this.reason = reason;
      }
      ReactPromise.prototype = Object.create(Promise.prototype);
      ReactPromise.prototype.then = function (resolve, reject) {
        switch (this.status) {
          case "resolved_model":
            initializeModelChunk(this);
            break;
          case "resolved_module":
            initializeModuleChunk(this);
        }
        switch (this.status) {
          case "fulfilled":
            "function" === typeof resolve && resolve(this.value);
            break;
          case "pending":
          case "blocked":
            "function" === typeof resolve &&
              (null === this.value && (this.value = []), this.value.push(resolve));
            "function" === typeof reject &&
              (null === this.reason && (this.reason = []), this.reason.push(reject));
            break;
          case "halted":
            break;
          default:
            "function" === typeof reject && reject(this.reason);
        }
      };
      function readChunk(chunk) {
        switch (chunk.status) {
          case "resolved_model":
            initializeModelChunk(chunk);
            break;
          case "resolved_module":
            initializeModuleChunk(chunk);
        }
        switch (chunk.status) {
          case "fulfilled":
            return chunk.value;
          case "pending":
          case "blocked":
          case "halted":
            throw chunk;
          default:
            throw chunk.reason;
        }
      }
      function wakeChunk(listeners, value) {
        for (var i = 0; i < listeners.length; i++) {
          var listener = listeners[i];
          "function" === typeof listener ? listener(value) : fulfillReference(listener, value);
        }
      }
      function rejectChunk(listeners, error) {
        for (var i = 0; i < listeners.length; i++) {
          var listener = listeners[i];
          "function" === typeof listener ? listener(error) : rejectReference(listener, error);
        }
      }
      function resolveBlockedCycle(resolvedChunk, reference) {
        var referencedChunk = reference.handler.chunk;
        if (null === referencedChunk) return null;
        if (referencedChunk === resolvedChunk) return reference.handler;
        reference = referencedChunk.value;
        if (null !== reference)
          for (referencedChunk = 0; referencedChunk < reference.length; referencedChunk++) {
            var listener = reference[referencedChunk];
            if (
              "function" !== typeof listener &&
              ((listener = resolveBlockedCycle(resolvedChunk, listener)), null !== listener)
            )
              return listener;
          }
        return null;
      }
      function wakeChunkIfInitialized(chunk, resolveListeners, rejectListeners) {
        switch (chunk.status) {
          case "fulfilled":
            wakeChunk(resolveListeners, chunk.value);
            break;
          case "blocked":
            for (var i = 0; i < resolveListeners.length; i++) {
              var listener = resolveListeners[i];
              if ("function" !== typeof listener) {
                var cyclicHandler = resolveBlockedCycle(chunk, listener);
                if (null !== cyclicHandler)
                  switch (
                    (fulfillReference(listener, cyclicHandler.value),
                    resolveListeners.splice(i, 1),
                    i--,
                    null !== rejectListeners &&
                      ((listener = rejectListeners.indexOf(listener)),
                      -1 !== listener && rejectListeners.splice(listener, 1)),
                    chunk.status)
                  ) {
                    case "fulfilled":
                      wakeChunk(resolveListeners, chunk.value);
                      return;
                    case "rejected":
                      null !== rejectListeners && rejectChunk(rejectListeners, chunk.reason);
                      return;
                  }
              }
            }
          case "pending":
            if (chunk.value)
              for (i = 0; i < resolveListeners.length; i++) chunk.value.push(resolveListeners[i]);
            else chunk.value = resolveListeners;
            if (chunk.reason) {
              if (rejectListeners)
                for (
                  resolveListeners = 0;
                  resolveListeners < rejectListeners.length;
                  resolveListeners++
                )
                  chunk.reason.push(rejectListeners[resolveListeners]);
            } else chunk.reason = rejectListeners;
            break;
          case "rejected":
            rejectListeners && rejectChunk(rejectListeners, chunk.reason);
        }
      }
      function triggerErrorOnChunk(response, chunk, error) {
        "pending" !== chunk.status && "blocked" !== chunk.status
          ? chunk.reason.error(error)
          : ((response = chunk.reason),
            (chunk.status = "rejected"),
            (chunk.reason = error),
            null !== response && rejectChunk(response, error));
      }
      function createResolvedIteratorResultChunk(response, value, done) {
        return new ReactPromise(
          "resolved_model",
          (done ? '{"done":true,"value":' : '{"done":false,"value":') + value + "}",
          response,
        );
      }
      function resolveIteratorResultChunk(response, chunk, value, done) {
        resolveModelChunk(
          response,
          chunk,
          (done ? '{"done":true,"value":' : '{"done":false,"value":') + value + "}",
        );
      }
      function resolveModelChunk(response, chunk, value) {
        if ("pending" !== chunk.status) chunk.reason.enqueueModel(value);
        else {
          var resolveListeners = chunk.value,
            rejectListeners = chunk.reason;
          chunk.status = "resolved_model";
          chunk.value = value;
          chunk.reason = response;
          null !== resolveListeners &&
            (initializeModelChunk(chunk),
            wakeChunkIfInitialized(chunk, resolveListeners, rejectListeners));
        }
      }
      function resolveModuleChunk(response, chunk, value) {
        if ("pending" === chunk.status || "blocked" === chunk.status) {
          response = chunk.value;
          var rejectListeners = chunk.reason;
          chunk.status = "resolved_module";
          chunk.value = value;
          chunk.reason = null;
          null !== response &&
            (initializeModuleChunk(chunk),
            wakeChunkIfInitialized(chunk, response, rejectListeners));
        }
      }
      var initializingHandler = null;
      function initializeModelChunk(chunk) {
        var prevHandler = initializingHandler;
        initializingHandler = null;
        var resolvedModel = chunk.value,
          response = chunk.reason;
        chunk.status = "blocked";
        chunk.value = null;
        chunk.reason = null;
        try {
          var value = JSON.parse(resolvedModel, response._fromJSON),
            resolveListeners = chunk.value;
          null !== resolveListeners &&
            ((chunk.value = null), (chunk.reason = null), wakeChunk(resolveListeners, value));
          if (null !== initializingHandler) {
            if (initializingHandler.errored) throw initializingHandler.reason;
            if (0 < initializingHandler.deps) {
              initializingHandler.value = value;
              initializingHandler.reason = null;
              initializingHandler.chunk = chunk;
              return;
            }
          }
          chunk.status = "fulfilled";
          chunk.value = value;
          chunk.reason = null;
        } catch (error) {
          ((chunk.status = "rejected"), (chunk.reason = error));
        } finally {
          initializingHandler = prevHandler;
        }
      }
      function initializeModuleChunk(chunk) {
        try {
          var value = requireModule(chunk.value);
          chunk.status = "fulfilled";
          chunk.value = value;
          chunk.reason = null;
        } catch (error) {
          ((chunk.status = "rejected"), (chunk.reason = error));
        }
      }
      function reportGlobalError(weakResponse, error) {
        weakResponse._closed = !0;
        weakResponse._closedReason = error;
        weakResponse._chunks.forEach(function (chunk) {
          "pending" === chunk.status
            ? triggerErrorOnChunk(weakResponse, chunk, error)
            : "fulfilled" === chunk.status && null !== chunk.reason && chunk.reason.error(error);
        });
      }
      function createLazyChunkWrapper(chunk) {
        return { $$typeof: REACT_LAZY_TYPE, _payload: chunk, _init: readChunk };
      }
      function getChunk(response, id) {
        var chunks = response._chunks,
          chunk = chunks.get(id);
        chunk ||
          ((chunk = response._closed
            ? new ReactPromise("rejected", null, response._closedReason)
            : new ReactPromise("pending", null, null)),
          chunks.set(id, chunk));
        return chunk;
      }
      function fulfillReference(reference, value) {
        var response = reference.response,
          handler = reference.handler,
          parentObject = reference.parentObject,
          key = reference.key,
          map = reference.map,
          path = reference.path;
        try {
          for (var i = 1; i < path.length; i++) {
            for (; value.$$typeof === REACT_LAZY_TYPE;) {
              var referencedChunk = value._payload;
              if (referencedChunk === handler.chunk) value = handler.value;
              else {
                switch (referencedChunk.status) {
                  case "resolved_model":
                    initializeModelChunk(referencedChunk);
                    break;
                  case "resolved_module":
                    initializeModuleChunk(referencedChunk);
                }
                switch (referencedChunk.status) {
                  case "fulfilled":
                    value = referencedChunk.value;
                    continue;
                  case "blocked":
                    var cyclicHandler = resolveBlockedCycle(referencedChunk, reference);
                    if (null !== cyclicHandler) {
                      value = cyclicHandler.value;
                      continue;
                    }
                  case "pending":
                    path.splice(0, i - 1);
                    null === referencedChunk.value
                      ? (referencedChunk.value = [reference])
                      : referencedChunk.value.push(reference);
                    null === referencedChunk.reason
                      ? (referencedChunk.reason = [reference])
                      : referencedChunk.reason.push(reference);
                    return;
                  case "halted":
                    return;
                  default:
                    rejectReference(reference, referencedChunk.reason);
                    return;
                }
              }
            }
            var name = path[i];
            if ("object" === typeof value && null !== value && hasOwnProperty.call(value, name))
              value = value[name];
            else throw Error("Invalid reference.");
          }
          var mappedValue = map(response, value, parentObject, key);
          "__proto__" !== key && (parentObject[key] = mappedValue);
          "" === key && null === handler.value && (handler.value = mappedValue);
          if (
            parentObject[0] === REACT_ELEMENT_TYPE &&
            "object" === typeof handler.value &&
            null !== handler.value &&
            handler.value.$$typeof === REACT_ELEMENT_TYPE
          ) {
            var element = handler.value;
            switch (key) {
              case "3":
                element.props = mappedValue;
            }
          }
        } catch (error) {
          rejectReference(reference, error);
          return;
        }
        handler.deps--;
        0 === handler.deps &&
          ((reference = handler.chunk),
          null !== reference &&
            "blocked" === reference.status &&
            ((value = reference.value),
            (reference.status = "fulfilled"),
            (reference.value = handler.value),
            (reference.reason = handler.reason),
            null !== value && wakeChunk(value, handler.value)));
      }
      function rejectReference(reference, error) {
        var handler = reference.handler;
        reference = reference.response;
        handler.errored ||
          ((handler.errored = !0),
          (handler.value = null),
          (handler.reason = error),
          (handler = handler.chunk),
          null !== handler &&
            "blocked" === handler.status &&
            triggerErrorOnChunk(reference, handler, error));
      }
      function waitForReference(referencedChunk, parentObject, key, response, map, path) {
        if (initializingHandler) {
          var handler = initializingHandler;
          handler.deps++;
        } else
          handler = initializingHandler = {
            parent: null,
            chunk: null,
            value: null,
            reason: null,
            deps: 1,
            errored: !1,
          };
        parentObject = {
          response: response,
          handler: handler,
          parentObject: parentObject,
          key: key,
          map: map,
          path: path,
        };
        null === referencedChunk.value
          ? (referencedChunk.value = [parentObject])
          : referencedChunk.value.push(parentObject);
        null === referencedChunk.reason
          ? (referencedChunk.reason = [parentObject])
          : referencedChunk.reason.push(parentObject);
        return null;
      }
      function loadServerReference(response, metaData, parentObject, key) {
        if (!response._serverReferenceConfig)
          return createBoundServerReference(metaData, response._callServer);
        var serverReference = resolveServerReference(response._serverReferenceConfig, metaData.id),
          promise = preloadModule(serverReference);
        if (promise) metaData.bound && (promise = Promise.all([promise, metaData.bound]));
        else if (metaData.bound) promise = Promise.resolve(metaData.bound);
        else
          return (
            (promise = requireModule(serverReference)),
            registerBoundServerReference(promise, metaData.id, metaData.bound),
            promise
          );
        if (initializingHandler) {
          var handler = initializingHandler;
          handler.deps++;
        } else
          handler = initializingHandler = {
            parent: null,
            chunk: null,
            value: null,
            reason: null,
            deps: 1,
            errored: !1,
          };
        promise.then(
          function () {
            var resolvedValue = requireModule(serverReference);
            if (metaData.bound) {
              var boundArgs = metaData.bound.value.slice(0);
              boundArgs.unshift(null);
              resolvedValue = resolvedValue.bind.apply(resolvedValue, boundArgs);
            }
            registerBoundServerReference(resolvedValue, metaData.id, metaData.bound);
            "__proto__" !== key && (parentObject[key] = resolvedValue);
            "" === key && null === handler.value && (handler.value = resolvedValue);
            if (
              parentObject[0] === REACT_ELEMENT_TYPE &&
              "object" === typeof handler.value &&
              null !== handler.value &&
              handler.value.$$typeof === REACT_ELEMENT_TYPE
            )
              switch (((boundArgs = handler.value), key)) {
                case "3":
                  boundArgs.props = resolvedValue;
              }
            handler.deps--;
            0 === handler.deps &&
              ((resolvedValue = handler.chunk),
              null !== resolvedValue &&
                "blocked" === resolvedValue.status &&
                ((boundArgs = resolvedValue.value),
                (resolvedValue.status = "fulfilled"),
                (resolvedValue.value = handler.value),
                (resolvedValue.reason = null),
                null !== boundArgs && wakeChunk(boundArgs, handler.value)));
          },
          function (error) {
            if (!handler.errored) {
              handler.errored = !0;
              handler.value = null;
              handler.reason = error;
              var chunk = handler.chunk;
              null !== chunk &&
                "blocked" === chunk.status &&
                triggerErrorOnChunk(response, chunk, error);
            }
          },
        );
        return null;
      }
      function getOutlinedModel(response, reference, parentObject, key, map) {
        reference = reference.split(":");
        var id = parseInt(reference[0], 16);
        id = getChunk(response, id);
        switch (id.status) {
          case "resolved_model":
            initializeModelChunk(id);
            break;
          case "resolved_module":
            initializeModuleChunk(id);
        }
        switch (id.status) {
          case "fulfilled":
            var value = id.value;
            for (id = 1; id < reference.length; id++) {
              for (; value.$$typeof === REACT_LAZY_TYPE;) {
                value = value._payload;
                switch (value.status) {
                  case "resolved_model":
                    initializeModelChunk(value);
                    break;
                  case "resolved_module":
                    initializeModuleChunk(value);
                }
                switch (value.status) {
                  case "fulfilled":
                    value = value.value;
                    break;
                  case "blocked":
                  case "pending":
                    return waitForReference(
                      value,
                      parentObject,
                      key,
                      response,
                      map,
                      reference.slice(id - 1),
                    );
                  case "halted":
                    return (
                      initializingHandler
                        ? ((response = initializingHandler), response.deps++)
                        : (initializingHandler = {
                            parent: null,
                            chunk: null,
                            value: null,
                            reason: null,
                            deps: 1,
                            errored: !1,
                          }),
                      null
                    );
                  default:
                    return (
                      initializingHandler
                        ? ((initializingHandler.errored = !0),
                          (initializingHandler.value = null),
                          (initializingHandler.reason = value.reason))
                        : (initializingHandler = {
                            parent: null,
                            chunk: null,
                            value: null,
                            reason: value.reason,
                            deps: 0,
                            errored: !0,
                          }),
                      null
                    );
                }
              }
              var name = reference[id];
              if (
                "object" !== typeof value ||
                null === value ||
                (getPrototypeOf(value) !== ObjectPrototype &&
                  getPrototypeOf(value) !== ArrayPrototype) ||
                !hasOwnProperty.call(value, name)
              )
                throw Error("Invalid reference.");
              value = value[name];
            }
            return map(response, value, parentObject, key);
          case "pending":
          case "blocked":
            return waitForReference(id, parentObject, key, response, map, reference);
          case "halted":
            return (
              initializingHandler
                ? ((response = initializingHandler), response.deps++)
                : (initializingHandler = {
                    parent: null,
                    chunk: null,
                    value: null,
                    reason: null,
                    deps: 1,
                    errored: !1,
                  }),
              null
            );
          default:
            return (
              initializingHandler
                ? ((initializingHandler.errored = !0),
                  (initializingHandler.value = null),
                  (initializingHandler.reason = id.reason))
                : (initializingHandler = {
                    parent: null,
                    chunk: null,
                    value: null,
                    reason: id.reason,
                    deps: 0,
                    errored: !0,
                  }),
              null
            );
        }
      }
      function createMap(response, model) {
        return new Map(model);
      }
      function createSet(response, model) {
        return new Set(model);
      }
      function createBlob(response, model) {
        return new Blob(model.slice(1), { type: model[0] });
      }
      function createFormData(response, model) {
        response = new FormData();
        for (var i = 0; i < model.length; i++) response.append(model[i][0], model[i][1]);
        return response;
      }
      function extractIterator(response, model) {
        return model[Symbol.iterator]();
      }
      function createModel(response, model) {
        return model;
      }
      function parseModelString(response, parentObject, key, value) {
        if ("$" === value[0]) {
          if ("$" === value)
            return (
              null !== initializingHandler &&
                "0" === key &&
                (initializingHandler = {
                  parent: initializingHandler,
                  chunk: null,
                  value: null,
                  reason: null,
                  deps: 0,
                  errored: !1,
                }),
              REACT_ELEMENT_TYPE
            );
          switch (value[1]) {
            case "$":
              return value.slice(1);
            case "L":
              return (
                (parentObject = parseInt(value.slice(2), 16)),
                (response = getChunk(response, parentObject)),
                createLazyChunkWrapper(response)
              );
            case "@":
              return (
                (parentObject = parseInt(value.slice(2), 16)),
                getChunk(response, parentObject)
              );
            case "S":
              return Symbol.for(value.slice(2));
            case "h":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, loadServerReference)
              );
            case "T":
              parentObject = "$" + value.slice(2);
              response = response._tempRefs;
              if (null == response)
                throw Error(
                  "Missing a temporary reference set but the RSC response returned a temporary reference. Pass a temporaryReference option with the set that was used with the reply.",
                );
              return response.get(parentObject);
            case "Q":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, createMap)
              );
            case "W":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, createSet)
              );
            case "B":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, createBlob)
              );
            case "K":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, createFormData)
              );
            case "Z":
              return resolveErrorProd();
            case "i":
              return (
                (value = value.slice(2)),
                getOutlinedModel(response, value, parentObject, key, extractIterator)
              );
            case "I":
              return Infinity;
            case "-":
              return "$-0" === value ? -0 : -Infinity;
            case "N":
              return NaN;
            case "u":
              return;
            case "D":
              return new Date(Date.parse(value.slice(2)));
            case "n":
              return BigInt(value.slice(2));
            default:
              return (
                (value = value.slice(1)),
                getOutlinedModel(response, value, parentObject, key, createModel)
              );
          }
        }
        return value;
      }
      function missingCall() {
        throw Error(
          'Trying to call a function from "use server" but the callServer option was not implemented in your router runtime.',
        );
      }
      function ResponseInstance(
        bundlerConfig,
        serverReferenceConfig,
        moduleLoading,
        callServer,
        encodeFormAction,
        nonce,
        temporaryReferences,
      ) {
        var chunks = new Map();
        this._bundlerConfig = bundlerConfig;
        this._serverReferenceConfig = serverReferenceConfig;
        this._moduleLoading = moduleLoading;
        this._callServer = void 0 !== callServer ? callServer : missingCall;
        this._encodeFormAction = encodeFormAction;
        this._nonce = nonce;
        this._chunks = chunks;
        this._stringDecoder = new TextDecoder();
        this._fromJSON = null;
        this._closed = !1;
        this._closedReason = null;
        this._tempRefs = temporaryReferences;
        this._fromJSON = createFromJSONCallback(this);
      }
      function resolveBuffer(response, id, buffer) {
        response = response._chunks;
        var chunk = response.get(id);
        chunk && "pending" !== chunk.status
          ? chunk.reason.enqueueValue(buffer)
          : response.set(id, new ReactPromise("fulfilled", buffer, null));
      }
      function resolveModule(response, id, model) {
        var chunks = response._chunks,
          chunk = chunks.get(id);
        model = JSON.parse(model, response._fromJSON);
        var clientReference = resolveClientReference(response._bundlerConfig, model);
        if ((model = preloadModule(clientReference))) {
          if (chunk) {
            var blockedChunk = chunk;
            blockedChunk.status = "blocked";
          } else
            ((blockedChunk = new ReactPromise("blocked", null, null)),
              chunks.set(id, blockedChunk));
          model.then(
            function () {
              return resolveModuleChunk(response, blockedChunk, clientReference);
            },
            function (error) {
              return triggerErrorOnChunk(response, blockedChunk, error);
            },
          );
        } else
          chunk
            ? resolveModuleChunk(response, chunk, clientReference)
            : chunks.set(id, new ReactPromise("resolved_module", clientReference, null));
      }
      function resolveStream(response, id, stream, controller) {
        var chunks = response._chunks;
        response = chunks.get(id);
        response
          ? "pending" === response.status &&
            ((id = response.value),
            (response.status = "fulfilled"),
            (response.value = stream),
            (response.reason = controller),
            null !== id && wakeChunk(id, response.value))
          : chunks.set(id, new ReactPromise("fulfilled", stream, controller));
      }
      function startReadableStream(response, id, type) {
        var controller = null,
          closed = !1;
        type = new ReadableStream({
          type: type,
          start: function (c) {
            controller = c;
          },
        });
        var previousBlockedChunk = null;
        resolveStream(response, id, type, {
          enqueueValue: function (value) {
            null === previousBlockedChunk
              ? controller.enqueue(value)
              : previousBlockedChunk.then(function () {
                  controller.enqueue(value);
                });
          },
          enqueueModel: function (json) {
            if (null === previousBlockedChunk) {
              var chunk = new ReactPromise("resolved_model", json, response);
              initializeModelChunk(chunk);
              "fulfilled" === chunk.status
                ? controller.enqueue(chunk.value)
                : (chunk.then(
                    function (v) {
                      return controller.enqueue(v);
                    },
                    function (e) {
                      return controller.error(e);
                    },
                  ),
                  (previousBlockedChunk = chunk));
            } else {
              chunk = previousBlockedChunk;
              var chunk$53 = new ReactPromise("pending", null, null);
              chunk$53.then(
                function (v) {
                  return controller.enqueue(v);
                },
                function (e) {
                  return controller.error(e);
                },
              );
              previousBlockedChunk = chunk$53;
              chunk.then(function () {
                previousBlockedChunk === chunk$53 && (previousBlockedChunk = null);
                resolveModelChunk(response, chunk$53, json);
              });
            }
          },
          close: function () {
            if (!closed)
              if (((closed = !0), null === previousBlockedChunk)) controller.close();
              else {
                var blockedChunk = previousBlockedChunk;
                previousBlockedChunk = null;
                blockedChunk.then(function () {
                  return controller.close();
                });
              }
          },
          error: function (error) {
            if (!closed)
              if (((closed = !0), null === previousBlockedChunk)) controller.error(error);
              else {
                var blockedChunk = previousBlockedChunk;
                previousBlockedChunk = null;
                blockedChunk.then(function () {
                  return controller.error(error);
                });
              }
          },
        });
      }
      function asyncIterator() {
        return this;
      }
      function createIterator(next) {
        next = { next: next };
        next[ASYNC_ITERATOR] = asyncIterator;
        return next;
      }
      function startAsyncIterable(response, id, iterator) {
        var buffer = [],
          closed = !1,
          nextWriteIndex = 0,
          iterable = {};
        iterable[ASYNC_ITERATOR] = function () {
          var nextReadIndex = 0;
          return createIterator(function (arg) {
            if (void 0 !== arg)
              throw Error(
                "Values cannot be passed to next() of AsyncIterables passed to Client Components.",
              );
            if (nextReadIndex === buffer.length) {
              if (closed) return new ReactPromise("fulfilled", { done: !0, value: void 0 }, null);
              buffer[nextReadIndex] = new ReactPromise("pending", null, null);
            }
            return buffer[nextReadIndex++];
          });
        };
        resolveStream(response, id, iterator ? iterable[ASYNC_ITERATOR]() : iterable, {
          enqueueValue: function (value) {
            if (nextWriteIndex === buffer.length)
              buffer[nextWriteIndex] = new ReactPromise(
                "fulfilled",
                { done: !1, value: value },
                null,
              );
            else {
              var chunk = buffer[nextWriteIndex],
                resolveListeners = chunk.value,
                rejectListeners = chunk.reason;
              chunk.status = "fulfilled";
              chunk.value = { done: !1, value: value };
              chunk.reason = null;
              null !== resolveListeners &&
                wakeChunkIfInitialized(chunk, resolveListeners, rejectListeners);
            }
            nextWriteIndex++;
          },
          enqueueModel: function (value) {
            nextWriteIndex === buffer.length
              ? (buffer[nextWriteIndex] = createResolvedIteratorResultChunk(response, value, !1))
              : resolveIteratorResultChunk(response, buffer[nextWriteIndex], value, !1);
            nextWriteIndex++;
          },
          close: function (value) {
            if (!closed)
              for (
                closed = !0,
                  nextWriteIndex === buffer.length
                    ? (buffer[nextWriteIndex] = createResolvedIteratorResultChunk(
                        response,
                        value,
                        !0,
                      ))
                    : resolveIteratorResultChunk(response, buffer[nextWriteIndex], value, !0),
                  nextWriteIndex++;
                nextWriteIndex < buffer.length;
              )
                resolveIteratorResultChunk(response, buffer[nextWriteIndex++], '"$undefined"', !0);
          },
          error: function (error) {
            if (!closed)
              for (
                closed = !0,
                  nextWriteIndex === buffer.length &&
                    (buffer[nextWriteIndex] = new ReactPromise("pending", null, null));
                nextWriteIndex < buffer.length;
              )
                triggerErrorOnChunk(response, buffer[nextWriteIndex++], error);
          },
        });
      }
      function resolveErrorProd() {
        var error = Error(
          "An error occurred in the Server Components render. The specific message is omitted in production builds to avoid leaking sensitive details. A digest property is included on this error instance which may provide additional details about the nature of the error.",
        );
        error.stack = "Error: " + error.message;
        return error;
      }
      function mergeBuffer(buffer, lastChunk) {
        for (var l = buffer.length, byteLength = lastChunk.length, i = 0; i < l; i++)
          byteLength += buffer[i].byteLength;
        byteLength = new Uint8Array(byteLength);
        for (var i$54 = (i = 0); i$54 < l; i$54++) {
          var chunk = buffer[i$54];
          byteLength.set(chunk, i);
          i += chunk.byteLength;
        }
        byteLength.set(lastChunk, i);
        return byteLength;
      }
      function resolveTypedArray(response, id, buffer, lastChunk, constructor, bytesPerElement) {
        buffer =
          0 === buffer.length && 0 === lastChunk.byteOffset % bytesPerElement
            ? lastChunk
            : mergeBuffer(buffer, lastChunk);
        constructor = new constructor(
          buffer.buffer,
          buffer.byteOffset,
          buffer.byteLength / bytesPerElement,
        );
        resolveBuffer(response, id, constructor);
      }
      function processFullBinaryRow(response, id, tag, buffer, chunk) {
        switch (tag) {
          case 65:
            resolveBuffer(response, id, mergeBuffer(buffer, chunk).buffer);
            return;
          case 79:
            resolveTypedArray(response, id, buffer, chunk, Int8Array, 1);
            return;
          case 111:
            resolveBuffer(response, id, 0 === buffer.length ? chunk : mergeBuffer(buffer, chunk));
            return;
          case 85:
            resolveTypedArray(response, id, buffer, chunk, Uint8ClampedArray, 1);
            return;
          case 83:
            resolveTypedArray(response, id, buffer, chunk, Int16Array, 2);
            return;
          case 115:
            resolveTypedArray(response, id, buffer, chunk, Uint16Array, 2);
            return;
          case 76:
            resolveTypedArray(response, id, buffer, chunk, Int32Array, 4);
            return;
          case 108:
            resolveTypedArray(response, id, buffer, chunk, Uint32Array, 4);
            return;
          case 71:
            resolveTypedArray(response, id, buffer, chunk, Float32Array, 4);
            return;
          case 103:
            resolveTypedArray(response, id, buffer, chunk, Float64Array, 8);
            return;
          case 77:
            resolveTypedArray(response, id, buffer, chunk, BigInt64Array, 8);
            return;
          case 109:
            resolveTypedArray(response, id, buffer, chunk, BigUint64Array, 8);
            return;
          case 86:
            resolveTypedArray(response, id, buffer, chunk, DataView, 1);
            return;
        }
        for (var stringDecoder = response._stringDecoder, row = "", i = 0; i < buffer.length; i++)
          row += stringDecoder.decode(buffer[i], decoderOptions);
        buffer = row += stringDecoder.decode(chunk);
        switch (tag) {
          case 73:
            resolveModule(response, id, buffer);
            break;
          case 72:
            id = buffer[0];
            buffer = buffer.slice(1);
            response = JSON.parse(buffer, response._fromJSON);
            buffer = ReactDOMSharedInternals.d;
            switch (id) {
              case "D":
                buffer.D(response);
                break;
              case "C":
                "string" === typeof response
                  ? buffer.C(response)
                  : buffer.C(response[0], response[1]);
                break;
              case "L":
                id = response[0];
                tag = response[1];
                3 === response.length ? buffer.L(id, tag, response[2]) : buffer.L(id, tag);
                break;
              case "m":
                "string" === typeof response
                  ? buffer.m(response)
                  : buffer.m(response[0], response[1]);
                break;
              case "X":
                "string" === typeof response
                  ? buffer.X(response)
                  : buffer.X(response[0], response[1]);
                break;
              case "S":
                "string" === typeof response
                  ? buffer.S(response)
                  : buffer.S(
                      response[0],
                      0 === response[1] ? void 0 : response[1],
                      3 === response.length ? response[2] : void 0,
                    );
                break;
              case "M":
                "string" === typeof response
                  ? buffer.M(response)
                  : buffer.M(response[0], response[1]);
            }
            break;
          case 69:
            tag = response._chunks;
            chunk = tag.get(id);
            buffer = JSON.parse(buffer);
            stringDecoder = resolveErrorProd();
            stringDecoder.digest = buffer.digest;
            chunk
              ? triggerErrorOnChunk(response, chunk, stringDecoder)
              : tag.set(id, new ReactPromise("rejected", null, stringDecoder));
            break;
          case 84:
            response = response._chunks;
            (tag = response.get(id)) && "pending" !== tag.status
              ? tag.reason.enqueueValue(buffer)
              : response.set(id, new ReactPromise("fulfilled", buffer, null));
            break;
          case 78:
          case 68:
          case 74:
          case 87:
            throw Error(
              "Failed to read a RSC payload created by a development version of React on the server while using a production version on the client. Always use matching versions on the server and the client.",
            );
          case 82:
            startReadableStream(response, id, void 0);
            break;
          case 114:
            startReadableStream(response, id, "bytes");
            break;
          case 88:
            startAsyncIterable(response, id, !1);
            break;
          case 120:
            startAsyncIterable(response, id, !0);
            break;
          case 67:
            (response = response._chunks.get(id)) &&
              "fulfilled" === response.status &&
              response.reason.close("" === buffer ? '"$undefined"' : buffer);
            break;
          default:
            ((tag = response._chunks),
              (chunk = tag.get(id))
                ? resolveModelChunk(response, chunk, buffer)
                : tag.set(id, new ReactPromise("resolved_model", buffer, response)));
        }
      }
      function createFromJSONCallback(response) {
        return function (key, value) {
          if ("__proto__" !== key) {
            if ("string" === typeof value) return parseModelString(response, this, key, value);
            if ("object" === typeof value && null !== value) {
              if (value[0] === REACT_ELEMENT_TYPE) {
                if (
                  ((key = {
                    $$typeof: REACT_ELEMENT_TYPE,
                    type: value[1],
                    key: value[2],
                    ref: null,
                    props: value[3],
                  }),
                  null !== initializingHandler)
                )
                  if (
                    ((value = initializingHandler),
                    (initializingHandler = value.parent),
                    value.errored)
                  )
                    ((key = new ReactPromise("rejected", null, value.reason)),
                      (key = createLazyChunkWrapper(key)));
                  else if (0 < value.deps) {
                    var blockedChunk = new ReactPromise("blocked", null, null);
                    value.value = key;
                    value.chunk = blockedChunk;
                    key = createLazyChunkWrapper(blockedChunk);
                  }
              } else key = value;
              return key;
            }
            return value;
          }
        };
      }
      function createResponseFromOptions(options) {
        return new ResponseInstance(
          null,
          null,
          null,
          options && options.callServer ? options.callServer : void 0,
          void 0,
          void 0,
          options && options.temporaryReferences ? options.temporaryReferences : void 0,
        );
      }
      function startReadingFromStream(response, stream, isSecondaryStream) {
        function progress(_ref2) {
          var value = _ref2.value;
          if (_ref2.done)
            isSecondaryStream || reportGlobalError(response, Error("Connection closed."));
          else {
            var i = 0,
              rowState = streamState._rowState;
            _ref2 = streamState._rowID;
            for (
              var rowTag = streamState._rowTag,
                rowLength = streamState._rowLength,
                buffer = streamState._buffer,
                chunkLength = value.length;
              i < chunkLength;
            ) {
              var lastIdx = -1;
              switch (rowState) {
                case 0:
                  lastIdx = value[i++];
                  58 === lastIdx
                    ? (rowState = 1)
                    : (_ref2 = (_ref2 << 4) | (96 < lastIdx ? lastIdx - 87 : lastIdx - 48));
                  continue;
                case 1:
                  rowState = value[i];
                  84 === rowState ||
                  65 === rowState ||
                  79 === rowState ||
                  111 === rowState ||
                  85 === rowState ||
                  83 === rowState ||
                  115 === rowState ||
                  76 === rowState ||
                  108 === rowState ||
                  71 === rowState ||
                  103 === rowState ||
                  77 === rowState ||
                  109 === rowState ||
                  86 === rowState
                    ? ((rowTag = rowState), (rowState = 2), i++)
                    : (64 < rowState && 91 > rowState) ||
                        35 === rowState ||
                        114 === rowState ||
                        120 === rowState
                      ? ((rowTag = rowState), (rowState = 3), i++)
                      : ((rowTag = 0), (rowState = 3));
                  continue;
                case 2:
                  lastIdx = value[i++];
                  44 === lastIdx
                    ? (rowState = 4)
                    : (rowLength = (rowLength << 4) | (96 < lastIdx ? lastIdx - 87 : lastIdx - 48));
                  continue;
                case 3:
                  lastIdx = value.indexOf(10, i);
                  break;
                case 4:
                  ((lastIdx = i + rowLength), lastIdx > value.length && (lastIdx = -1));
              }
              var offset = value.byteOffset + i;
              if (-1 < lastIdx)
                ((rowLength = new Uint8Array(value.buffer, offset, lastIdx - i)),
                  processFullBinaryRow(response, _ref2, rowTag, buffer, rowLength),
                  (i = lastIdx),
                  3 === rowState && i++,
                  (rowLength = _ref2 = rowTag = rowState = 0),
                  (buffer.length = 0));
              else {
                value = new Uint8Array(value.buffer, offset, value.byteLength - i);
                buffer.push(value);
                rowLength -= value.byteLength;
                break;
              }
            }
            streamState._rowState = rowState;
            streamState._rowID = _ref2;
            streamState._rowTag = rowTag;
            streamState._rowLength = rowLength;
            return reader.read().then(progress).catch(error);
          }
        }
        function error(e) {
          reportGlobalError(response, e);
        }
        var streamState = {
            _rowState: 0,
            _rowID: 0,
            _rowTag: 0,
            _rowLength: 0,
            _buffer: [],
          },
          reader = stream.getReader();
        reader.read().then(progress).catch(error);
      }
      exports.createFromFetch = function (promiseForResponse, options) {
        var response = createResponseFromOptions(options);
        promiseForResponse.then(
          function (r) {
            startReadingFromStream(response, r.body, !1);
          },
          function (e) {
            reportGlobalError(response, e);
          },
        );
        return getChunk(response, 0);
      };
      exports.createFromReadableStream = function (stream, options) {
        options = createResponseFromOptions(options);
        startReadingFromStream(options, stream, !1);
        return getChunk(options, 0);
      };
      exports.createServerReference = function (id, callServer) {
        function action() {
          var args = Array.prototype.slice.call(arguments);
          return callServer(id, args);
        }
        registerBoundServerReference(action, id, null);
        return action;
      };
      exports.createTemporaryReferenceSet = function () {
        return new Map();
      };
      exports.encodeReply = function (value, options) {
        return new Promise(function (resolve, reject) {
          var abort = processReply(
            value,
            "",
            options && options.temporaryReferences ? options.temporaryReferences : void 0,
            resolve,
            reject,
          );
          if (options && options.signal) {
            var signal = options.signal;
            if (signal.aborted) abort(signal.reason);
            else {
              var listener = function () {
                abort(signal.reason);
                signal.removeEventListener("abort", listener);
              };
              signal.addEventListener("abort", listener);
            }
          }
        });
      };
      exports.registerServerReference = function (reference, id) {
        registerBoundServerReference(reference, id, null);
        return reference;
      };

      /***/
    },

    /***/ 9439: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "reducer", {
        enumerable: true,
        get: function () {
          return reducer;
        },
      });
      const _routerreducertypes = __webpack_require__(9131);
      const _navigatereducer = __webpack_require__(5005);
      const _serverpatchreducer = __webpack_require__(5410);
      const _restorereducer = __webpack_require__(5826);
      const _refreshreducer = __webpack_require__(1499);
      const _prefetchreducer = __webpack_require__(3065);
      const _hmrrefreshreducer = __webpack_require__(2829);
      const _serveractionreducer = __webpack_require__(6992);
      /**
       * Reducer that handles the app-router state updates.
       */ function clientReducer(state, action) {
        switch (action.type) {
          case _routerreducertypes.ACTION_NAVIGATE: {
            return (0, _navigatereducer.navigateReducer)(state, action);
          }
          case _routerreducertypes.ACTION_SERVER_PATCH: {
            return (0, _serverpatchreducer.serverPatchReducer)(state, action);
          }
          case _routerreducertypes.ACTION_RESTORE: {
            return (0, _restorereducer.restoreReducer)(state, action);
          }
          case _routerreducertypes.ACTION_REFRESH: {
            return (0, _refreshreducer.refreshReducer)(state, action);
          }
          case _routerreducertypes.ACTION_HMR_REFRESH: {
            return (0, _hmrrefreshreducer.hmrRefreshReducer)(state, action);
          }
          case _routerreducertypes.ACTION_PREFETCH: {
            return (0, _prefetchreducer.prefetchReducer)(state, action);
          }
          case _routerreducertypes.ACTION_SERVER_ACTION: {
            return (0, _serveractionreducer.serverActionReducer)(state, action);
          }
          // This case should never be hit as dispatch is strongly typed.
          default:
            throw Object.defineProperty(new Error("Unknown action"), "__NEXT_ERROR_CODE", {
              value: "E295",
              enumerable: false,
              configurable: true,
            });
        }
      }
      function serverReducer(state, _action) {
        return state;
      }
      const reducer = false ? 0 : clientReducer;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=router-reducer.js.map

      /***/
    },

    /***/ 9466: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "handleMutable", {
        enumerable: true,
        get: function () {
          return handleMutable;
        },
      });
      const _computechangedpath = __webpack_require__(6107);
      function isNotUndefined(value) {
        return typeof value !== "undefined";
      }
      function handleMutable(state, mutable) {
        var _mutable_shouldScroll;
        // shouldScroll is true by default, can override to false.
        const shouldScroll =
          (_mutable_shouldScroll = mutable.shouldScroll) != null ? _mutable_shouldScroll : true;
        let nextUrl = state.nextUrl;
        if (isNotUndefined(mutable.patchedTree)) {
          // If we received a patched tree, we need to compute the changed path.
          const changedPath = (0, _computechangedpath.computeChangedPath)(
            state.tree,
            mutable.patchedTree,
          );
          if (changedPath) {
            // If the tree changed, we need to update the nextUrl
            nextUrl = changedPath;
          } else if (!nextUrl) {
            // if the tree ends up being the same (ie, no changed path), and we don't have a nextUrl, then we should use the canonicalUrl
            nextUrl = state.canonicalUrl;
          }
          // otherwise this will be a no-op and continue to use the existing nextUrl
        }
        var _mutable_scrollableSegments;
        return {
          // Set href.
          canonicalUrl: isNotUndefined(mutable.canonicalUrl)
            ? mutable.canonicalUrl === state.canonicalUrl
              ? state.canonicalUrl
              : mutable.canonicalUrl
            : state.canonicalUrl,
          pushRef: {
            pendingPush: isNotUndefined(mutable.pendingPush)
              ? mutable.pendingPush
              : state.pushRef.pendingPush,
            mpaNavigation: isNotUndefined(mutable.mpaNavigation)
              ? mutable.mpaNavigation
              : state.pushRef.mpaNavigation,
            preserveCustomHistoryState: isNotUndefined(mutable.preserveCustomHistoryState)
              ? mutable.preserveCustomHistoryState
              : state.pushRef.preserveCustomHistoryState,
          },
          // All navigation requires scroll and focus management to trigger.
          focusAndScrollRef: {
            apply: shouldScroll
              ? isNotUndefined(mutable == null ? void 0 : mutable.scrollableSegments)
                ? true
                : state.focusAndScrollRef.apply
              : false,
            onlyHashChange: mutable.onlyHashChange || false,
            hashFragment: shouldScroll
              ? mutable.hashFragment && mutable.hashFragment !== ""
                ? decodeURIComponent(mutable.hashFragment.slice(1))
                : state.focusAndScrollRef.hashFragment
              : null,
            segmentPaths: shouldScroll
              ? (_mutable_scrollableSegments =
                  mutable == null ? void 0 : mutable.scrollableSegments) != null
                ? _mutable_scrollableSegments
                : state.focusAndScrollRef.segmentPaths
              : [],
          },
          // Apply cache.
          cache: mutable.cache ? mutable.cache : state.cache,
          prefetchCache: mutable.prefetchCache ? mutable.prefetchCache : state.prefetchCache,
          // Apply patched router state.
          tree: isNotUndefined(mutable.patchedTree) ? mutable.patchedTree : state.tree,
          nextUrl,
        };
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=handle-mutable.js.map

      /***/
    },

    /***/ 9478: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "addBasePath", {
        enumerable: true,
        get: function () {
          return addBasePath;
        },
      });
      const _addpathprefix = __webpack_require__(3179);
      const _normalizetrailingslash = __webpack_require__(9291);
      const basePath = false || "";
      function addBasePath(path, required) {
        return (0, _normalizetrailingslash.normalizePathTrailingSlash)(
          false ? 0 : (0, _addpathprefix.addPathPrefix)(path, basePath),
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=add-base-path.js.map

      /***/
    },

    /***/ 9643: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /** @internal */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ReadonlyURLSearchParams: function () {
          return ReadonlyURLSearchParams;
        },
        RedirectType: function () {
          return _redirecterror.RedirectType;
        },
        forbidden: function () {
          return _forbidden.forbidden;
        },
        notFound: function () {
          return _notfound.notFound;
        },
        permanentRedirect: function () {
          return _redirect.permanentRedirect;
        },
        redirect: function () {
          return _redirect.redirect;
        },
        unauthorized: function () {
          return _unauthorized.unauthorized;
        },
        unstable_isUnrecognizedActionError: function () {
          return unstable_isUnrecognizedActionError;
        },
        unstable_rethrow: function () {
          return _unstablerethrow.unstable_rethrow;
        },
      });
      const _redirect = __webpack_require__(426);
      const _redirecterror = __webpack_require__(9721);
      const _notfound = __webpack_require__(7658);
      const _forbidden = __webpack_require__(7535);
      const _unauthorized = __webpack_require__(9892);
      const _unstablerethrow = __webpack_require__(7328);
      class ReadonlyURLSearchParamsError extends Error {
        constructor() {
          super(
            "Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams",
          );
        }
      }
      class ReadonlyURLSearchParams extends URLSearchParams {
        /** @deprecated Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams */ append() {
          throw new ReadonlyURLSearchParamsError();
        }
        /** @deprecated Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams */ delete() {
          throw new ReadonlyURLSearchParamsError();
        }
        /** @deprecated Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams */ set() {
          throw new ReadonlyURLSearchParamsError();
        }
        /** @deprecated Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams */ sort() {
          throw new ReadonlyURLSearchParamsError();
        }
      }
      function unstable_isUnrecognizedActionError() {
        throw Object.defineProperty(
          new Error("`unstable_isUnrecognizedActionError` can only be used on the client."),
          "__NEXT_ERROR_CODE",
          {
            value: "E776",
            enumerable: false,
            configurable: true,
          },
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=navigation.react-server.js.map

      /***/
    },

    /***/ 9701: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        createEmptyCacheNode: function () {
          return createEmptyCacheNode;
        },
        createPrefetchURL: function () {
          return createPrefetchURL;
        },
        default: function () {
          return AppRouter;
        },
        isExternalURL: function () {
          return isExternalURL;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _approutercontextsharedruntime = __webpack_require__(6764);
      const _routerreducertypes = __webpack_require__(9131);
      const _createhreffromurl = __webpack_require__(8150);
      const _hooksclientcontextsharedruntime = __webpack_require__(4357);
      const _useactionqueue = __webpack_require__(7964);
      const _isbot = __webpack_require__(8245);
      const _addbasepath = __webpack_require__(9478);
      const _approuterannouncer = __webpack_require__(8815);
      const _redirectboundary = __webpack_require__(1583);
      const _findheadincache = __webpack_require__(6568);
      const _unresolvedthenable = __webpack_require__(2923);
      const _removebasepath = __webpack_require__(8103);
      const _hasbasepath = __webpack_require__(6669);
      const _computechangedpath = __webpack_require__(6107);
      const _navfailurehandler = __webpack_require__(6917);
      const _approuterinstance = __webpack_require__(7267);
      const _redirect = __webpack_require__(426);
      const _redirecterror = __webpack_require__(9721);
      const _links = __webpack_require__(2767);
      const _rooterrorboundary = /*#__PURE__*/ _interop_require_default._(
        __webpack_require__(5830),
      );
      const _globalerror = /*#__PURE__*/ _interop_require_default._(__webpack_require__(6634));
      const _boundarycomponents = __webpack_require__(1915);
      const globalMutable = {};
      function isExternalURL(url) {
        return url.origin !== window.location.origin;
      }
      function createPrefetchURL(href) {
        // Don't prefetch for bots as they don't navigate.
        if ((0, _isbot.isBot)(window.navigator.userAgent)) {
          return null;
        }
        let url;
        try {
          url = new URL((0, _addbasepath.addBasePath)(href), window.location.href);
        } catch (_) {
          // TODO: Does this need to throw or can we just console.error instead? Does
          // anyone rely on this throwing? (Seems unlikely.)
          throw Object.defineProperty(
            new Error("Cannot prefetch '" + href + "' because it cannot be converted to a URL."),
            "__NEXT_ERROR_CODE",
            {
              value: "E234",
              enumerable: false,
              configurable: true,
            },
          );
        }
        // Don't prefetch during development (improves compilation performance)
        if (false) {
        }
        // External urls can't be prefetched in the same way.
        if (isExternalURL(url)) {
          return null;
        }
        return url;
      }
      function HistoryUpdater(param) {
        let { appRouterState } = param;
        (0, _react.useInsertionEffect)(() => {
          if (false) {
          }
          const { tree, pushRef, canonicalUrl } = appRouterState;
          const historyState = {
            ...(pushRef.preserveCustomHistoryState ? window.history.state : {}),
            // Identifier is shortened intentionally.
            // __NA is used to identify if the history entry can be handled by the app-router.
            // __N is used to identify if the history entry can be handled by the old router.
            __NA: true,
            __PRIVATE_NEXTJS_INTERNALS_TREE: tree,
          };
          if (
            pushRef.pendingPush && // Skip pushing an additional history entry if the canonicalUrl is the same as the current url.
            // This mirrors the browser behavior for normal navigation.
            (0, _createhreffromurl.createHrefFromUrl)(new URL(window.location.href)) !==
              canonicalUrl
          ) {
            // This intentionally mutates React state, pushRef is overwritten to ensure additional push/replace calls do not trigger an additional history entry.
            pushRef.pendingPush = false;
            window.history.pushState(historyState, "", canonicalUrl);
          } else {
            window.history.replaceState(historyState, "", canonicalUrl);
          }
        }, [appRouterState]);
        (0, _react.useEffect)(() => {
          // The Next-Url and the base tree may affect the result of a prefetch
          // task. Re-prefetch all visible links with the updated values. In most
          // cases, this will not result in any new network requests, only if
          // the prefetch result actually varies on one of these inputs.
          if (false) {
          }
        }, [appRouterState.nextUrl, appRouterState.tree]);
        return null;
      }
      function createEmptyCacheNode() {
        return {
          lazyData: null,
          rsc: null,
          prefetchRsc: null,
          head: null,
          prefetchHead: null,
          parallelRoutes: new Map(),
          loading: null,
          navigatedAt: -1,
        };
      }
      function copyNextJsInternalHistoryState(data) {
        if (data == null) data = {};
        const currentState = window.history.state;
        const __NA = currentState == null ? void 0 : currentState.__NA;
        if (__NA) {
          data.__NA = __NA;
        }
        const __PRIVATE_NEXTJS_INTERNALS_TREE =
          currentState == null ? void 0 : currentState.__PRIVATE_NEXTJS_INTERNALS_TREE;
        if (__PRIVATE_NEXTJS_INTERNALS_TREE) {
          data.__PRIVATE_NEXTJS_INTERNALS_TREE = __PRIVATE_NEXTJS_INTERNALS_TREE;
        }
        return data;
      }
      function Head(param) {
        let { headCacheNode } = param;
        // If this segment has a `prefetchHead`, it's the statically prefetched data.
        // We should use that on initial render instead of `head`. Then we'll switch
        // to `head` when the dynamic response streams in.
        const head = headCacheNode !== null ? headCacheNode.head : null;
        const prefetchHead = headCacheNode !== null ? headCacheNode.prefetchHead : null;
        // If no prefetch data is available, then we go straight to rendering `head`.
        const resolvedPrefetchRsc = prefetchHead !== null ? prefetchHead : head;
        // We use `useDeferredValue` to handle switching between the prefetched and
        // final values. The second argument is returned on initial render, then it
        // re-renders with the first argument.
        return (0, _react.useDeferredValue)(head, resolvedPrefetchRsc);
      }
      /**
       * The global router that wraps the application components.
       */ function Router(param) {
        let { actionQueue, assetPrefix, globalError } = param;
        const state = (0, _useactionqueue.useActionQueue)(actionQueue);
        const { canonicalUrl } = state;
        // Add memoized pathname/query for useSearchParams and usePathname.
        const { searchParams, pathname } = (0, _react.useMemo)(() => {
          const url = new URL(canonicalUrl, false ? 0 : window.location.href);
          return {
            // This is turned into a readonly class in `useSearchParams`
            searchParams: url.searchParams,
            pathname: (0, _hasbasepath.hasBasePath)(url.pathname)
              ? (0, _removebasepath.removeBasePath)(url.pathname)
              : url.pathname,
          };
        }, [canonicalUrl]);
        if (false) {
        }
        (0, _react.useEffect)(() => {
          // If the app is restored from bfcache, it's possible that
          // pushRef.mpaNavigation is true, which would mean that any re-render of this component
          // would trigger the mpa navigation logic again from the lines below.
          // This will restore the router to the initial state in the event that the app is restored from bfcache.
          function handlePageShow(event) {
            var _window_history_state;
            if (
              !event.persisted ||
              !((_window_history_state = window.history.state) == null
                ? void 0
                : _window_history_state.__PRIVATE_NEXTJS_INTERNALS_TREE)
            ) {
              return;
            }
            // Clear the pendingMpaPath value so that a subsequent MPA navigation to the same URL can be triggered.
            // This is necessary because if the browser restored from bfcache, the pendingMpaPath would still be set to the value
            // of the last MPA navigation.
            globalMutable.pendingMpaPath = undefined;
            (0, _useactionqueue.dispatchAppRouterAction)({
              type: _routerreducertypes.ACTION_RESTORE,
              url: new URL(window.location.href),
              tree: window.history.state.__PRIVATE_NEXTJS_INTERNALS_TREE,
            });
          }
          window.addEventListener("pageshow", handlePageShow);
          return () => {
            window.removeEventListener("pageshow", handlePageShow);
          };
        }, []);
        (0, _react.useEffect)(() => {
          // Ensure that any redirect errors that bubble up outside of the RedirectBoundary
          // are caught and handled by the router.
          function handleUnhandledRedirect(event) {
            const error = "reason" in event ? event.reason : event.error;
            if ((0, _redirecterror.isRedirectError)(error)) {
              event.preventDefault();
              const url = (0, _redirect.getURLFromRedirectError)(error);
              const redirectType = (0, _redirect.getRedirectTypeFromError)(error);
              // TODO: This should access the router methods directly, rather than
              // go through the public interface.
              if (redirectType === _redirecterror.RedirectType.push) {
                _approuterinstance.publicAppRouterInstance.push(url, {});
              } else {
                _approuterinstance.publicAppRouterInstance.replace(url, {});
              }
            }
          }
          window.addEventListener("error", handleUnhandledRedirect);
          window.addEventListener("unhandledrejection", handleUnhandledRedirect);
          return () => {
            window.removeEventListener("error", handleUnhandledRedirect);
            window.removeEventListener("unhandledrejection", handleUnhandledRedirect);
          };
        }, []);
        // When mpaNavigation flag is set do a hard navigation to the new url.
        // Infinitely suspend because we don't actually want to rerender any child
        // components with the new URL and any entangled state updates shouldn't
        // commit either (eg: useTransition isPending should stay true until the page
        // unloads).
        //
        // This is a side effect in render. Don't try this at home, kids. It's
        // probably safe because we know this is a singleton component and it's never
        // in <Offscreen>. At least I hope so. (It will run twice in dev strict mode,
        // but that's... fine?)
        const { pushRef } = state;
        if (pushRef.mpaNavigation) {
          // if there's a re-render, we don't want to trigger another redirect if one is already in flight to the same URL
          if (globalMutable.pendingMpaPath !== canonicalUrl) {
            const location = window.location;
            if (pushRef.pendingPush) {
              location.assign(canonicalUrl);
            } else {
              location.replace(canonicalUrl);
            }
            globalMutable.pendingMpaPath = canonicalUrl;
          }
          // TODO-APP: Should we listen to navigateerror here to catch failed
          // navigations somehow? And should we call window.stop() if a SPA navigation
          // should interrupt an MPA one?
          // NOTE: This is intentionally using `throw` instead of `use` because we're
          // inside an externally mutable condition (pushRef.mpaNavigation), which
          // violates the rules of hooks.
          throw _unresolvedthenable.unresolvedThenable;
        }
        (0, _react.useEffect)(() => {
          const originalPushState = window.history.pushState.bind(window.history);
          const originalReplaceState = window.history.replaceState.bind(window.history);
          // Ensure the canonical URL in the Next.js Router is updated when the URL is changed so that `usePathname` and `useSearchParams` hold the pushed values.
          const applyUrlFromHistoryPushReplace = (url) => {
            var _window_history_state;
            const href = window.location.href;
            const tree =
              (_window_history_state = window.history.state) == null
                ? void 0
                : _window_history_state.__PRIVATE_NEXTJS_INTERNALS_TREE;
            (0, _react.startTransition)(() => {
              (0, _useactionqueue.dispatchAppRouterAction)({
                type: _routerreducertypes.ACTION_RESTORE,
                url: new URL(url != null ? url : href, href),
                tree,
              });
            });
          };
          /**
           * Patch pushState to ensure external changes to the history are reflected in the Next.js Router.
           * Ensures Next.js internal history state is copied to the new history entry.
           * Ensures usePathname and useSearchParams hold the newly provided url.
           */ window.history.pushState = function pushState(data, _unused, url) {
            // Avoid a loop when Next.js internals trigger pushState/replaceState
            if ((data == null ? void 0 : data.__NA) || (data == null ? void 0 : data._N)) {
              return originalPushState(data, _unused, url);
            }
            data = copyNextJsInternalHistoryState(data);
            if (url) {
              applyUrlFromHistoryPushReplace(url);
            }
            return originalPushState(data, _unused, url);
          };
          /**
           * Patch replaceState to ensure external changes to the history are reflected in the Next.js Router.
           * Ensures Next.js internal history state is copied to the new history entry.
           * Ensures usePathname and useSearchParams hold the newly provided url.
           */ window.history.replaceState = function replaceState(data, _unused, url) {
            // Avoid a loop when Next.js internals trigger pushState/replaceState
            if ((data == null ? void 0 : data.__NA) || (data == null ? void 0 : data._N)) {
              return originalReplaceState(data, _unused, url);
            }
            data = copyNextJsInternalHistoryState(data);
            if (url) {
              applyUrlFromHistoryPushReplace(url);
            }
            return originalReplaceState(data, _unused, url);
          };
          /**
           * Handle popstate event, this is used to handle back/forward in the browser.
           * By default dispatches ACTION_RESTORE, however if the history entry was not pushed/replaced by app-router it will reload the page.
           * That case can happen when the old router injected the history entry.
           */ const onPopState = (event) => {
            if (!event.state) {
              // TODO-APP: this case only happens when pushState/replaceState was called outside of Next.js. It should probably reload the page in this case.
              return;
            }
            // This case happens when the history entry was pushed by the `pages` router.
            if (!event.state.__NA) {
              window.location.reload();
              return;
            }
            // TODO-APP: Ideally the back button should not use startTransition as it should apply the updates synchronously
            // Without startTransition works if the cache is there for this path
            (0, _react.startTransition)(() => {
              (0, _approuterinstance.dispatchTraverseAction)(
                window.location.href,
                event.state.__PRIVATE_NEXTJS_INTERNALS_TREE,
              );
            });
          };
          // Register popstate event to call onPopstate.
          window.addEventListener("popstate", onPopState);
          return () => {
            window.history.pushState = originalPushState;
            window.history.replaceState = originalReplaceState;
            window.removeEventListener("popstate", onPopState);
          };
        }, []);
        const { cache, tree, nextUrl, focusAndScrollRef } = state;
        const matchingHead = (0, _react.useMemo)(() => {
          return (0, _findheadincache.findHeadInCache)(cache, tree[1]);
        }, [cache, tree]);
        // Add memoized pathParams for useParams.
        const pathParams = (0, _react.useMemo)(() => {
          return (0, _computechangedpath.getSelectedParams)(tree);
        }, [tree]);
        const layoutRouterContext = (0, _react.useMemo)(() => {
          return {
            parentTree: tree,
            parentCacheNode: cache,
            parentSegmentPath: null,
            // Root node always has `url`
            // Provided in AppTreeContext to ensure it can be overwritten in layout-router
            url: canonicalUrl,
          };
        }, [tree, cache, canonicalUrl]);
        const globalLayoutRouterContext = (0, _react.useMemo)(() => {
          return {
            tree,
            focusAndScrollRef,
            nextUrl,
          };
        }, [tree, focusAndScrollRef, nextUrl]);
        let head;
        if (matchingHead !== null) {
          // The head is wrapped in an extra component so we can use
          // `useDeferredValue` to swap between the prefetched and final versions of
          // the head. (This is what LayoutRouter does for segment data, too.)
          //
          // The `key` is used to remount the component whenever the head moves to
          // a different segment.
          const [headCacheNode, headKey, headKeyWithoutSearchParams] = matchingHead;
          head = /*#__PURE__*/ (0, _jsxruntime.jsx)(
            Head,
            {
              headCacheNode: headCacheNode,
            },
            false ? 0 : headKey,
          );
        } else {
          head = null;
        }
        let content = /*#__PURE__*/ (0, _jsxruntime.jsxs)(_redirectboundary.RedirectBoundary, {
          children: [
            head,
            /*#__PURE__*/ (0, _jsxruntime.jsx)(_boundarycomponents.RootLayoutBoundary, {
              children: cache.rsc,
            }),
            /*#__PURE__*/ (0, _jsxruntime.jsx)(_approuterannouncer.AppRouterAnnouncer, {
              tree: tree,
            }),
          ],
        });
        if (false) {
        } else {
          content = /*#__PURE__*/ (0, _jsxruntime.jsx)(_rooterrorboundary.default, {
            errorComponent: globalError[0],
            errorStyles: globalError[1],
            children: content,
          });
        }
        return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
          children: [
            /*#__PURE__*/ (0, _jsxruntime.jsx)(HistoryUpdater, {
              appRouterState: state,
            }),
            /*#__PURE__*/ (0, _jsxruntime.jsx)(RuntimeStyles, {}),
            /*#__PURE__*/ (0, _jsxruntime.jsx)(
              _hooksclientcontextsharedruntime.PathParamsContext.Provider,
              {
                value: pathParams,
                children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                  _hooksclientcontextsharedruntime.PathnameContext.Provider,
                  {
                    value: pathname,
                    children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                      _hooksclientcontextsharedruntime.SearchParamsContext.Provider,
                      {
                        value: searchParams,
                        children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                          _approutercontextsharedruntime.GlobalLayoutRouterContext.Provider,
                          {
                            value: globalLayoutRouterContext,
                            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                              _approutercontextsharedruntime.AppRouterContext.Provider,
                              {
                                value: _approuterinstance.publicAppRouterInstance,
                                children: /*#__PURE__*/ (0, _jsxruntime.jsx)(
                                  _approutercontextsharedruntime.LayoutRouterContext.Provider,
                                  {
                                    value: layoutRouterContext,
                                    children: content,
                                  },
                                ),
                              },
                            ),
                          },
                        ),
                      },
                    ),
                  },
                ),
              },
            ),
          ],
        });
      }
      function AppRouter(param) {
        let { actionQueue, globalErrorState, assetPrefix } = param;
        (0, _navfailurehandler.useNavFailureHandler)();
        const router = /*#__PURE__*/ (0, _jsxruntime.jsx)(Router, {
          actionQueue: actionQueue,
          assetPrefix: assetPrefix,
          globalError: globalErrorState,
        });
        // At the very top level, use the default GlobalError component as the final fallback.
        // When the app router itself fails, which means the framework itself fails, we show the default error.
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(_rooterrorboundary.default, {
          errorComponent: _globalerror.default,
          children: router,
        });
      }
      const runtimeStyles = new Set();
      let runtimeStyleChanged = new Set();
      globalThis._N_E_STYLE_LOAD = function (href) {
        let len = runtimeStyles.size;
        runtimeStyles.add(href);
        if (runtimeStyles.size !== len) {
          runtimeStyleChanged.forEach((cb) => cb());
        }
        // TODO figure out how to get a promise here
        // But maybe it's not necessary as react would block rendering until it's loaded
        return Promise.resolve();
      };
      function RuntimeStyles() {
        const [, forceUpdate] = _react.default.useState(0);
        const renderedStylesSize = runtimeStyles.size;
        (0, _react.useEffect)(() => {
          const changed = () => forceUpdate((c) => c + 1);
          runtimeStyleChanged.add(changed);
          if (renderedStylesSize !== runtimeStyles.size) {
            changed();
          }
          return () => {
            runtimeStyleChanged.delete(changed);
          };
        }, [renderedStylesSize, forceUpdate]);
        const dplId = false ? 0 : "";
        return [...runtimeStyles].map((href, i) =>
          /*#__PURE__*/ (0, _jsxruntime.jsx)(
            "link",
            {
              rel: "stylesheet",
              href: "" + href + dplId,
              // @ts-ignore
              precedence: "next",
            },
            i,
          ),
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-router.js.map

      /***/
    },

    /***/ 9721: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        REDIRECT_ERROR_CODE: function () {
          return REDIRECT_ERROR_CODE;
        },
        RedirectType: function () {
          return RedirectType;
        },
        isRedirectError: function () {
          return isRedirectError;
        },
      });
      const _redirectstatuscode = __webpack_require__(7223);
      const REDIRECT_ERROR_CODE = "NEXT_REDIRECT";
      var RedirectType = /*#__PURE__*/ (function (RedirectType) {
        RedirectType["push"] = "push";
        RedirectType["replace"] = "replace";
        return RedirectType;
      })({});
      function isRedirectError(error) {
        if (
          typeof error !== "object" ||
          error === null ||
          !("digest" in error) ||
          typeof error.digest !== "string"
        ) {
          return false;
        }
        const digest = error.digest.split(";");
        const [errorCode, type] = digest;
        const destination = digest.slice(2, -2).join(";");
        const status = digest.at(-2);
        const statusCode = Number(status);
        return (
          errorCode === REDIRECT_ERROR_CODE &&
          (type === "replace" || type === "push") &&
          typeof destination === "string" &&
          !isNaN(statusCode) &&
          statusCode in _redirectstatuscode.RedirectStatusCode
        );
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=redirect-error.js.map

      /***/
    },

    /***/ 9825: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      // This module can be shared between both pages router and app router

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        isRecoverableError: function () {
          return isRecoverableError;
        },
        onRecoverableError: function () {
          return onRecoverableError;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _bailouttocsr = __webpack_require__(2997);
      const _iserror = /*#__PURE__*/ _interop_require_default._(__webpack_require__(3240));
      const _reportglobalerror = __webpack_require__(1387);
      const recoverableErrors = new WeakSet();
      function isRecoverableError(error) {
        return recoverableErrors.has(error);
      }
      const onRecoverableError = (error) => {
        // x-ref: https://github.com/facebook/react/pull/28736
        let cause = (0, _iserror.default)(error) && "cause" in error ? error.cause : error;
        // Skip certain custom errors which are not expected to be reported on client
        if ((0, _bailouttocsr.isBailoutToCSRError)(cause)) return;
        if (false) {
        }
        (0, _reportglobalerror.reportGlobalError)(cause);
      };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=on-recoverable-error.js.map

      /***/
    },

    /***/ 9837: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "callServer", {
        enumerable: true,
        get: function () {
          return callServer;
        },
      });
      const _react = __webpack_require__(5127);
      const _routerreducertypes = __webpack_require__(9131);
      const _useactionqueue = __webpack_require__(7964);
      async function callServer(actionId, actionArgs) {
        return new Promise((resolve, reject) => {
          (0, _react.startTransition)(() => {
            (0, _useactionqueue.dispatchAppRouterAction)({
              type: _routerreducertypes.ACTION_SERVER_ACTION,
              actionId,
              actionArgs,
              resolve,
              reject,
            });
          });
        });
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=app-call-server.js.map

      /***/
    },

    /***/ 9892: /***/ (module, exports, __webpack_require__) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      Object.defineProperty(exports, "unauthorized", {
        enumerable: true,
        get: function () {
          return unauthorized;
        },
      });
      const _httpaccessfallback = __webpack_require__(9028);
      // TODO: Add `unauthorized` docs
      /**
       * @experimental
       * This function allows you to render the [unauthorized.js file](https://nextjs.org/docs/app/api-reference/file-conventions/unauthorized)
       * within a route segment as well as inject a tag.
       *
       * `unauthorized()` can be used in
       * [Server Components](https://nextjs.org/docs/app/building-your-application/rendering/server-components),
       * [Route Handlers](https://nextjs.org/docs/app/building-your-application/routing/route-handlers), and
       * [Server Actions](https://nextjs.org/docs/app/building-your-application/data-fetching/server-actions-and-mutations).
       *
       *
       * Read more: [Next.js Docs: `unauthorized`](https://nextjs.org/docs/app/api-reference/functions/unauthorized)
       */ const DIGEST = "" + _httpaccessfallback.HTTP_ERROR_FALLBACK_ERROR_CODE + ";401";
      function unauthorized() {
        if (true) {
          throw Object.defineProperty(
            new Error(
              "`unauthorized()` is experimental and only allowed to be used when `experimental.authInterrupts` is enabled.",
            ),
            "__NEXT_ERROR_CODE",
            {
              value: "E411",
              enumerable: false,
              configurable: true,
            },
          );
        }
        // eslint-disable-next-line no-throw-literal
        const error = Object.defineProperty(new Error(DIGEST), "__NEXT_ERROR_CODE", {
          value: "E394",
          enumerable: false,
          configurable: true,
        });
        error.digest = DIGEST;
        throw error;
      }
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=unauthorized.js.map

      /***/
    },
  },
]);
