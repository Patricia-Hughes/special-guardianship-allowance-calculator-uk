(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [877],
  {
    /***/ 1359: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ Advertising: () => /* binding */ Advertising,
        /* harmony export */ AdvertisingPreferences: () => /* binding */ AdvertisingPreferences,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5127);
      /* __next_internal_client_entry_do_not_use__ Advertising,AdvertisingPreferences auto */

      function Advertising() {
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          if (window.SGO_GOOGLE_CONFIG?.adsenseEnabled !== true) return;
          // The disabled feature adds no consent/ad runtime to the page download.
          // Calculator pages do not need to download that runtime even when enabled.
          const url = new URL(window.location.href);
          if (
            url.search ||
            url.hash ||
            !/^\/(privacy|rates|guidance(?:\/[a-z0-9-]+)?)$/.test(url.pathname)
          )
            return;
          let active = true;
          let stop;
          void __webpack_require__
            .e(/* import() */ 939)
            .then(__webpack_require__.bind(__webpack_require__, 939))
            .then((advertising) => {
              if (active) stop = advertising.startAdvertising();
            })
            .catch(() => {
              // A failed optional runtime download must not interrupt the page.
            });
          return () => {
            active = false;
            stop?.();
          };
        }, []);
        return null;
      }
      function AdvertisingPreferences() {
        const [status, setStatus] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)("off");
        const [failed, setFailed] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          if (window.SGO_GOOGLE_CONFIG?.adsenseEnabled !== true) return;
          setStatus("loading");
          let active = true;
          let unsubscribe;
          void __webpack_require__
            .e(/* import() */ 939)
            .then(__webpack_require__.bind(__webpack_require__, 939))
            .then((advertising) => {
              if (!active) return;
              const update = () => setStatus(advertising.advertisingStatus());
              unsubscribe = advertising.subscribeAdvertising(update);
              update();
              if (window.location.search || window.location.hash) setStatus("unavailable");
            })
            .catch(() => {
              if (active) setStatus("unavailable");
            });
          return () => {
            active = false;
            unsubscribe?.();
          };
        }, []);
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          children: [
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              role: "status",
              children: [
                status === "off" && "Advertising is currently off on this site.",
                status === "loading" && "Loading advertising privacy choices.",
                status === "ready" && "You can review or withdraw advertising consent here.",
                status === "unavailable" &&
                  "Advertising privacy choices are unavailable. No ads are loaded on this page.",
              ],
            }),
            status === "ready" &&
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                type: "button",
                className: "btn btn--secondary",
                onClick: async () => {
                  const advertising = await __webpack_require__
                    .e(/* import() */ 939)
                    .then(__webpack_require__.bind(__webpack_require__, 939));
                  setFailed(!advertising.openAdvertisingPreferences());
                },
                children: "Change advertising choices",
              }),
            failed &&
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                role: "alert",
                children:
                  "The privacy choices could not be opened. Please reload this page and try again.",
              }),
          ],
        });
      }

      /***/
    },

    /***/ 1713: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ ConsentControls: () => /* binding */ ConsentControls,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var _useAnalyticsConsent__WEBPACK_IMPORTED_MODULE_1__ =
        __webpack_require__(3937);
      /* __next_internal_client_entry_do_not_use__ ConsentControls auto */

      /**
       * Changing your mind, on the privacy page.
       *
       * Withdrawing consent has to be as easy as giving it, so this shows the current
       * answer in words and offers the opposite one. It is the same two functions the
       * banner uses, not a second implementation that could drift.
       */ function ConsentControls() {
        const { consent, configured, answer } = (0,
        _useAnalyticsConsent__WEBPACK_IMPORTED_MODULE_1__ /* .useAnalyticsConsent */.W)();
        if (configured === null || consent === null) return null;
        if (!configured)
          return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
            children: "Analytics are currently off on this site.",
          });
        const said = {
          granted: "You have said yes to analytics cookies.",
          denied: "You have said no to analytics cookies. Nothing is being counted.",
          unset: "You have not answered yet. Nothing is being counted until you do.",
        }[consent];
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "consent-controls",
          children: [
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              children: [
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                  children: "Your choice on this device:",
                }),
                " ",
                said,
              ],
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "btn-row",
              children: [
                consent !== "granted" &&
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn",
                    onClick: () => answer("granted"),
                    children: "Turn analytics on",
                  }),
                consent !== "denied" &&
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn btn--secondary",
                    onClick: () => answer("denied"),
                    children: "Turn analytics off",
                  }),
              ],
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
              className: "hint",
              children:
                "Turning it off stops any further counting straight away. Anything already counted has gone to Google; turning analytics off cannot remove past data.",
            }),
          ],
        });
      }

      /***/
    },

    /***/ 3937: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";

      // EXPORTS
      __webpack_require__.d(__webpack_exports__, {
        W: () => /* binding */ useAnalyticsConsent,
      });

      // EXTERNAL MODULE: ../../node_modules/.pnpm/next@15.5.24_@playwright+test@1.62.1_@types+node@22.20.1_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/next/dist/compiled/react/index.js
      var react = __webpack_require__(5127); // ./lib/analytics.ts
      /** Google Analytics loads only after an explicit, remembered Yes. */ const CONSENT_KEY =
        "sgo-analytics-consent";
      const CONSENT_EVENT = "sgo-analytics-consent-change";
      let pageConsent;
      /** Read the editable public config after its beforeInteractive script loads. */ function getMeasurementId() {
        if (false) {
        }
        const configured = window.SGO_GOOGLE_CONFIG?.ga4MeasurementId;
        const id = typeof configured === "string" ? configured.trim() : "";
        // Google's example tag and our placeholder must never start tracking.
        return /^G-[A-Z0-9]+$/.test(id) && !["G-MYTAG", "G-XXXXXXXXXX"].includes(id) ? id : "";
      }
      function readConsent() {
        if (false) {
        }
        if (pageConsent !== undefined) return pageConsent;
        try {
          const value = window.localStorage.getItem(CONSENT_KEY);
          return value === "granted" || value === "denied" ? value : "unset";
        } catch {
          return "unset";
        }
      }
      /** Keep this page's choice even when the browser refuses persistent storage. */ function writeConsent(
        value,
      ) {
        pageConsent = value;
        try {
          if (value === "unset") window.localStorage.removeItem(CONSENT_KEY);
          else window.localStorage.setItem(CONSENT_KEY, value);
        } catch {
          /* The in-memory choice still holds for this page. */
        }
        window.dispatchEvent(new Event(CONSENT_EVENT));
      }
      /** Synchronize the banner, privacy controls, and other open tabs. */ function subscribeToConsent(
        callback,
      ) {
        const storageChanged = (event) => {
          if (event.key !== CONSENT_KEY && event.key !== null) return;
          pageConsent = undefined;
          callback();
        };
        window.addEventListener(CONSENT_EVENT, callback);
        window.addEventListener("storage", storageChanged);
        return () => {
          window.removeEventListener(CONSENT_EVENT, callback);
          window.removeEventListener("storage", storageChanged);
        };
      }
      function cleanUrl(value) {
        try {
          const url = new URL(value);
          return ["http:", "https:"].includes(url.protocol) ? url.origin + url.pathname : "";
        } catch {
          return "";
        }
      }
      function pageDetails() {
        return {
          page_location: cleanUrl(window.location.href),
          page_referrer: cleanUrl(document.referrer),
          page_title: document.title,
        };
      }
      /** One tag per document; withdrawing and granting again also resets opt-out. */ function loadAnalytics() {
        const id = getMeasurementId();
        if (!id || readConsent() !== "granted") return;
        const flags = window;
        const wasDisabled = flags[`ga-disable-${id}`] === true;
        flags[`ga-disable-${id}`] = false;
        if (document.getElementById("ga-tag")) {
          if (wasDisabled) window.gtag?.("event", "page_view", pageDetails());
          return;
        }
        // Use Google's documented queue format (Arguments objects), and queue the
        // configuration before fetching the script so a fast load cannot race it.
        window.dataLayer = window.dataLayer ?? [];
        window.gtag = function gtag() {
          window.dataLayer?.push(arguments);
        };
        window.gtag("js", new Date());
        window.gtag("config", id, {
          send_page_view: false,
          allow_google_signals: false,
          allow_ad_personalization_signals: false,
          ...pageDetails(),
        });
        // Share-link query strings, fragments and calculator answers are excluded.
        window.gtag("event", "page_view", pageDetails());
        const script = document.createElement("script");
        script.id = "ga-tag";
        script.async = true;
        script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`;
        document.head.appendChild(script);
      }
      /** Google's documented opt-out flag is checked before subsequent hits. */ function disableAnalytics() {
        const id = getMeasurementId();
        if (!id) return;
        window[`ga-disable-${id}`] = true;
      } // ./components/ui/useAnalyticsConsent.ts

      /* __next_internal_client_entry_do_not_use__ useAnalyticsConsent auto */

      function useAnalyticsConsent() {
        const [consent, setConsent] = (0, react.useState)(null);
        const [configured, setConfigured] = (0, react.useState)(null);
        (0, react.useEffect)(() => {
          const synchronize = () => {
            const available = getMeasurementId() !== "";
            const choice = readConsent();
            setConfigured(available);
            setConsent(choice);
            if (available && choice === "granted") loadAnalytics();
            else disableAnalytics();
          };
          synchronize();
          return subscribeToConsent(synchronize);
        }, []);
        return {
          consent,
          configured,
          answer: writeConsent,
        };
      }

      /***/
    },

    /***/ 7197: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 1359),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 1713),
      );

      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [13, 511, 358], () => __webpack_exec__(7197));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
