(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [877],
  {
    /***/ 1713: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ ConsentControls: () => /* binding */ ConsentControls,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5127);
      /* harmony import */ var _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ =
        __webpack_require__(2789);
      /* __next_internal_client_entry_do_not_use__ ConsentControls auto */

      /**
       * Changing your mind, on the privacy page.
       *
       * Withdrawing consent has to be as easy as giving it, so this shows the current
       * answer in words and offers the opposite one. It is the same two functions the
       * banner uses, not a second implementation that could drift.
       */ function ConsentControls() {
        const [consent, setConsent] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          if (!_lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .ANALYTICS_CONFIGURED */.Y3) return;
          setConsent((0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .readConsent */.Xj)());
        }, []);
        if (
          !_lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .ANALYTICS_CONFIGURED */.Y3 ||
          consent === null
        )
          return null;
        const answer = (value) => {
          (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .writeConsent */.eD)(value);
          setConsent(value);
          if (value === "granted")
            (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .loadAnalytics */.L0)();
          else (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .disableAnalytics */.Re)();
        };
        const said = {
          granted: "You have said yes to analytics cookies.",
          denied: "You have said no to analytics cookies. Nothing is being counted.",
          unset: "You have not answered yet. Nothing is being counted until you do.",
        }[consent];
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "consent-controls",
          children: [
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              children: [
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                  children: "Your choice on this device:",
                }),
                " ",
                said,
              ],
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "btn-row",
              children: [
                consent !== "granted" &&
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn",
                    onClick: () => answer("granted"),
                    children: "Turn analytics on",
                  }),
                consent !== "denied" &&
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn btn--secondary",
                    onClick: () => answer("denied"),
                    children: "Turn analytics off",
                  }),
              ],
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
              className: "hint",
              children:
                "Turning it off stops any further counting straight away. Anything already counted has gone to Google and I cannot reach into it, though it holds nothing that identifies you.",
            }),
          ],
        });
      }

      /***/
    },

    /***/ 2789: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ L0: () => /* binding */ loadAnalytics,
        /* harmony export */ Re: () => /* binding */ disableAnalytics,
        /* harmony export */ Xj: () => /* binding */ readConsent,
        /* harmony export */ Y3: () => /* binding */ ANALYTICS_CONFIGURED,
        /* harmony export */ eD: () => /* binding */ writeConsent,
        /* harmony export */
      });
      /* unused harmony exports GA_MEASUREMENT_ID, CONSENT_KEY */
      /**
       * Google Analytics, behind consent.
       *
       * Nothing here runs unless two things are true: a measurement ID was supplied
       * at build time, and the reader has actively agreed. There is no consent mode,
       * no "denied" default that still phones home, and no script tag in the HTML.
       * The tag is injected by JavaScript after the reader presses Yes, and never
       * otherwise.
       *
       * That is stricter than most implementations because of who uses this site.
       * People arrive here describing a child in their care, their benefits and their
       * income, at a hard moment. Consent has to mean what it says.
       */ /** Set at build time. Absent means the whole feature is off, banner included. */ const GA_MEASUREMENT_ID =
        "G-M4VRDKT4YE" ?? 0;
      /** Whether this build carries analytics at all. */ const ANALYTICS_CONFIGURED =
        GA_MEASUREMENT_ID.length > 0;
      /** Where the reader's answer is kept. Their browser, nowhere else. */ const CONSENT_KEY =
        "sgo-analytics-consent";
      /**
       * Read the stored answer.
       *
       * Every access is wrapped: a browser with site data blocked throws on the
       * property itself, and a reader who has blocked storage must still get a
       * working site, not a blank one.
       */ function readConsent() {
        try {
          const v = window.localStorage.getItem(CONSENT_KEY);
          return v === "granted" || v === "denied" ? v : "unset";
        } catch {
          return "unset";
        }
      }
      /** Record the answer. Failing to store it is not an error worth showing. */ function writeConsent(
        value,
      ) {
        try {
          if (value === "unset") window.localStorage.removeItem(CONSENT_KEY);
          else window.localStorage.setItem(CONSENT_KEY, value);
        } catch {
          /* storage blocked: the choice holds for this page view only */
        }
      }
      /**
       * Inject the Google tag. Called only from the consent flow.
       *
       * Idempotent: pressing Yes twice, or a re-render, must not load it twice.
       */ function loadAnalytics() {
        if (!ANALYTICS_CONFIGURED) return;
        if (typeof document === "undefined") return;
        if (document.getElementById("ga-tag")) return;
        const s = document.createElement("script");
        s.id = "ga-tag";
        s.async = true;
        s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(GA_MEASUREMENT_ID)}`;
        document.head.appendChild(s);
        window.dataLayer = window.dataLayer ?? [];
        window.gtag = function gtag(...args) {
          window.dataLayer?.push(args);
        };
        window.gtag("js", new Date());
        // No advertising features, and no automatic capture of the query string: a
        // shared result link carries the child's ages, and that is not Google's.
        window.gtag("config", GA_MEASUREMENT_ID, {
          anonymize_ip: true,
          allow_google_signals: false,
          allow_ad_personalization_signals: false,
          page_location: window.location.origin + window.location.pathname,
        });
      }
      /**
       * Undo consent within the current page view.
       *
       * Removing the tag cannot un-send what was already sent, so this also sets the
       * documented opt-out flag, which the loaded tag checks before every hit.
       */ function disableAnalytics() {
        if (!ANALYTICS_CONFIGURED) return;
        if (false) {
        }
        window[`ga-disable-${GA_MEASUREMENT_ID}`] = true;
      }

      /***/
    },

    /***/ 8865: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 1713),
      );

      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [13, 511, 358], () => __webpack_exec__(8865));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
