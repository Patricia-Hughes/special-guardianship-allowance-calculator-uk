(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [39],
  {
    /***/ 949: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 4335),
      );

      /***/
    },

    /***/ 4335: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ default: () => /* binding */ Error,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* __next_internal_client_entry_do_not_use__ default auto */
      /**
       * What someone sees when a page fails to render.
       *
       * Without this, React unmounts the tree and the page goes white, which is
       * indistinguishable from a broken site and tells nobody anything. It matters
       * more here than on most sites: the money formatter deliberately refuses to
       * display a figure it cannot trust, and refusing is only better than showing a
       * wrong number if the person is told what happened.
       */ function Error({ reset }) {
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
          id: "main",
          className: "container site-main",
          children: [
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
              children: "Something went wrong on this page",
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
              children:
                "The calculator stopped rather than show you a figure it could not stand behind. That is deliberate, but it means you have not got an answer, and I am sorry.",
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
              children:
                "Try again. If it keeps happening, the guides and the rate tables still work.",
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "row gap-lg",
              children: [
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                  type: "button",
                  className: "btn",
                  onClick: reset,
                  children: "Try again",
                }),
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                  className: "btn btn--secondary",
                  href: "/",
                  children: "Start again",
                }),
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                  className: "btn btn--secondary",
                  href: "/rates",
                  children: "See the rate tables",
                }),
              ],
            }),
            /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
              className: "gap-xl",
              children:
                "Nothing you typed was sent anywhere. It was only ever in your own browser, and this page has not kept it.",
            }),
          ],
        });
      }

      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [13, 511, 358], () => __webpack_exec__(949));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
