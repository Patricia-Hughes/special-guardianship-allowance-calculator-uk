(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [177],
  {
    /***/ 1063: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ StaleWatch: () => /* binding */ StaleWatch,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5127);
      /* __next_internal_client_entry_do_not_use__ StaleWatch auto */

      /**
       * The stale-rates banner, checked against the READER's date.
       *
       * The deadline is baked in at build time; the comparison is not. A static site
       * that nobody rebuilds keeps serving the same HTML for years, so the only clock
       * that can tell a carer their figures have expired is the one in their own
       * browser.
       *
       * Rendered on the server too when the build itself was already stale, so the
       * warning survives with JavaScript off. In every other case the server renders
       * nothing and this fills it in after hydration, which is why the two branches
       * cannot be collapsed into one.
       */ function StaleWatch({ effectiveTo, staleAtBuildTime }) {
        const [staleNow, setStaleNow] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)(
          staleAtBuildTime,
        );
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          // Compared as ISO strings in UTC, the same way the engine does it, so a
          // reader in BST at half past midnight on 1 April cannot see a different
          // answer from the one the calculation uses.
          const check = () => setStaleNow(new Date().toISOString().slice(0, 10) > effectiveTo);
          check();
          // A tab left open across the boundary is a real case for this audience:
          // people leave the page up and come back to it.
          const daily = setInterval(check, 60 * 60 * 1000);
          return () => clearInterval(daily);
        }, [effectiveTo]);
        if (!staleNow) return null;
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
          role: "alert",
          className: "banner-critical",
          children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "wrap",
            children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              children: [
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                  children: "These rates may be out of date.",
                }),
                " My newest figures ran to ",
                effectiveTo,
                ". New rates take effect on 1 April each year. Please check the current national minimum allowance before using anything here in a letter.",
              ],
            }),
          }),
        });
      }

      /***/
    },

    /***/ 2789: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ L0: () => /* binding */ loadAnalytics,
        /* harmony export */ Re: () => /* binding */ disableAnalytics,
        /* harmony export */ Xj: () => /* binding */ readConsent,
        /* harmony export */ Y3: () => /* binding */ ANALYTICS_CONFIGURED,
        /* harmony export */ eD: () => /* binding */ writeConsent,
        /* harmony export */
      });
      /* unused harmony exports GA_MEASUREMENT_ID, CONSENT_KEY */
      /**
       * Google Analytics, behind consent.
       *
       * Nothing here runs unless two things are true: a measurement ID was supplied
       * at build time, and the reader has actively agreed. There is no consent mode,
       * no "denied" default that still phones home, and no script tag in the HTML.
       * The tag is injected by JavaScript after the reader presses Yes, and never
       * otherwise.
       *
       * That is stricter than most implementations because of who uses this site.
       * People arrive here describing a child in their care, their benefits and their
       * income, at a hard moment. Consent has to mean what it says.
       */ /** Set at build time. Absent means the whole feature is off, banner included. */ const GA_MEASUREMENT_ID =
        "G-M4VRDKT4YE" ?? 0;
      /** Whether this build carries analytics at all. */ const ANALYTICS_CONFIGURED =
        GA_MEASUREMENT_ID.length > 0;
      /** Where the reader's answer is kept. Their browser, nowhere else. */ const CONSENT_KEY =
        "sgo-analytics-consent";
      /**
       * Read the stored answer.
       *
       * Every access is wrapped: a browser with site data blocked throws on the
       * property itself, and a reader who has blocked storage must still get a
       * working site, not a blank one.
       */ function readConsent() {
        try {
          const v = window.localStorage.getItem(CONSENT_KEY);
          return v === "granted" || v === "denied" ? v : "unset";
        } catch {
          return "unset";
        }
      }
      /** Record the answer. Failing to store it is not an error worth showing. */ function writeConsent(
        value,
      ) {
        try {
          if (value === "unset") window.localStorage.removeItem(CONSENT_KEY);
          else window.localStorage.setItem(CONSENT_KEY, value);
        } catch {
          /* storage blocked: the choice holds for this page view only */
        }
      }
      /**
       * Inject the Google tag. Called only from the consent flow.
       *
       * Idempotent: pressing Yes twice, or a re-render, must not load it twice.
       */ function loadAnalytics() {
        if (!ANALYTICS_CONFIGURED) return;
        if (typeof document === "undefined") return;
        if (document.getElementById("ga-tag")) return;
        const s = document.createElement("script");
        s.id = "ga-tag";
        s.async = true;
        s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(GA_MEASUREMENT_ID)}`;
        document.head.appendChild(s);
        window.dataLayer = window.dataLayer ?? [];
        window.gtag = function gtag(...args) {
          window.dataLayer?.push(args);
        };
        window.gtag("js", new Date());
        // No advertising features, and no automatic capture of the query string: a
        // shared result link carries the child's ages, and that is not Google's.
        window.gtag("config", GA_MEASUREMENT_ID, {
          anonymize_ip: true,
          allow_google_signals: false,
          allow_ad_personalization_signals: false,
          page_location: window.location.origin + window.location.pathname,
        });
      }
      /**
       * Undo consent within the current page view.
       *
       * Removing the tag cannot un-send what was already sent, so this also sets the
       * documented opt-out flag, which the loaded tag checks before every hit.
       */ function disableAnalytics() {
        if (!ANALYTICS_CONFIGURED) return;
        if (false) {
        }
        window[`ga-disable-${GA_MEASUREMENT_ID}`] = true;
      }

      /***/
    },

    /***/ 3041: /***/ () => {
      // extracted by mini-css-extract-plugin
      /***/
    },

    /***/ 3601: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ ConsentBanner: () => /* binding */ ConsentBanner,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5127);
      /* harmony import */ var _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ =
        __webpack_require__(2789);
      /* __next_internal_client_entry_do_not_use__ ConsentBanner auto */

      /**
       * The cookie consent bar.
       *
       * Renders nothing on the server and nothing at all in a build with no
       * measurement ID, so a site without analytics has no banner and nothing to
       * consent to, exactly as before.
       *
       * The reader is asked once. Until they answer, no tag is loaded, which is what
       * makes this consent rather than notice. Both buttons are the same size and
       * the same prominence: a "reject" hidden in small grey text is not a free
       * choice, and this audience is the wrong one to play that game with.
       */ function ConsentBanner() {
        const [consent, setConsent] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          if (!_lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .ANALYTICS_CONFIGURED */.Y3) return;
          const stored = (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .readConsent */.Xj)();
          setConsent(stored);
          if (stored === "granted")
            (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .loadAnalytics */.L0)();
        }, []);
        if (!_lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .ANALYTICS_CONFIGURED */.Y3)
          return null;
        // null means the effect has not run: server render, and the first paint.
        if (consent === null || consent !== "unset") return null;
        const answer = (value) => {
          (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .writeConsent */.eD)(value);
          setConsent(value);
          if (value === "granted")
            (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .loadAnalytics */.L0)();
          else (0, _lib_analytics__WEBPACK_IMPORTED_MODULE_2__ /* .disableAnalytics */.Re)();
        };
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("section", {
          className: "consent print-hide",
          "aria-label": "Cookies on this site",
          children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "wrap consent__inner",
            children: [
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "consent__text",
                children: [
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    children: [
                      /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(
                        "strong",
                        {
                          children: "May I count your visit?",
                        },
                      ),
                      " I would like to use Google Analytics to see which pages people find useful. It sets cookies and sends Google the pages you look at.",
                    ],
                  }),
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "consent__note",
                    children: [
                      "Nothing you type into the calculator is ever sent, whichever you choose. Saying no changes nothing about how the site works. You can change your mind at any time on the",
                      " ",
                      /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "/privacy",
                        children: "privacy page",
                      }),
                      ".",
                    ],
                  }),
                ],
              }),
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "consent__actions",
                children: [
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn",
                    onClick: () => answer("granted"),
                    children: "Yes, that is fine",
                  }),
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn btn--secondary",
                    onClick: () => answer("denied"),
                    children: "No thank you",
                  }),
                ],
              }),
            ],
          }),
        });
      }

      /***/
    },

    /***/ 7326: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 3601),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 1063),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.t.bind(__webpack_require__, 3041, 23),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.t.bind(__webpack_require__, 9552, 23),
      );

      /***/
    },

    /***/ 9552: /***/ () => {
      // extracted by mini-css-extract-plugin
      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [518, 13, 511, 358], () => __webpack_exec__(7326));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
