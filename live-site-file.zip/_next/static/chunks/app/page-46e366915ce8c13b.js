(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [974],
  {
    /***/ 4925: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";

      // EXPORTS
      __webpack_require__.d(__webpack_exports__, {
        CalculatorShell: () => /* binding */ CalculatorShell,
      });

      // EXTERNAL MODULE: ../../node_modules/.pnpm/next@15.5.24_@playwright+test@1.62.1_@types+node@22.20.1_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/next/dist/compiled/react/jsx-runtime.js
      var jsx_runtime = __webpack_require__(8767);
      // EXTERNAL MODULE: ../../node_modules/.pnpm/next@15.5.24_@playwright+test@1.62.1_@types+node@22.20.1_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/next/dist/compiled/react/index.js
      var react = __webpack_require__(5127); // ../../packages/engine/dist/data/benefits.2025-26.json
      const benefits_2025_26_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"financialYear":"2025-26","effectiveFrom":"2025-04-07","dataVersion":"2025-26.0","childBenefit":{"eldestWeeklyPence":2605,"additionalChildWeeklyPence":1725,"sourceId":"cb-ga-uprating-order-2025"},"guardiansAllowance":{"weeklyPerChildPence":2210,"taxFree":true,"disregardedForMeansTestedBenefits":true,"exemptFromBenefitCap":true,"eligibilityNote":"Both parents dead, or one dead and the other untraceable / serving 2+ years / whereabouts unknown. Parental UK residence condition applies.","sourceId":"cb-ga-uprating-order-2025"},"sgoAllowanceTaxTreatment":{"taxable":false,"disregardedForClaimantsOwnMeansTestedBenefits":true},"incomeSupportApplicableAmounts":{"status":"SOURCED","sourceId":"dwp-benefit-rates-2026-27","schema":{"singleUnder25Pence":7290,"single25PlusPence":9205,"couplePence":14465,"dependentChildPence":8466,"familyPremiumPence":1948,"disabilityPremiumPence":4320,"disabilityPremiumCouplePence":6165,"carerPremiumPence":4640}},"capitalRules":{"sourceId":"dwp-benefit-rates-2026-27","upperLimitPence":1600000,"disregardedPence":600000,"childDisregardPence":300000,"tariffPerBlockPence":100,"blockSizePence":25000}}',
      ); // ../../packages/engine/dist/data/benefits.2026-27.json
      const benefits_2026_27_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"financialYear":"2026-27","effectiveFrom":"2026-04-06","dataVersion":"2026-27.1","childBenefit":{"eldestWeeklyPence":2705,"additionalChildWeeklyPence":1790,"sourceId":"cb-ga-uprating-order-2026"},"guardiansAllowance":{"weeklyPerChildPence":2295,"taxFree":true,"disregardedForMeansTestedBenefits":true,"exemptFromBenefitCap":true,"eligibilityNote":"Both parents dead, or one dead and the other untraceable / serving 2+ years / whereabouts unknown. Parental UK residence condition applies.","sourceId":"cb-ga-uprating-order-2026"},"universalCredit":{"childElementMonthlyPence":30394,"firstChildBornBefore6Apr2017MonthlyPence":35188,"childElementNote":"Two rates, not one. A first child born before 6 April 2017 keeps the higher protected rate; every other child gets the standard element.","twoChildLimitAbolished":true,"twoChildLimitAbolishedFrom":"2026-04-06","statute":"Universal Credit (Removal of Two Child Limit) Act 2026 c.13","sourceId":"dwp-benefit-rates-2026-27"},"benefitCap":{"annualOutsideLondonPence":2202000,"annualLondonPence":2532300,"sourceId":"dwp-benefit-rates-2026-27"},"carersAllowance":{"weeklyPence":8645,"earningsLimitWeeklyPence":20400},"qualifyingCareRelief":{"appliesToSpecialGuardians":false},"sgoAllowanceTaxTreatment":{"taxable":false,"disregardedForClaimantsOwnMeansTestedBenefits":true},"incomeSupportApplicableAmounts":{"status":"SOURCED","sourceId":"dwp-benefit-rates-2026-27","schema":{"singleUnder25Pence":7565,"single25PlusPence":9555,"couplePence":15015,"dependentChildPence":8788,"familyPremiumPence":2022,"disabilityPremiumPence":4485,"disabilityPremiumCouplePence":6400,"carerPremiumPence":4815}},"capitalRules":{"sourceId":"dwp-benefit-rates-2026-27","upperLimitPence":1600000,"disregardedPence":600000,"childDisregardPence":300000,"tariffPerBlockPence":100,"blockSizePence":25000,"universalCreditTariffPer250MonthlyPence":435}}',
      ); // ../../packages/engine/dist/data/citations.json
      const citations_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"ca1989-s14a":{"label":"Children Act 1989, s.14A","url":"https://www.legislation.gov.uk/ukpga/1989/41/section/14A","kind":"statute","retrieved":"2026-08-29"},"sg-regs-2005-reg5":{"label":"Special Guardianship Regulations 2005, reg 5","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/5","kind":"regulation","retrieved":"2026-08-29","holding":"The council remains responsible for assessing support needs for three years from the making of the order."},"sg-regs-2005-reg6":{"label":"Special Guardianship Regulations 2005, reg 6","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/6","kind":"regulation","retrieved":"2026-08-29"},"sg-regs-2005-reg7":{"label":"Special Guardianship Regulations 2005, reg 7","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/7","kind":"regulation","retrieved":"2026-08-29"},"sg-regs-2005-reg9":{"label":"Special Guardianship Regulations 2005, reg 9","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/9","kind":"regulation","retrieved":"2026-08-29","holding":"Financial support ceases in the circumstances set out in the regulation, including when the child reaches 18 unless the conditions for continuing are met."},"dfe-guidance-2017-para65":{"label":"DfE Special Guardianship Guidance (Jan 2017), para 65","url":"https://www.gov.uk/government/publications/special-guardianship-guidance","kind":"guidance","retrieved":"2026-08-29"},"lewisham-2008":{"label":"R (B) v Lewisham LBC [2008] EWHC 738 (Admin)","url":"https://www.bailii.org/ew/cases/EWHC/Admin/2008/738.html","kind":"case","retrieved":"2026-09-03","holding":"Using the lower adoption allowance model was unlawful. Fostering allowances are the starting point."},"kirklees-2010":{"label":"Barrett v Kirklees MBC [2010] EWHC 467 (Admin)","url":"https://www.bailii.org/ew/cases/EWHC/Admin/2010/467.html","kind":"case","retrieved":"2026-09-03","holding":"A flat two-thirds of the core fostering allowance was an unjustified departure from guidance."},"merton-2012":{"label":"R (TT) v Merton LBC [2012] EWHC 2055 (Admin)","url":"https://caselaw.nationalarchives.gov.uk/ewhc/admin/2012/2055","kind":"case","retrieved":"2026-09-03","holding":"Blanket percentage deduction unlawful. BUT: no duty to pay every special guardian an allowance, and the means-test methodology itself was upheld as lawful."},"tower-hamlets-2013":{"label":"R (X) v Tower Hamlets LBC [2013] EWCA Civ 904","url":"https://caselaw.nationalarchives.gov.uk/ewca/civ/2013/904","kind":"case","retrieved":"2026-09-03","holding":"Paying family foster carers less than unrelated foster carers was unlawful. Former foster carers should not be worse off."},"lgsco-devon-2024":{"label":"LGSCO decision, Devon County Council (23 000 973, 25 January 2024)","url":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973","kind":"ombudsman","retrieved":"2026-08-31","holding":"The council was at fault for deducting Child Benefit from all special guardians on Universal Credit as a blanket rule, without looking at individual circumstances. It was ordered to recalculate and to refund deductions. Devon changed the policy with effect from 1 January 2024, and a later complaint about its current practice was not upheld."},"lgsco-southend-2020":{"label":"LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)","kind":"ombudsman","retrieved":"2026-08-31","holding":"Reducing the whole allowance to 75% of the core fostering allowance in year one and 50% in year two misapplied the two-year transitional provision, which concerns the reward element only. Backdating of about 6,948 pounds was recommended, and the council estimated 37 other families were affected."},"lgsco-north-tyneside-17002928":{"label":"LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)","url":"https://web.archive.org/web/20231216202817/https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf","kind":"ombudsman","retrieved":"2026-09-01","holding":"Calculating a special guardianship allowance as a percentage of the fostering allowance was contrary to statutory guidance and case law. The council identified 171 families who may not have received the right support, and payments were backdated to November 2013.","archivedFrom":"https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf"},"corambaaf-pn75":{"label":"CoramBAAF Practice Note 75 - special guardianship financial support","url":"https://corambaaf.org.uk/sites/default/files/Members%20Area/Resources/Practice%20Notes/PN%2075%20Financial%20Support%20for%20Special%20Guardians_Englandv2.pdf","kind":"guidance","retrieved":"2026-09-03","holding":"The DfE standardised means-test model is non-statutory and pre-dates Universal Credit."},"dfe-nma-2026-27":{"label":"DfE National Minimum Allowance for foster carers, 2026 to 2027","url":"https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","kind":"dataset","retrieved":"2026-08-29"},"dfe-nma-2025-26":{"label":"DfE National Minimum Allowance for foster carers, 2025 to 2026","url":"https://web.archive.org/web/20251130000000/https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","kind":"dataset","retrieved":"2026-09-03","archivedFrom":"https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering"},"wg-nma-2026-27":{"label":"The Fostering Network, national minimum allowances table, reproducing the Welsh 2026 to 2027 rates","url":"https://www.thefosteringnetwork.org.uk/policy-and-campaigns/empowering-children-and-young-people/allowances/","kind":"dataset","retrieved":"2026-09-03"},"hsc-fostering-2026-27":{"label":"HSC (Northern Ireland) fostering allowances, 2026 to 2027","url":"https://www.health-ni.gov.uk/sites/default/files/2026-05/Foster%20care%20allowances%202026-27.pdf","kind":"dataset","retrieved":"2026-09-03"},"sra-2026-27":{"label":"Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026","url":"https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/","kind":"dataset","retrieved":"2026-08-31","holding":"A national minimum for foster and kinship carers alike. Councils may pay more."},"cb-ga-uprating-order-2026":{"label":"Child Benefit and Guardian\'s Allowance Up-rating Order 2026","url":"https://www.legislation.gov.uk/uksi/2026/232/made","kind":"regulation","retrieved":"2026-09-03"},"cb-ga-uprating-order-2025":{"label":"Child Benefit and Guardian\'s Allowance Up-rating Order 2025","url":"https://www.legislation.gov.uk/uksi/2025/292/made","kind":"regulation","retrieved":"2026-09-03"},"uc-two-child-limit-act-2026":{"label":"Universal Credit (Removal of Two Child Limit) Act 2026 c.13","url":"https://www.legislation.gov.uk/ukpga/2026/13","kind":"statute","retrieved":"2026-09-03"},"kinship-zones-2026":{"label":"Kinship Zones - kinship allowance pilot (2026-2029)","url":"https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care","kind":"dataset","retrieved":"2026-08-29","holding":"A pilot in seven English councils paying a non-means-tested allowance equal to the fostering National Minimum Allowance."},"dwp-benefit-rates-2026-27":{"label":"DWP, Benefit and pension rates 2026 to 2027","url":"https://www.gov.uk/government/publications/benefit-and-pension-rates-2026-to-2027/proposed-benefit-and-pension-rates-2026-to-2027","kind":"dataset","retrieved":"2026-08-29"},"kinship-care-guidance-2024":{"label":"DfE, Kinship Care: statutory guidance for local authorities (October 2024)","url":"https://assets.publishing.service.gov.uk/media/670d3ed5e84ae1fd8592f2fa/Kinship_Care_-_statutory_guidance_for_local_authorities__October_2024.pdf","kind":"guidance","retrieved":"2026-08-29","holding":"In calculating ongoing special guardianship financial support, the local authority should have regard to the fostering allowance that would have been paid if the child was fostered."},"lgsco-rochdale-2019":{"label":"LGSCO decision, Rochdale MBC (17 010 167, May 2019), council\'s judicial review challenge dismissed","url":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/17-010-167","kind":"ombudsman","retrieved":"2026-09-01"},"sg-regs-2005-reg13":{"label":"Special Guardianship Regulations 2005, reg 13(2)","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/13","kind":"regulation","retrieved":"2026-09-03","holding":"Reg 13(2): in determining the amount of financial support the local authority MUST take account of any other grant, benefit, allowance or resource available to the person. It does not name Child Benefit. It imposes a duty to take other benefits into account, of which Child Benefit is one."},"north-tyneside-decision-2025":{"label":"North Tyneside Council, Decision Record: Foster Care, Special Guardianship, Adoption and Child Arrangement Order Allowance Increases","kind":"guidance","retrieved":"2026-08-29","holding":"Special guardianship allowances are uplifted alongside fostering allowances, with London and South East weighting applied in line with the recommended minimum levels. All uplifts take effect from 1 April 2025."},"shropshire-sg-policy-2021":{"label":"Shropshire Council, Special Guardianship Allowances Policy (Cabinet, 8 February 2021)","url":"https://shropshire.gov.uk/committee-services/documents/s26540/Special Guardianship Allowances Policy.pdf","kind":"guidance","retrieved":"2026-08-29"},"lincolnshire-sg-framework":{"label":"Lincolnshire County Council, Special Guardianship Allowance Assessment Framework","kind":"guidance","retrieved":"2026-08-29","holding":"Distinguishes the statutory \'Special Guardianship Guidance\' from the non-statutory \'Standardised means test model for adoption and special guardianship financial support\'."},"derby-sg-scheme":{"label":"Derby City Council, Special Guardianship Orders and Derby Support Scheme","url":"https://derbycsc.trixonline.co.uk/chapter/special-guardianship-orders-and-derby-support-scheme","kind":"guidance","retrieved":"2026-08-29"},"fostering-news-2025-uplifts":{"label":"Fostering news, \'2025 Allowance Uplifts Across the UK\'","url":"https://fosteringnews.co.uk/fostering/2025-allowance-uplifts-across-the-uk-england-wales-scotland-ni/","kind":"dataset","retrieved":"2026-08-29"},"fostering-network-allowances":{"label":"The Fostering Network, Foster Care Allowances","url":"https://www.thefosteringnetwork.org.uk/policy-and-campaigns/empowering-children-and-young-people/allowances/","kind":"dataset","retrieved":"2026-08-29"},"parliament-wq-14259":{"label":"UK Parliament written question 14259 (National Minimum Allowance uplifts)","url":"https://questions-statements.parliament.uk/written-questions/detail/2024-11-13/14259","kind":"dataset","retrieved":"2026-08-29"},"dfe-nma-2024-25":{"label":"DfE National Minimum Allowance for foster carers, 2024 to 2025 (National Archives snapshot)","url":"https://web.archive.org/web/20250302000000/https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","kind":"dataset","retrieved":"2026-08-30","holding":"Weekly allowances for the tax year from 6 April 2024 to 5 April 2025, by region and age band. This guidance applies to England."},"lgsco-devon-24-003-172":{"label":"LGSCO decision, Devon County Council (24 003 172), not upheld","url":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/24-003-172","kind":"ombudsman","retrieved":"2026-08-31"},"lgsco-22-018-116":{"label":"LGSCO decision, friends and family carers (22 018 116)","url":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/22-018-116","kind":"ombudsman","retrieved":"2026-08-31"},"lgsco-22-011-906":{"label":"LGSCO decision, friends and family carers (22 011 906)","url":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/22-011-906","kind":"ombudsman","retrieved":"2026-08-31"},"sra-2024-25":{"label":"Scottish Recommended Allowance, rates announced 29 August 2023, unchanged for 2024/25","url":"https://www.gov.scot/news/new-national-allowance-for-foster-and-kinship-carers/","kind":"dataset","retrieved":"2026-08-31","holding":"A national minimum for foster and kinship carers alike. Councils may pay more."},"sra-implementation-review":{"label":"Scottish Government, Foster and kinship carers, Scottish Recommended Allowance: implementation review","url":"https://www.gov.scot/publications/review-implementation-scottish-recommended-allowance-foster-kinship-carers/","kind":"dataset","retrieved":"2026-09-03"},"devon-sgo-procedures-2024":{"label":"Devon County Council, Applications for Special Guardianship Orders (procedures manual), last updated 24 October 2024","url":"https://devoncs.trixonline.co.uk/chapter/applications-for-special-guardianship-orders","kind":"guidance","retrieved":"2026-08-31"},"leeds-sgo-support-offer-2024":{"label":"Leeds City Council, Revised Special Guardianship Support Offer, cover report, 1 March 2024","url":"https://democracy.leeds.gov.uk/documents/s254642/Special%20Guardianship%20Order%20Support%20Cover%20Report%20010324.pdf","kind":"guidance","retrieved":"2026-08-31"},"ciw-nma-bulletin-2023-24":{"label":"Care Inspectorate Wales, National Minimum Allowances for Foster Carers 2023 to 2024, bulletin of 27 January 2023","url":"https://content.govdelivery.com/accounts/UKWALES_CSSIW_INT/bulletins/3450cef","kind":"dataset","retrieved":"2026-08-31"},"wg-codes-consultation-2026":{"label":"Welsh Government, consultation on changes to two codes of practice: Part 6 and Special Guardianship Orders, 12 February to 7 April 2026","url":"https://www.gov.wales/written-statement-launch-consultation-revisions-part-6-and-special-guardianship-codes-practice","kind":"guidance","retrieved":"2026-08-31"},"ni-model-scheme-2024-25":{"label":"Department of Health (Northern Ireland), Foster care allowances, Model Scheme 2024-25","url":"https://www.health-ni.gov.uk/sites/default/files/publications/health/model-scheme-2024-25.pdf","kind":"dataset","retrieved":"2026-09-01","holding":"Sets the weekly foster care scale rates in Northern Ireland from 1 April 2024 at 149, 166, 187 and 219 pounds across four age bands."},"wg-nma-2024-25":{"label":"Welsh Government, National Minimum Allowances for foster carers 2024 to 2025, circular of 26 February 2024","url":"https://www.thefosteringnetwork.org.uk/media/rzzgloqq/nma-letter-2024-25-english-e-_0.pdf","kind":"dataset","retrieved":"2026-09-03","holding":"Sets the Welsh national minimum allowances from 1 April 2024 at 218 pounds for ages 0 to 4, 199 pounds for 5 to 15 and 248 pounds for 16 and over, a rise of 3 per cent."},"sg-regs-2005-reg6-2-b":{"label":"Special Guardianship Regulations 2005, reg 6(2)(b)","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/6","kind":"regulation","retrieved":"2026-09-01","holding":"The specific provision on taking a child\'s needs into account when deciding financial support, including any disability or the consequences of earlier abuse or neglect."},"ca1989-s14f-3":{"label":"Children Act 1989, s.14F(3)","url":"https://www.legislation.gov.uk/ukpga/1989/41/section/14F","kind":"statute","retrieved":"2026-09-03","holding":"A local authority MAY assess a person\'s needs for special guardianship support services on request, but MUST do so where that person is of a description prescribed in regulations. The duty to assess therefore does not exist in the Act alone: it needs reg 11(1) to supply the prescribed description."},"sg-regs-2005-reg11":{"label":"Special Guardianship Regulations 2005, reg 11","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/11","kind":"regulation","retrieved":"2026-09-03","holding":"Prescribes, for the purposes of s.14F(3), the persons at whose request an assessment MUST be carried out: reg 11(1)(a) a relevant child looked after, or looked after immediately before the order; (b) a special guardian or prospective special guardian of such a child; (c) a parent of such a child. Where reg 11(1) does not apply, reg 11(2) to (3) require the authority, if minded not to assess, to give notice with reasons and allow representations."},"sg-regs-2005-reg18":{"label":"Special Guardianship Regulations 2005, reg 18(2)(a)","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/18","kind":"regulation","retrieved":"2026-09-03","holding":"The local authority must review financial support payable periodically on receipt of the annual statement mentioned in reg 10. The trigger is receipt of the statement, not the passage of twelve months."},"sg-regs-2005-reg10":{"label":"Special Guardianship Regulations 2005, reg 10","url":"https://www.legislation.gov.uk/uksi/2005/1109/regulation/10","kind":"regulation","retrieved":"2026-09-03","holding":"Conditions. Reg 10(1)(b) requires the special guardian to agree to supply an annual statement of their circumstances. That statement is what triggers the review duty in reg 18(2)(a)."},"ni-model-scheme-2025-26":{"label":"Department of Health (Northern Ireland), Model Scheme 2025-26, Section 1, Foster Care Allowances","url":"https://www.health-ni.gov.uk/sites/default/files/2026-05/Foster%20care%20allowances%202025-26.pdf","kind":"guidance","retrieved":"2026-09-03","holding":"SCALE RATES from 1 April 2025: 155.00, 173.00, 194.00 and 228.00 a week."},"sra-2025-26":{"label":"Scottish Government, Scottish Recommended Allowance: information for carers and professionals, page updated 27 June 2025","url":"https://web.archive.org/web/20251015000000/https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/","kind":"guidance","retrieved":"2026-09-03","archivedFrom":"https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/","holding":"2025-26 weekly allowances, backdated to 1 April 2025: 0 to 4 at 171.17, 5 to 10 at 199.14, 11 to 15 at 199.14, 16 and over at 272.97. The same page states that no family should be worse off, that the allowance is the higher of what is currently paid or the SRA, and that the SRA does not apply to continuing care."},"dfe-nma-2024-25-second-capture":{"label":"GOV.UK, Help with the cost of fostering, capture of 2 March 2025","url":"https://web.archive.org/web/20250302000000/https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","kind":"guidance","retrieved":"2026-09-03","archivedFrom":"https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering"},"dfe-no-minimum-after-18":{"label":"GOV.UK, Help with the cost of fostering, on allowances after a child is old enough to leave foster care","url":"https://web.archive.org/web/20251130000000/https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","kind":"guidance","retrieved":"2026-09-03","archivedFrom":"https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering","holding":"States in terms: \\"There is no minimum allowance when your child is old enough to leave foster care.\\""},"wg-nma-2026-27-approval":{"label":"Welsh Government, decision reports 2026, recording ministerial approval of the National Minimum Allowances for 2026 to 2027","url":"https://www.llyw.cymru/adroddiadau-ar-benderfyniadau-2026","kind":"guidance","retrieved":"2026-09-03","holding":"Records in Welsh that the Minister for Children and Social Care approved the National Minimum Allowances for Foster Carers for 2026 to 2027. Establishes that the allowance exists and was approved. Contains NO rate table."}}',
      ); // ../../packages/engine/dist/data/kinship-zones.json
      const kinship_zones_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"programme":"Kinship Zones (kinship allowance pilot)","liveFrom":"2026-04-01","runsUntil":"2029","fundingFirstTwoYearsPence":12600000000,"approxChildren":5000,"allowanceBasis":"non-means-tested, equal to the fostering National Minimum Allowance","evaluator":"Foundations / Alma Economics","localAuthorities":["bexley","bolton","newcastle-upon-tyne","north-east-lincolnshire","medway","thurrock","wiltshire"],"eligibility":{"orderTypes":["special-guardianship-order","lives-with-child-arrangements-order"],"childWouldOtherwiseBeInCare":true,"excludesThoseAlreadyOnReg6Support":true},"lastVerified":"2026-08-29","reviewEvery":"P3M","warning":"PILOT ONLY. Does not change the law in other authorities. Councils already paying NMA-equivalent were ineligible to apply.","sourceId":"kinship-zones-2026"}',
      ); // ../../packages/engine/dist/data/la-overrides.json
      const la_overrides_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"e":[{"slug":"devon","name":"Devon County Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Allowance aligned to the basic fostering allowance rate, with the standardised means-test model. Devon\'s procedures state that paying a fixed percentage of the fostering allowance would not be lawful. The living costs disregard is set at 100% of the Income Support applicable amount rather than the model\'s 125%, with tiered housing disregards.","deductsChildBenefit":false,"deductsChildBenefitFromMeansTestedClaimants":false,"taper":null,"capital":null,"lawfulnessFlag":{"code":"LGSCO_UPHELD","summary":"In January 2024 the Ombudsman found Devon at fault for deducting Child Benefit from all special guardians on Universal Credit as a blanket rule, without looking at individual circumstances. Recalculation and refunds were ordered.","sourceUrl":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973","decisionDate":"2024-01-25","concernsFormerPolicy":true,"policyChangedOn":"1 January 2024","supersededBy":{"summary":"A later complaint about the way Devon calculates allowances now was not upheld. The Ombudsman found its current practice consistent with government guidance.","sourceUrl":"https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/24-003-172","decisionDate":"2024-10-01"}},"policySourceUrl":"https://devoncs.trixonline.co.uk/chapter/applications-for-special-guardianship-orders","verifiedOn":"2026-08-31","fixedPercentageOfFosteringRate":null,"livingCostsMultiplierPercent":100,"policySourceDate":"2024-10-24","flatRateSuppressedNote":"The flat core rate of £213.01, read on 24 October 2024, has been REMOVED rather than served. Against the 2026/27 rest-of-England minimums it sits below the 11-15 and 16-17 bands, so it would fire BELOW_NMA, a critical warning naming Devon, on a figure nobody has re-verified since Devon uprated. Devon\'s May 2025 cabinet decision reportedly set 16+ at £258 and other ages at £237.44, and £213.01 matches neither. Devon now falls back to the national minimums. Restore a flat rate only from Devon\'s current published schedule, with the date it was read."},{"slug":"leeds","name":"Leeds City Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Revised Special Guardianship Support Offer of March 2024. Uses the standardised means-test model, with support that is not means tested for carers of children subject to non-agency orders who already receive a means-tested benefit. The maximum is pegged to Leeds\'s own weekly fostering allowance rates.","lawfulnessFlag":null,"policySourceUrl":"https://democracy.leeds.gov.uk/documents/s254642/Special%20Guardianship%20Order%20Support%20Cover%20Report%20010324.pdf","verifiedOn":"2026-08-31","fixedPercentageOfFosteringRate":null,"policyUnderReview":true,"policyUnderReviewNote":"Leeds City Council\'s own procedures manual says its special guardianship financial support information is under review. What is shown here is the revised offer of March 2024, which is the last version it published.","policySourceDate":"2024-03-01"},{"slug":"north-tyneside","name":"North Tyneside Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Equivalence to the maximum fostering allowance, uplifted annually in line with the National Minimum Allowance, means tested. The council abolished its earlier percentage model in 2018.","lawfulnessFlag":{"code":"LGSCO_UPHELD","summary":"In February 2018 the Ombudsman found North Tyneside at fault for calculating special guardianship allowances as a percentage of its fostering allowance. The council identified 171 families who may not have received the right support, and payments were backdated to November 2013. North Tyneside abolished the percentage model that year.","sourceUrl":"https://web.archive.org/web/20231216202817/https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf","decisionDate":"2018-02-27","concernsFormerPolicy":true,"policyChangedOn":"2018","sourceNote":"Archived capture. The live lgo.org.uk address for this report times out."},"councilApplicationDate":"1 April","policySourceUrl":"https://northtyneside.gov.uk/sites/default/files/web-page-related-files/20250321%20-%20Decision%20Record%20-%20Fostering%20Allowance.pdf","policySourceDate":"2025-03-21","verifiedOn":"2026-08-29","fixedPercentageOfFosteringRate":null},{"slug":"shropshire","name":"Shropshire Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Special Guardianship Allowances Policy agreed by Cabinet in 2021, including backdated payments to special guardians of children who were previously looked after","lawfulnessFlag":null,"policySourceUrl":"https://shropshire.gov.uk/committee-services/documents/s26540/Special Guardianship Allowances Policy.pdf","policySourceDate":"2021-02-08","verifiedOn":"2026-08-29","fixedPercentageOfFosteringRate":null},{"slug":"lincolnshire","name":"Lincolnshire County Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Uses the DfE standardised means-test model and publishes a full worked example of the calculation. Its own policy classifies that model as non-statutory guidance","lawfulnessFlag":null,"policySourceUrl":"https://www.lincolnshire.gov.uk/directory-record/82363/special-guardianship-allowance-assessment-framework","verifiedOn":"2026-08-29","fixedPercentageOfFosteringRate":null},{"slug":"derby","name":"Derby City Council","nation":"england","region":"rest-of-england","publishable":true,"corePolicy":"Allowance set at the equivalent of Derby\'s basic fostering rate for a child of that age","lawfulnessFlag":null,"policySourceUrl":"https://derbycsc.trixonline.co.uk/chapter/special-guardianship-orders-and-derby-support-scheme","policySourceDate":"2024-05-10","verifiedOn":"2026-08-29","fixedPercentageOfFosteringRate":null}]}',
      ); // ../../packages/engine/dist/data/la-region-map.json
      const la_region_map_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"AX":"ONS_GOR_PROXY_DOCUMENTED","O8":"ONS Government Office Region (DfE publishes no authority-level list)","Fk":153,"Tj":{"barking-and-dagenham":"london","barnet":"london","barnsley":"rest-of-england","bath-and-north-east-somerset":"rest-of-england","bedford":"rest-of-england","bexley":"london","birmingham":"rest-of-england","blackburn-with-darwen":"rest-of-england","blackpool":"rest-of-england","bolton":"rest-of-england","bournemouth-christchurch-and-poole":"rest-of-england","bracknell-forest":"south-east","bradford":"rest-of-england","brent":"london","brighton-and-hove":"south-east","bristol":"rest-of-england","bromley":"london","buckinghamshire":"south-east","bury":"rest-of-england","calderdale":"rest-of-england","cambridgeshire":"rest-of-england","camden":"london","central-bedfordshire":"rest-of-england","cheshire-east":"rest-of-england","cheshire-west-and-chester":"rest-of-england","city-of-london":"london","cornwall":"rest-of-england","county-durham":"rest-of-england","coventry":"rest-of-england","croydon":"london","cumberland":"rest-of-england","darlington":"rest-of-england","derby":"rest-of-england","derbyshire":"rest-of-england","devon":"rest-of-england","doncaster":"rest-of-england","dorset":"rest-of-england","dudley":"rest-of-england","ealing":"london","east-riding-of-yorkshire":"rest-of-england","east-sussex":"south-east","enfield":"london","essex":"rest-of-england","gateshead":"rest-of-england","gloucestershire":"rest-of-england","greenwich":"london","hackney":"london","halton":"rest-of-england","hammersmith-and-fulham":"london","hampshire":"south-east","haringey":"london","harrow":"london","hartlepool":"rest-of-england","havering":"london","herefordshire":"rest-of-england","hertfordshire":"rest-of-england","hillingdon":"london","hounslow":"london","isle-of-wight":"south-east","isles-of-scilly":"rest-of-england","islington":"london","kensington-and-chelsea":"london","kent":"south-east","kingston-upon-hull":"rest-of-england","kingston-upon-thames":"london","kirklees":"rest-of-england","knowsley":"rest-of-england","lambeth":"london","lancashire":"rest-of-england","leeds":"rest-of-england","leicester":"rest-of-england","leicestershire":"rest-of-england","lewisham":"london","lincolnshire":"rest-of-england","liverpool":"rest-of-england","luton":"rest-of-england","manchester":"rest-of-england","medway":"south-east","merton":"london","middlesbrough":"rest-of-england","milton-keynes":"south-east","newcastle-upon-tyne":"rest-of-england","newham":"london","norfolk":"rest-of-england","north-east-lincolnshire":"rest-of-england","north-lincolnshire":"rest-of-england","north-northamptonshire":"rest-of-england","north-somerset":"rest-of-england","north-tyneside":"rest-of-england","north-yorkshire":"rest-of-england","northumberland":"rest-of-england","nottingham":"rest-of-england","nottinghamshire":"rest-of-england","oldham":"rest-of-england","oxfordshire":"south-east","peterborough":"rest-of-england","plymouth":"rest-of-england","portsmouth":"south-east","reading":"south-east","redbridge":"london","redcar-and-cleveland":"rest-of-england","richmond-upon-thames":"london","rochdale":"rest-of-england","rotherham":"rest-of-england","rutland":"rest-of-england","salford":"rest-of-england","sandwell":"rest-of-england","sefton":"rest-of-england","sheffield":"rest-of-england","shropshire":"rest-of-england","slough":"south-east","solihull":"rest-of-england","somerset":"rest-of-england","south-gloucestershire":"rest-of-england","south-tyneside":"rest-of-england","southampton":"south-east","southend-on-sea":"rest-of-england","southwark":"london","st-helens":"rest-of-england","staffordshire":"rest-of-england","stockport":"rest-of-england","stockton-on-tees":"rest-of-england","stoke-on-trent":"rest-of-england","suffolk":"rest-of-england","sunderland":"rest-of-england","surrey":"south-east","sutton":"london","swindon":"rest-of-england","tameside":"rest-of-england","telford-and-wrekin":"rest-of-england","thurrock":"rest-of-england","torbay":"rest-of-england","tower-hamlets":"london","trafford":"rest-of-england","wakefield":"rest-of-england","walsall":"rest-of-england","waltham-forest":"london","wandsworth":"london","warrington":"rest-of-england","warwickshire":"rest-of-england","west-berkshire":"south-east","west-northamptonshire":"rest-of-england","west-sussex":"south-east","westminster":"london","westmorland-and-furness":"rest-of-england","wigan":"rest-of-england","wiltshire":"rest-of-england","windsor-and-maidenhead":"south-east","wirral":"rest-of-england","wokingham":"south-east","wolverhampton":"rest-of-england","worcestershire":"rest-of-england","york":"rest-of-england"},"Dy":{"barking-and-dagenham":"Barking and Dagenham","barnet":"Barnet","barnsley":"Barnsley","bath-and-north-east-somerset":"Bath and North East Somerset","bedford":"Bedford","bexley":"Bexley","birmingham":"Birmingham","blackburn-with-darwen":"Blackburn with Darwen","blackpool":"Blackpool","bolton":"Bolton","bournemouth-christchurch-and-poole":"Bournemouth, Christchurch and Poole","bracknell-forest":"Bracknell Forest","bradford":"Bradford","brent":"Brent","brighton-and-hove":"Brighton and Hove","bristol":"Bristol","bromley":"Bromley","buckinghamshire":"Buckinghamshire","bury":"Bury","calderdale":"Calderdale","cambridgeshire":"Cambridgeshire","camden":"Camden","central-bedfordshire":"Central Bedfordshire","cheshire-east":"Cheshire East","cheshire-west-and-chester":"Cheshire West and Chester","city-of-london":"City of London","cornwall":"Cornwall","county-durham":"County Durham","coventry":"Coventry","croydon":"Croydon","cumberland":"Cumberland","darlington":"Darlington","derby":"Derby","derbyshire":"Derbyshire","devon":"Devon","doncaster":"Doncaster","dorset":"Dorset","dudley":"Dudley","ealing":"Ealing","east-riding-of-yorkshire":"East Riding of Yorkshire","east-sussex":"East Sussex","enfield":"Enfield","essex":"Essex","gateshead":"Gateshead","gloucestershire":"Gloucestershire","greenwich":"Greenwich","hackney":"Hackney","halton":"Halton","hammersmith-and-fulham":"Hammersmith and Fulham","hampshire":"Hampshire","haringey":"Haringey","harrow":"Harrow","hartlepool":"Hartlepool","havering":"Havering","herefordshire":"Herefordshire","hertfordshire":"Hertfordshire","hillingdon":"Hillingdon","hounslow":"Hounslow","isle-of-wight":"Isle of Wight","isles-of-scilly":"Isles of Scilly","islington":"Islington","kensington-and-chelsea":"Kensington and Chelsea","kent":"Kent","kingston-upon-hull":"Kingston upon Hull","kingston-upon-thames":"Kingston upon Thames","kirklees":"Kirklees","knowsley":"Knowsley","lambeth":"Lambeth","lancashire":"Lancashire","leeds":"Leeds","leicester":"Leicester","leicestershire":"Leicestershire","lewisham":"Lewisham","lincolnshire":"Lincolnshire","liverpool":"Liverpool","luton":"Luton","manchester":"Manchester","medway":"Medway","merton":"Merton","middlesbrough":"Middlesbrough","milton-keynes":"Milton Keynes","newcastle-upon-tyne":"Newcastle upon Tyne","newham":"Newham","norfolk":"Norfolk","north-east-lincolnshire":"North East Lincolnshire","north-lincolnshire":"North Lincolnshire","north-northamptonshire":"North Northamptonshire","north-somerset":"North Somerset","north-tyneside":"North Tyneside","north-yorkshire":"North Yorkshire","northumberland":"Northumberland","nottingham":"Nottingham","nottinghamshire":"Nottinghamshire","oldham":"Oldham","oxfordshire":"Oxfordshire","peterborough":"Peterborough","plymouth":"Plymouth","portsmouth":"Portsmouth","reading":"Reading","redbridge":"Redbridge","redcar-and-cleveland":"Redcar and Cleveland","richmond-upon-thames":"Richmond upon Thames","rochdale":"Rochdale","rotherham":"Rotherham","rutland":"Rutland","salford":"Salford","sandwell":"Sandwell","sefton":"Sefton","sheffield":"Sheffield","shropshire":"Shropshire","slough":"Slough","solihull":"Solihull","somerset":"Somerset","south-gloucestershire":"South Gloucestershire","south-tyneside":"South Tyneside","southampton":"Southampton","southend-on-sea":"Southend-on-Sea","southwark":"Southwark","st-helens":"St Helens","staffordshire":"Staffordshire","stockport":"Stockport","stockton-on-tees":"Stockton-on-Tees","stoke-on-trent":"Stoke-on-Trent","suffolk":"Suffolk","sunderland":"Sunderland","surrey":"Surrey","sutton":"Sutton","swindon":"Swindon","tameside":"Tameside","telford-and-wrekin":"Telford and Wrekin","thurrock":"Thurrock","torbay":"Torbay","tower-hamlets":"Tower Hamlets","trafford":"Trafford","wakefield":"Wakefield","walsall":"Walsall","waltham-forest":"Waltham Forest","wandsworth":"Wandsworth","warrington":"Warrington","warwickshire":"Warwickshire","west-berkshire":"West Berkshire","west-northamptonshire":"West Northamptonshire","west-sussex":"West Sussex","westminster":"Westminster","westmorland-and-furness":"Westmorland and Furness","wigan":"Wigan","wiltshire":"Wiltshire","windsor-and-maidenhead":"Windsor and Maidenhead","wirral":"Wirral","wokingham":"Wokingham","wolverhampton":"Wolverhampton","worcestershire":"Worcestershire","york":"York"}}',
      ); // ../../packages/engine/dist/data/rates.2024-25.json
      const rates_2024_25_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"financialYear":"2024-25","effectiveFrom":"2024-04-01","effectiveTo":"2025-03-31","dfeStatedTaxYearFrom":"2024-04-06","dfeStatedTaxYearTo":"2025-04-05","councilApplicationFrom":"2024-04-01","dataVersion":"2024-25.1","england":{"sourceId":"dfe-nma-2024-25","unit":"weekly-pence","upliftPercent":6.88,"ageBands":[{"id":"0-2","minAge":0,"maxAge":2},{"id":"3-4","minAge":3,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"regions":{"london":{"0-2":19100,"3-4":19500,"5-10":21700,"11-15":24800,"16-17":28900},"south-east":{"0-2":18300,"3-4":18900,"5-10":20800,"11-15":23800,"16-17":27800},"rest-of-england":{"0-2":16500,"3-4":17000,"5-10":18700,"11-15":21300,"16-17":24900}}},"wales":{"sourceId":"wg-nma-2024-25","unit":"weekly-pence","upliftPercent":3,"anomalyConfirmed":true,"anomalyConfirmedOn":"2026-09-01","userFacingNote":"In Wales the rate for a child under 5 is higher than for a child aged 5 to 15. That is not a mistake on this site. It is how the Welsh Government publishes them.","ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-15","minAge":5,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17,"openEnded":true}],"rates":{"0-4":21800,"5-15":19900,"16-17":24800},"bandNote":"The Welsh letter prints the top band as \\"16+\\", so it is marked openEnded here. The maxAge of 17 is this calculator\'s own cap, because the product is for children under 18 and the bands must tile 0 to 17 exactly. Not a transcription error, and not a closed band in the source. The letter also states the rates apply from 1 April, so Wales follows the council convention rather than the DfE tax year."},"northern-ireland":{"sourceId":"ni-model-scheme-2024-25","unit":"weekly-pence","upliftPercent":3,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17,"openEnded":true}],"rates":{"0-4":14900,"5-10":16600,"11-15":18700,"16-17":21900}},"scotland":{"sourceId":"sra-2024-25","unit":"weekly-pence","upliftPercent":0,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-15","minAge":5,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"rates":{"0-4":16831,"5-15":19581,"16-17":26841}}}',
      ); // ../../packages/engine/dist/data/rates.2025-26.json
      const rates_2025_26_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"financialYear":"2025-26","effectiveFrom":"2025-04-01","effectiveTo":"2026-03-31","dfeStatedTaxYearFrom":"2025-04-06","dfeStatedTaxYearTo":"2026-04-05","councilApplicationFrom":"2025-04-01","dataVersion":"2025-26.2","england":{"sourceId":"dfe-nma-2025-26","unit":"weekly-pence","upliftPercent":3.55,"ageBands":[{"id":"0-2","minAge":0,"maxAge":2},{"id":"3-4","minAge":3,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"regions":{"london":{"0-2":19800,"3-4":20100,"5-10":22500,"11-15":25700,"16-17":29900},"south-east":{"0-2":18900,"3-4":19600,"5-10":21600,"11-15":24700,"16-17":28800},"rest-of-england":{"0-2":17000,"3-4":17600,"5-10":19400,"11-15":22000,"16-17":25800}}},"wales":null,"northern-ireland":{"sourceId":"ni-model-scheme-2025-26","unit":"weekly-pence","upliftPercent":4,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17,"openEnded":true}],"rates":{"0-4":15500,"5-10":17300,"11-15":19400,"16-17":22800}},"scotland":{"sourceId":"sra-2025-26","unit":"weekly-pence","upliftPercent":1.7,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-15","minAge":5,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"rates":{"0-4":17117,"5-15":19914,"16-17":27297}}}',
      ); // ../../packages/engine/dist/data/rates.2026-27.json
      const rates_2026_27_namespaceObject = /*#__PURE__*/ JSON.parse(
        '{"financialYear":"2026-27","effectiveFrom":"2026-04-01","effectiveTo":"2027-03-31","dfeStatedTaxYearFrom":"2026-04-06","dfeStatedTaxYearTo":"2027-04-05","councilApplicationFrom":"2026-04-01","dataVersion":"2026-27.1","england":{"sourceId":"dfe-nma-2026-27","unit":"weekly-pence","upliftPercent":3.35,"ageBands":[{"id":"0-2","minAge":0,"maxAge":2},{"id":"3-4","minAge":3,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"regions":{"london":{"0-2":20500,"3-4":20800,"5-10":23300,"11-15":26600,"16-17":30900},"south-east":{"0-2":19500,"3-4":20300,"5-10":22300,"11-15":25500,"16-17":29800},"rest-of-england":{"0-2":17600,"3-4":18200,"5-10":20100,"11-15":22700,"16-17":26700}}},"wales":{"sourceId":"wg-nma-2026-27","unit":"weekly-pence","upliftPercent":2.2,"verify":true,"anomalyConfirmed":true,"anomalyConfirmedOn":"2026-09-01","userFacingNote":"In Wales the rate for a child under 5 is higher than for a child aged 5 to 15. That is not a mistake on this site. It is how the Welsh Government publishes them.","ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-15","minAge":5,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17,"openEnded":true}],"rates":{"0-4":22900,"5-15":20800,"16-17":26000},"bandNote":"The Welsh letter prints the top band as \\"16+\\", so it is marked openEnded here. The maxAge of 17 is this calculator\'s own cap, because the product is for children under 18 and the bands must tile 0 to 17 exactly. Not a transcription error, and not a closed band in the source. The letter also states the rates apply from 1 April, so Wales follows the council convention rather than the DfE tax year.","approvalSourceId":"wg-nma-2026-27-approval"},"northern-ireland":{"sourceId":"hsc-fostering-2026-27","unit":"weekly-pence","upliftPercent":3,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-10","minAge":5,"maxAge":10},{"id":"11-15","minAge":11,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"rates":{"0-4":16000,"5-10":17900,"11-15":20000,"16-17":23500}},"scotland":{"sourceId":"sra-2026-27","unit":"weekly-pence","upliftPercent":3.8,"ageBands":[{"id":"0-4","minAge":0,"maxAge":4},{"id":"5-15","minAge":5,"maxAge":15},{"id":"16-17","minAge":16,"maxAge":17}],"rates":{"0-4":17768,"5-15":20671,"16-17":28335}}}',
      ); // ../../packages/engine/dist/errors.js
      /**
       * Engine error taxonomy.
       *
       * These are separate classes because the UI treats them differently (spec §33),
       * and because collapsing them would mean showing a carer an internal failure as
       * though it were something they typed wrong:
       *
       *   ValidationError     show the field error, keep the person on the step
       *   DataError           "we don't have verified rates for that date yet"
       *   GuardrailViolation  never shown raw; log the rule code and fall back
       *   MoneyError          a programming error, and should never reach a user
       *
       * GuardrailViolation lives in guardrails.ts, with the rules it reports on.
       */ class EngineError extends Error {
        constructor(message) {
          super(message);
          this.name = new.target.name;
        }
      }
      /** A money value that is not an integer number of pence, or an unparseable input. */ class MoneyError extends EngineError {}
      /** Reference data is missing, stale, or not yet sourced. Never guess past this. */ class errors_DataError extends EngineError {}
      /** Input failed schema validation. Carries the field path for the form to highlight. */ class ValidationError extends EngineError {
        constructor(message, issues = []) {
          super(message);
          this.issues = issues;
        }
      } //# sourceMappingURL=errors.js.map
      // ../../packages/engine/dist/referenceData.js

      /**
       * Reference data access.
       *
       * [R10] Rate data is never hardcoded in engine source. It lives in versioned
       * JSON under /data with an effective date, copied into this package at build
       * time by scripts/sync-engine-data.ts, which also strips the maintainer-only
       * fields so they are not shipped to a browser.
       *
       * The `with { type: 'json' }` on each import is required, not decorative. Node
       * refuses a JSON import in an ES module without it, so the built package threw
       * ERR_IMPORT_ATTRIBUTE_MISSING the moment anything loaded it outside a bundler,
       * despite package.json advertising `exports` and `main`. Next and vitest both
       * accept the attribute, so it costs nothing and makes the published shape
       * honest. Do not strip them.
       */

      const ENGINE_VERSION = "0.1.0";
      // ─── Tables, newest first ──────────────────────────────────────────────────
      const RATE_TABLES = [
        rates_2026_27_namespaceObject,
        rates_2025_26_namespaceObject,
        rates_2024_25_namespaceObject,
      ];
      const BENEFIT_TABLES = [benefits_2026_27_namespaceObject, benefits_2025_26_namespaceObject];
      const KINSHIP_ZONES = kinship_zones_namespaceObject;
      // ─── Councils ──────────────────────────────────────────────────────────────
      /**
       * All seeded LA overrides, including those not yet publishable. Use
       * publishableLaOverride for anything that reaches a user.
       */ const LA_OVERRIDES_ALL = Object.fromEntries(
        la_overrides_namespaceObject.e.map((a) => [a.slug, a]),
      );
      /**
       * [HARD R9] Any statement about a NAMED council must be backed by a stored,
       * dated, live source URL. An entry without one is invisible to the engine: the
       * calculation falls back to national minimums and raises COUNCIL_POLICY_UNKNOWN,
       * which is an honest gap rather than an unsourced claim about a real body.
       */ function isPublishable(la) {
        if (!la || !la.publishable || !la.policySourceUrl) return false;
        const finding = la.lawfulnessFlag;
        if (finding && (!finding.sourceUrl || !finding.decisionDate)) return false;
        return true;
      }
      /** Resolve a publishable override from a given override map. */ function publishableLaOverrideIn(
        overrides,
        slug,
      ) {
        if (!slug) return undefined;
        const la = overrides[slug];
        return isPublishable(la) ? la : undefined;
      }
      /** Convenience over the shipped override set. */ function publishableLaOverride(slug) {
        return publishableLaOverrideIn(LA_OVERRIDES_ALL, slug);
      }
      /** True when we hold a seeded-but-unpublishable entry for this council. */ function hasUnpublishableLaOverrideIn(
        overrides,
        slug,
      ) {
        if (!slug) return false;
        const la = overrides[slug];
        return la !== undefined && !isPublishable(la);
      }
      function hasUnpublishableLaOverride(slug) {
        return hasUnpublishableLaOverrideIn(LA_OVERRIDES_ALL, slug);
      }
      // ─── Regions ───────────────────────────────────────────────────────────────
      const LA_REGION_MAP = la_region_map_namespaceObject.Tj;
      const LA_NAMES = la_region_map_namespaceObject.Dy;
      /**
       * verificationNote and knownDiscrepancies are maintainer prose and are stripped
       * from the shipped copy by sync-engine-data. They live in /data if you want the
       * reasoning; what the browser needs is the short statement of what the mapping
       * rests on, which is regionSource.
       */ const LA_REGION_MAP_META = {
        verificationStatus: la_region_map_namespaceObject.AX,
        /** What the mapping actually rests on. The DfE publishes no authority-level list. */ regionSource:
          la_region_map_namespaceObject.O8,
        expectedAuthorityCount: la_region_map_namespaceObject.Fk,
      };
      const CITATIONS = citations_namespaceObject;
      /** Resolve a citation id to a full Citation. Throws on an unknown id [R3]. */ function cite(
        id,
      ) {
        const citation = CITATIONS[id];
        if (!citation) throw new errors_DataError(`Unknown citation id: "${id}"`);
        return {
          id,
          ...citation,
          retrieved: citation.retrieved,
        };
      }
      function allCitationIds() {
        return Object.keys(CITATIONS);
      } //# sourceMappingURL=referenceData.js.map
      // ../../packages/engine/dist/deps.js

      /**
       * The reference data the engine calculates against.
       *
       * The engine is a pure function of (input, data). Data is injectable so the
       * legal test cases in spec §35 can exercise paths the SHIPPED data deliberately
       * blocks: the means test, whose Income Support amounts are PENDING_SOURCE, and
       * LA overrides whose source URLs are not yet re-sourced. Injecting for a test
       * never loosens the shipped defaults and never lets a legal test be skipped.
       *
       * Production callers pass nothing and get the versioned files under /data.
       */
      function defaultDeps() {
        return {
          rateTables: RATE_TABLES,
          benefitTables: BENEFIT_TABLES,
          laOverrides: LA_OVERRIDES_ALL,
          kinshipZones: KINSHIP_ZONES,
        };
      }
      function resolveDeps(partial) {
        return {
          ...defaultDeps(),
          ...partial,
        };
      } //# sourceMappingURL=deps.js.map
      // ../../packages/engine/dist/money.js

      /**
       * Money handling, spec §10 [HARD].
       *
       * Floating-point money in a legal calculator is a defect, not a style
       * preference. A carer showing a social worker a figure that is a penny off
       * undermines the whole document.
       *
       * The rules this file exists to enforce:
       *
       *  1. all internal arithmetic is in integer pence
       *  2. parse once, at the boundary, in parseMoney
       *  3. round only at presentation, and only once
       *  4. rounding is half-up
       *  5. weekly to monthly is × 52 ÷ 12. Never × 4, never × 4.33
       *  6. annual is weekly × 52. Not × 52.18
       */
      const pence = (n) => {
        if (!Number.isFinite(n)) throw new MoneyError(`Non-finite pence: ${n}`);
        if (!Number.isInteger(n)) throw new MoneyError(`Non-integer pence: ${n}`);
        return n;
      };
      const ZERO = 0;
      // ─── In ────────────────────────────────────────────────────────────────────
      /** Anything a person might type around a number, and the shape of what is left. */ const DECORATION =
        /[£,\s]/g;
      /**
       * Up to nine digits before the point, which is 9,999,999.99 and more money
       * than any figure on this site. Unbounded `\d+` accepted a twenty-digit entry,
       * which multiplied out past Number.MAX_SAFE_INTEGER and still satisfied
       * Number.isInteger, because a large enough double is integral even when it can
       * no longer represent every integer near it. The arithmetic then lost precision
       * silently, with nothing to say so.
       */ const AMOUNT = /^\d{1,9}(\.\d{1,2})?$/;
      /**
       * Parse a user string into pence. Handles "1,234.5", "£12", " 12 ".
       *
       * Rejects "12.567": more than two decimal places is a typo, not a rounding
       * opportunity, and silently rounding it would accept an amount nobody typed.
       */ function parseMoney(input) {
        const cleaned = input.replace(DECORATION, "");
        if (cleaned === "") return pence(0);
        if (!AMOUNT.test(cleaned)) throw new MoneyError(`Invalid money input: "${input}"`);
        const [whole = "0", fraction = ""] = cleaned.split(".");
        return pence(Number(whole) * 100 + Number(fraction.padEnd(2, "0")));
      }
      // ─── Arithmetic ────────────────────────────────────────────────────────────
      const add = (...xs) => pence(xs.reduce((a, b) => a + b, 0));
      const sub = (a, b) => pence(a - b);
      const clampMin0 = (a) => pence(Math.max(0, a));
      const max = (a, b) => (a >= b ? a : b);
      const min = (a, b) => (a <= b ? a : b);
      /**
       * Multiply by a rate. Half-up rounding.
       *
       * Math.round is half-up for positive values, which is what councils use when
       * presenting figures. Money here is never negative, because clampMin0 guards
       * the subtraction sites, so the half-down-for-negatives behaviour of
       * Math.round is not reachable.
       *
       * This used to add Number.EPSILON "to nudge values stored fractionally below
       * their decimal representation". It did nothing. Number.EPSILON is the gap
       * between 1 and the next double, about 2.2e-16; the gap at a pence-sized value
       * like 15975 is about 1.8e-12, roughly ten thousand times larger. Adding the
       * smaller number to the bigger one is absorbed entirely, so `x + EPSILON === x`
       * for every value this function ever sees and the result was identical without
       * it. It was a comment describing a protection that was not there, which is
       * worse than no protection at all.
       */ function mul(a, rate) {
        if (!Number.isFinite(rate)) throw new MoneyError(`Non-finite rate: ${rate}`);
        return pence(Math.round(a * rate));
      }
      // ─── Periods ───────────────────────────────────────────────────────────────
      const WEEKS_PER_YEAR = 52;
      const MONTHS_PER_YEAR = 12;
      /** Councils use 52 weeks, not 4-week months. */ const weeklyToMonthly = (w) =>
        pence(Math.round((w * WEEKS_PER_YEAR) / MONTHS_PER_YEAR));
      const monthlyToWeekly = (m) => pence(Math.round((m * MONTHS_PER_YEAR) / WEEKS_PER_YEAR));
      const weeklyToAnnual = (w) => pence(w * WEEKS_PER_YEAR);
      // ─── Out ───────────────────────────────────────────────────────────────────
      /**
       * Format for display. en-GB. Shows pence only when there are any, unless forced.
       *
       * Every money value on screen goes through here, which makes it the one place
       * that can guarantee nobody is ever shown "£NaN". The Pence brand is enforced
       * by pence(), but a cast can smuggle a raw number past it, and the failure is
       * silent and convincing: a figure someone might take to their council. Refuse
       * instead. app/error.tsx turns this into a visible message rather than a blank
       * page.
       */ function formatMoney(p, opts) {
        if (!Number.isFinite(p)) {
          throw new MoneyError(`Refusing to display a non-finite amount: ${p}`);
        }
        const showPence = opts?.showPence ?? p % 100 !== 0;
        return new Intl.NumberFormat("en-GB", {
          style: "currency",
          currency: "GBP",
          minimumFractionDigits: showPence ? 2 : 0,
          maximumFractionDigits: showPence ? 2 : 0,
        }).format(p / 100);
      }
      // ─── Sharing a total out ───────────────────────────────────────────────────
      /**
       * Apportion a total across weights without losing pennies (spec §10).
       *
       * Largest-remainder allocation: the parts always sum EXACTLY to the total, for
       * any weights and any total. Test T27 fuzzes this over 10k cases.
       */ function apportion(total, weights) {
        if (weights.length === 0) return [];
        const totalWeight = weights.reduce((a, b) => a + b, 0);
        if (totalWeight === 0) {
          // Nothing to weight by: give the whole total to the first slot so no penny
          // is dropped, rather than returning zeros that do not sum to the total.
          return weights.map((_, i) => pence(i === 0 ? total : 0));
        }
        const exact = weights.map((w) => (total * w) / totalWeight);
        const shares = exact.map((r) => Math.floor(r));
        const pennies = total - shares.reduce((a, b) => a + b, 0);
        // The pennies left over by flooring go to the largest fractional parts, ties
        // broken by position so the result is deterministic.
        const byRemainder = exact
          .map((r, i) => ({
            i,
            fraction: r - Math.floor(r),
          }))
          .sort((a, b) => b.fraction - a.fraction || a.i - b.i);
        for (let k = 0; k < pennies; k++) {
          const slot = byRemainder[k % byRemainder.length];
          /* c8 ignore next */ if (slot === undefined) break;
          shares[slot.i] = (shares[slot.i] ?? 0) + 1;
        }
        return shares.map((n) => pence(n));
      } //# sourceMappingURL=money.js.map
      // ../../packages/engine/dist/flagCatalogue.js

      /**
       * The 34 warnings, spec §17.
       *
       * This file is prose, not logic. Each warning is both an inline card on the
       * result and a link to its guidance page, and they are the reason people share
       * this site: the warning is often worth more to a carer than the number.
       *
       * Copy rules (spec §18, §2 R7): never assert that a council has broken the law.
       * State what the guidance and the decisions say, and what the carer can ask
       * for. Reading age target 12 to 14.
       *
       * Gate 18 in scripts/gates/claims.ts reads this file and fails the build on a
       * warning that makes a claim with no citation behind it.
       */
      const money = (p) => (p === undefined ? "the amount" : formatMoney(p));
      const FLAG_CATALOGUE = {
        UNLAWFUL_CB_DEDUCTION_RISK: {
          severity: "critical",
          title: "Taking Child Benefit off your allowance may not be lawful in your case",
          // Regulation 13 expressly permits the deduction. Saying only that the
          // Ombudsman found one wrong left a carer with nothing prepared for the
          // council's obvious reply, and pointed them at a question they cannot win.
          // The test is justification, not prohibition.
          body: () =>
            "You have told me you get a means-tested benefit **and** that your council takes Child Benefit off your allowance.\n\n" + // Reg 13(2) does not name Child Benefit. It imposes a DUTY to take account
            // of other benefits, of which Child Benefit is plainly one, and the
            // deduction itself was contemplated in Barrett v Kirklees. Attributing the
            // deduction to the text of reg 13 invites a council lawyer to correct it.
            "The regulations require your council to take account of other benefits available to you, and Child Benefit is one of them. The courts have contemplated it being deducted. What is not allowed is applying the same rule to everybody without looking at individual circumstances.\n\n" +
            "In 2024 the Local Government and Social Care Ombudsman found a council at fault for deducting Child Benefit from every special guardian on Universal Credit as a blanket policy. That council had to recalculate around 170 carers' allowances and pay refunds. It changed its policy, and a later complaint about the new practice was not upheld.\n\n" +
            "So the question is not whether your council can deduct Child Benefit. It is whether it decided your case individually, and what its reasons were. Ask for those reasons in writing.\n\n" +
            "The Ombudsman normally expects a complaint within 12 months of you becoming aware of a problem.",
          citationId: "sg-regs-2005-reg13",
          actionUrl: "/guidance/child-benefit-deduction",
        },
        FIXED_PERCENTAGE_POLICY: {
          // No court has held fixed percentages unlawful as a class: Kirklees and
          // Merton each concerned one council's policy on its own facts, and the
          // Ombudsman says "fault", reserving "unlawful" for what a court held. So
          // the heading asks a question rather than making a finding. "Unjustified
          // departure" stays, because departing from statutory guidance without good
          // reason is where the unlawfulness lies, and is glossed once for a reading
          // age of 12 to 14.
          severity: "critical",
          title: "Your council may be starting from the wrong figure",
          body: (c) =>
            `${c.councilName ? `${c.councilName}'s published policy` : "This policy"} appears to set the allowance at a fixed share of the fostering rate${c.policyCheckedOn ? `, as I read it on ${c.policyCheckedOn}` : ""}.\n\n` +
            "The courts have held that applying a flat percentage, two-thirds or a third or any other fixed fraction, without looking at the individual case, is an unjustified departure from the guidance. In other words, the council has stepped away from a rule it is supposed to follow without explaining why. The starting point should be the core fostering allowance, and your own circumstances should then be considered.\n\n" + // The qualification comes from Merton, while the warning cites Kirklees for
            // the main proposition, so Merton is named in the sentence itself.
            "This does not mean you are owed the full fostering rate. In the Merton case the court also held that a council does not have to pay every special guardian an allowance, and that means testing one is lawful. The problem is the blanket nature of a fixed fraction, not the arithmetic.\n\n" +
            "Ask for the written policy and for the reasons behind the figure you were given.",
          citationId: "kirklees-2010",
          actionUrl: "/guidance/fixed-percentage-policies",
        },
        BELOW_NMA: {
          severity: "critical",
          title: "This rate is below the national minimum for fostering",
          body: (c) =>
            `The rate I hold for ${c.councilName ?? "your council"} (${money(c.coreWeekly)} a week) is below the national minimum fostering allowance for ${c.ageBand ? `the ${c.ageBand} age band` : "this age band"} in your area (${money(c.nationalWeekly)} a week).\n\n` +
            "The statutory guidance says the core fostering allowance is the starting point for a special guardianship allowance. A figure below it needs an explanation.\n\n" + // "National minimum" reads as "the least I am entitled to". It is not: it
            // is a minimum for FOSTERING allowances, and there is no statutory floor
            // for a special guardianship allowance at all.
            "Two things this does not mean. It is a minimum for fostering allowances, not a floor your own allowance cannot go below. And it is about the figure your council starts from, not the amount you end up with: a lower final figure after a means test can be perfectly proper, while a lower starting figure is the thing worth asking about.\n\n" +
            "Ask the council to explain in writing how it arrived at the figure and how it compares with what it pays its foster carers.",
          citationId: "dfe-guidance-2017-para65",
          actionUrl: "/guidance/what-your-council-must-consider",
        },
        LGSCO_FINDING_AGAINST_LA: {
          // Wording note: a finding about a policy a council has since changed is not
          // a finding about the council today. Where the data records that the policy
          // changed, or that a later complaint about the current practice was not
          // upheld, this flag must say so in the same breath. Devon is the live case.
          severity: "critical",
          title: "The Ombudsman has made a finding about this council",
          body: (c) =>
            `${c.policySummary ?? "The Local Government and Social Care Ombudsman has published a decision about this council's special guardianship allowance practice."}\n\n` +
            (c.decisionDate ? `The decision was made on ${c.decisionDate}.` : "") +
            (c.policySourceUrl ? ` You can read it here: ${c.policySourceUrl}` : "") +
            (c.decisionDate || c.policySourceUrl ? "\n\n" : "") +
            (c.policyChangedOn
              ? `The council changed its policy from ${c.policyChangedOn}.\n\n`
              : "") +
            (c.supersededSummary ? `${c.supersededSummary}\n\n` : "") +
            "A published decision about one carer does not automatically apply to you, but it is relevant background if you are asking the council to look at your case again.",
          actionUrl: "/guidance/complaining-to-the-ombudsman",
        },
        // Regulation 7 says the reward element MAY continue to be paid for two years,
        // and longer where the council considers that appropriate. It is a power, not
        // an entitlement. Calling it a protection told carers they held something they
        // do not, and handed any council an easy correction. Their position is still
        // strong, but it comes from the guidance and Tower Hamlets, not from reg 7
        // creating a right.
        REG7_FLOOR_APPLIED: {
          severity: "important",
          title: "Your council can keep paying your old fostering rate for two years",
          body: (c) =>
            `You fostered this child before the order, and the order was made ${c.monthsSinceOrder !== undefined ? `${c.monthsSinceOrder} months` : "less than two years"} ago.\n\n` +
            `For the first two years your council can carry on paying the reward part of what you were paid as a foster carer. My estimate assumes it does, so I have shown ${money(c.previousWeekly)} a week rather than a lower figure. That is what I have assumed, not a figure your council has agreed.\n\n` +
            "The Court of Appeal has held that family foster carers should not be worse off than unrelated foster carers, which is the argument for continuing it.",
          citationId: "sg-regs-2005-reg7",
          actionUrl: "/guidance/former-foster-carers",
        },
        REG7_EXPIRING: {
          severity: "important",
          title: "The two-year point is coming up",
          body: (c) =>
            `The order was made ${c.monthsSinceOrder !== undefined ? `${c.monthsSinceOrder} months` : "more than 18 months"} ago. The two years during which your council can keep paying the reward part of your former fostering allowance end at 24 months.\n\n` +
            "It cuts both ways. After two years the reward element can lawfully stop, and it can also lawfully carry on: the council can agree to continue it where it considers that appropriate. Ask now, in writing, rather than after your payments drop.",
          citationId: "sg-regs-2005-reg7",
          actionUrl: "/guidance/former-foster-carers",
        },
        REG7_EXTENSION_AVAILABLE: {
          severity: "important",
          title: "You can ask for the reward element to carry on past two years",
          // Two corrections from the review of 2 September. Reg 7 only bites where the
          // remuneration decision was taken before the order, and the continuation
          // test is exceptional needs or circumstances, not ordinary ones.
          body: () =>
            "Two years is not a hard stop. Your council can carry on paying the reward element beyond it, but only where it considers that necessary because of the **exceptional needs of the child, or other exceptional circumstances**.\n\n" +
            "That is a higher bar than it sounds, so it is worth putting your case in those terms rather than saying the needs have not reduced.\n\n" +
            "There is also a question that comes first: this rule only applies where your council decided to include a reward element **before** the order was made. Ask whether it did.",
          citationId: "sg-regs-2005-reg7",
          actionUrl: "/guidance/former-foster-carers",
        },
        REG7_MISAPPLICATION_WARNING: {
          severity: "important",
          title: "Check what your council is tapering",
          body: () =>
            "Regulation 7 is about the **reward** part of a former foster carer's allowance, which a council can keep paying for two years. It does not authorise stepping down the whole allowance.\n\n" +
            "The Ombudsman found in 2020 that reducing an entire allowance to 75% and then 50% misapplied that rule. If your payments are being stepped down, ask the council which element it is reducing and why.",
          citationId: "lgsco-southend-2020",
          actionUrl: "/guidance/former-foster-carers",
        },
        // Neither of these says "must". The claim that a council must assess where
        // the child was looked after is very likely right, but reg 6 governs when
        // financial support is PAYABLE rather than when an assessment is owed, so it
        // does not support the claim, and the correct provision is not yet confirmed.
        // Tracked in data/watchlist.json as must-assess-provision.
        NOT_LOOKED_AFTER_BEFORE_ORDER: {
          severity: "important",
          title: "Your assessment is not automatic",
          body: () =>
            "Because the child was not in the council's care immediately before the order, the circumstances in which financial support is payable are narrower. It is discretionary, which means it is up to the council. That does not shut the door: it can still consider your case, and you can ask.\n\n" +
            "Put the request in writing and ask for the decision and its reasons in writing too.",
          citationId: "sg-regs-2005-reg6",
          actionUrl: "/guidance/who-can-get-an-allowance",
        },
        LOOKED_AFTER_STATUS_UNKNOWN: {
          severity: "info",
          title: "Worth checking: was the child in care just before the order?",
          body: () =>
            "You told me you were not sure. It matters, because it changes how strong your position is. If the child was in the council's care immediately before the order, you are squarely within the circumstances where financial support is payable. If not, those circumstances are narrower, though you can still ask.\n\n" +
            "Your social worker or the court paperwork will say.",
          citationId: "sg-regs-2005-reg6",
          actionUrl: "/guidance/who-can-get-an-allowance",
        },
        KINSHIP_ZONE_ELIGIBLE: {
          severity: "important",
          title: "Your council is in the Kinship Zones pilot",
          body: (c) =>
            `${c.councilName ?? "Your council"} is one of seven councils in the Kinship Zones pilot. In the pilot, eligible carers get an allowance equal to the full fostering National Minimum Allowance, and it is **not** means tested.\n\n` +
            "Ask your council whether you qualify, and ask for the answer in writing.",
          citationId: "kinship-zones-2026",
          actionUrl: "/guidance/kinship-zones",
        },
        KINSHIP_ZONE_PILOT_CAVEAT: {
          severity: "important",
          title: "The pilot is time-limited and has conditions",
          body: () =>
            "Kinship Zones runs from April 2026 to 2029 in seven councils only. It does not change the law anywhere else.\n\n" +
            "You cannot get the pilot allowance and regulation 6 financial support for the same child at the same time. The scheme may change when it is evaluated.",
          citationId: "kinship-zones-2026",
          actionUrl: "/guidance/kinship-zones",
        },
        KINSHIP_ZONE_EXCLUDED_REG6: {
          severity: "info",
          title: "You are in a pilot area but already on regulation 6 support",
          body: (c) =>
            "Your council is in the Kinship Zones pilot, but the pilot excludes carers already receiving regulation 6 financial support, so I have used the normal rules for your estimate.\n\n" +
            (c.kinshipZoneWeekly !== undefined
              ? `For comparison, the pilot rate for ${c.ageBand ? `the ${c.ageBand} age band` : "your child's age band"} would be ${money(c.kinshipZoneWeekly)} a week with no means test.\n\n`
              : "") +
            "That comparison is worth raising with your council if your current support is lower.",
          citationId: "kinship-zones-2026",
          actionUrl: "/guidance/kinship-zones",
        },
        KINSHIP_ZONE_COMPARISON: {
          severity: "info",
          title: "What the pilot rate would be",
          body: (c) =>
            `The Kinship Zones pilot rate for your child's age band is ${money(c.kinshipZoneWeekly)} a week, not means tested.`,
          citationId: "kinship-zones-2026",
          actionUrl: "/guidance/kinship-zones",
        },
        ENHANCEMENT_AVAILABLE: {
          severity: "important",
          title: "You can ask for more because of your child's needs",
          body: () =>
            "You told me your child has a disability or additional needs. The regulations let a council pay more than the core allowance to meet the consequences of a disability, or of abuse or neglect the child suffered.\n\n" +
            "There is **no national figure** for this and I have not added one to your estimate. It is decided council by council, on the child's needs. Ask for it, and give specifics: therapy, travel, respite, equipment, extra wear and tear.",
          citationId: "sg-regs-2005-reg6",
          actionUrl: "/guidance/enhancements-for-additional-needs",
        },
        MEANS_TEST_MODEL_OUTDATED: {
          severity: "important",
          title: "The means test model is not law, and it pre-dates Universal Credit",
          body: () =>
            "Most English councils use a standard Department for Education spreadsheet model to work out how much of your income to take into account. That model is **not statutory**. No law requires it, and it was written before Universal Credit existed.\n\n" +
            "Your council may use a different method, and it is entitled to. Treat the figure below as an illustration of how the common model works, not as the answer your council will reach.",
          citationId: "corambaaf-pn75",
          actionUrl: "/guidance/how-the-means-test-works",
        },
        TAPER_METHOD_ASSUMED: {
          severity: "important",
          title: "I had to assume how your council reduces the allowance",
          body: (c) =>
            `There is **no published national rule** for how much of your spare income a council takes off the allowance. Policies vary.\n\n` + // Without a guard this rendered: 'I have assumed the "undefined" method.'
            // The engine happens always to supply one today, so nothing was reaching a
            // carer, but a flag body must read as a sentence whatever it is handed.
            `I have assumed ${c.taperMethod === undefined ? "the most common approach, which is pound for pound" : c.taperMethod === "pound-for-pound" ? "pound-for-pound, which is the most common approach" : `the "${c.taperMethod}" method`}. Your council may use another.\n\nAsk it two things: which method it uses, **and where that comes from**. There being no national rule is not a gap in my research, it is how the scheme is built, so a council that cannot say where its own taper comes from is in a weaker position than one that can.`,
          citationId: "corambaaf-pn75",
          actionUrl: "/guidance/how-the-means-test-works",
        },
        APRIL_RATE_BOUNDARY: {
          severity: "info",
          title: "You are in the few days of April where the rules disagree",
          body: () =>
            "The government sets these rates for a **tax year running 6 April to 5 April**. Councils normally put their increase in from **1 April**.\n\n" +
            "Between 1 and 5 April the two do not line up. I have shown you the new rate, because that is what councils normally pay from 1 April. But if your council follows the tax year, it may still be paying last year's rate for a few more days.\n\n" +
            "It is worth a few pounds, not a few hundred. If you are checking a backdated claim, it is worth getting right.",
          citationId: "north-tyneside-decision-2025",
          actionUrl: "/guidance/rates",
        },
        WALES_BAND_ORDER_ANOMALY: {
          severity: "info",
          title: "In Wales, under-5s get more than 5 to 15 year olds",
          body: () =>
            "The Welsh rates pay **more for a child under 5 than for a child aged 5 to 15**. Everywhere else in the UK the rate rises with age, so this looks like a mistake.\n\n" +
            "It is not a mistake on this site. That is how the Welsh Government publishes them, and the same pattern appears in other years too.\n\n" +
            "The Welsh Government's own circular for an earlier year prints them that way, so the pattern is settled. This year's figures come from a table reproducing that circular, because the letter for this year has not been published anywhere I can find. I am telling you rather than quietly correcting it.",
          citationId: "wg-nma-2024-25",
          actionUrl: "/guidance/rates",
        },
        CAPITAL_RULE_MAY_APPLY: {
          severity: "info",
          title: "Your council may have a savings rule",
          body: (c) =>
            `You told me about savings of ${money(c.savingsCapital)}. Some councils count savings above a threshold, and a council may borrow the rule the benefits system uses: £6,000, then £1 a week for each £250 above it. There is no national rule for special guardianship, and I do not hold your council's.\n\n` +
            "I have not applied any savings rule to your estimate. Ask your council whether it has one.",
          citationId: "dwp-benefit-rates-2026-27",
          actionUrl: "/guidance/how-the-means-test-works",
        },
        ANNUAL_REVIEW_DUE: {
          severity: "info",
          title: "Your allowance should be reviewed every year",
          // The trigger is receipt of the annual statement, not twelve months passing.
          // A carer who has never been asked for one has a sharper question than "it
          // has been a year": the council has not set up the thing that produces the
          // review at all.
          body: () =>
            "Your council has to review your financial support when it receives your annual statement of circumstances. The review is triggered by that statement, not simply by a year going by.\n\n" +
            "So if your council has never asked you for an annual statement, that is the thing to raise. Ask whether it wants one, and if not, why your support has not been reviewed. Rates go up every April.",
          citationId: "sg-regs-2005-reg18",
          actionUrl: "/guidance/annual-reviews",
        },
        THREE_YEAR_RESPONSIBILITY: {
          severity: "info",
          title: "Which council is responsible",
          // Reg 5(2) carries an exception that matters most to exactly the carers most
          // likely to be reading this: where support was already being provided and the
          // decision to provide it was taken before the order, responsibility does not
          // end at three years at all.
          body: () =>
            "For three years after the order, the council that looked after the child stays responsible for assessing support needs, even if you have moved away. After three years, responsibility usually passes to the council where you live.\n\n" +
            "**There is an important exception.** If your council was already paying you financial support, and it decided to pay it **before** the order was made, then it stays responsible for that support after the three years are up. It does not pass to your new council. That will often be the case if you were the child's foster carer.\n\n" +
            "If you have moved recently, it is worth being clear which council you should be asking.",
          citationId: "sg-regs-2005-reg5",
          actionUrl: "/guidance/which-council-is-responsible",
        },
        AGE_17_TRANSITION: {
          severity: "important",
          title: "Plan now for what happens at 18",
          body: () =>
            "Your child is 17. Special guardianship financial support normally stops when they turn 18, unless they stay in full-time education or training, in which case it can continue.\n\n" +
            "Ask your council now, in writing, what will happen on their eighteenth birthday and what you need to do to keep support going.",
          citationId: "sg-regs-2005-reg9",
          actionUrl: "/guidance/turning-18",
        },
        BENEFIT_CAP_RISK: {
          severity: "info",
          title: "Check whether the benefit cap affects you",
          body: () =>
            "Households getting a lot of benefit income can hit the benefit cap. Special guardianship allowance itself is not counted as your income for your own means-tested benefits, and Guardian's Allowance is exempt from the cap.\n\n" +
            "If your benefits have been reduced without explanation, this is worth checking with an adviser.",
          citationId: "dwp-benefit-rates-2026-27",
          actionUrl: "/guidance/benefits-and-your-allowance",
        },
        TWO_CHILD_LIMIT_ABOLISHED: {
          severity: "info",
          title: "The two-child limit no longer applies",
          body: () =>
            "The two-child limit in Universal Credit was removed from April 2026. If you are caring for three or more children and your Universal Credit has not changed, check your award.",
          citationId: "uc-two-child-limit-act-2026",
          actionUrl: "/guidance/benefits-and-your-allowance",
        },
        GUARDIANS_ALLOWANCE_CHECK: {
          severity: "info",
          title: "Check whether you can claim Guardian's Allowance",
          body: () =>
            "Guardian's Allowance is a weekly payment for someone bringing up a child whose parents have died, or where one has died and the other cannot be traced, is serving a long prison sentence, or cannot be found.\n\n" +
            "It is tax free, it is ignored for means-tested benefits, and it is exempt from the benefit cap. It is a separate claim, and it is not paid automatically alongside Child Benefit.",
          citationId: "cb-ga-uprating-order-2026",
          actionUrl: "/guidance/benefits-and-your-allowance",
        },
        RATES_STALE: {
          severity: "critical",
          title: "These rates may be out of date",
          body: (c) =>
            `The rate table I am using ran to ${c.effectiveTo ?? "a date that has now passed"}. New rates are normally announced for April and I have not yet published them.\n\n` +
            "Treat the figures below as last year's. Check the current national minimum allowance before you use them in a letter.",
          actionUrl: "/guidance/rates",
        },
        COUNCIL_POLICY_UNKNOWN: {
          severity: "info",
          title: "I do not hold your council's published policy",
          body: (c) =>
            `I do not yet hold a sourced, dated copy of ${c.councilName ?? "your council"}'s special guardianship financial support policy, so your estimate uses the national minimum figures for your area.\n\n` + // Was "Councils must have a published policy", unsourced, which is the one
            // thing this site is not allowed to do. What is on record is the October
            // 2024 duty to publish a kinship local offer.
            "Every council in England has to publish a kinship local offer setting out the support it provides, and most publish a financial support policy as well. Asking for it in writing is a good first step, and it is the document any later challenge rests on.",
          citationId: "kinship-care-guidance-2024",
          actionUrl: "/guidance/asking-for-the-policy",
        },
        SCOTLAND_SRA_IS_A_FLOOR: {
          severity: "important",
          title: "The Scottish Recommended Allowance is a minimum, not a maximum",
          body: () =>
            "The Scottish Recommended Allowance is the floor. Your council can pay more, and some do.\n\n" +
            "If you are being offered less than the recommended allowance, ask why in writing.",
          citationId: "sra-2026-27",
          actionUrl: "/guidance/scotland-kinship-care",
        },
        SCOTLAND_FOSTER_KINSHIP_PARITY: {
          severity: "important",
          title: "Kinship carers and foster carers get the same recommended rate",
          body: () =>
            "Scotland sets one recommended allowance for foster carers and kinship carers alike. If your council pays its foster carers more than it pays you for a child of the same age, ask it to explain the difference.",
          citationId: "sra-2026-27",
          actionUrl: "/guidance/scotland-kinship-care",
        },
        LGSCO_FINDING_FORMER_POLICY: {
          // Same facts as LGSCO_FINDING_AGAINST_LA, different present tense. A council
          // that changed the policy it was criticised for is not a council currently
          // at fault, so this is not a "check these first" item and does not carry
          // that heading's alarm. It still matters: the remedy in these cases is
          // usually backdating, which can reach an order made years ago.
          severity: "important",
          title: "The Ombudsman made a finding about a policy this council has since changed",
          body: (c) =>
            `${c.policySummary ?? "The Local Government and Social Care Ombudsman published a decision about how this council used to calculate special guardianship allowances."}\n\n` +
            (c.decisionDate ? `The decision was made on ${c.decisionDate}.` : "") +
            (c.policySourceUrl ? ` You can read it here: ${c.policySourceUrl}` : "") +
            (c.decisionDate || c.policySourceUrl ? "\n\n" : "") +
            (c.policyChangedOn
              ? `The council changed that policy from ${c.policyChangedOn}.\n\n`
              : "") +
            (c.supersededSummary ? `${c.supersededSummary}\n\n` : "") +
            "This is history rather than a live problem, but it is worth knowing. Where a council has been found at fault, the Ombudsman has often asked it to go back and recalculate old awards, so it can still be relevant to an order made some years ago.",
          actionUrl: "/guidance/complaining-to-the-ombudsman",
        },
        LA_LIVING_COSTS_VARIATION: {
          severity: "important",
          title: "Your council allows a different amount for basic living costs",
          body: (c) =>
            `The standardised model most councils use allows basic living costs at ${c.modelLivingCostsPercent ?? 125}% of the Income Support rate for a household your size. ` +
            `${c.councilName ?? "Your council"} publishes ${c.livingCostsPercent ?? 100}%, and that is the figure used above.\n\n` +
            "Allowing less for living costs leaves more income counted as spare, which means a larger contribution expected from you and a smaller allowance. It is a local choice, not a national rule.\n\n" +
            "If the figure matters to you, ask the council to confirm the percentage it applied and why.",
          citationId: "corambaaf-pn75",
          actionUrl: "/guidance/how-the-means-test-works",
        },
        LA_POLICY_UNDER_REVIEW: {
          severity: "info",
          title: "This council is rewriting its policy",
          body: (c) =>
            (c.policyUnderReviewNote ??
              `${c.councilName ?? "This council"} says its special guardianship financial support policy is under review, so what is shown here is the last version it published.`) +
            "\n\nAsk the council for its current position in writing before you rely on any figure here.",
          actionUrl: "/guidance/asking-for-the-policy",
        },
        SCOTLAND_NO_WORSE_OFF: {
          severity: "info",
          title: "No family should be worse off",
          body: () =>
            "Where you already have an arrangement that pays more than the recommended allowance, the higher amount applies. Moving to the recommended rate should not reduce what you get.",
          citationId: "sra-2026-27",
          actionUrl: "/guidance/scotland-kinship-care",
        },
      }; //# sourceMappingURL=flagCatalogue.js.map
      // ../../packages/engine/dist/flags.js

      /**
       * Assembling and ordering the warnings, spec §17.
       *
       * The warnings themselves are in flagCatalogue.ts. This file decides which one
       * is shown first, and turns a code plus some context into a Flag the result
       * page can render.
       */

      /**
       * Ordering within a severity follows this array, which is roughly descending by
       * financial impact (spec §17).
       */ const FLAG_ORDER = [
        "UNLAWFUL_CB_DEDUCTION_RISK",
        "FIXED_PERCENTAGE_POLICY",
        "BELOW_NMA",
        "LGSCO_FINDING_AGAINST_LA",
        "LGSCO_FINDING_FORMER_POLICY",
        "RATES_STALE",
        "REG7_FLOOR_APPLIED",
        "REG7_EXPIRING",
        "REG7_EXTENSION_AVAILABLE",
        "REG7_MISAPPLICATION_WARNING",
        "NOT_LOOKED_AFTER_BEFORE_ORDER",
        "KINSHIP_ZONE_ELIGIBLE",
        "KINSHIP_ZONE_PILOT_CAVEAT",
        "ENHANCEMENT_AVAILABLE",
        "MEANS_TEST_MODEL_OUTDATED",
        "LA_LIVING_COSTS_VARIATION",
        "TAPER_METHOD_ASSUMED",
        "AGE_17_TRANSITION",
        "SCOTLAND_SRA_IS_A_FLOOR",
        "SCOTLAND_FOSTER_KINSHIP_PARITY",
        "SCOTLAND_NO_WORSE_OFF",
        "COUNCIL_POLICY_UNKNOWN",
        "LA_POLICY_UNDER_REVIEW",
        "LOOKED_AFTER_STATUS_UNKNOWN",
        "KINSHIP_ZONE_EXCLUDED_REG6",
        "KINSHIP_ZONE_COMPARISON",
        "CAPITAL_RULE_MAY_APPLY",
        "ANNUAL_REVIEW_DUE",
        "THREE_YEAR_RESPONSIBILITY",
        "BENEFIT_CAP_RISK",
        "TWO_CHILD_LIMIT_ABOLISHED",
        // Both are notes about how a rate table is printed rather than about the
        // carer's own position, so they sit at the quiet end. They were missing from
        // this list entirely, and indexOf returns -1 for a code that is not here,
        // which sorted them AHEAD of everything else in their severity band: a
        // Welsh carer met a remark about band ordering before anything about their
        // rights. checkFlagOrderIsComplete keeps the two lists in step.
        "APRIL_RATE_BOUNDARY",
        "WALES_BAND_ORDER_ANOMALY",
        "GUARDIANS_ALLOWANCE_CHECK",
      ];
      const SEVERITY_ORDER = {
        critical: 0,
        important: 1,
        info: 2,
      };
      function makeFlag(code, ctx = {}) {
        const spec = FLAG_CATALOGUE[code];
        const flag = {
          code,
          severity: spec.severity,
          title: spec.title,
          body: spec.body(ctx),
        };
        if (spec.citationId) flag.citation = cite(spec.citationId);
        if (spec.actionUrl) flag.actionUrl = spec.actionUrl;
        return flag;
      }
      /** Sort critical, then important, then info, and within each by the order above. */ function sortFlags(
        flags,
      ) {
        // A code missing from FLAG_ORDER sorts LAST rather than first. indexOf gives
        // -1, which put an unlisted warning at the top of its severity band, and the
        // failure was silent: nothing looked wrong, the ordering was just quietly
        // decided by an oversight. The test keeps the lists in step; this makes the
        // consequence harmless if one ever slips through again.
        const rank = (code) => {
          const i = FLAG_ORDER.indexOf(code);
          return i === -1 ? FLAG_ORDER.length : i;
        };
        return [...flags].sort((a, b) => {
          const bySeverity = SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity];
          return bySeverity !== 0 ? bySeverity : rank(a.code) - rank(b.code);
        });
      }
      /**
       * Drop duplicates by what the warning SAYS, not just by its code.
       *
       * Keying on the code alone lost information. BELOW_NMA and
       * KINSHIP_ZONE_EXCLUDED_REG6 are raised once per child and carry that child's
       * age band and rates, so a carer with a 3-year-old and a 16-year-old had one of
       * the two messages silently thrown away, and the survivor named an age band
       * without saying which child it belonged to. On a critical warning about being
       * underpaid, that is a shortfall the reader never learns about.
       *
       * Two flags with the same code and the same text are the same message and
       * collapse, which is what handles the warnings raised per child that carry no
       * per-child detail. Two with different text are different messages and both
       * stay. sortFlags is a stable sort and ranks by code, so the survivors of one
       * code stay together, in the order the children were entered.
       */ function dedupeFlags(flags) {
        const seen = new Set();
        return flags.filter((f) => {
          // A NUL separator, because a flag body contains spaces and newlines and
          // must not be able to collide with the code in front of it.
          const key = `${f.code}\u0000${f.body}`;
          return seen.has(key) ? false : (seen.add(key), true);
        });
      } //# sourceMappingURL=flags.js.map
      // ../../packages/engine/dist/meansTest.js

      /**
       * Means test module, spec §14.
       *
       * This models the DfE Standardised Means Test Model, which most English
       * councils use. It is NOT statutory and it pre-dates Universal Credit [R6], so
       * every result that uses it carries MEANS_TEST_MODEL_OUTDATED.
       *
       * The order of the steps is the part that gets implemented wrong. The 20%
       * disregard comes off INCOME, before any expenditure. Applying it to what is
       * left after outgoings doubles the answer, and it is the single most common
       * error in this calculation. Test T17 exists only to catch it.
       */

      // ─── What counts ───────────────────────────────────────────────────────────
      /**
       * Income that counts. Encoded as data rather than prose because social workers
       * and carers both get this wrong, and the breakdown panel renders it back.
       */ const COUNTABLE_INCOME = /* unused pure expression or super */ null && [
        "net-earnings",
        "self-employed-drawings",
        "employer-sick-pay",
        "esa-incapacity",
        "smp-spp-sap-maternity-allowance",
        "bereavement-benefit",
        "working-tax-credit",
        "pensions",
        "income-support",
        "jsa",
        "child-tax-credit",
        "child-benefit-other-children",
        "savings-interest",
        "lodger-income",
        "property-income",
        "maintenance-received",
        "other-adoption-sg-allowances",
        "assessed-child-legal-entitlement",
      ];
      const DISREGARDED_INCOME = /* unused pure expression or super */ null && [
        "dla-pip-child",
        "criminal-injuries-compensation",
        "fostering-income-other-children",
        "guardians-allowance",
        "sg-allowance-itself",
        "child-benefit-assessed-child",
        "wtc-childcare-element",
      ];
      // ─── The model's own numbers ───────────────────────────────────────────────
      const DISREGARD_RATE = 0.2;
      /**
       * The DfE standardised model allows basic living costs at 125% of the Income
       * Support applicable amount. Councils may differ, and at least one does:
       * Devon's published procedures set it at 100%. So this is the default, not the
       * law.
       */ const CORE_LIVING_COSTS_MULTIPLIER = 1.25;
      const DEFAULT_TAPER = {
        method: "pound-for-pound",
      };
      /** Common pattern (Wolverhampton model). Default OFF, see spec §14.4. */ const DEFAULT_CAPITAL =
        {
          thresholdPence: pence(600000),
          tariffPerBlockPence: pence(100),
          blockSizePence: pence(25000),
          period: "weekly",
          enabled: false,
        };
      // ─── Allowable expenditure ─────────────────────────────────────────────────
      /**
       * The Income Support applicable amount for this household, WEEKLY.
       *
       * The unit is in the name because getting it wrong is expensive and silent.
       * DWP publishes these figures weekly, the means test works monthly, and the
       * applicable amount feeds the single largest line of allowable expenditure.
       * Treating a weekly figure as monthly shrinks that line by a factor of 4.33,
       * which inflates disposable income, which inflates the contribution the council
       * expects, which cuts the carer's allowance. runMeansTest converts.
       *
       * [HARD] Throws while the DWP figures are PENDING_SOURCE. Do not estimate: a
       * wrong applicable amount silently shifts every means-tested result.
       */ function incomeSupportApplicableAmountWeekly(f, benefits) {
        const amounts = benefits.incomeSupportApplicableAmounts;
        if (amounts.status === "PENDING_SOURCE") {
          throw new errors_DataError(
            `Income Support applicable amounts for ${benefits.financialYear} are not yet sourced. ` +
              "The means test cannot run without them and they must not be estimated (spec §8.4, §14.5).",
          );
        }
        const schema = amounts.schema;
        const need = (value, name) => {
          if (value === null || value === undefined) {
            throw new errors_DataError(`Income Support applicable amount "${name}" is missing`);
          }
          return value;
        };
        const couple = f.adultsInHousehold >= 2;
        let total = couple
          ? need(schema.couplePence, "couplePence")
          : f.claimantUnder25 === true
            ? need(schema.singleUnder25Pence, "singleUnder25Pence")
            : need(schema.single25PlusPence, "single25PlusPence");
        total +=
          need(schema.dependentChildPence, "dependentChildPence") * f.dependentChildrenInHousehold;
        if (f.dependentChildrenInHousehold > 0) {
          total += need(schema.familyPremiumPence, "familyPremiumPence");
        }
        if (f.householdHasDisabilityPremium === true) {
          total += disabilityPremium(schema, couple, need);
        }
        if (f.householdHasCarerPremium === true) {
          total += need(schema.carerPremiumPence, "carerPremiumPence");
        }
        return pence(total);
      }
      /**
       * DWP publishes a separate, higher couple rate. Charging a couple the single
       * rate understates the applicable amount, which understates allowable
       * expenditure, which overstates the contribution the council expects: the
       * direction of error that costs the carer money. Falls back to the single rate
       * for a table sourced before the couple rate was.
       */ function disabilityPremium(schema, couple, need) {
        const coupleRate = schema.disabilityPremiumCouplePence;
        if (couple && coupleRate !== null && coupleRate !== undefined) return coupleRate;
        return need(schema.disabilityPremiumPence, "disabilityPremiumPence");
      }
      // ─── Capital and taper ─────────────────────────────────────────────────────
      /** Tariff income from capital. Only runs where an LA override enables it. */ function tariffIncome(
        savings,
        capital,
      ) {
        if (!capital.enabled) return pence(0);
        if (savings <= capital.thresholdPence) return pence(0);
        const above = savings - capital.thresholdPence;
        const blocks = Math.ceil(above / capital.blockSizePence);
        const perPeriod = pence(blocks * capital.tariffPerBlockPence);
        // The config states the tariff weekly or monthly; the means test is monthly.
        return capital.period === "weekly" ? weeklyToMonthly(perPeriod) : perPeriod;
      }
      /**
       * The taper, genuinely underdetermined (spec §14.3).
       *
       * There is NO published national taper. Policies vary between pound-for-pound,
       * which is the most common, a percentage of disposable income, and a threshold
       * below which nothing is deducted. Configurable, defaulting to
       * pound-for-pound, and every result that uses it carries TAPER_METHOD_ASSUMED.
       */ function applyTaper(disposable, taper) {
        switch (taper.method) {
          case "pound-for-pound":
            return disposable;
          case "percentage":
            // Throws rather than defaulting. `?? 1` meant a percentage taper with no
            // percentage quietly became 100 per cent, which is pound-for-pound: the
            // harshest option there is, produced by a configuration mistake, with
            // nothing on the page to say it had happened.
            if (taper.percentage === undefined) {
              throw new errors_DataError(
                "A percentage taper was configured with no percentage. Set one, or use pound-for-pound.",
              );
            }
            return mul(disposable, taper.percentage);
          case "threshold":
            if (taper.thresholdMonthly === undefined) {
              throw new errors_DataError(
                "A threshold taper was configured with no threshold. Set one, or use pound-for-pound.",
              );
            }
            return clampMin0(sub(disposable, taper.thresholdMonthly));
        }
      }
      // ─── The calculation ───────────────────────────────────────────────────────
      /**
       * Records each step as it goes, so the result page can show the arithmetic and
       * a carer can check it or hand it to their council.
       */ class Breakdown {
        add(label, operation, valuePence, runningTotalPence, note) {
          const step = {
            label,
            operation,
            valuePence,
            runningTotalPence,
          };
          if (note) step.note = note;
          this.steps.push(step);
        }
        constructor() {
          this.steps = [];
        }
      }
      function runMeansTest(
        f,
        benefits,
        taper,
        capital,
        livingCostsMultiplier = CORE_LIVING_COSTS_MULTIPLIER,
      ) {
        const breakdown = new Breakdown();
        const income = countableIncome(f, breakdown);
        const afterDisregard = applyDisregard(income, breakdown);
        const coreLiving = coreLivingCosts(f, benefits, livingCostsMultiplier);
        const expenditure = allowableExpenditure(
          f,
          coreLiving,
          livingCostsMultiplier,
          afterDisregard,
          breakdown,
        );
        const disposable = clampMin0(sub(afterDisregard, expenditure));
        breakdown.add("Income left over", "result", disposable, disposable);
        // tariffIncome already returns zero when the rule is off, so the ternary that
        // used to guard this call did nothing.
        const capitalTariff = tariffIncome(f.savingsCapital, capital);
        if (capital.enabled) {
          breakdown.add(
            "Assumed income from savings",
            "add",
            capitalTariff,
            add(disposable, capitalTariff),
          );
        }
        const contributionMonthly = applyTaper(add(disposable, capitalTariff), taper);
        breakdown.add(
          "What the council expects you to put in (monthly)",
          "result",
          contributionMonthly,
          contributionMonthly,
          `Using the "${taper.method}" method. There is no national rule for this step.`,
        );
        const contributionWeekly = monthlyToWeekly(contributionMonthly);
        breakdown.add(
          "What the council expects you to put in (weekly)",
          "result",
          contributionWeekly,
          contributionWeekly,
          "Monthly × 12 ÷ 52.",
        );
        return {
          totalCountableIncomeMonthly: income,
          disregardRate: DISREGARD_RATE,
          incomeAfterDisregardMonthly: afterDisregard,
          coreLivingCostsMonthly: coreLiving,
          coreLivingCostsMultiplier: livingCostsMultiplier,
          totalExpenditureMonthly: expenditure,
          disposableIncomeMonthly: disposable,
          capitalTariffMonthly: capitalTariff,
          taperMethod: taper.method,
          assessedContributionMonthly: contributionMonthly,
          assessedContributionWeekly: contributionWeekly,
          steps: breakdown.steps,
        };
      }
      /** Step 1: everything that counts as income, monthly. */ function countableIncome(
        f,
        breakdown,
      ) {
        let running = f.netEarnings;
        breakdown.add("Net earnings (monthly)", "add", f.netEarnings, running);
        running = add(running, f.otherIncome);
        breakdown.add(
          "Other income: pensions, maintenance received, lodgers",
          "add",
          f.otherIncome,
          running,
        );
        running = add(running, f.countableBenefits);
        breakdown.add(
          "Benefits that count",
          "add",
          f.countableBenefits,
          running,
          "Disability benefits for the child, Guardian's Allowance and the allowance itself are all ignored.",
        );
        running = add(running, f.childBenefitOtherChildren);
        breakdown.add(
          "Child Benefit for your other children",
          "add",
          f.childBenefitOtherChildren,
          running,
          "Child Benefit for the child this assessment is about is NOT counted here. It is only ever a separate, opt-in deduction at the end.",
        );
        return running;
      }
      /**
       * Step 2: the 20% disregard, applied to INCOME, BEFORE expenditure.
       *
       * [HARD] Correct:  (3000 × 0.8) − 2000 = 400
       *        Wrong:    (3000 − 2000) × 0.8 = 800
       */ function applyDisregard(income, breakdown) {
        const afterDisregard = mul(income, 1 - DISREGARD_RATE);
        breakdown.add(
          "20% of your income is ignored",
          "multiply",
          sub(income, afterDisregard),
          afterDisregard,
          "The disregard comes off your income first, before any of your outgoings are taken into account.",
        );
        return afterDisregard;
      }
      function coreLivingCosts(f, benefits, livingCostsMultiplier) {
        // DWP publishes the applicable amounts weekly; everything else here is
        // monthly. Convert before applying the uplift.
        return mul(
          weeklyToMonthly(incomeSupportApplicableAmountWeekly(f, benefits)),
          livingCostsMultiplier,
        );
      }
      /** Step 3: allowable expenditure, ending with basic living costs. */ function allowableExpenditure(
        f,
        coreLiving,
        livingCostsMultiplier,
        afterDisregard,
        breakdown,
      ) {
        let total = pence(0);
        const spend = (label, amount, note) => {
          total = add(total, amount);
          breakdown.add(label, "subtract", amount, sub(afterDisregard, total), note);
        };
        spend("Rent or mortgage", f.housingCosts);
        spend("Council tax", f.councilTax);
        spend("Essential loan repayments", f.essentialLoanRepayments);
        spend("Maintenance you pay out", f.maintenancePaid);
        spend("Pension contributions", f.pensionContributions);
        spend("Childcare costs", f.childcareCosts);
        // The note states the council's own percentage. Saying "plus 25%" to a Devon
        // carer, whose council allows 100%, would describe a calculation the page is
        // not showing them.
        const upliftPercent = Math.round((livingCostsMultiplier - 1) * 100);
        spend(
          "Basic living costs",
          coreLiving,
          upliftPercent === 0
            ? "Income Support rates for a household your size."
            : `Income Support rates for a household your size, plus ${upliftPercent}%.`,
        );
        return total;
      }
      /** True when the means test can run at all for this benefit table. */ function meansTestAvailable(
        benefits,
      ) {
        return benefits.incomeSupportApplicableAmounts.status !== "PENDING_SOURCE";
      } //# sourceMappingURL=meansTest.js.map
      // ../../packages/engine/dist/councilPolicy.js

      /**
       * What we hold about an individual council, and what it is safe to say.
       *
       * Two rules run through this file.
       *
       * A council is only ever described from a recorded field, never from the
       * wording of a policy summary. A council paying the full rate, or one that
       * abolished a percentage model years ago, must not be accused of running one.
       *
       * A claim about a council is dated wherever we can date it, so it reads as an
       * observation of a policy at a moment rather than a standing accusation.
       */

      function taperFor(la, input) {
        return input.taperOverride ?? la?.taper ?? DEFAULT_TAPER;
      }
      function capitalFor(la) {
        return la?.capital ?? DEFAULT_CAPITAL;
      }
      /**
       * Basic living costs as a multiple of the Income Support applicable amount.
       *
       * The DfE model says 125%. A council may publish something else, and Devon
       * does, so this reads the council's own figure where we hold one. An absent
       * percentage means the council follows the model; it never means we failed to
       * look, because an entry only reaches the engine when publishable.
       */ function livingCostsMultiplierFor(la) {
        const pct = la?.livingCostsMultiplierPercent;
        if (pct === undefined) return CORE_LIVING_COSTS_MULTIPLIER;
        if (!Number.isFinite(pct) || pct <= 0) {
          throw new errors_DataError(
            `la-overrides "${la?.slug}" has livingCostsMultiplierPercent ${String(pct)}, which is not a ` +
              "usable percentage. A wrong figure here silently changes every means-tested result.",
          );
        }
        return pct / 100;
      }
      function councilNameFor(slug, deps) {
        if (!slug) return undefined;
        return publishableLaOverrideIn(deps.laOverrides, slug)?.name ?? LA_NAMES[slug];
      }
      function isKinshipZoneEligible(input, deps = defaultDeps()) {
        const slug = input.carer.localAuthoritySlug;
        if (!slug || !deps.kinshipZones.localAuthorities.includes(slug)) return false;
        if (input.carer.childWouldOtherwiseBeInCare !== true) return false;
        if (input.carer.alreadyReceivingReg6Support === true) return false;
        return true;
      }
      /** True when the carer's council runs the Kinship Zones pilot, whatever their own eligibility. */ function isInKinshipZone(
        input,
        deps,
      ) {
        const slug = input.carer.localAuthoritySlug;
        return slug !== undefined && deps.kinshipZones.localAuthorities.includes(slug);
      }
      /** Everything we can say about the carer's own council, from what we have recorded. */ function councilPolicyFlags(
        la,
      ) {
        if (!la) return [];
        const flags = [];
        // Only an upheld finding is served. A complaint that was not upheld, or one
        // whose outcome we have not recorded, is not something to put in front of a
        // carer as a finding against their council.
        const finding = la.lawfulnessFlag;
        if (finding?.code === "LGSCO_UPHELD") {
          flags.push(
            makeFlag(
              finding.concernsFormerPolicy
                ? "LGSCO_FINDING_FORMER_POLICY"
                : "LGSCO_FINDING_AGAINST_LA",
              {
                councilName: la.name,
                policySummary: finding.summary,
                policySourceUrl: finding.sourceUrl,
                // Where the criticised policy has been changed, or a later complaint
                // about the current practice was not upheld, the flag says so with the
                // finding rather than after it.
                ...(finding.decisionDate
                  ? {
                      decisionDate: finding.decisionDate,
                    }
                  : {}),
                ...(finding.policyChangedOn
                  ? {
                      policyChangedOn: finding.policyChangedOn,
                    }
                  : {}),
                ...(finding.supersededBy
                  ? {
                      supersededSummary: finding.supersededBy.summary,
                    }
                  : {}),
              },
            ),
          );
        }
        if (la.policyUnderReview) {
          flags.push(
            makeFlag("LA_POLICY_UNDER_REVIEW", {
              councilName: la.name,
              ...(la.policyUnderReviewNote
                ? {
                    policyUnderReviewNote: la.policyUnderReviewNote,
                  }
                : {}),
            }),
          );
        }
        const fraction = la.fixedPercentageOfFosteringRate;
        if (typeof fraction === "number" && fraction < 1) {
          flags.push(
            makeFlag("FIXED_PERCENTAGE_POLICY", {
              councilName: la.name,
              ...(la.policySourceDate
                ? {
                    policyCheckedOn: la.policySourceDate,
                  }
                : {}),
            }),
          );
        }
        return flags;
      } //# sourceMappingURL=councilPolicy.js.map
      // ../../packages/engine/dist/dates.js

      /**
       * Dates and financial years, spec §11 [HARD].
       *
       * Two uprating calendars collide, and this is the most likely source of a
       * silent wrong answer:
       *
       *   fostering NMA and SG allowance rates    change on 1 April, the financial year
       *   Child Benefit, Guardian's Allowance,    change in the first full week of
       *   Carer's Allowance, UC, Income Support   April, around 6 April, the benefit year
       *
       * So between 1 and 6 April, NEW allowance rates coexist with OLD benefit rates.
       * Rate tables and benefit tables are therefore two independent lookups with
       * independent effective dates. Never assume one file's financial year implies
       * the other's.
       *
       * Everything here is UTC. A user in BST computing "today" at 00:30 on 1 April
       * must not get the previous financial year.
       */
      const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
      const MS_PER_DAY = 86400000;
      const dates_MONTHS_PER_YEAR = 12;
      /** The financial year starts on 1 April, which is month 3 counting from zero. */ const APRIL = 3;
      // ─── Building and reading dates ────────────────────────────────────────────
      /** Parse a date at UTC midnight. Every date in this file goes through here. */ const utc = (
        date,
      ) => new Date(`${date}T00:00:00Z`);
      const toIso = (d) => d.toISOString().slice(0, 10);
      function isoDate(s) {
        if (!ISO_DATE.test(s)) throw new DataError(`Not an ISO date (YYYY-MM-DD): "${s}"`);
        const d = new Date(`${s}T00:00:00Z`);
        // Round-tripping catches 2026-02-30, which Date happily rolls into March.
        if (Number.isNaN(d.getTime()) || toIso(d) !== s) {
          throw new DataError(`Not a real calendar date: "${s}"`);
        }
        return s;
      }
      /** Today in UTC, as YYYY-MM-DD. */ function todayUtc(now = new Date()) {
        return toIso(now);
      }
      /** ISO dates sort lexicographically, so plain string comparison is correct here. */ const onOrAfter =
        (a, b) => a >= b;
      const onOrBefore = (a, b) => a <= b;
      // ─── Choosing a table ──────────────────────────────────────────────────────
      /**
       * The rate table covering `asAt`.
       *
       * Throws rather than falling back: an out-of-range date must never silently
       * borrow another year's figures.
       */ function selectRateTable(tables, asAt) {
        const match = tables.find((t) => asAt >= t.effectiveFrom && asAt <= t.effectiveTo);
        if (!match) throw new errors_DataError(`No rate table effective on ${asAt}`);
        if (match.status === "PENDING_SOURCE") {
          throw new errors_DataError(`Rate table for ${match.financialYear} is not yet sourced`);
        }
        return match;
      }
      /**
       * The benefit table for `asAt`. INDEPENDENT of the rate table (§11).
       *
       * Benefit tables have no end date, so the newest one that has come into force
       * wins rather than the one whose range contains the date.
       */ function selectBenefitTable(tables, asAt) {
        const inForce = tables
          .filter((t) => asAt >= t.effectiveFrom)
          .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom));
        if (inForce.length === 0)
          throw new errors_DataError(`No benefit table effective on ${asAt}`);
        return inForce[0];
      }
      // ─── Arithmetic ────────────────────────────────────────────────────────────
      /** Age at a given date. Not age today: this is what makes backdating correct. */ function ageAt(
        dob,
        at,
      ) {
        const born = utc(dob);
        const on = utc(at);
        let age = on.getUTCFullYear() - born.getUTCFullYear();
        const months = on.getUTCMonth() - born.getUTCMonth();
        if (months < 0 || (months === 0 && on.getUTCDate() < born.getUTCDate())) age--;
        return age;
      }
      /** Add whole months in UTC, clamping to the end of a shorter target month. */ function addMonths(
        date,
        months,
      ) {
        const d = utc(date);
        const day = d.getUTCDate();
        // Move to the 1st first, so adding a month to the 31st cannot overflow into
        // the month after the one intended.
        d.setUTCDate(1);
        d.setUTCMonth(d.getUTCMonth() + months);
        const lastDay = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
        d.setUTCDate(Math.min(day, lastDay));
        return toIso(d);
      }
      function addDays(date, days) {
        const d = utc(date);
        d.setUTCDate(d.getUTCDate() + days);
        return toIso(d);
      }
      /** Whole months between two dates, floored. */ function monthsBetween(from, to) {
        const a = utc(from);
        const b = utc(to);
        const months =
          (b.getUTCFullYear() - a.getUTCFullYear()) * dates_MONTHS_PER_YEAR +
          (b.getUTCMonth() - a.getUTCMonth());
        return b.getUTCDate() < a.getUTCDate() ? months - 1 : months;
      }
      /** Whole days between two dates. */ function daysBetween(from, to) {
        return Math.round((utc(to).getTime() - utc(from).getTime()) / MS_PER_DAY);
      }
      // ─── Financial years ───────────────────────────────────────────────────────
      /** The financial year label ("2026-27") containing a date. The year starts 1 April. */ function financialYearOf(
        date,
      ) {
        const d = utc(date);
        const year = d.getUTCFullYear();
        const startYear = d.getUTCMonth() >= APRIL ? year : year - 1;
        return `${startYear}-${String((startYear + 1) % 100).padStart(2, "0")}`;
      }
      /** Every 1 April strictly after `from` and on or before `to`. */ function financialYearBoundaries(
        from,
        to,
      ) {
        const out = [];
        for (let year = utc(from).getUTCFullYear(); ; year++) {
          const boundary = `${year}-04-01`;
          if (boundary > to) break;
          if (boundary > from) out.push(boundary);
          /* c8 ignore next */ if (year > 3000) break;
        }
        return out;
      }
      // ─── Age bands ─────────────────────────────────────────────────────────────
      /**
       * Dates within (from, to] on which the child moves into a new age band.
       *
       * A child crossing an age band mid-year changes the rate, so backdating has to
       * cut a segment at each one or it pays the whole period at one rate.
       */ function ageBandChangeDates(dob, from, to, bands) {
        const ages = [...new Set(bands.map((b) => b.minAge))].sort((a, b) => a - b);
        return ages
          .filter((age) => age !== 0)
          .map((age) => nthBirthday(dob, age))
          .filter((birthday) => birthday > from && birthday <= to)
          .sort();
      }
      /** The date the child turns `age`. 29 February births roll to 1 March in common years. */ function nthBirthday(
        dob,
        age,
      ) {
        const born = utc(dob);
        const year = born.getUTCFullYear() + age;
        const month = born.getUTCMonth();
        const day = born.getUTCDate();
        const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
        return day > lastDay
          ? toIso(new Date(Date.UTC(year, month + 1, 1)))
          : toIso(new Date(Date.UTC(year, month, day)));
      } //# sourceMappingURL=dates.js.map
      // ../../packages/engine/dist/resolve.js

      /**
       * Working out where a carer stands, from whichever answer they gave.
       *
       * Two questions here have two possible answers each: a child's age can come
       * from a date of birth or from a stated age, and the time since the order can
       * come from a date or from a stated number of months. Both readings have to be
       * resolved the same way everywhere.
       *
       * This lives apart from the engine so guardrails.ts can resolve a carer's
       * position on exactly the same basis the engine used. When the two disagree,
       * for example the engine preferring orderDate while a guardrail reads
       * monthsSinceOrderMade, a correct result throws a spurious violation, which the
       * UI turns into "we can't estimate this". Same helper, both sides.
       */
      /** Age of a child at a date: from date of birth where given, else the stated age. */ function ageOf(
        child,
        asAt,
      ) {
        return child.dateOfBirth ? ageAt(child.dateOfBirth, asAt) : child.ageYears;
      }
      /**
       * Months since the order, or undefined when the carer has not told us.
       *
       * The date wins where it was given. Undefined is not zero: everything that
       * depends on how long ago the order was made has to decide for itself what to
       * do when it does not know, rather than being handed a number that says today.
       */ function monthsSinceOrder(carer, asAt) {
        return carer.orderDate
          ? Math.max(0, monthsBetween(carer.orderDate, asAt))
          : carer.monthsSinceOrderMade;
      }
      /**
       * The regulation 7 window is the 24 months after the order.
       *
       * A window, not a protection. Regulation 7 lets a council carry on paying the
       * reward element of a former foster carer's allowance, and lets it stop. Inside
       * the window the power exists; it was never a guarantee, and calling it one
       * told carers they held something they do not.
       */ const REG7_WINDOW_MONTHS = 24;
      function withinReg7Window(carer, asAt) {
        const months = monthsSinceOrder(carer, asAt);
        // Not knowing is not the same as being inside it. Claiming the window when
        // nobody said when the order was made would floor the figure on a power the
        // council may no longer have, and the number a carer takes to their council
        // has to be one we can stand behind.
        if (months === undefined) return false;
        return carer.wasFosterCarerForThisChild && months < REG7_WINDOW_MONTHS;
      } //# sourceMappingURL=resolve.js.map
      // ../../packages/engine/dist/rates.js

      /**
       * Looking up what a nation, region and age band are worth.
       *
       * Every function here either finds a published figure or throws. Nothing is
       * derived, interpolated or defaulted: a rate the data does not hold is a
       * DataError, never a plausible guess.
       */

      function regimeFor(nation) {
        switch (nation) {
          case "england":
            return "england-sgo";
          case "wales":
            return "wales-sgo";
          case "northern-ireland":
            return "ni-sgo";
          case "scotland":
            return "scotland-kinship";
        }
      }
      function nationRates(rates, nation) {
        const table = nation === "england" ? rates.england : rates[nation];
        if (!table) {
          throw new errors_DataError(
            `No ${nation} rates in the ${rates.financialYear} table. They must be sourced, not derived.`,
          );
        }
        return table;
      }
      /**
       * The band covering a child's age.
       *
       * Only minAge and maxAge decide this. Some bands also carry `openEnded: true`,
       * which the Welsh top band does because the circular prints it as "16+": that
       * flag is a note to whoever next reads the data explaining why maxAge is 17
       * when the source names no upper limit. It is documentation, not behaviour, and
       * nothing here reads it. Bands must tile 0 to 17 exactly, because the product is
       * for children under 18, so an open band and a band closed at 17 are the same
       * band as far as this function is concerned.
       */ function resolveAgeBand(rates, nation, child, asAt) {
        const age = ageOf(child, asAt);
        const band = nationRates(rates, nation).ageBands.find(
          (b) => age >= b.minAge && age <= b.maxAge,
        );
        if (!band) {
          throw new errors_DataError(
            `No ${nation} age band covers age ${age} in ${rates.financialYear}`,
          );
        }
        return band;
      }
      /**
       * England region, from the explicit choice or from the council the carer picked.
       *
       * Spec §12 makes picking a council the default and most reliable path, and
       * la-region-map.json is what makes that work: it covers every English
       * children's services authority, whereas la-overrides holds policy detail for a
       * handful. So the region map is consulted for every council, not just the ones
       * we hold a policy for.
       *
       * An explicit region always wins. §12 route 3 is the fallback that must always
       * be available, including where our mapping is wrong.
       */ function resolveEnglandRegion(carer, deps = defaultDeps()) {
        if (carer.englandRegion) return carer.englandRegion;
        const la = publishableLaOverrideIn(deps.laOverrides, carer.localAuthoritySlug);
        if (la) return la.region;
        const mapped = carer.localAuthoritySlug
          ? LA_REGION_MAP[carer.localAuthoritySlug]
          : undefined;
        if (mapped) return mapped;
        throw new errors_DataError("An England region is required. Choose a region or a council.");
      }
      /**
       * The citation for the table a figure actually came from.
       *
       * [R3] Every numeric output carries the citation it derives from. The result
       * page used to list only the LAW: the statutory guidance saying the fostering
       * allowance is the starting point, and the regulations behind it. None of them
       * states the figure. A carer printing the page and handing it to a social
       * worker was asked where their number came from and the document answered with
       * statutes, while the GOV.UK table that actually prints it was nowhere on the
       * page.
       *
       * Read off the table in use, never hardcoded. The Scottish path used to name
       * the 2026/27 source whatever year it had priced, which is the same fault as
       * attributing a Welsh figure to a page that does not contain it.
       */ function citeRateSource(rates, nation) {
        return cite(nationRates(rates, nation).sourceId);
      }
      /** The national minimum weekly rate for this carer's area and this age band. */ function lookupRate(
        rates,
        carer,
        band,
        deps = defaultDeps(),
      ) {
        const table = nationRates(rates, carer.nation);
        if (carer.nation === "england") {
          const region = resolveEnglandRegion(carer, deps);
          const value = table.regions[region]?.[band.id];
          if (value === undefined) {
            throw new errors_DataError(
              `No England rate for ${region} / ${band.id} in ${rates.financialYear}`,
            );
          }
          return pence(value);
        }
        const value = table.rates[band.id];
        if (value === undefined) {
          throw new errors_DataError(
            `No ${carer.nation} rate for ${band.id} in ${rates.financialYear}`,
          );
        }
        return pence(value);
      } //# sourceMappingURL=rates.js.map
      // ../../packages/engine/dist/guardrails.js

      /**
       * Guardrails, spec §15.
       *
       * Rules R1 to R5 are runtime assertions here, not UI copy. If the engine
       * computes a violating result it throws, and the UI falls back to "we can't
       * estimate this, here is who to contact". A rule written only into the wording
       * of a page is a rule that stops being true the next time someone edits the
       * page.
       *
       * UI contract: a GuardrailViolation is never shown raw to a user. The results
       * component catches it, logs the rule code and no user data, and renders the
       * fallback plus the advice-line block.
       */

      class GuardrailViolation extends EngineError {
        constructor(rule, message) {
          super(`[${rule}] ${message}`);
          this.rule = rule;
        }
      }
      /** The fixed fractions that have been litigated. See R1. */ const SUSPICIOUS_RATIOS = [
        2 / 3,
        0.58,
        0.75,
        0.5,
      ];
      /** How close to one of those counts as being that one. */ const RATIO_TOLERANCE = 0.001;
      /**
       * Anything that only makes sense under English law. None of it may appear on a
       * Scottish result: special guardianship orders do not exist in Scots law, and
       * citing one sends a Scottish kinship carer to argue a rule their council is
       * not bound by.
       */ const ENGLISH_CITATION_IDS = [
        "sg-regs-2005-reg5",
        "sg-regs-2005-reg6",
        "sg-regs-2005-reg7",
        "sg-regs-2005-reg9",
        "sg-regs-2005-reg10",
        "sg-regs-2005-reg11",
        "sg-regs-2005-reg18",
        "ca1989-s14f-3",
        "dfe-guidance-2017-para65",
        "lewisham-2008",
        "kirklees-2010",
        "merton-2012",
        "tower-hamlets-2013",
        "lgsco-devon-2024",
        "lgsco-southend-2020",
        "lgsco-north-tyneside-17002928",
      ];
      function assertGuardrails(input, result) {
        assertScotlandIsSeparate(input, result);
        // Resolve the carer's position exactly as the engine did, see resolve.ts.
        // Reading it differently here turns a correct result into a spurious
        // violation, which the UI shows as "we can't estimate this".
        const asAt = input.asAtDate ?? todayUtc();
        const insideReg7Window = withinReg7Window(input.carer, asAt);
        const previous = input.carer.previousWeeklyFosteringAllowance;
        for (const child of result.perChild) {
          assertNotAFixedFraction(child, result.meansTestApplied);
          assertCited(child);
          assertSane(child);
        }
        // [R4] A former foster carer must never be shown a HOUSEHOLD TOTAL below their
        // previous fostering allowance within 24 months of the order.
        //
        // The total, because the carer gives that figure once for the whole household.
        // Asserting it per child was the same mistake the engine was making, so this
        // rule agreed with the fault instead of catching it: a carer with two children
        // was shown twice what they used to be paid and nothing objected.
        if (insideReg7Window && previous !== undefined && result.totalWeekly < previous) {
          throw new GuardrailViolation("R4", "Below the reg 7 former foster carer floor");
        }
        assertChildBenefitDeductionIsLoud(input, result);
      }
      /** [R5] Scotland must never be routed through the SGO engine, in either direction. */ function assertScotlandIsSeparate(
        input,
        result,
      ) {
        if (input.carer.nation === "scotland" && result.regime !== "scotland-kinship") {
          throw new GuardrailViolation("R5", "Scotland routed through the SGO engine");
        }
        if (result.regime !== "scotland-kinship") return;
        if (input.carer.nation !== "scotland") {
          throw new GuardrailViolation(
            "R5",
            "Non-Scottish input routed to the Scottish kinship regime",
          );
        }
        for (const child of result.perChild) {
          if (child.citations.some((c) => ENGLISH_CITATION_IDS.includes(c.id))) {
            throw new GuardrailViolation("R5", "English citation attached to a Scottish result");
          }
        }
        for (const flag of result.flags) {
          if (flag.citation && ENGLISH_CITATION_IDS.includes(flag.citation.id)) {
            throw new GuardrailViolation(
              "R5",
              "English citation attached to a Scottish result flag",
            );
          }
        }
      }
      /** [R1] Never output a fixed percentage of the fostering rate as "the answer". */ function assertNotAFixedFraction(
        child,
        meansTestApplied,
      ) {
        if (meansTestApplied || child.maximumWeekly <= 0) return;
        const ratio = child.estimatedAllowanceWeekly / child.maximumWeekly;
        if (SUSPICIOUS_RATIOS.some((r) => Math.abs(ratio - r) < RATIO_TOLERANCE)) {
          throw new GuardrailViolation(
            "R1",
            `Fixed-fraction output (${ratio}) without a means test`,
          );
        }
      }
      /** [R3] Every numeric output carries the citation it derives from. */ function assertCited(
        child,
      ) {
        if (child.citations.length === 0) {
          throw new GuardrailViolation("R3", `Uncited figure for child ${child.childId}`);
        }
      }
      function assertSane(child) {
        if (child.estimatedAllowanceWeekly < 0) {
          throw new GuardrailViolation("SANITY", "Negative allowance");
        }
        // Only a floor can lift an estimate above the ceiling. Anything else means
        // the arithmetic went the wrong way.
        if (child.estimatedAllowanceWeekly > child.maximumWeekly && child.floorApplied === null) {
          throw new GuardrailViolation("SANITY", "Estimate exceeds maximum with no floor applied");
        }
      }
      /** [R2] A Child Benefit deduction must never be silent. */ function assertChildBenefitDeductionIsLoud(
        input,
        result,
      ) {
        const deducted = result.perChild.some((c) => c.childBenefitDeductionWeekly > 0);
        if (!deducted) return;
        if (!input.applyChildBenefitDeduction) {
          throw new GuardrailViolation("R2", "Child Benefit deducted without explicit opt-in");
        }
        if (
          input.carer.onMeansTestedBenefits &&
          !result.flags.some((f) => f.code === "UNLAWFUL_CB_DEDUCTION_RISK")
        ) {
          throw new GuardrailViolation(
            "R2",
            "CB deducted from a means-tested claimant without a critical flag",
          );
        }
      } //# sourceMappingURL=guardrails.js.map
      // ../../packages/engine/dist/result.js

      /**
       * Assembling the final result, and the last gate before it leaves the engine.
       *
       * Every path ends here, and every path therefore ends in assertGuardrails,
       * which throws rather than let a legally wrong figure reach a carer.
       */

      function finalise(input, perChild, opts) {
        const totalWeekly = add(...perChild.map((c) => c.estimatedAllowanceWeekly));
        const result = {
          regime: opts.regime,
          financialYear: opts.rates.financialYear,
          ratesEffectiveFrom: opts.rates.effectiveFrom,
          perChild,
          totalWeekly,
          totalAnnual: weeklyToAnnual(totalWeekly),
          meansTestApplied: opts.meansTestApplied,
          flags: sortFlags(dedupeFlags(opts.flags)),
          warnings: opts.warnings ?? [],
          computedAt: new Date().toISOString(),
          engineVersion: ENGINE_VERSION,
          dataVersion: opts.rates.dataVersion,
        };
        if (opts.meansTestBreakdown) result.meansTestBreakdown = opts.meansTestBreakdown;
        assertRateSourceIsCited(input, result, opts.rates);
        assertGuardrails(input, result);
        return result;
      }
      /**
       * [R3] Every figure names the table it came from.
       *
       * assertGuardrails only checks that a child HAS citations, so a result citing
       * four documents, none of which prints the figure, passed it. That is what the
       * page did: statutes and regulations, and no link to the rate table. The check
       * lives here rather than in guardrails.ts because this is the only place that
       * still knows which table was used.
       */ function assertRateSourceIsCited(input, result, rates) {
        const expected = citeRateSource(rates, input.carer.nation).id;
        for (const child of result.perChild) {
          if (!child.citations.some((c) => c.id === expected)) {
            throw new GuardrailViolation(
              "R3",
              `Child ${child.childId} shows a figure from "${expected}" without citing it`,
            );
          }
        }
      } //# sourceMappingURL=result.js.map
      // ../../packages/engine/dist/standingFlags.js

      /**
       * The flags that are true of an SGO result regardless of the numbers.
       *
       * Everything here is driven off recorded data or off the carer's own answers,
       * so a warning disappears by itself the day the underlying fact changes.
       */

      /** How long before the reg 7 window closes the carer should be warned. */ const REG7_EXPIRING_FROM_MONTHS = 18;
      /** How long a council keeps a duty to the child after the order (spec §17). */ const CONTINUING_RESPONSIBILITY_MONTHS = 36;
      /** Three or more dependent children is where the abolished limit used to bite. */ const TWO_CHILD_LIMIT_THRESHOLD = 3;
      function standingFlags(input, asAt, rates, deps) {
        return [
          ...rateTableFlags(input, asAt, rates),
          ...childFlags(input, asAt),
          ...carerHistoryFlags(input, asAt),
          ...householdFlags(input),
          ...councilCoverageFlags(input, deps),
        ];
      }
      function rateTableFlags(input, asAt, rates) {
        const flags = [];
        if (asAt > rates.effectiveTo) {
          flags.push(
            makeFlag("RATES_STALE", {
              effectiveTo: rates.effectiveTo,
            }),
          );
        }
        // Wales pays more for an under-5 than for a 5-15 year old, which reads as a
        // bug to anyone who has seen any other UK rate table. Driven off the data, so
        // the warning goes the day the Welsh Government's circular either confirms
        // the figures or corrects them.
        if (input.carer.nation === "wales" && rates.wales?.anomalyConfirmed === true) {
          flags.push(makeFlag("WALES_BAND_ORDER_ANOMALY"));
        }
        // 1 to 5 April: councils uplift from 1 April, the DfE states the rates for a
        // tax year starting 6 April. Both are right, so rather than pick a side
        // silently we serve the council convention, which is what the carer is
        // actually paid, and say that the other reading exists.
        const { councilApplicationFrom, dfeStatedTaxYearFrom } = rates;
        if (
          councilApplicationFrom !== undefined &&
          dfeStatedTaxYearFrom !== undefined &&
          asAt >= councilApplicationFrom &&
          asAt < dfeStatedTaxYearFrom
        ) {
          flags.push(makeFlag("APRIL_RATE_BOUNDARY"));
        }
        return flags;
      }
      function childFlags(input, asAt) {
        const flags = [];
        for (const child of input.children) {
          if (child.wasLookedAfterImmediatelyBeforeOrder === false) {
            flags.push(makeFlag("NOT_LOOKED_AFTER_BEFORE_ORDER"));
          }
          if (child.wasLookedAfterImmediatelyBeforeOrder === "unknown") {
            flags.push(makeFlag("LOOKED_AFTER_STATUS_UNKNOWN"));
          }
          if (ageOf(child, asAt) === 17) {
            flags.push(makeFlag("AGE_17_TRANSITION"));
          }
        }
        return flags;
      }
      function carerHistoryFlags(input, asAt) {
        const flags = [];
        const months = monthsSinceOrder(input.carer, asAt);
        if (input.carer.wasFosterCarerForThisChild) {
          flags.push(makeFlag("REG7_EXTENSION_AVAILABLE"));
          flags.push(makeFlag("REG7_MISAPPLICATION_WARNING"));
          if (
            months !== undefined &&
            months >= REG7_EXPIRING_FROM_MONTHS &&
            months < REG7_WINDOW_MONTHS
          ) {
            flags.push(
              makeFlag("REG7_EXPIRING", {
                monthsSinceOrder: months,
              }),
            );
          }
        }
        // Silent when we were not told how long ago the order was made. This used to
        // read a blank box as zero, so it told every carer who skipped the question
        // that their council still had a three-year duty, including carers whose
        // order was made a decade ago.
        if (months !== undefined && months < CONTINUING_RESPONSIBILITY_MONTHS) {
          flags.push(makeFlag("THREE_YEAR_RESPONSIBILITY"));
        }
        flags.push(makeFlag("ANNUAL_REVIEW_DUE"));
        flags.push(makeFlag("GUARDIANS_ALLOWANCE_CHECK"));
        return flags;
      }
      function householdFlags(input) {
        const householdChildren =
          input.finances?.dependentChildrenInHousehold ?? input.children.length;
        return householdChildren >= TWO_CHILD_LIMIT_THRESHOLD
          ? [makeFlag("TWO_CHILD_LIMIT_ABOLISHED")]
          : [];
      }
      /**
       * [§33] A council we hold no publishable policy for is not an error. Use the
       * national minimums and say so. This covers both a council absent from
       * la-overrides entirely and one seeded but held back for want of a source URL
       * (ADR-0001). From the carer's point of view they are the same situation.
       */ function councilCoverageFlags(input, deps) {
        const slug = input.carer.localAuthoritySlug;
        if (!slug || publishableLaOverrideIn(deps.laOverrides, slug)) return [];
        return [
          makeFlag("COUNCIL_POLICY_UNKNOWN", {
            councilName: councilNameFor(slug, deps),
          }),
        ];
      } //# sourceMappingURL=standingFlags.js.map
      // ../../packages/engine/dist/regimes/kinshipZone.js

      /**
       * The Kinship Zones pilot, spec §13.5.
       *
       * In a pilot area, a carer whose child would otherwise be in care gets the full
       * fostering national minimum allowance with no means test at all. So there is
       * no contribution, no deduction and no floor to apply: the rate is the answer.
       */

      function kinshipZonePath(input, rates, asAt, deps) {
        const flags = [
          makeFlag("KINSHIP_ZONE_ELIGIBLE", {
            councilName: councilNameFor(input.carer.localAuthoritySlug, deps),
          }),
          makeFlag("KINSHIP_ZONE_PILOT_CAVEAT"),
          ...standingFlags(input, asAt, rates, deps),
        ];
        const perChild = input.children.map((child) => {
          const band = resolveAgeBand(rates, input.carer.nation, child, asAt);
          const rate = lookupRate(rates, input.carer, band, deps);
          if (child.hasDisabilityOrAdditionalNeeds) flags.push(makeFlag("ENHANCEMENT_AVAILABLE"));
          return {
            childId: child.id,
            ageBand: band.id,
            ageAtCalculation: ageOf(child, asAt),
            coreAllowanceWeekly: rate,
            enhancementWeekly: pence(0),
            maximumWeekly: rate,
            assessedContributionWeekly: pence(0),
            childBenefitDeductionWeekly: pence(0),
            estimatedAllowanceWeekly: rate,
            floorApplied: "kinship-zone-nma",
            citations: [
              // The rate table first: the pilot pays the full NMA, so the figure comes
              // from the fostering table and that is what a carer needs to be able to
              // check.
              citeRateSource(rates, input.carer.nation),
              cite("kinship-zones-2026"),
              cite("dfe-guidance-2017-para65"),
            ],
          };
        });
        return finalise(input, perChild, {
          regime: "kinship-zone",
          rates,
          flags,
          meansTestApplied: false,
        });
      } //# sourceMappingURL=kinshipZone.js.map
      // ../../packages/engine/dist/regimes/scotland.js

      /**
       * Scotland, spec §13.4.
       *
       * [HARD R5] No regulation 6, regulation 7, paragraph 65 or English case law may
       * be attached to a Scottish result. Special guardianship orders do not exist in
       * Scots law, and citing them at a Scottish kinship carer is worse than useless:
       * it sends them to argue a rule their council is not bound by.
       *
       * The Scottish Recommended Allowance is a floor, not a ceiling, which is why
       * the estimate here is the rate itself with no deduction of any kind.
       */

      function scotlandPath(input, rates, asAt, deps) {
        const flags = [
          makeFlag("SCOTLAND_SRA_IS_A_FLOOR"),
          makeFlag("SCOTLAND_FOSTER_KINSHIP_PARITY"),
          makeFlag("SCOTLAND_NO_WORSE_OFF"),
        ];
        if (asAt > rates.effectiveTo) {
          flags.push(
            makeFlag("RATES_STALE", {
              effectiveTo: rates.effectiveTo,
            }),
          );
        }
        const perChild = input.children.map((child) => {
          const band = resolveAgeBand(rates, "scotland", child, asAt);
          const rate = lookupRate(rates, input.carer, band, deps);
          return {
            childId: child.id,
            ageBand: band.id,
            ageAtCalculation: ageOf(child, asAt),
            coreAllowanceWeekly: rate,
            enhancementWeekly: pence(0),
            maximumWeekly: rate,
            assessedContributionWeekly: pence(0),
            childBenefitDeductionWeekly: pence(0),
            estimatedAllowanceWeekly: rate,
            floorApplied: "scottish-recommended-allowance",
            // The table actually used, not a hardcoded year. This named the 2026/27
            // source whatever year it had priced, so a figure from an earlier table
            // linked a page that does not contain it.
            citations: [citeRateSource(rates, "scotland")],
          };
        });
        return finalise(input, perChild, {
          regime: "scotland-kinship",
          rates,
          flags,
          meansTestApplied: false,
        });
      } //# sourceMappingURL=scotland.js.map
      // ../../packages/engine/dist/regimes/sgo.js

      /**
       * England, Wales and Northern Ireland, spec §13.
       *
       * The shape of the calculation, in the order a carer would follow it:
       *
       *   1. what the council should be starting from, per child
       *   2. stop there if no finances were given, because the ceiling is the answer
       *      most people came for and must never be gated behind a means test
       *   3. otherwise assess a contribution, share it across the children, take any
       *      opted-in Child Benefit deduction, and apply the regulation 7 floor
       */

      /**
       * The sources behind every SGO figure, fresh each time so nothing shares an array.
       *
       * The rate table comes first because it is the one that answers "where does
       * this number come from". The other two are the law that says the fostering
       * allowance is the starting point, which is a different question. For a while
       * only the law was listed, so the page cited statutes at a figure none of them
       * prints.
       */ const sgoCitations = (rates, nation) => [
        citeRateSource(rates, nation),
        cite("dfe-guidance-2017-para65"),
        cite("sg-regs-2005-reg6"),
      ];
      function sgoPath(
        input,
        rates,
        /** Looked up on demand: only a means-tested result ever reads it. */ benefitsFor,
        asAt,
        deps,
      ) {
        const la = publishableLaOverrideIn(deps.laOverrides, input.carer.localAuthoritySlug);
        const measured = measureChildren(input, rates, asAt, la, deps);
        const flags = [
          ...standingFlags(input, asAt, rates, deps),
          ...councilPolicyFlags(la),
          ...measured.flags,
        ];
        return input.finances
          ? meansTested(input, measured.children, flags, rates, benefitsFor, asAt, la)
          : maximumOnly(input, measured.children, flags, rates, asAt);
      }
      // ─── 1: the maximum, per child ─────────────────────────────────────────────
      function measureChildren(input, rates, asAt, la, deps) {
        const flags = [];
        // A carer in a pilot area who is already on regulation 6 support runs the
        // normal path, plus a note comparing it with the pilot rate (§13.5).
        const excludedFromPilot =
          isInKinshipZone(input, deps) && input.carer.alreadyReceivingReg6Support === true;
        const children = input.children.map((child) => {
          const band = resolveAgeBand(rates, input.carer.nation, child, asAt);
          const national = lookupRate(rates, input.carer, band, deps);
          const core =
            la?.flatCoreRateWeeklyPence !== undefined
              ? pence(la.flatCoreRateWeeklyPence)
              : national;
          if (core < national) {
            flags.push(
              makeFlag("BELOW_NMA", {
                councilName: la?.name,
                coreWeekly: core,
                nationalWeekly: national,
                ageBand: band.id,
              }),
            );
          }
          // [§13.3] There is NO national figure for a disability enhancement. Do not
          // invent one and do not apply a percentage. Default 0, and tell the carer
          // to ask for it.
          const enhancement =
            la?.enhancementWeeklyPence !== undefined ? pence(la.enhancementWeeklyPence) : pence(0);
          if (child.hasDisabilityOrAdditionalNeeds) flags.push(makeFlag("ENHANCEMENT_AVAILABLE"));
          if (excludedFromPilot) {
            // The band goes in because the pilot rate differs by age, and dedupeFlags
            // now keeps one message per distinct text: without it, two children in
            // different bands would collapse to a single figure naming neither.
            flags.push(
              makeFlag("KINSHIP_ZONE_EXCLUDED_REG6", {
                kinshipZoneWeekly: national,
                ageBand: band.id,
              }),
            );
          }
          return {
            child,
            band,
            core,
            enhancement,
            maximum: add(core, enhancement),
          };
        });
        return {
          children,
          flags,
        };
      }
      // ─── 2: no finances given, so the ceiling is the whole answer ──────────────
      function maximumOnly(input, children, flags, rates, asAt) {
        // [R4] The regulation 7 floor is not a means-test step. A former foster carer
        // inside the two years must never be shown a household total below their
        // previous fostering allowance, including on this path, which is the whole of
        // what most people see.
        const maximums = children.map((c) => c.maximum);
        const floor = applyReg7Floor(input, maximums, maximums, asAt);
        flags.push(...floor.flags);
        const perChild = children.map((c, i) => ({
          ...baseResult(c, asAt),
          assessedContributionWeekly: pence(0),
          childBenefitDeductionWeekly: pence(0),
          estimatedAllowanceWeekly: floor.values[i] ?? c.maximum,
          floorApplied: floor.reason,
          citations: floor.reason
            ? flooredCitations(rates, input.carer.nation)
            : sgoCitations(rates, input.carer.nation),
        }));
        return finalise(input, perChild, {
          regime: regimeFor(input.carer.nation),
          rates,
          flags,
          meansTestApplied: false,
        });
      }
      // ─── 3: means tested ───────────────────────────────────────────────────────
      function meansTested(input, children, flags, rates, benefitsFor, asAt, la) {
        const finances = input.finances;
        if (!finances) throw new errors_DataError("meansTested called without finances");
        // Resolved here rather than by the caller: this is the only branch that needs
        // a benefit table, and asking for one earlier refused results that do not.
        const benefits = benefitsFor();
        if (!meansTestAvailable(benefits)) {
          // Blocked on PENDING_SOURCE data. runMeansTest would throw; surface the
          // DataError rather than silently return a maximum-only result labelled as
          // means tested.
          throw new errors_DataError(
            `The means test cannot run for ${benefits.financialYear}: the DWP Income Support ` +
              "applicable amounts are not yet sourced (spec §8.4). Maximum-only results are unaffected.",
          );
        }
        const taper = taperFor(la, input);
        const capital = capitalFor(la);
        const livingCostsMultiplier = livingCostsMultiplierFor(la);
        const assessment = runMeansTest(finances, benefits, taper, capital, livingCostsMultiplier);
        flags.push(makeFlag("MEANS_TEST_MODEL_OUTDATED"));
        if (livingCostsMultiplier !== CORE_LIVING_COSTS_MULTIPLIER) {
          // A council allowing less for living costs assesses a bigger contribution
          // and so pays a smaller allowance. Say where the difference comes from
          // rather than leave the carer to wonder.
          flags.push(
            makeFlag("LA_LIVING_COSTS_VARIATION", {
              ...(la?.name
                ? {
                    councilName: la.name,
                  }
                : {}),
              livingCostsPercent: Math.round(livingCostsMultiplier * 100),
              modelLivingCostsPercent: Math.round(CORE_LIVING_COSTS_MULTIPLIER * 100),
              ...(la?.policySourceUrl
                ? {
                    policySourceUrl: la.policySourceUrl,
                  }
                : {}),
            }),
          );
        }
        if (!la?.taper && !input.taperOverride) {
          flags.push(
            makeFlag("TAPER_METHOD_ASSUMED", {
              taperMethod: taper.method,
            }),
          );
        }
        // Against the model threshold, not the council's own: where no capital rule is
        // switched on there is no council threshold in play, and this flag only says
        // that a rule might exist, not that one has been applied.
        if (!capital.enabled && finances.savingsCapital > DEFAULT_CAPITAL.thresholdPence) {
          flags.push(
            makeFlag("CAPITAL_RULE_MAY_APPLY", {
              savingsCapital: finances.savingsCapital,
            }),
          );
        }
        // The contribution is shared across the children in proportion to what each
        // is worth, so no child absorbs all of it.
        const shares = apportion(
          assessment.assessedContributionWeekly,
          children.map((c) => c.maximum),
        );
        // Priced child by child first, then floored across the household, because the
        // floor is a household figure. See applyReg7Floor.
        const childBenefits = children.map((c) =>
          childBenefitDeduction(input, c.child, benefits, flags),
        );
        const netted = children.map((c, i) =>
          clampMin0(sub(sub(c.maximum, shares[i] ?? pence(0)), childBenefits[i] ?? pence(0))),
        );
        const floor = applyReg7Floor(
          input,
          netted,
          children.map((c) => c.maximum),
          asAt,
        );
        flags.push(...floor.flags);
        const perChild = children.map((c, i) => ({
          ...baseResult(c, asAt),
          assessedContributionWeekly: shares[i] ?? pence(0),
          childBenefitDeductionWeekly: childBenefits[i] ?? pence(0),
          estimatedAllowanceWeekly: floor.values[i] ?? pence(0),
          floorApplied: floor.reason,
          citations: floor.reason
            ? flooredCitations(rates, input.carer.nation)
            : [...sgoCitations(rates, input.carer.nation), cite("merton-2012")],
        }));
        return finalise(input, perChild, {
          regime: regimeFor(input.carer.nation),
          rates,
          flags,
          meansTestApplied: true,
          meansTestBreakdown: assessment,
        });
      }
      // ─── Shared pieces ─────────────────────────────────────────────────────────
      function baseResult(c, asAt) {
        return {
          childId: c.child.id,
          ageBand: c.band.id,
          ageAtCalculation: ageOf(c.child, asAt),
          coreAllowanceWeekly: c.core,
          enhancementWeekly: c.enhancement,
          maximumWeekly: c.maximum,
        };
      }
      const flooredCitations = (rates, nation) => [
        ...sgoCitations(rates, nation),
        cite("sg-regs-2005-reg7"),
        cite("tower-hamlets-2013"),
      ];
      /**
       * [R4] Regulation 7: a former foster carer must never be shown a HOUSEHOLD
       * TOTAL below their previous fostering allowance within 24 months of the order.
       *
       * The total, not each child. The carer is asked once what they were paid as a
       * foster carer, and the answer is what they actually received, for everyone
       * they were fostering. Flooring each child at that figure paid a carer with two
       * children twice what they used to get, and three children three times it, in
       * the largest text on the page and in the letter they send their council.
       *
       * Where the total falls short, the previous allowance is shared back across the
       * children by what each is worth. That is the same weighting the assessed
       * contribution uses, so the two steps cannot disagree, and apportion guarantees
       * the shares sum to the previous allowance exactly rather than a penny either
       * side of it.
       *
       * A child can come out above its own maximum this way. That is the floor doing
       * its job, and it is why floorApplied is set on every child rather than only on
       * the ones that moved: assertSane allows an estimate above the ceiling only
       * when a floor explains it.
       */ function applyReg7Floor(input, candidates, weights, asAt) {
        const previous = input.carer.previousWeeklyFosteringAllowance;
        const total = add(...candidates);
        if (!withinReg7Window(input.carer, asAt) || previous === undefined || total >= previous) {
          return {
            values: candidates,
            reason: null,
            flags: [],
          };
        }
        return {
          values: apportion(previous, weights),
          reason: "reg7-former-foster-carer",
          flags: [
            makeFlag("REG7_FLOOR_APPLIED", {
              previousWeekly: previous,
              monthsSinceOrder: monthsSinceOrder(input.carer, asAt),
            }),
          ],
        };
      }
      /**
       * [R2] Child Benefit is NEVER deducted by default. Only on an explicit opt-in,
       * and never silently.
       */ function childBenefitDeduction(input, child, benefits, flags) {
        if (!input.applyChildBenefitDeduction) return pence(0);
        if (input.carer.onMeansTestedBenefits) flags.push(makeFlag("UNLAWFUL_CB_DEDUCTION_RISK"));
        const value = child.isEldestInHousehold
          ? benefits.childBenefit.eldestWeeklyPence
          : benefits.childBenefit.additionalChildWeeklyPence;
        if (value === null || value === undefined) {
          throw new errors_DataError(
            `Child Benefit rates for ${benefits.financialYear} are not yet sourced, so they cannot be deducted.`,
          );
        }
        return pence(value);
      } //# sourceMappingURL=sgo.js.map

      // EXTERNAL MODULE: ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js + 4 modules
      var types = __webpack_require__(7406);
      // EXTERNAL MODULE: ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js
      var ZodError = __webpack_require__(8852); // ../../packages/engine/dist/schema.js
      /**
       * Zod schemas, spec §6 and the validation table at §20.1.
       *
       * The web form and the engine share these, so a value that passes the form
       * cannot fail the engine and vice versa.
       *
       * Every message here is read by a carer, so every one needs wording, including
       * the type errors. A bare `.min(0)` leaves Zod to say "Expected number,
       * received nan" when a box is empty, which tells someone who has never seen a
       * form error before precisely nothing about what to do. That failure is what
       * this file exists to prevent.
       */

      // ─── Limits ────────────────────────────────────────────────────────────────
      /** £100,000 a month ceiling on any money field (spec §20.1). */ const MAX_MONEY_PENCE = 10000000;
      /** £1,000 a week is far above any real fostering allowance. */ const MAX_FOSTERING_ALLOWANCE_PENCE = 100000;
      /** £10m of savings. Past this the means test is not the carer's problem. */ const MAX_SAVINGS_PENCE = 1000000000;
      const MAX_CHILDREN = 10;
      const MAX_CHILD_AGE = 17;
      const MAX_ADULTS = 6;
      const MAX_HOUSEHOLD_CHILDREN = 20;
      /** 100 years, so a mistyped date cannot pass as a very old order. */ const MAX_MONTHS_SINCE_ORDER = 1200;
      // ─── Primitives ────────────────────────────────────────────────────────────
      const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
      const isoDateSchema = types /* string */
        .Yj()
        .regex(ISO_DATE_RE, "Enter a date as YYYY-MM-DD.") // Round-tripping catches 2026-02-30, which Date happily rolls into March.
        .refine((s) => {
          const d = new Date(`${s}T00:00:00Z`);
          return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
        }, "Enter a real date.");
      const penceSchema = types /* number */
        .ai()
        .int("Enter an amount like 1250 or 1250.50.")
        .min(0, "Enter an amount of £0 or more.");
      const moneyFieldSchema = penceSchema.max(
        MAX_MONEY_PENCE,
        "Enter an amount like 1250 or 1250.50.",
      );
      const nationSchema = types /* enum */
        .k5(["england", "wales", "scotland", "northern-ireland"]);
      const englandRegionSchema = types /* enum */
        .k5(["london", "south-east", "rest-of-england"]);
      const meansTestedBenefitSchema = types /* enum */
        .k5([
          "universal-credit",
          "income-support",
          "jsa-income-based",
          "esa-income-related",
          "pension-credit",
          "housing-benefit",
          "council-tax-support",
        ]);
      /** Add a cross-field problem at the path of the box the carer should look at. */ const problem =
        (ctx, path, message) => {
          ctx.addIssue({
            code: ZodError /* ZodIssueCode */.eq.custom,
            path,
            message,
          });
        };
      // ─── One child ─────────────────────────────────────────────────────────────
      const childInputSchema = types /* object */
        .Ik({
          id: types /* string */
            .Yj()
            .min(1),
          ageYears: types /* number */
            .ai({
              required_error: "Enter the child’s age, in years.",
              invalid_type_error:
                "Enter the child’s age as a number, in years. For a baby under one, enter 0.",
            })
            .int("Enter the age in whole years. For a child of two and a half, enter 2.")
            .min(0, "An age cannot be less than 0. For a baby under one, enter 0.")
            .max(
              MAX_CHILD_AGE,
              "This calculator is for children under 18. If they have turned 18, support works differently, and my guide on turning 18 explains what happens next.",
            ),
          dateOfBirth: isoDateSchema.optional(),
          hasDisabilityOrAdditionalNeeds: types /* boolean */
            .zM(),
          wasLookedAfterImmediatelyBeforeOrder: types /* union */
            .KC([
              types /* boolean */
                .zM(),
              types /* literal */
                .eu("unknown"),
            ]),
          isEldestInHousehold: types /* boolean */
            .zM(),
        });
      // ─── The carer ─────────────────────────────────────────────────────────────
      const carerInputSchema = types /* object */
        .Ik({
          nation: nationSchema,
          englandRegion: englandRegionSchema.optional(),
          localAuthoritySlug: types /* string */
            .Yj()
            .regex(/^[a-z0-9-]+$/)
            .optional(),
          wasFosterCarerForThisChild: types /* boolean */
            .zM(),
          orderDate: isoDateSchema.optional(),
          monthsSinceOrderMade: types /* number */
            .ai()
            .int()
            .min(0)
            .max(MAX_MONTHS_SINCE_ORDER)
            .optional(),
          previousWeeklyFosteringAllowance: penceSchema
            .max(
              MAX_FOSTERING_ALLOWANCE_PENCE,
              "Enter the weekly amount you received as a foster carer.",
            )
            .optional(),
          onMeansTestedBenefits: types /* boolean */
            .zM(),
          meansTestedBenefitsHeld: types /* array */
            .YO(meansTestedBenefitSchema)
            .optional(),
          childWouldOtherwiseBeInCare: types /* boolean */
            .zM()
            .optional(),
          alreadyReceivingReg6Support: types /* boolean */
            .zM()
            .optional(),
        })
        .superRefine((carer, ctx) => {
          // England rates vary by region, so one of the two routes to a region has to
          // be taken. Everywhere else has a single national table.
          if (carer.nation === "england" && !carer.englandRegion && !carer.localAuthoritySlug) {
            problem(ctx, ["englandRegion"], "Choose a region so I can use the right rates.");
          }
          // Without the previous allowance the reg 7 floor cannot be applied, and a
          // former foster carer would silently be shown a figure below it.
          if (
            carer.wasFosterCarerForThisChild &&
            carer.previousWeeklyFosteringAllowance === undefined
          ) {
            problem(
              ctx,
              ["previousWeeklyFosteringAllowance"],
              "Enter the weekly amount you received as a foster carer.",
            );
          }
          // And without the timing it cannot be applied either, for the same reason.
          // The reg 7 window is the 24 months after the order, so an amount with no
          // date attached is an amount the engine has to ignore. It used to ignore it
          // in silence: a carer who gave a 500 pound allowance and left both date
          // boxes empty was shown the standard rate instead, with no error and
          // nothing to say a figure they had entered had been discarded.
          if (
            carer.wasFosterCarerForThisChild &&
            carer.orderDate === undefined &&
            carer.monthsSinceOrderMade === undefined
          ) {
            problem(
              ctx,
              ["monthsSinceOrderMade"],
              "Tell me when the order was made, either the date or roughly how many months ago. " +
                "Your old fostering rate only counts for the first two years.",
            );
          }
        });
      // ─── Finances ──────────────────────────────────────────────────────────────
      const financesInputSchema = types /* object */
        .Ik({
          netEarnings: moneyFieldSchema,
          otherIncome: moneyFieldSchema,
          countableBenefits: moneyFieldSchema,
          childBenefitOtherChildren: moneyFieldSchema,
          savingsCapital: penceSchema.max(MAX_SAVINGS_PENCE),
          housingCosts: moneyFieldSchema,
          councilTax: moneyFieldSchema,
          childcareCosts: moneyFieldSchema,
          essentialLoanRepayments: moneyFieldSchema,
          maintenancePaid: moneyFieldSchema,
          pensionContributions: moneyFieldSchema,
          adultsInHousehold: types /* number */
            .ai({
              required_error: "Enter how many adults live in your household.",
              invalid_type_error:
                "Enter how many adults live in your household, as a number from 1 to 6.",
            })
            .int("Enter a whole number of adults, from 1 to 6.")
            .min(1, "There is at least one adult in the household: you. Enter 1 or more.")
            .max(MAX_ADULTS, "Enter a number from 1 to 6. If your household is larger, enter 6."),
          dependentChildrenInHousehold: types /* number */
            .ai({
              required_error: "Enter how many dependent children live in your household.",
              invalid_type_error:
                "Enter how many dependent children live in your household, as a number.",
            })
            .int("Enter a whole number of children.")
            .min(0, "Enter 0 or more.")
            .max(
              MAX_HOUSEHOLD_CHILDREN,
              "Enter a number up to 20. If your household is larger, enter 20.",
            ),
          householdHasDisabilityPremium: types /* boolean */
            .zM()
            .optional(),
          householdHasCarerPremium: types /* boolean */
            .zM()
            .optional(),
          claimantUnder25: types /* boolean */
            .zM()
            .optional(),
        });
      const taperConfigSchema = types /* object */
        .Ik({
          method: types /* enum */
            .k5(["pound-for-pound", "percentage", "threshold"]),
          percentage: types /* number */
            .ai()
            .min(0)
            .max(1)
            .optional(),
          thresholdMonthly: penceSchema.optional(),
        }) // A method with no figure behind it used to fall back to pound-for-pound,
        // the harshest option, in silence. applyTaper now refuses it, so the
        // configuration has to be caught here rather than blowing up mid-calculation
        // and showing a carer "we cannot estimate this".
        .superRefine((taper, ctx) => {
          if (taper.method === "percentage" && taper.percentage === undefined) {
            problem(ctx, ["percentage"], "A percentage taper needs a percentage.");
          }
          if (taper.method === "threshold" && taper.thresholdMonthly === undefined) {
            problem(ctx, ["thresholdMonthly"], "A threshold taper needs a threshold.");
          }
        });
      // ─── The whole input ───────────────────────────────────────────────────────
      const calculatorInputSchema = types /* object */
        .Ik({
          carer: carerInputSchema,
          children: types /* array */
            .YO(childInputSchema)
            .min(1, "Add at least one child.")
            .max(MAX_CHILDREN, "This calculator handles up to 10 children."),
          finances: financesInputSchema.optional(),
          applyChildBenefitDeduction: types /* boolean */
            .zM()
            .default(false),
          taperOverride: taperConfigSchema.optional(),
          asAtDate: isoDateSchema.optional(),
        })
        .superRefine((input, ctx) => {
          if (
            input.finances &&
            input.finances.dependentChildrenInHousehold < input.children.length
          ) {
            problem(
              ctx,
              ["finances", "dependentChildrenInHousehold"],
              "This should include the children you have already entered.",
            );
          }
          if (input.children.filter((c) => c.isEldestInHousehold).length > 1) {
            problem(ctx, ["children"], "Only one child can be the eldest in the household.");
          }
          checkTheEldestIsTheOldest(input.children, ctx);
        });
      /**
       * Marking a younger child as the eldest contradicts the ages just given, and it
       * is not harmless: only the eldest attracts the higher rate of Child Benefit,
       * so the mistake moves money. Easy to make, too, since the choice sits below
       * the ages and the form pre-selects one.
       */ function checkTheEldestIsTheOldest(children, ctx) {
        if (children.length <= 1) return;
        const marked = children.findIndex((c) => c.isEldestInHousehold);
        if (marked < 0) return;
        const markedAge = children[marked].ageYears;
        const oldest = Math.max(...children.map((c) => c.ageYears));
        if (markedAge >= oldest) return;
        problem(
          ctx,
          ["children", marked, "isEldestInHousehold"],
          `You have marked the child aged ${markedAge} as the eldest, but you have also ` +
            `entered a child aged ${oldest}. Only the eldest child attracts the higher rate of ` +
            "Child Benefit, so this changes the figures. Mark the oldest child instead.",
        );
      }
      /** Parse, converting Zod's error into the engine's own ValidationError. */ function parseCalculatorInput(
        input,
      ) {
        const result = calculatorInputSchema.safeParse(input);
        if (result.success) return result.data;
        const issues = result.error.issues.map((i) => ({
          path: i.path.join("."),
          message: i.message,
        }));
        throw new ValidationError(issues[0]?.message ?? "That input is not valid.", issues);
      } //# sourceMappingURL=schema.js.map
      // ../../packages/engine/dist/engine.js

      /**
       * The calculation entry point, spec §13.
       *
       * Pure. No DOM, no network, integer pence throughout. This file only routes;
       * the arithmetic lives in the regime module the routing picks.
       *
       *   validate → select rate table → select benefit table (independently, §11)
       *     → Scotland?     → regimes/scotland
       *     → Kinship Zone? → regimes/kinshipZone
       *     → otherwise       regimes/sgo   (England, Wales, Northern Ireland)
       *
       * The two table selections are independent because they have different
       * effective dates. Deriving one from the other would silently apply a benefit
       * figure from the wrong year.
       */

      function calculate(rawInput, depsOverride) {
        const input = parseCalculatorInput(rawInput);
        const deps = resolveDeps(depsOverride);
        const asAt = input.asAtDate ?? todayUtc();
        const rates = selectRateTable(deps.rateTables, asAt);
        // The benefit table is looked up only where something reads it, which is the
        // means test and the Child Benefit deduction. It used to be selected here,
        // before the routing, so a date with no benefit table refused every path
        // including the ones that never touch one: a Scottish carer asking about an
        // earlier year was turned away over a table their result does not use.
        const benefitsFor = () => selectBenefitTable(deps.benefitTables, asAt);
        if (input.carer.nation === "scotland") return scotlandPath(input, rates, asAt, deps);
        if (isKinshipZoneEligible(input, deps)) return kinshipZonePath(input, rates, asAt, deps);
        return sgoPath(input, rates, benefitsFor, asAt, deps);
      } // ../../packages/engine/dist/featureFlags.js

      //# sourceMappingURL=engine.js.map

      /**
       * Feature flags and rollout — spec §39.
       *
       * Phase 1 (launch): England, Scotland and NI. Maximum-only calculation. All
       * guidance pages except Wales. Print/PDF export. No means test, no backdating,
       * no LA pages.
       *
       * That is already better than anything currently available. A carer who learns
       * their council's lawful ceiling and can print it has what they need. Do NOT
       * hold Phase 1 for Phase 2 data.
       */ const FLAGS = {
        MEANS_TEST_ENABLED: true,
        BACKDATING_ENABLED: true,
        WALES_ROUTE_ENABLED: true,
        LETTER_GENERATOR: true,
        POSTCODE_LOOKUP: true,
        KINSHIP_ZONE_PATH: true,
        WELSH_LANGUAGE: false,
        LA_PAGES: false,
      }; //# sourceMappingURL=featureFlags.js.map
      // ./components/results/MaximumHero.tsx

      /* __next_internal_client_entry_do_not_use__ MaximumHero auto */

      const FLOOR_HEADING = {
        // Regulation 7 is a power, not an entitlement: it lets a council keep
        // paying the reward element, and lets it stop. Saying the figure is
        // "protected" told carers they held something they do not.
        "reg7-former-foster-carer": "I have assumed your old fostering rate continues",
        "kinship-zone-nma": "The pilot rate applies to you",
        "scottish-recommended-allowance": "This is the recommended minimum",
      };
      const REGION_LABEL = {
        london: "London",
        "south-east": "the South East",
        "rest-of-england": "the rest of England",
      };
      /**
       * THE number. Spec §21: lead with the ceiling, not the estimate.
       *
       * "Your council's maximum for a 12-year-old in the South East is £255/week."
       * This is what most users came for, and it is shown before any finances are
       * asked for.
       */ /**
       * Where a floor has raised the figure above the area maximum, reg 7 is the
       * case that matters, the protected amount is the number the carer needs, and
       * it must not be left buried in a flag underneath the area maximum. §21 says
       * lead with the ceiling; for these carers the ceiling is not the whole story.
       */ function FloorNotice({ result }) {
        const floored = result.perChild.filter(
          (c) =>
            c.floorApplied === "reg7-former-foster-carer" &&
            c.estimatedAllowanceWeekly > c.maximumWeekly,
        );
        if (floored.length === 0) return null;
        const total = result.totalWeekly;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "avoid-break hero--assumed",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h3", {
              className: "flush-top",
              children: FLOOR_HEADING["reg7-former-foster-carer"],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "hero__figure",
              children: [
                formatMoney(total),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  className: "hero__unit",
                  children: " a week",
                }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "flush",
              children: [
                "You fostered ",
                result.perChild.length > 1 ? "these children" : "this child",
                " before the order, and it was made less than two years ago. For that period your council can carry on paying the reward part of your fostering allowance, and it can carry on for longer if it thinks that right. I have assumed it does, which is why this figure is higher than the standard rate for your area. That is my assumption, not something your council has agreed.",
              ],
            }),
            result.perChild.length > 1 &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                className: "flush-bot",
                children: [
                  "This is the total for all ",
                  result.perChild.length,
                  " children, because the amount you told me you were paid as a foster carer was a total too.",
                ],
              }),
          ],
        });
      }
      function MaximumHero({ result, regionLabel }) {
        // Through `add`, not a cast: the cast would let a bad value reach the screen.
        const total = add(...result.perChild.map((c) => c.maximumWeekly));
        const single = result.perChild.length === 1 ? result.perChild[0] : undefined;
        const region = regionLabel ? (REGION_LABEL[regionLabel] ?? regionLabel) : undefined;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          "aria-labelledby": "maximum-heading",
          className: "avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "maximum-heading",
              children:
                result.regime === "scotland-kinship"
                  ? "The recommended allowance for your area"
                  : result.regime === "kinship-zone"
                    ? "The Kinship Zones pilot rate for your area"
                    : "The most your council should be starting from",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "hero__figure",
              children: [
                formatMoney(total),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  className: "hero__unit",
                  children: " a week",
                }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "hero__annual",
              children: [formatMoney(weeklyToAnnual(total)), " a year"],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "muted",
              children: single
                ? /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                      "For a ",
                      single.ageAtCalculation,
                      "-year-old",
                      region ? ` in ${region}` : "",
                      " (age band ",
                      single.ageBand,
                      "), financial year",
                      " ",
                      result.financialYear.replace("-", "/"),
                      ".",
                    ],
                  })
                : /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                      "For ",
                      result.perChild.length,
                      " children",
                      region ? ` in ${region}` : "",
                      ", financial year",
                      " ",
                      result.financialYear.replace("-", "/"),
                      ".",
                    ],
                  }),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(FloorNotice, {
              result: result,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                  children: "This is an estimate.",
                }),
                " ",
                result.regime === "scotland-kinship"
                  ? "The Scottish Recommended Allowance is a minimum. Your council can pay more."
                  : result.regime === "kinship-zone"
                    ? "The pilot pays the full fostering National Minimum Allowance with no means test."
                    : "Your council can lawfully pay less after assessing your circumstances. But this is the figure the guidance says it should start from.",
              ],
            }),
          ],
        });
      } // ./components/results/PrintedInputs.tsx

      const NATION_LABEL = {
        england: "England",
        wales: "Wales",
        scotland: "Scotland",
        "northern-ireland": "Northern Ireland",
      };
      const PrintedInputs_REGION_LABEL = {
        london: "London",
        "south-east": "South East England",
        "rest-of-england": "Rest of England",
      };
      const LOOKED_AFTER = {
        true: "Yes",
        false: "No",
        unknown: "Not sure",
      };
      /**
       * [§19 item 2] The printed document must contain the inputs the user gave, so a
       * social worker can check them.
       *
       * Without this the printed page is an assertion. With it, it is a calculation
       * somebody else can follow and disagree with, which is the point of handing it
       * over.
       *
       * Print-only: on screen the user can see their own answers in the form.
       */ function PrintedInputs({ input, councilName }) {
        const money = (p) => (p === undefined ? "Not given" : formatMoney(p));
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          className: "print-only avoid-break",
          "aria-labelledby": "printed-inputs-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "printed-inputs-heading",
              children: "What this estimate is based on",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("table", {
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("caption", {
                  className: "sr-only",
                  children: "The answers this estimate was calculated from",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("tbody", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "row",
                          children: "Nation",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: NATION_LABEL[input.carer.nation] ?? input.carer.nation,
                        }),
                      ],
                    }),
                    input.carer.englandRegion &&
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                        children: [
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                            scope: "row",
                            children: "Region",
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                            children:
                              PrintedInputs_REGION_LABEL[input.carer.englandRegion] ??
                              input.carer.englandRegion,
                          }),
                        ],
                      }),
                    councilName &&
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                        children: [
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                            scope: "row",
                            children: "Council",
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                            children: councilName,
                          }),
                        ],
                      }),
                    input.children.map((c, i) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                        "tr",
                        {
                          children: [
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("th", {
                              scope: "row",
                              children: ["Child ", input.children.length > 1 ? i + 1 : ""],
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("td", {
                              children: [
                                "Age ",
                                c.ageYears,
                                c.hasDisabilityOrAdditionalNeeds
                                  ? ", has a disability or additional needs"
                                  : "",
                                ". ",
                                "In the council's care immediately before the order:",
                                " ",
                                LOOKED_AFTER[String(c.wasLookedAfterImmediatelyBeforeOrder)],
                              ],
                            }),
                          ],
                        },
                        c.id,
                      ),
                    ),
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "row",
                          children: "Was the child's foster carer before the order",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: input.carer.wasFosterCarerForThisChild ? "Yes" : "No",
                        }),
                      ],
                    }),
                    input.carer.wasFosterCarerForThisChild &&
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                          /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                            children: [
                              /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                                scope: "row",
                                children: "Previous weekly fostering allowance, all children",
                              }),
                              /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                                children: money(input.carer.previousWeeklyFosteringAllowance),
                              }),
                            ],
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                            children: [
                              /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                                scope: "row",
                                children: "Order made",
                              }),
                              /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                                children: input.carer.orderDate
                                  ? input.carer.orderDate
                                  : input.carer.monthsSinceOrderMade === undefined
                                    ? "Not given"
                                    : `About ${input.carer.monthsSinceOrderMade} months ago`,
                              }),
                            ],
                          }),
                        ],
                      }),
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "row",
                          children: "Receives means-tested benefits",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: input.carer.onMeansTestedBenefits ? "Yes" : "No",
                        }),
                      ],
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "row",
                          children: "Council deducts Child Benefit",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: input.applyChildBenefitDeduction
                            ? "Yes, as told to me by the carer"
                            : "Not applied, I never deduct it unless told to",
                        }),
                      ],
                    }),
                    input.finances &&
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                        children: [
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                            scope: "row",
                            children: "Financial details",
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                            children:
                              "Given, and used for the means-tested estimate. The full arithmetic is set out below.",
                          }),
                        ],
                      }),
                  ],
                }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "If any of this is wrong, the figures below will be wrong too. These answers were entered by the carer and were not checked against any records.",
            }),
          ],
        });
      } // ./components/results/EstimateCard.tsx

      /**
       * Shown only where finances were given. Visually smaller than the maximum, and
       * always labelled "estimate" (spec §21).
       *
       * Never shows a confidence percentage, a progress bar implying precision, or a
       * comparison to a "typical" award. There is no typical award and implying one
       * is misleading.
       *
       * The card used to print the figure and nothing about how it got there, which
       * made the two flat ends of the model look like the site ignoring what was
       * typed. Below roughly £1,300 a month nothing is deducted at all, and above
       * roughly £2,500 the deduction already exceeds the maximum, so in both bands a
       * carer can change the numbers and watch the answer sit still. It was reported
       * as a bug, and as a piece of writing it was one: the arithmetic was right and
       * the page never said what it had done.
       */ function EstimateCard({ result }) {
        if (!result.meansTestApplied) return null;
        // Household totals, because the model assesses one contribution and shares it
        // across the children rather than testing each child separately.
        const maximum = add(...result.perChild.map((c) => c.maximumWeekly));
        const contribution = add(...result.perChild.map((c) => c.assessedContributionWeekly));
        const deducted = sub(maximum, result.totalWeekly);
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          "aria-labelledby": "estimate-heading",
          className: "avoid-break panel",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "estimate-heading",
              className: "flush-top big",
              children: "Your estimate after a means test",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "estimate__figure",
              children: [formatMoney(result.totalWeekly), " a week"],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "estimate__note",
              children: [formatMoney(weeklyToAnnual(result.totalWeekly)), " a year"],
            }),
            contribution === 0
              ? /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Nothing has been taken off.",
                    }),
                    " On the figures you gave, the model works out that you are not expected to contribute anything, so the estimate is the same as the maximum above. That is the model doing its job, not your answers being ignored.",
                  ],
                })
              : result.totalWeekly === 0
                ? /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                        children:
                          "The model reduces the allowance to nothing on the figures you gave.",
                      }),
                      " ",
                      "It expects a contribution of ",
                      formatMoney(contribution),
                      " a week, which is more than the",
                      " ",
                      formatMoney(maximum),
                      " maximum, so nothing is left. Above roughly this level of income the figure stays at zero however much you change the other boxes, because the contribution has already passed the maximum.",
                    ],
                  })
                : /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)("strong", {
                        children: [formatMoney(deducted), " a week has been taken off"],
                      }),
                      " the",
                      " ",
                      formatMoney(maximum),
                      " maximum above, on the figures you gave.",
                    ],
                  }),
            result.totalWeekly === 0 &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                children:
                  "A zero here does not mean your council must pay you nothing. It means this one common model, applied to these figures, produces nothing. Your council has to look at your actual circumstances, and it can pay more than the model suggests.",
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "flush",
              children: [
                "This applies the means-test model most English councils use. It is",
                " ",
                /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                  children: "not a statutory rule",
                }),
                ", and your council may work it out differently. The arithmetic is set out in full below so you can check it, or ask your council to.",
              ],
            }),
          ],
        });
      } // ./components/ui/ScrollableTable.tsx

      /**
       * A horizontally scrollable container for a wide table.
       *
       * The page body must never scroll sideways (§24), so wide content scrolls
       * inside its own container. A scrollable container must be keyboard-operable —
       * otherwise someone navigating without a mouse can see that a table continues
       * off-screen and has no way to reach the rest of it. Hence tabIndex and an
       * accessible name.
       */ function ScrollableTable({ label, children }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
          className: "scroll-x",
          tabIndex: 0,
          role: "group",
          "aria-label": label,
          children: children,
        });
      } // ./components/results/PerChildTable.tsx

      const FLOOR_LABEL = {
        "reg7-former-foster-carer": "Held at your previous fostering allowance (reg 7)",
        "kinship-zone-nma": "Kinship Zones pilot rate",
        "scottish-recommended-allowance": "Scottish Recommended Allowance",
      };
      /** Shown when there is more than one child (spec §21 item 3). */ function PerChildTable({
        result,
      }) {
        if (result.perChild.length < 2) return null;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          "aria-labelledby": "per-child-heading",
          className: "avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "per-child-heading",
              children: "Each child",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(ScrollableTable, {
              label: "Weekly figures for each child",
              children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("table", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("caption", {
                    className: "sr-only",
                    children: "Weekly figures for each child, in pounds",
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("thead", {
                    children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Age",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Age band",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Maximum",
                        }),
                        result.meansTestApplied &&
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                            scope: "col",
                            children: "Your contribution",
                          }),
                        result.perChild.some((c) => c.childBenefitDeductionWeekly > 0) &&
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                            scope: "col",
                            children: "Child Benefit taken off",
                          }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Estimate",
                        }),
                      ],
                    }),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("tbody", {
                    children: result.perChild.map((c) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                        "tr",
                        {
                          children: [
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                              scope: "row",
                              children: c.ageAtCalculation,
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              children: c.ageBand,
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              children: formatMoney(c.maximumWeekly),
                            }),
                            result.meansTestApplied &&
                              /*#__PURE__*/ (0, jsx_runtime.jsxs)("td", {
                                children: ["−", formatMoney(c.assessedContributionWeekly)],
                              }),
                            result.perChild.some((x) => x.childBenefitDeductionWeekly > 0) &&
                              /*#__PURE__*/ (0, jsx_runtime.jsxs)("td", {
                                children: ["−", formatMoney(c.childBenefitDeductionWeekly)],
                              }),
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("td", {
                              children: [
                                /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                                  children: formatMoney(c.estimatedAllowanceWeekly),
                                }),
                                c.floorApplied &&
                                  /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                                    className: "small",
                                    children: FLOOR_LABEL[c.floorApplied],
                                  }),
                              ],
                            }),
                          ],
                        },
                        c.childId,
                      ),
                    ),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("tfoot", {
                    children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "row",
                          colSpan: 2,
                          children: "Total",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: formatMoney(
                            add(...result.perChild.map((c) => c.maximumWeekly)),
                          ),
                        }),
                        result.meansTestApplied && /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {}),
                        result.perChild.some((x) => x.childBenefitDeductionWeekly > 0) &&
                          /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {}),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                          children: /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                            children: formatMoney(result.totalWeekly),
                          }),
                        }),
                      ],
                    }),
                  }),
                ],
              }),
            }),
          ],
        });
      } // ./components/results/ArithmeticPanel.tsx

      /**
       * "Show the arithmetic", spec §21 item 5, printed open (§19).
       *
       * A <details>/<summary> disclosure, not a div with an onClick (§24). The print
       * stylesheet forces it open, because the whole point of the printed page is
       * that a social worker can check the working.
       */ function ArithmeticPanel({ breakdown }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("details", {
          className: "avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("summary", {
              children: "Show the arithmetic",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "Every step of the calculation, with your figures in it. All amounts are monthly unless the line says otherwise.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(ScrollableTable, {
              label: "Step-by-step means test calculation",
              children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("table", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("caption", {
                    className: "sr-only",
                    children: "Step-by-step means test calculation",
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("thead", {
                    children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Step",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Amount",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Running total",
                        }),
                      ],
                    }),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("tbody", {
                    children: breakdown.steps.map((step, i) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                        "tr",
                        {
                          children: [
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("th", {
                              scope: "row",
                              className: "table__rowlabel",
                              children: [
                                step.label,
                                step.note &&
                                  /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                                    className: "table__note",
                                    children: step.note,
                                  }),
                              ],
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("td", {
                              className: "nowrap",
                              children: [
                                step.operation === "subtract" && "−",
                                step.operation === "add" && "+",
                                formatMoney(step.valuePence),
                              ],
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: step.operation === "result" ? "nowrap strong" : "nowrap",
                              children: formatMoney(step.runningTotalPence),
                            }),
                          ],
                        },
                        i,
                      ),
                    ),
                  }),
                ],
              }),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              children: [
                "The 20% disregard comes off your income ",
                /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                  children: "before",
                }),
                " your outgoings are taken into account. Councils sometimes do this the other way round, which produces a much larger contribution. It is worth checking which way yours has done it.",
              ],
            }),
          ],
        });
      } // ../../packages/engine/dist/backdating.js

      /**
       * Backdating module, spec §16.
       *
       * High value: the Ombudsman has ordered councils to backdate, so "what should I
       * have been paid since the order?" is a real question with real money attached.
       *
       * The work is all in the segmenting. The rate changes on every 1 April, on
       * every birthday that crosses an age band, and when the reg 7 window closes, so
       * the period is cut at each of those and each piece is priced on its own.
       *
       * [HARD] If a segment falls in a financial year whose rate data is
       * PENDING_SOURCE, it is not estimated. The year goes in `blockedYears` and the
       * carer sees a partial total with an explicit note. A backdating figure built
       * on a guessed historic rate is worse than no figure: the carer takes it to a
       * complaint and it gets shot down.
       */

      const DAYS_PER_WEEK = 7;
      const BACKDATING_CAVEATS = [
        "This shows the difference against your council's lawful maximum, not a guaranteed entitlement.",
        "A council can lawfully pay less after properly assessing your circumstances.",
        "The Ombudsman normally expects complaints within 12 months of you becoming aware, though there is discretion.",
        "Backdating has been ordered in real cases (Devon 2024; North Tyneside 17 002 928).",
      ];
      // ─── Where to cut ──────────────────────────────────────────────────────────
      /**
       * Split the period at every point where the rate could change (§16):
       *   1. each 1 April, the financial year boundary
       *   2. each 6 April, where the DfE's tax year disagrees with it
       *   3. each birthday that crosses an age band boundary
       *   4. the 24-month reg 7 anniversary
       *   5. the start of the requested period
       */ function segmentBoundaries(input, bands) {
        const { fromDate, toDate, base } = input;
        const points = new Map();
        // First writer wins throughout, so a date that is both a year boundary and a
        // birthday keeps the reason listed first here.
        const cut = (date, reason) => {
          if (date > fromDate && date <= toDate && !points.has(date)) points.set(date, reason);
        };
        points.set(fromDate, "period-start");
        // Only England has a tax-year framing to disagree with. The Welsh circular
        // says "from 1 April", the Northern Irish model scheme says "From 1st April",
        // and the Scottish rates were backdated to 1 April. Cutting those three at
        // 6 April produces five-day segments with the same rate on both sides: noise
        // in the segment list and nothing in the arithmetic.
        const hasTaxYearFraming = base.carer.nation === "england";
        for (const boundary of financialYearBoundaries(fromDate, toDate)) {
          if (!points.has(boundary)) points.set(boundary, "financial-year-change");
          // The five days a council and the DfE disagree about. Cutting here keeps
          // 1 to 5 April in a segment of its own, so the part of the total that
          // depends on which convention the council follows can be stated rather
          // than buried inside a longer segment.
          if (hasTaxYearFraming) {
            cut(`${boundary.slice(0, 4)}-04-06`, "april-tax-year-boundary");
          }
        }
        for (const child of base.children) {
          if (!child.dateOfBirth) continue;
          for (const date of ageBandChangeDates(child.dateOfBirth, fromDate, toDate, bands)) {
            cut(date, "age-band-change");
          }
        }
        if (base.carer.wasFosterCarerForThisChild && base.carer.orderDate) {
          cut(addMonths(base.carer.orderDate, REG7_WINDOW_MONTHS), "reg7-anniversary");
        }
        return [...points.entries()]
          .map(([date, reason]) => ({
            date: date,
            reason,
          }))
          .sort((a, b) => a.date.localeCompare(b.date));
      }
      function rateTableFor(tables, asAt, nation) {
        const match = tables.find((t) => asAt >= t.effectiveFrom && asAt <= t.effectiveTo);
        if (!match)
          return {
            blocked: financialYearOf(asAt),
          };
        if (match.status === "PENDING_SOURCE")
          return {
            blocked: match.financialYear,
          };
        // A year can be sourced for one nation and not another: the archived GOV.UK
        // table for 2024/25 says in terms that it applies to England. Block the year
        // for the others, so an English carer still gets their figure and a Welsh one
        // gets an honest gap instead of a thrown error.
        if (!match[nation])
          return {
            blocked: match.financialYear,
          };
        return match;
      }
      /**
       * The band for a child at a moment.
       *
       * Segmentation guarantees the band does not change inside a segment, so the age
       * at the start is the age throughout. The date of birth is dropped because the
       * age has already been resolved and passing both would resolve it twice.
       */ function bandAt(table, nation, child, ageYears, at) {
        return resolveAgeBand(
          table,
          nation,
          {
            ...child,
            ageYears,
            dateOfBirth: undefined,
          },
          at,
        );
      }
      // ─── The calculation ───────────────────────────────────────────────────────
      function calculateBackdating(input, depsOverride) {
        const deps = {
          ...defaultDeps(),
          ...depsOverride,
        };
        const { base, fromDate, toDate, actuallyPaidWeekly } = input;
        const nation = base.carer.nation;
        if (toDate < fromDate) {
          throw new errors_DataError("The end of the backdating period is before its start.");
        }
        if (base.children.length !== 1) {
          // Apportioning a household contribution across a period, per child, with
          // age-band changes at different dates, is not specified. Refuse rather than
          // invent an allocation.
          throw new errors_DataError("Backdating currently supports one child at a time.");
        }
        const child = base.children[0];
        /* c8 ignore next */ if (!child) throw new errors_DataError("Backdating needs a child.");
        const boundaries = segmentBoundaries(input, ageBandsFor(deps, nation));
        const segments = [];
        const blockedYears = new Set();
        const yearsCovered = new Set();
        let aprilBoundaryDifference = pence(0);
        for (const [i, start] of boundaries.entries()) {
          // Segments are half-open: [start, nextStart). The displayed `to` is the day
          // before the next segment begins, so the period reads naturally.
          const next = boundaries[i + 1];
          const endExclusive = next ? next.date : addDays(toDate, 1);
          const displayTo = addDays(endExclusive, -1);
          if (displayTo < start.date) continue;
          const table = rateTableFor(deps.rateTables, start.date, nation);
          if ("blocked" in table) {
            blockedYears.add(table.blocked);
            continue;
          }
          yearsCovered.add(table.financialYear);
          const weeks = daysBetween(start.date, endExclusive) / DAYS_PER_WEEK;
          const age = child.dateOfBirth ? ageAt(child.dateOfBirth, start.date) : child.ageYears;
          const band = bandAt(table, nation, child, age, start.date);
          const maximumWeekly = lookupRate(table, base.carer, band, deps);
          const shouldHaveBeenPaidWeekly = backdating_applyReg7Floor(
            base,
            start.date,
            maximumWeekly,
          );
          const segment = {
            from: start.date,
            to: displayTo,
            weeks: Math.round(weeks * 100) / 100,
            financialYear: table.financialYear,
            ageBand: band.id,
            maximumWeekly,
            shouldHaveBeenPaidWeekly,
            actuallyPaidWeekly,
            segmentShortfall: mul(
              clampMin0(sub(shouldHaveBeenPaidWeekly, actuallyPaidWeekly)),
              weeks,
            ),
            reason: start.reason,
          };
          const alternative = taxYearAlternative(deps, base, child, age, start.date, maximumWeekly);
          if (alternative) {
            segment.taxYearAlternativeWeekly = alternative.weekly;
            aprilBoundaryDifference = add(
              aprilBoundaryDifference,
              mul(alternative.difference, weeks),
            );
          }
          segments.push(segment);
        }
        return {
          segments,
          totalShouldHaveBeenPaid: add(
            ...segments.map((s) => mul(s.shouldHaveBeenPaidWeekly, s.weeks)),
          ),
          totalActuallyPaid: add(...segments.map((s) => mul(s.actuallyPaidWeekly, s.weeks))),
          shortfall: add(...segments.map((s) => s.segmentShortfall)),
          yearsCovered: [...yearsCovered].sort(),
          blockedYears: [...blockedYears].sort(),
          aprilBoundaryDifference,
          caveats: caveatsFor(blockedYears, aprilBoundaryDifference),
        };
      }
      /**
       * Age bands come from the CURRENT table. They have been stable across the
       * sourced years, and a change would be caught by the data validation gate.
       */ function ageBandsFor(deps, nation) {
        const current = deps.rateTables.find((t) => t.status !== "PENDING_SOURCE");
        /* c8 ignore next */ if (!current)
          throw new errors_DataError("No sourced rate table available.");
        const section = nation === "england" ? current.england : current[nation];
        if (!section) throw new errors_DataError(`No ${nation} rates available for backdating.`);
        return section.ageBands;
      }
      /**
       * [R4] Within the reg 7 window a former foster carer's previous allowance is
       * the floor, so a segment inside the window is priced at whichever is higher.
       *
       * The previous allowance is a HOUSEHOLD figure: the carer is asked once what
       * they were paid, for everyone they were fostering. Comparing it against one
       * child's maximum is only correct here because calculateBackdating refuses more
       * than one child, so the household and the child are the same thing. Lift that
       * restriction and this becomes the bug sgo.ts had, where a carer with two
       * children was shown twice what they used to be paid: floor the summed total
       * and share it back, the way applyReg7Floor in regimes/sgo.ts does.
       */ function backdating_applyReg7Floor(base, at, maximumWeekly) {
        const previous = base.carer.previousWeeklyFosteringAllowance;
        if (!base.carer.wasFosterCarerForThisChild || previous === undefined) return maximumWeekly;
        const months = base.carer.orderDate
          ? monthsBetween(base.carer.orderDate, at)
          : base.carer.monthsSinceOrderMade;
        // Unknown is not inside the window. See withinReg7Window in resolve.ts.
        if (months === undefined) return maximumWeekly;
        return months < REG7_WINDOW_MONTHS && previous > maximumWeekly ? previous : maximumWeekly;
      }
      /** 1 to 5 April: the days the council convention and the DfE tax year disagree. */ function inAprilWindow(
        date,
      ) {
        const monthDay = date.slice(5);
        return monthDay >= "04-01" && monthDay <= "04-05";
      }
      /**
       * What the DfE tax year reading would have paid for this segment.
       *
       * The payout follows the council convention, because that is what decides what
       * a carer was actually paid. This records the other reading so the difference
       * is visible instead of assumed away. If the previous year is not sourced there
       * is nothing to compare against, and nothing is claimed.
       */ function taxYearAlternative(deps, base, child, age, at, maximumWeekly) {
        // England only, for the same reason the 6 April cut is: nowhere else has a
        // second convention for the alternative to be an alternative TO.
        if (base.carer.nation !== "england" || !inAprilWindow(at)) return null;
        const previous = rateTableFor(deps.rateTables, addDays(at, -7), base.carer.nation);
        if ("blocked" in previous) return null;
        const band = bandAt(previous, base.carer.nation, child, age, at);
        const weekly = lookupRate(previous, base.carer, band, deps);
        return {
          weekly,
          difference: clampMin0(sub(maximumWeekly, weekly)),
        };
      }
      function caveatsFor(blockedYears, aprilBoundaryDifference) {
        const caveats = [...BACKDATING_CAVEATS];
        if (aprilBoundaryDifference > 0) {
          caveats.unshift(
            `Councils normally raise their rates on 1 April and I have used that date. The Department for ` +
              `Education states the same rates on a tax year beginning 6 April. If your council follows the tax ` +
              `year instead, ${formatMoney(aprilBoundaryDifference)} of the figure below would not apply.`,
          );
        }
        if (blockedYears.size > 0) {
          caveats.unshift(
            `I have left out ${[...blockedYears]
              .sort()
              .join(", ")} because I do not yet hold verified rates for ` +
              `${blockedYears.size === 1 ? "that year" : "those years"}. The total below covers only the years I can evidence.`,
          );
        }
        return caveats;
      } // ./components/calculator/MoneyInput.tsx
      //# sourceMappingURL=backdating.js.map

      /* __next_internal_client_entry_do_not_use__ MoneyInput auto */

      /**
       * [§24] inputMode="decimal", NOT type="number", spinners are hostile to screen
       * readers and to shaky hands. Parsing happens once, here, at the boundary (§10).
       *
       * Validates on blur, not on keystroke (§20.1). Never clears the field on error.
       */ function MoneyInput({
        label,
        hint,
        name,
        value,
        onChange,
        required = false,
        error: externalError,
      }) {
        const id = (0, react.useId)();
        const [parseError, setParseError] = (0, react.useState)(null);
        // The typing error wins while it stands: it is about what is in the box now.
        const error = parseError ?? externalError ?? null;
        const validate = (raw) => {
          if (raw.trim() === "") {
            setParseError(required ? "Enter an amount." : null);
            onChange(raw, required ? null : 0);
            return;
          }
          try {
            const p = parseMoney(raw);
            setParseError(null);
            onChange(raw, p);
          } catch {
            setParseError("Enter an amount like 1250 or 1250.50.");
            onChange(raw, null);
          }
        };
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "field",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
              className: "field__label",
              htmlFor: id,
              children: label,
            }),
            hint &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                className: "field__hint",
                id: `${id}-hint`,
                children: hint,
              }),
            error &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                className: "field__error",
                id: `${id}-error`,
                role: "alert",
                children: error,
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("span", {
              className: "money-input",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  "aria-hidden": "true",
                  className: "money-input__prefix",
                  children: "\xa3",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                  id: id,
                  name: name,
                  type: "text",
                  inputMode: "decimal",
                  autoComplete: "off",
                  value: value,
                  "aria-invalid": error ? true : undefined,
                  "aria-describedby":
                    [hint ? `${id}-hint` : null, error ? `${id}-error` : null]
                      .filter(Boolean)
                      .join(" ") || undefined,
                  onChange: (e) => onChange(e.target.value, null),
                  onBlur: (e) => validate(e.target.value),
                }),
              ],
            }),
          ],
        });
      } // ./components/results/BackdatingPanel.tsx

      /* __next_internal_client_entry_do_not_use__ BackdatingPanel auto */

      /**
       * "What should I have been paid since the order?", spec §16.
       *
       * A disclosure rather than another step in the form. Most people come for one
       * number and leave; this is a second, harder question, and putting it in the
       * main flow would make everyone answer it.
       *
       * The period is split at every point the rate could change, each April, each
       * birthday that crosses an age band, the reg 7 two-year anniversary, because a
       * single average rate across two years is exactly the kind of figure a council
       * can pick apart.
       *
       * Where a year has no verified rates, it is left out and said so. A total built
       * partly on a guess is worse than a smaller total that holds up.
       */ /**
       * Turn an engine error into a sentence a carer can act on.
       *
       * The engine refuses rather than guessing, which is right, and its refusals name
       * the reason precisely for whoever has to fix the data. Those are two different
       * audiences. This maps the cases this panel can actually cause and keeps one
       * plain fallback for everything else.
       */ function carerFacing(e) {
        const raw = e instanceof Error ? e.message : "";
        if (/not yet sourced|PENDING_SOURCE|No rate table effective/i.test(raw)) {
          return (
            "I do not hold checked figures for part of that period, so I will not guess at them. " +
            "Try a later start date, or ask your council for its own figures for those years."
          );
        }
        if (/one child at a time|needs a child/i.test(raw)) {
          return "I can only work this out for one child at a time.";
        }
        if (/before its start|before the start/i.test(raw)) {
          return "The end date is before the start date.";
        }
        return "I could not work that period out. Check the dates and try again.";
      }
      function BackdatingPanel({ input }) {
        const fromId = (0, react.useId)();
        const toId = (0, react.useId)();
        const today = new Date().toISOString().slice(0, 10);
        const [from, setFrom] = (0, react.useState)(input.carer.orderDate ?? "");
        const [to, setTo] = (0, react.useState)(today);
        const [paid, setPaid] = (0, react.useState)({
          raw: "",
          pence: 0,
        });
        const [result, setResult] = (0, react.useState)(null);
        const [error, setError] = (0, react.useState)(null);
        // Backdating segments one child's history. Apportioning across several, each
        // with its own birthdays, is not specified, so the engine refuses it.
        //
        // It used to render nothing at all here, so a carer with two children never
        // saw that the question existed, let alone why it was missing. Saying so is
        // better than a silent absence: they can still ask their council, and they
        // now know there is something to ask about.
        if (input.children.length !== 1) {
          return /*#__PURE__*/ (0, jsx_runtime.jsxs)("details", {
            className: "avoid-break gap-lg print-hide",
            children: [
              /*#__PURE__*/ (0, jsx_runtime.jsx)("summary", {
                children: "Were you underpaid in the past?",
              }),
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                children:
                  "If your council has been paying you less than it should have been, you can ask it to make up the difference, and the Ombudsman has told councils to do exactly that.",
              }),
              /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                    children: "I can only work this out for one child at a time.",
                  }),
                  " You have told me about",
                  " ",
                  input.children.length,
                  " children, and each of them has their own birthdays and their own age bands, so a single total across all of them would be a figure your council could pick apart. Rather than give you one I cannot stand behind, I would rather say so.",
                ],
              }),
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "flush-bot",
                children:
                  "You can still ask. The letter asking for a written breakdown, further down this page, covers it, and your council has to explain how it reached each child's figure.",
              }),
            ],
          });
        }
        const run = () => {
          setError(null);
          setResult(null);
          if (!from) {
            setError("Enter the date you want to count from.");
            return;
          }
          if (to < from) {
            setError("The end date is before the start date.");
            return;
          }
          if (paid.pence === null) {
            setError("Enter what you have been paid, or 0 if you have had nothing.");
            return;
          }
          try {
            setResult(
              calculateBackdating({
                base: input,
                fromDate: from,
                toDate: to,
                actuallyPaidWeekly: paid.pence,
              }),
            );
          } catch (e) {
            // Never the raw message. Engine errors are written for maintainers and
            // say things like "No rate table effective on 2019-04-01", sometimes with
            // a spec section number attached. That is not something to put in front
            // of a grandparent who has just typed in two dates.
            setError(carerFacing(e));
          }
        };
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("details", {
          className: "avoid-break gap-lg",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("summary", {
              children: "Were you underpaid in the past?",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "If your council has been paying you less than it should have been, you can ask for the difference. The Ombudsman has ordered councils to backdate payments in real cases.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "Tell me the period and what you have actually been paid, and I will work out the gap year by year.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
              className: "field",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
                  className: "field__label",
                  htmlFor: fromId,
                  children: "Count from",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  className: "field__hint",
                  id: `${fromId}-hint`,
                  children: "Usually the date the special guardianship order was made.",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                  id: fromId,
                  name: "backdate-from",
                  type: "date",
                  value: from,
                  "aria-describedby": `${fromId}-hint`,
                  onChange: (e) => setFrom(e.target.value),
                }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
              className: "field",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
                  className: "field__label",
                  htmlFor: toId,
                  children: "Count until",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  className: "field__hint",
                  id: `${toId}-hint`,
                  children: "Today, unless you are checking a period that has already ended.",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                  id: toId,
                  name: "backdate-to",
                  type: "date",
                  value: to,
                  "aria-describedby": `${toId}-hint`,
                  onChange: (e) => setTo(e.target.value),
                }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(MoneyInput, {
              name: "backdate-paid",
              label: "What the council has actually paid you, per week",
              hint: "If it has paid you nothing, enter 0.",
              value: paid.raw,
              onChange: (raw, pence) =>
                setPaid({
                  raw,
                  pence,
                }),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
              type: "button",
              className: "btn",
              onClick: run,
              children: "Work out the difference",
            }),
            error &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "field__error gap-md",
                role: "alert",
                children: error,
              }),
            result &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(BackdatingResultView, {
                result: result,
              }),
          ],
        });
      }
      function BackdatingResultView({ result }) {
        const nothingOwed = result.shortfall <= 0;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          "aria-live": "polite",
          className: "gap-lg",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h3", {
              children: nothingOwed ? "I cannot see a shortfall" : "The difference",
            }),
            nothingOwed
              ? /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                  children:
                    "Over the period you gave me, what you were paid matches or exceeds the maximum your council should have been starting from. That does not mean nothing is wrong, it means this particular check does not show a gap.",
                })
              : /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                      className: "backdating__figure",
                      children: formatMoney(result.shortfall),
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                      children: [
                        "Your council should have been starting from",
                        " ",
                        formatMoney(result.totalShouldHaveBeenPaid),
                        " across",
                        " ",
                        result.yearsCovered.map((y) => y.replace("-", "/")).join(", "),
                        ". You were actually paid ",
                        formatMoney(result.totalActuallyPaid),
                        ".",
                      ],
                    }),
                  ],
                }),
            result.blockedYears.length > 0 &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                className: "callout",
                role: "note",
                "aria-label": "Years left out",
                children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                  className: "flush",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("strong", {
                      children: [
                        result.blockedYears.map((y) => y.replace("-", "/")).join(" and "),
                        " ",
                        result.blockedYears.length === 1 ? "is" : "are",
                        " not included.",
                      ],
                    }),
                    " ",
                    "I do not hold verified rates for",
                    " ",
                    result.blockedYears.length === 1 ? "that year" : "those years",
                    " in your part of the UK, and I will not estimate them. The figure above covers only the years I can evidence, so the real gap may be larger.",
                  ],
                }),
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(ScrollableTable, {
              label: "Backdating period by period",
              children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("table", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("caption", {
                    className: "sr-only",
                    children: "What you should have been paid, period by period",
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("thead", {
                    children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("tr", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Period",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Weeks",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Age band",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Should have been",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Actually paid",
                        }),
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("th", {
                          scope: "col",
                          children: "Difference",
                        }),
                      ],
                    }),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("tbody", {
                    children: result.segments.map((s, i) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                        "tr",
                        {
                          children: [
                            /*#__PURE__*/ (0, jsx_runtime.jsxs)("th", {
                              scope: "row",
                              className: "table__rowlabel nowrap",
                              children: [
                                formatDate(s.from),
                                " to ",
                                formatDate(s.to),
                                /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
                                  className: "table__note",
                                  children: [
                                    s.financialYear.replace("-", "/"),
                                    " \xb7 ",
                                    reasonLabel(s.reason),
                                  ],
                                }),
                              ],
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: "nowrap",
                              children: s.weeks,
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: "nowrap",
                              children: s.ageBand,
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: "nowrap",
                              children: formatMoney(s.shouldHaveBeenPaidWeekly),
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: "nowrap",
                              children: formatMoney(s.actuallyPaidWeekly),
                            }),
                            /*#__PURE__*/ (0, jsx_runtime.jsx)("td", {
                              className: "nowrap strong",
                              children: formatMoney(s.segmentShortfall),
                            }),
                          ],
                        },
                        i,
                      ),
                    ),
                  }),
                ],
              }),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h4", {
              children: "Before you use this figure",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("ul", {
              children: result.caveats.map((c, i) =>
                /*#__PURE__*/ (0, jsx_runtime.jsx)(
                  "li",
                  {
                    children: c,
                  },
                  i,
                ),
              ),
            }),
          ],
        });
      }
      function formatDate(iso) {
        const [y, m, d] = iso.split("-");
        return `${d}/${m}/${y}`;
      }
      function reasonLabel(reason) {
        switch (reason) {
          case "financial-year-change":
            return "rates changed on 1 April";
          case "age-band-change":
            return "moved up an age band";
          case "reg7-anniversary":
            return "the two-year point passed";
          case "april-tax-year-boundary":
            return "the tax year began";
          case "period-start":
            return "start of the period";
          default:
            return "end of the period";
        }
      } // ../../packages/letters/dist/templates.js

      /**
       * The nine letters, spec §18.
       *
       * This file is prose, not logic. It is kept apart from the module's code so a
       * change to how letters are generated cannot touch a word of what they say, and
       * so a solicitor reviewing the wording has one file to read.
       *
       * Copy rules, from the spec, and they matter more than the templating:
       *  - Polite, short, specific. These go to a social worker the carer has an
       *    ongoing relationship with. An aggressive letter damages that relationship
       *    and the child's placement.
       *  - Always request, never demand or threaten.
       *  - Cite the regulation or decision in one line, not a legal essay.
       *  - Never assert the council has broken the law. Assert what the guidance and
       *    the decisions say, and ask them to confirm their position.
       *  - Leave [YOUR NAME], [CHILD'S NAME], [REFERENCE] as visible placeholders.
       *
       * Gate 18 in scripts/gates/claims.ts reads this file and fails the build on a
       * letter that cites nothing.
       */
      const templates_REGION_LABEL = {
        london: "London",
        "south-east": "the South East",
        "rest-of-england": "the rest of England",
      };
      const PLACEHOLDER_NAME = "[YOUR NAME]";
      const PLACEHOLDER_CHILD = "[CHILD'S NAME]";
      const PLACEHOLDER_REF = "[REFERENCE]";
      const to = (ctx) =>
        ctx.councilName
          ? `Dear ${ctx.councilName} Children's Services,`
          : "Dear Children's Services,";
      const signOff = () =>
        `Thank you for your help.\n\nYours sincerely,\n\n${PLACEHOLDER_NAME}\nSpecial guardian for ${PLACEHOLDER_CHILD}\nReference: ${PLACEHOLDER_REF}`;
      /**
       * What the carer was paid before the order, if they told me.
       *
       * Only in the three letters where the old fostering rate is part of the
       * argument: challenging a fixed percentage, asking which element was reduced,
       * and asking for the reward element to continue. It used to appear in eight of
       * the nine, including the complaint, where it sat between the complaint itself
       * and the list of what happened and did no work at all.
       *
       * Stated as the past fact it is. This figure is their FOSTERING allowance from
       * before the order, so writing "I currently receive" put a false sentence in
       * every letter: a former foster carer may be receiving nothing now, and the
       * council knows what it pays them.
       */ const paidLine = (ctx) =>
        ctx.previousFosteringWeekly === undefined
          ? ""
          : `Before the order was made I was paid ${formatMoney(ctx.previousFosteringWeekly)} a week in total as a foster carer.\n\n`;
      /**
       * The order date as a person would write it.
       *
       * The date arrives as an ISO string because that is what the engine works in,
       * and it was going straight into the letter: "the order was made on
       * 2025-01-15". In a letter from a grandmother to her council that reads like a
       * database record, which is the opposite of the impression the letter is
       * trying to make.
       */ const onOrderDate = (ctx) => {
        if (!ctx.orderDate) return "";
        const d = new Date(`${ctx.orderDate}T00:00:00Z`);
        if (Number.isNaN(d.getTime())) return ` on ${ctx.orderDate}`;
        return ` on ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
      };
      const MONTHS = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ];
      const templates_LETTER_TEMPLATES = {
        "challenge-child-benefit-deduction": {
          title: "Ask about Child Benefit being taken off your allowance",
          subject: () =>
            `Special guardianship allowance. Child Benefit deduction, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}. ` +
            "I understand that Child Benefit is being taken into account when my special guardianship allowance is worked out. I would be grateful if you could confirm in writing:\n\n" +
            "1. whether Child Benefit is deducted from my allowance, and if so how much;\n" +
            "2. whether your policy deducts Child Benefit from carers who receive means-tested benefits; and\n" +
            "3. how that was decided in my case.\n\n" +
            (ctx.onMeansTestedBenefits
              ? "I receive means-tested benefits. In 2024 the Local Government and Social Care Ombudsman found that deducting Child Benefit as a blanket rule from carers in that position was not appropriate, and asked the council concerned to recalculate its awards. I would be grateful if you could confirm how your policy takes that decision into account.\n\n"
              : "I would also be grateful if you could send me the part of your policy that covers this.\n\n") + // Concedes nothing the council would not say in its first reply, and moves
            // the exchange straight onto the ground the carer can actually win on.
            "I understand the regulations allow Child Benefit to be taken into account. I am asking how that was decided in my case, rather than whether it is permitted.\n\n" +
            signOff(),
          citationIds: ["lgsco-devon-2024", "sg-regs-2005-reg13", "sg-regs-2005-reg6"],
          suggestedBy: ["UNLAWFUL_CB_DEDUCTION_RISK"],
        },
        "challenge-fixed-percentage": {
          title:
            "Ask how your allowance was calculated, where a percentage seems to have been used",
          subject: () =>
            `Special guardianship allowance, how my allowance was calculated, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}. ${paidLine(ctx)}` + // Attributed, so the carer is quoting a published source rather than
            // asserting a number of ours. If our rate data or region mapping were ever
            // wrong, an unattributed figure would cost them credibility on their
            // strongest point.
            `My understanding is that the national minimum fostering allowance published by the Department for Education for a child in the ${ctx.childAgeBand} age band in ${templates_REGION_LABEL[ctx.region]} is ${formatMoney(ctx.nmaWeekly)} a week, and that the statutory guidance treats the core fostering allowance as the starting point for a special guardianship allowance.\n\n` +
            "Please could you tell me:\n\n" +
            "1. what figure you used as the starting point for my allowance;\n" +
            "2. whether a fixed percentage or proportion was applied at any stage; and\n" +
            "3. what was taken into account about my circumstances and my child's needs.\n\n" +
            "I ask because the courts have said that applying a flat percentage of the fostering allowance, without considering the individual case, is a departure from the guidance that needs to be justified. I would like to understand how the figure in my case was reached.\n\n" +
            signOff(),
          citationIds: ["kirklees-2010", "merton-2012", "dfe-guidance-2017-para65"],
          suggestedBy: ["FIXED_PERCENTAGE_POLICY", "BELOW_NMA"],
        },
        // Two letters, because one was doing two jobs badly. A carer whose whole
        // allowance is being stepped down was being handed the extension letter,
        // which never asks the tapering question and whose second question accepts
        // that the allowance will drop. That gave away the strongest argument they
        // had. See REG7_MISAPPLICATION_WARNING and the Southend decision.
        "ask-which-element-reduced": {
          title: "Ask which part of your allowance is being reduced",
          subject: () =>
            `Special guardianship allowance, how it is being reduced, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}, and I was ${PLACEHOLDER_CHILD}'s foster carer before the special guardianship order was made` +
            onOrderDate(ctx) +
            `. ${paidLine(ctx)}` +
            "My payments are being reduced, and I would like to understand exactly what is being reduced and why. Please could you confirm:\n\n" +
            "1. which element of my allowance is being reduced, and by how much;\n" +
            "2. the basis on which that reduction is being made; and\n" +
            "3. if regulation 7 is being relied on, how it is being applied in my case.\n\n" +
            "I ask because regulation 7 concerns the reward element of a former foster carer's allowance. The Ombudsman found in 2020 that reducing an entire allowance in stages misapplied that rule. I would like to understand which of these applies to my payments.\n\n" +
            signOff(),
          citationIds: ["sg-regs-2005-reg7", "lgsco-southend-2020"],
          suggestedBy: ["REG7_MISAPPLICATION_WARNING"],
        },
        "request-reg7-extension": {
          title: "Ask for the reward element to continue past two years",
          subject: () =>
            `Special guardianship allowance, continuing the reward element, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}, and I was ${PLACEHOLDER_CHILD}'s foster carer before the special guardianship order was made` +
            onOrderDate(ctx) +
            `. ${paidLine(ctx)}` + // Regulation 7 is a power, not an entitlement. Opening with "is protected"
            // hands the council an easy correction and weakens everything after it.
            // Two things the earlier draft got wrong, both from the review of
            // 2 September. Regulation 7 only applies at all where the decision to
            // include remuneration was taken BEFORE the order, so that is a threshold
            // question and it comes first. And the continuation test is exceptional
            // needs or other exceptional circumstances, not "the needs have not
            // reduced", which is a request that fails on its own terms.
            "I understand that your council can continue paying the reward element of my former fostering allowance for two years after the order, and beyond that where it considers continuation necessary because of the exceptional needs of the child or other exceptional circumstances.\n\n" +
            "I would be grateful if you could confirm:\n\n" +
            "1. whether the decision to include an element of remuneration in my financial support was taken before the special guardianship order was made;\n" +
            "2. the date on which the two-year period ends;\n" +
            "3. how I should ask for the reward element to continue beyond it; and\n" +
            "4. what you would consider to be exceptional needs or exceptional circumstances in a case like mine.\n\n" +
            `I would like to set out the particular needs and circumstances in ${PLACEHOLDER_CHILD}'s case. Please let me know what information would help you decide.\n\n` +
            signOff(),
          citationIds: ["sg-regs-2005-reg7", "tower-hamlets-2013"],
          suggestedBy: ["REG7_EXPIRING", "REG7_EXTENSION_AVAILABLE", "REG7_FLOOR_APPLIED"],
        },
        "request-enhancement-disability": {
          title: "Ask for more because of your child's needs",
          subject: () =>
            `Special guardianship allowance, request for an enhancement, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}. ` +
            "The regulations allow financial support to take account of a child's disability or additional needs, including the consequences of any abuse or neglect they experienced before the order.\n\n" +
            `${PLACEHOLDER_CHILD} has additional needs which mean extra costs for our household. In particular:\n\n` +
            "  • [describe the need, e.g. travel to therapy appointments]\n" +
            "  • [describe the cost, e.g. £__ a month]\n" +
            "  • [add as many as apply]\n\n" +
            "I would be grateful if you could assess whether an enhancement to my allowance would be appropriate, and let me know what evidence would help.\n\n" +
            signOff(),
          citationIds: ["sg-regs-2005-reg6-2-b"],
          suggestedBy: ["ENHANCEMENT_AVAILABLE"],
        },
        "request-written-policy": {
          title: "Ask for your council's written policy",
          obtains: "your council's written policy",
          subject: () =>
            `Request for your special guardianship financial support policy, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}.\n\n` +
            "Please could you send me a copy of your current policy on financial support for special guardians, including:\n\n" +
            "1. how the starting figure for an allowance is decided;\n" +
            "2. how any means test is applied, and what income is taken into account;\n" +
            "3. whether Child Benefit is taken into account; and\n" +
            "4. how allowances are reviewed each year.\n\n" +
            "A link to the published version is fine if it is on your website.\n\n" +
            signOff(),
          citationIds: ["sg-regs-2005-reg6", "dfe-guidance-2017-para65"],
          suggestedBy: ["COUNCIL_POLICY_UNKNOWN"],
        },
        "request-calculation-breakdown": {
          title: "Ask for the arithmetic behind your figure",
          obtains: "the arithmetic behind your figure",
          subject: () =>
            `Special guardianship allowance, request for a breakdown, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}. ` + // Always "my allowance". The only figure the letter can quote is the old
            // fostering allowance, and the breakdown being asked for is of the
            // CURRENT allowance, so "that figure" pointed at the wrong number.
            "I would be grateful for a written breakdown of how my allowance was calculated, showing:\n\n" +
            "1. the starting figure and where it came from;\n" +
            "2. what income was taken into account, and what was disregarded;\n" +
            "3. what outgoings were allowed; and\n" +
            "4. any deductions, and the reason for each.\n\n" +
            `For reference, the national minimum fostering allowance for the ${ctx.childAgeBand} age band in ${templates_REGION_LABEL[ctx.region]} is ${formatMoney(ctx.nmaWeekly)} a week.\n\n` +
            signOff(),
          citationIds: ["sg-regs-2005-reg6", "dfe-guidance-2017-para65"],
          suggestedBy: ["MEANS_TEST_MODEL_OUTDATED", "TAPER_METHOD_ASSUMED"],
        },
        "request-annual-review": {
          title: "Ask for your annual review",
          subject: () => `Special guardianship allowance, annual review, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I am the special guardian for ${PLACEHOLDER_CHILD}. ` + // The duty is triggered by receipt of the annual statement, not by twelve
            // months passing. A carer who has never been asked for one is not late for
            // a review: the council has not set up the thing that produces it.
            "I understand that my financial support should be reviewed when you receive my annual statement of circumstances, and that the national minimum allowance rates changed in April.\n\n" +
            "Please could you confirm:\n\n" +
            "1. whether you have asked me for an annual statement of my circumstances, and if not, whether you would like one now;\n" +
            "2. when my financial support was last reviewed; and\n" +
            "3. what information you need from me so that a review can take place.\n\n" +
            signOff(),
          citationIds: ["sg-regs-2005-reg18", "sg-regs-2005-reg10"],
          suggestedBy: ["ANNUAL_REVIEW_DUE", "RATES_STALE"],
        },
        "formal-complaint-stage-1": {
          title: "Make a stage 1 complaint",
          subject: () =>
            `Stage 1 complaint, special guardianship allowance, ref ${PLACEHOLDER_REF}`,
          body: (ctx) =>
            `${to(ctx)}\n\n` +
            `I would like to make a stage 1 complaint about the way my special guardianship allowance for ${PLACEHOLDER_CHILD} has been handled. ` +
            "What happened:\n\n" +
            "  • [what you asked for, and when]\n" +
            "  • [what the council did or did not do]\n" +
            "  • [what effect it has had on you and your child]\n\n" +
            "What I would like to happen:\n\n" +
            "  • [e.g. a written explanation of how the figure was calculated]\n" +
            "  • [e.g. a reassessment]\n\n" + // A bracket inside a bracket, with an instruction to the reader buried in a
            // sentence addressed to the council. The sentence to send and the note
            // about whether to send it are now separate lines.
            "I raised this on [DATE] and have not had a full answer.\n" +
            "[Delete the line above if you have not raised it before.]\n\n" +
            "I am asking for it to be looked at under your complaints procedure. Please confirm you have received this and let me know when I can expect a reply.\n\n" +
            "If I am not satisfied with the outcome, I understand I can ask the Local Government and Social Care Ombudsman to look at it.\n\n" +
            signOff(),
          citationIds: ["sg-regs-2005-reg6"],
          // Deliberately empty. A published decision about a different carer is not a
          // reason for this carer to complain, and this site's own warning says so.
          // Promoting a formal complaint on the strength of it sent carers into the
          // process without the evidence to make it stick.
          suggestedBy: [],
          requiresFirst: ["request-written-policy", "request-calculation-breakdown"],
          // ONE exception, from the review of 2 September, for whoever builds the
          // letters screen. The Ombudsman normally expects a complaint within twelve
          // months of the carer becoming aware of the problem. Where a carer says the
          // problem has been running close to or beyond that, the gate could cost them
          // the complaint altogether, which is the one case where slowing someone down
          // does real harm. Surface the time limit and let them through, with a note
          // that they can complain now and supply the documents afterwards. A narrow
          // exception to a good rule, not a loosening of it.
          gateExceptionNearTimeLimit: true,
        },
      }; //# sourceMappingURL=templates.js.map
      // ../../packages/letters/dist/index.js

      /**
       * @sgo/letters, spec §18.
       *
       * Template letters, pre-filled with the carer's own figures. The wording lives
       * in templates.ts; this file is only the code that picks one, fills it in and
       * turns it into text.
       */

      /**
       * The order letters are offered in, most useful first.
       *
       * It follows the flag catalogue's own severity order in the engine: the Child
       * Benefit deduction first, then the policy challenges, then the requests, then
       * the complaint.
       */ const PRIORITY = [
        "challenge-child-benefit-deduction",
        "challenge-fixed-percentage",
        "ask-which-element-reduced",
        "request-reg7-extension",
        "request-enhancement-disability",
        "request-calculation-breakdown",
        "request-written-policy",
        "request-annual-review",
        "formal-complaint-stage-1",
      ];
      function generateLetter(template, ctx) {
        const spec = templates_LETTER_TEMPLATES[template];
        return {
          template,
          subject: spec.subject(ctx),
          body: spec.body(ctx),
          citations: spec.citationIds.map(cite),
        };
      }
      /**
       * Which letters to offer, given the flags that fired (spec §18).
       *
       * Letters whose trigger fired come first, then the rest, each group in priority
       * order. A letter with prerequisites is never promoted, whatever fired: it sits
       * at the end until the carer says they have already asked the questions it
       * assumes they asked.
       */ function suggestLetters(flagsRaised) {
        const raised = new Set(flagsRaised);
        const templates = Object.keys(templates_LETTER_TEMPLATES);
        const byPriority = (a, b) => PRIORITY.indexOf(a) - PRIORITY.indexOf(b);
        const triggered = (t) =>
          templates_LETTER_TEMPLATES[t].suggestedBy.some((f) => raised.has(f));
        const gated = (t) => (templates_LETTER_TEMPLATES[t].requiresFirst ?? []).length > 0;
        const ordered = [
          ...templates.filter(triggered).sort(byPriority),
          ...templates.filter((t) => !triggered(t)).sort(byPriority),
        ];
        return [...ordered.filter((t) => !gated(t)), ...ordered.filter(gated)];
      }
      /**
       * What a carer must already HOLD before this letter is worth sending. Empty for
       * every letter but the formal complaint.
       *
       * Noun phrases, not titles. The titles are imperatives, so the sentence that
       * uses this read "a complaint made before you hold ask for your council's
       * written policy and ask for the arithmetic behind your figure". The title is
       * kept as the fallback, so a letter added to a requiresFirst list without an
       * `obtains` still reads as something rather than nothing.
       */ function lettersRequiredFirst(t) {
        return (templates_LETTER_TEMPLATES[t].requiresFirst ?? []).map(
          (r) => templates_LETTER_TEMPLATES[r].obtains ?? templates_LETTER_TEMPLATES[r].title,
        );
      }
      function letterTitle(t) {
        return LETTER_TEMPLATES[t].title;
      }
      /** A .txt download: subject line, then the body. No email client required. */ function letterAsPlainText(
        letter,
      ) {
        const sources = letter.citations
          .map((c) => `  ${c.label}${c.url ? `\n    ${c.url}` : ""}`)
          .join("\n");
        return (
          `Subject: ${letter.subject}\n\n${letter.body}\n\n` +
          `---\nWho to send this to:\n` +
          "  For the first three years after the order, the council that looked after the child stays\n" +
          "  responsible, even if you have moved away. After that it is usually the council where you\n" +
          "  live. See /guidance/which-council-is-responsible if you are not sure.\n\n" +
          `What this letter refers to:\n${sources}\n\n` +
          "This letter was prepared using an online estimate. It is not legal advice.\n"
        );
      } //# sourceMappingURL=index.js.map
      // ./components/ui/useCopyToClipboard.ts

      /* __next_internal_client_entry_do_not_use__ useCopyToClipboard auto */
      /**
       * Copy text, and always say what happened.
       *
       * Both copy buttons on this site were written the same wrong way: a refused
       * clipboard set the flag back to false, and the status line rendered nothing,
       * so the button appeared to do absolutely nothing. That is the worst possible
       * answer on a page whose whole job is handing a carer something to send. It was
       * fixed once, in the letters, and left standing in the share control, which is
       * why the logic now lives in one place instead of two.
       *
       * The clipboard is refused more often than it looks: an insecure origin, a
       * locked-down browser, or a device that simply does not grant it. None of that
       * is the carer's fault and none of it should look like a broken page.
       */ function useCopyToClipboard() {
        const [state, setState] = (0, react.useState)("idle");
        // Clear the confirmation after a while, so it belongs to the press that
        // caused it rather than sitting there for the rest of the session.
        (0, react.useEffect)(() => {
          if (state === "idle") return;
          const t = setTimeout(() => setState("idle"), 8000);
          return () => clearTimeout(t);
        }, [state]);
        const copy = (0, react.useCallback)((text) => {
          const writer = navigator.clipboard?.writeText(text);
          if (!writer) {
            setState("failed");
            return;
          }
          void writer.then(
            () => setState("done"),
            () => setState("failed"),
          );
        }, []);
        return {
          state,
          copy,
        };
      } // ./components/results/LettersPanel.tsx

      /* __next_internal_client_entry_do_not_use__ LettersPanel auto */
      /**
       * The letters, spec §18.
       *
       * The point of the whole calculator is not the number. It is a carer who knows
       * what to ask and has the words to ask it, so this is where the sourcing work
       * pays off: every letter arrives already carrying this carer's council, region,
       * age band and figure.
       *
       * Deliberately small. It renders text, copies it, and downloads it. There is no
       * account, nothing is saved, and nothing is sent on the carer's behalf. The
       * carer sends their own letter from their own email, which is also the only way
       * the reply reaches them.
       */

      /** Why this letter is being offered, in one line, from the warning that fired. */ const REASON =
        {
          "challenge-child-benefit-deduction":
            "Your council takes Child Benefit off your allowance, and you are on means-tested benefits.",
          "challenge-fixed-percentage":
            "Your council appears to pay a fixed share of the fostering rate.",
          "ask-which-element-reduced": "Your allowance is being stepped down.",
          "request-reg7-extension": "You fostered this child before the order.",
          "request-enhancement-disability":
            "You told me your child has a disability or additional needs.",
          "request-calculation-breakdown":
            "You have not been shown how your figure was worked out.",
          "request-written-policy": "Everything else rests on this document.",
          "request-annual-review": "Your allowance may not have been reviewed recently.",
          "formal-complaint-stage-1":
            "Only once you have asked for the policy and the breakdown and been answered badly, or not at all.",
        };
      /**
       * The Ombudsman normally expects a complaint within twelve months of the carer
       * becoming aware of a problem. Past this many months, the gate on the formal
       * complaint does more harm than good, so it lifts and says why.
       */ const OMBUDSMAN_MONTHS = 12;
      function LettersPanel({ result, input, councilName }) {
        const ctx = {
          ...(councilName
            ? {
                councilName,
              }
            : {}),
          childAgeBand: result.perChild[0]?.ageBand ?? "",
          region: input.carer.englandRegion ?? "rest-of-england",
          nmaWeekly: result.perChild[0]?.maximumWeekly ?? 0,
          ...(input.carer.previousWeeklyFosteringAllowance !== undefined
            ? {
                previousFosteringWeekly: input.carer.previousWeeklyFosteringAllowance,
              }
            : {}),
          onMeansTestedBenefits: input.carer.onMeansTestedBenefits,
          wasFosterCarer: input.carer.wasFosterCarerForThisChild,
          ...(input.carer.orderDate
            ? {
                orderDate: input.carer.orderDate,
              }
            : {}),
          flagsRaised: result.flags.map((f) => f.code),
        };
        // Long-running problems are the one case where holding a carer back can cost
        // them the complaint altogether.
        // Only when we actually know. Lifting the gate on an unknown would push a
        // carer straight to a formal complaint with nothing attached to it.
        const nearTimeLimit =
          input.carer.monthsSinceOrderMade !== undefined &&
          input.carer.monthsSinceOrderMade >= OMBUDSMAN_MONTHS;
        const templates = suggestLetters(ctx.flagsRaised);
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          className: "section print-hide",
          "aria-labelledby": "letters-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "letters-heading",
              children: "Letters you can send",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "lede",
              children:
                "Each one is already filled in with your council, your area and your figure. Copy it, change anything you want, and send it from your own email.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "muted small",
              children:
                "Keep them short and polite. These go to a social worker you will be dealing with for years, and a letter that asks a clear question gets a better answer than one that accuses.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("ol", {
              className: "letters",
              children: templates.map((template) =>
                /*#__PURE__*/ (0, jsx_runtime.jsx)(
                  "li",
                  {
                    children: /*#__PURE__*/ (0, jsx_runtime.jsx)(Letter, {
                      template: template,
                      ctx: ctx,
                      nearTimeLimit: nearTimeLimit,
                    }),
                  },
                  template,
                ),
              ),
            }),
          ],
        });
      }
      function Letter({ template, ctx, nearTimeLimit }) {
        const [open, setOpen] = (0, react.useState)(false);
        const { state: copied, copy } = useCopyToClipboard();
        const spec = templates_LETTER_TEMPLATES[template];
        const letter = generateLetter(template, ctx);
        const text = letterAsPlainText(letter);
        const prerequisites = lettersRequiredFirst(template);
        // The gate lifts near the Ombudsman's time limit, because waiting can cost
        // the carer the complaint entirely. It says so rather than silently opening.
        const gated = prerequisites.length > 0;
        const lifted = gated && Boolean(spec.gateExceptionNearTimeLimit) && nearTimeLimit;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "letter",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h3", {
              className: "letter__title",
              children: spec.title,
            }),
            REASON[template] &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "letter__why muted",
                children: REASON[template],
              }),
            gated &&
              !lifted &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                className: "callout callout--important",
                role: "note",
                "aria-label": "Send these first",
                children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                  className: "flush",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Send these first.",
                    }),
                    " A complaint made before you hold ",
                    joinAnd(prerequisites),
                    " ",
                    "has no documents attached, is easy to answer with a general reassurance, and starts a formal clock you cannot restart. Use it once you have asked and been answered badly, or not at all.",
                  ],
                }),
              }),
            lifted &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                className: "callout callout--critical",
                role: "note",
                "aria-label": "Time limit",
                children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                  className: "flush",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Do not wait for this one.",
                    }),
                    " The Ombudsman normally expects a complaint within 12 months of you becoming aware of a problem, and yours has been running longer than that. You can complain now and supply ",
                    joinAnd(prerequisites),
                    " afterwards. Ask for them at the same time.",
                  ],
                }),
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
              type: "button",
              className: "btn btn--secondary",
              "aria-expanded": open,
              onClick: () => setOpen((o) => !o),
              children: open ? "Hide this letter" : "Read this letter",
            }),
            open &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("pre", {
                    className: "letter__body",
                    tabIndex: 0,
                    "aria-label": `${spec.title}, full text`,
                    children: text,
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
                    className: "row gap-lg",
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
                        type: "button",
                        className: "btn",
                        onClick: () => copy(text),
                        children: "Copy the whole letter",
                      }),
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(DownloadLink, {
                        template: template,
                        text: text,
                      }),
                    ],
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                    "aria-live": "polite",
                    className: "share__status",
                    children: [
                      copied === "done" && "Letter copied. Paste it into an email.",
                      copied === "failed" &&
                        "Your browser would not let me copy it. Select the letter above and copy it yourself, or use Download as a file.",
                    ],
                  }),
                ],
              }),
          ],
        });
      }
      /**
       * A .txt download, built in the browser.
       *
       * An object URL rather than a data: URI, because the site's own CSP does not
       * allow data: navigations and a carer clicking a dead link would have no idea
       * why. Created on click and revoked afterwards so nothing leaks.
       */ function DownloadLink({ template, text }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
          type: "button",
          className: "btn btn--secondary",
          onClick: () => {
            const url = URL.createObjectURL(
              new Blob([text], {
                type: "text/plain;charset=utf-8",
              }),
            );
            const a = document.createElement("a");
            a.href = url;
            a.download = `${template}.txt`;
            // Attached before the click, and the URL revoked on a later tick.
            // Revoking on the very next line cancelled the download before it
            // started in Safari and older Firefox, and a detached anchor is
            // ignored outright by some browsers. Nothing visible happened, which
            // this suite could not catch because it only ran Chromium.
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 60000);
          },
          children: "Download as a file",
        });
      }
      /** "the written policy and the calculation breakdown" */ function joinAnd(titles) {
        const lower = titles.map((t) => t.charAt(0).toLowerCase() + t.slice(1));
        if (lower.length <= 1) return lower[0] ?? "";
        return `${lower.slice(0, -1).join(", ")} and ${lower[lower.length - 1]}`;
      } // ./components/results/NextSteps.tsx

      /**
       * Five numbered steps, each linking to the relevant guidance page (spec §21
       * item 6). The steps adapt to what actually fired, so a former foster carer and
       * a first-time special guardian do not get the same list.
       */ function NextSteps({ result }) {
        const has = (code) => result.flags.some((f) => f.code === code);
        const scotland = result.regime === "scotland-kinship";
        const steps = [];
        steps.push({
          title: "Ask for your council’s written policy",
          // Was "Councils must have a published policy", with nothing behind it. The
          // same sentence was removed from the COUNCIL_POLICY_UNKNOWN warning after
          // the legal review of 1 September; this copy of it lives on the result page
          // and so was not in the packs the reviewer was given. What is on record is
          // the October 2024 duty to publish a kinship local offer.
          body: "Every council in England has to publish a kinship local offer setting out the support it provides. It is the document every later question rests on.",
          href: "/guidance/asking-for-the-policy",
        });
        steps.push({
          title: "Ask for the calculation in writing",
          body: "Ask how your figure was worked out: the starting point, what income counted, what outgoings were allowed, and every deduction with its reason.",
          href: scotland ? "/guidance/scotland-kinship-care" : "/guidance/how-the-means-test-works",
        });
        if (has("UNLAWFUL_CB_DEDUCTION_RISK")) {
          steps.push({
            title: "Query the Child Benefit deduction",
            // The regulations permit the deduction. Saying only that the Ombudsman
            // found one wrong points the carer at a question they cannot win.
            body: "The regulations allow a council to take Child Benefit into account, so the question is not whether yours may. It is whether it decided your case individually. The Ombudsman found a council at fault for applying the same rule to everybody.",
            href: "/guidance/child-benefit-deduction",
          });
        }
        if (has("REG7_FLOOR_APPLIED") || has("REG7_EXPIRING") || has("REG7_EXTENSION_AVAILABLE")) {
          steps.push({
            title: "Ask about the two-year point",
            body: "As a former foster carer, your council can carry on paying the reward part of your fostering allowance for two years, and for longer if it considers that appropriate. Nothing about that is automatic in either direction, so it is worth asking.",
            href: "/guidance/former-foster-carers",
          });
        }
        if (has("ENHANCEMENT_AVAILABLE")) {
          steps.push({
            title: "Ask for more because of your child's needs",
            body: "There is no national figure for this, so it will not appear in any estimate. But the regulations allow it and you have to ask.",
            href: "/guidance/enhancements-for-additional-needs",
          });
        }
        if (has("KINSHIP_ZONE_ELIGIBLE") || has("KINSHIP_ZONE_EXCLUDED_REG6")) {
          steps.push({
            title: "Ask whether the Kinship Zones pilot applies to you",
            body: "Your council is one of seven in the pilot. The pilot rate is not means tested.",
            href: "/guidance/kinship-zones",
          });
        }
        steps.push({
          title: "Print this page and take it with you",
          body: "A printed page with the figures, the arithmetic and the sources on it is far harder to wave away than a conversation.",
          href: "#print",
        });
        steps.push({
          title: "If you get nowhere, complain, then go to the Ombudsman",
          body: "Use your council’s complaints procedure first. If you are still not satisfied, the Ombudsman can look at it, and has ordered councils to backdate payments.",
          href: "/guidance/complaining-to-the-ombudsman",
        });
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          "aria-labelledby": "next-steps-heading",
          className: "avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "next-steps-heading",
              children: "What to do next",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("ol", {
              children: steps.slice(0, 6).map((s, i) =>
                /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                  "li",
                  {
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                        children: s.title,
                      }),
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                        children: s.body,
                      }),
                      !s.href.startsWith("#") &&
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                          href: s.href,
                          children: "Read the guide",
                        }),
                    ],
                  },
                  i,
                ),
              ),
            }),
          ],
        });
      } // ./components/results/PrintButton.tsx

      /* __next_internal_client_entry_do_not_use__ PrintButton auto */
      /**
       * "The single most important call to action on the page" (spec §21 item 8).
       *
       * Print stylesheet first, PDF library second (§19): window.print() plus a
       * well-built print.css gets 90% of the value at 5% of the cost, and works with
       * the browser's own "Save as PDF".
       */ function PrintButton() {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          id: "print",
          className: "print-hide gap-xl",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
              type: "button",
              className: "btn",
              onClick: () => window.print(),
              children: "Print this, or save it as a PDF",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "gap-md muted",
              children:
                "The printed version has your figures, the full arithmetic and every source on it, ready to hand to your social worker. In the print dialogue, choose “Save as PDF” if you would rather email it.",
            }),
          ],
        });
      } // ./components/ui/SourceLink.tsx

      /**
       * A citation, with its URL and retrieval date. [R3] Every numeric output
       * carries the citation it derives from.
       *
       * Where a citation has no URL yet, we say so plainly rather than rendering a
       * dead link, an unsourced claim looks worse than an acknowledged gap, and the
       * gap is tracked (spec §42 item 9).
       */ function SourceLink({ citation }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("span", {
          children: [
            citation.url
              ? /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                  href: citation.url,
                  rel: "noopener",
                  children: citation.label,
                })
              : /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  children: citation.label,
                }),
            " ",
            /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
              className: "muted small",
              children: citation.url
                ? /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                      "(checked ",
                      citation.retrieved,
                      citation.archivedFrom
                        ? ", shown from the web archive because the original address no longer responds"
                        : "",
                      ")",
                    ],
                  })
                : /*#__PURE__*/ (0, jsx_runtime.jsx)(jsx_runtime.Fragment, {
                    children: "(I am still sourcing a public link for this)",
                  }),
            }),
          ],
        });
      }
      function CitationsList({ citations }) {
        const unique = Array.from(new Map(citations.map((c) => [c.id, c])).values());
        if (unique.length === 0) return null;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          className: "avoid-break",
          "aria-labelledby": "citations-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "citations-heading",
              children: "Where these figures and rules come from",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("ul", {
              children: unique.map((c) =>
                /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                  "li",
                  {
                    className: "citation-item",
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(SourceLink, {
                        citation: c,
                      }),
                      c.holding &&
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                          className: "muted gap-sm",
                          children: c.holding,
                        }),
                    ],
                  },
                  c.id,
                ),
              ),
            }),
          ],
        });
      } // ./components/ui/Markdown.tsx

      /**
       * A deliberately tiny Markdown renderer for flag bodies.
       *
       * Flag copy is authored in this repository, reviewed alongside the legal copy,
       * and uses only paragraphs, bold and inline links. Pulling in a full Markdown
       * pipeline for that would cost more than the calculator route's entire JS
       * budget (§31) and would add an HTML-injection surface for no gain.
       *
       * It renders text as text: nothing here interprets raw HTML.
       */ function Markdown({ children }) {
        const paragraphs = children.split("\n\n").filter((p) => p.trim().length > 0);
        return /*#__PURE__*/ (0, jsx_runtime.jsx)(jsx_runtime.Fragment, {
          children: paragraphs.map((para, i) =>
            /*#__PURE__*/ (0, jsx_runtime.jsx)(
              "p",
              {
                className: "md-para",
                children: inline(para),
              },
              i,
            ),
          ),
        });
      }
      /** Handles **bold** only; everything else is literal text. */ function inline(text) {
        const out = [];
        const parts = text.split(/(\*\*[^*]+\*\*)/g);
        parts.forEach((part, i) => {
          if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
            out.push(
              /*#__PURE__*/ (0, jsx_runtime.jsx)(
                "strong",
                {
                  children: part.slice(2, -2),
                },
                i,
              ),
            );
          } else if (part.length > 0) {
            out.push(part);
          }
        });
        return out;
      } // ./components/flags/FlagCard.tsx

      /**
       * One point, set as prose rather than as a card.
       *
       * The severity is carried by the section heading above (see FlagList), so this
       * needs no chip, no icon and no border of its own. What is left is what a reader
       * actually wants: a bold line saying what the point is, the explanation indented
       * under it, and the source.
       *
       * Kept in a file still named FlagCard.tsx so the print stylesheet's `.flag-card`
       * page-break rule keeps working; the class is applied below for that reason.
       */ function FlagItem({ flag }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "flag-item flag-card avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h4", {
              className: "flag-item__title",
              children: flag.title,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
              className: "flag-item__body",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)(Markdown, {
                  children: flag.body,
                }),
                flag.citation &&
                  /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                    className: "flag-item__source",
                    children: [
                      "Source: ",
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(SourceLink, {
                        citation: flag.citation,
                      }),
                    ],
                  }),
                flag.actionUrl &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                    className: "flag-item__action",
                    children: /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                      href: flag.actionUrl,
                      children: "Read more about this",
                    }),
                  }),
              ],
            }),
          ],
        });
      } // ./components/flags/FlagList.tsx

      /**
       * One heading, then sections under it.
       *
       * Every flag used to be its own bordered card. A typical result raises seven or
       * eight, most of them informational, so the page became a stack of near
       * identical boxes each shouting WORTH KNOWING, and the two that genuinely
       * mattered were lost among them. Emphasis applied everywhere is emphasis
       * nowhere.
       *
       * Now the severity is a section heading, said once, and the items below it read
       * as ordinary prose. §23 forbids signalling severity by colour alone; the
       * heading carries it in words, which is a stronger guarantee than the coloured
       * chip it replaces.
       *
       * Flags arrive already sorted by the engine (critical, important, info, then by
       * financial impact within a severity). This does not re-sort them: the ordering
       * is a legal-content decision, made once, in the engine.
       */ const GROUPS = [
        {
          severity: "critical",
          heading: "Check these first",
          blurb:
            "Each of these has been found wrong in a published decision. The source is on the card.",
        },
        {
          severity: "important",
          heading: "Worth raising",
          blurb: "Ask your council about these when you write to it.",
        },
        {
          severity: "info",
          heading: "Worth knowing",
          blurb: "Background that may matter to your case.",
        },
      ];
      function FlagList({ flags }) {
        if (flags.length === 0) return null;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          "aria-labelledby": "flags-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "flags-heading",
              children: "What to check with your council",
            }),
            GROUPS.map(({ severity, heading, blurb }) => {
              const inGroup = flags.filter((f) => f.severity === severity);
              if (inGroup.length === 0) return null;
              return /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                "div",
                {
                  className: `flag-group flag-group--${severity}`,
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("h3", {
                      className: "flag-group__heading",
                      children: heading,
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                      className: "flag-group__blurb",
                      children: blurb,
                    }),
                    inGroup.map((f) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(
                        FlagItem,
                        {
                          flag: f,
                        },
                        f.code,
                      ),
                    ),
                  ],
                },
                severity,
              );
            }),
          ],
        });
      } // ./components/ui/Disclaimer.tsx

      /**
       * [HARD R7] No output may be presented as legal advice. A persistent disclaimer
       * plus advice-line signposting appears on every page and in the printed output.
       */
      function Disclaimer({ compact = false }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "callout callout--important avoid-break",
          role: "note",
          "aria-label": "Important",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "flush",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                  children: "This is an estimate, not legal advice.",
                }),
                " Financial support for special guardians is discretionary, and there is no fixed amount you can require your council to pay. It shows you the figure your council should be starting from, and what the rules and the published decisions say about how it has to decide.",
              ],
            }),
            !compact &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "gap-md flush-bot",
                children:
                  "Your council can lawfully pay less than the maximum after properly assessing your circumstances. If something here matters to your case, talk to one of the advice lines below before you rely on it.",
              }),
          ],
        });
      } // ./components/ui/AdviceLines.tsx

      /**
       * Advice-line signposting, required on every result and every page (R7).
       * These are national organisations with kinship-care expertise; the contact
       * details are deliberately not stored as data because they are not figures the
       * engine uses, but they must be checked at each content review.
       */
      function AdviceLines({ headingId = "advice-lines-heading" } = {}) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          className: "avoid-break",
          "aria-labelledby": headingId,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: headingId,
              children: "Who can help",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "These organisations give free, independent advice on kinship care and special guardianship. They are not part of your council.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("ul", {
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("li", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Kinship",
                    }),
                    ": advice and peer support for kinship carers.",
                    " ",
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                      href: "https://kinship.org.uk/",
                      rel: "noopener",
                      children: "kinship.org.uk",
                    }),
                  ],
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("li", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Family Rights Group",
                    }),
                    ": free advice line for families dealing with children's services.",
                    " ",
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                      href: "https://frg.org.uk/",
                      rel: "noopener",
                      children: "frg.org.uk",
                    }),
                  ],
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("li", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Citizens Advice",
                    }),
                    ": benefits, debt and general advice.",
                    " ",
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                      href: "https://www.citizensadvice.org.uk/",
                      rel: "noopener",
                      children: "citizensadvice.org.uk",
                    }),
                  ],
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("li", {
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "Local Government and Social Care Ombudsman",
                    }),
                    " (England), if you have complained to your council and are not satisfied.",
                    " ",
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                      href: "https://www.lgo.org.uk/",
                      rel: "noopener",
                      children: "lgo.org.uk",
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      } // ./lib/urlState.ts

      /**
       * URL state, spec §22.
       *
       * [HARD R8] Financial data must NEVER go in a URL. URLs end up in server logs,
       * browser history, referrer headers and messaging-app previews. Only
       * non-sensitive, non-identifying answers are shareable:
       *
       *   nation, englandRegion, localAuthoritySlug, child ages,
       *   disability flag, wasFosterCarerForThisChild            yes
       *   previousWeeklyFosteringAllowance, all FinancesInput,
       *   onMeansTestedBenefits, postcode                        NEVER
       *
       * So a shared link reproduces the MAXIMUM calculation, never the means-tested
       * one. Everything read back in is re-validated here rather than trusted: a URL
       * is user input, and it may have been edited, truncated by a chat app, or
       * simply typed wrong.
       */ const NATIONS = ["england", "wales", "scotland", "northern-ireland"];
      const REGIONS = ["london", "south-east", "rest-of-england"];
      const SLUG = /^[a-z0-9-]{1,64}$/;
      /** The schema's own limits, so a link cannot carry more than the form accepts. */ const urlState_MAX_CHILDREN = 10;
      const MAX_AGE = 17;
      /** Short keys, because the link is meant to be pasted into a message. */ const KEY = {
        nation: "n",
        region: "r",
        la: "la",
        ages: "c",
        disability: "d",
        formerFosterCarer: "ff",
      };
      /** `/?n=england&r=south-east&la=kent&c=12,7&ff=1` */ function toQueryString(s) {
        const q = new URLSearchParams();
        if (s.nation) q.set(KEY.nation, s.nation);
        if (s.region) q.set(KEY.region, s.region);
        if (s.la) q.set(KEY.la, s.la);
        if (s.ages?.length) q.set(KEY.ages, s.ages.join(","));
        if (s.disability?.length) q.set(KEY.disability, s.disability.join(","));
        if (s.formerFosterCarer) q.set(KEY.formerFosterCarer, "1");
        const query = q.toString();
        return query ? `?${query}` : "";
      }
      /** Parse a comma-separated list of integers, keeping only those in range. */ function numberList(
        raw,
        min,
        max,
      ) {
        if (!raw) return [];
        return raw
          .split(",")
          .map((x) => Number.parseInt(x, 10))
          .filter((x) => Number.isInteger(x) && x >= min && x <= max);
      }
      function fromQueryString(search) {
        const q = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
        const out = {};
        const nation = q.get(KEY.nation);
        if (nation && NATIONS.includes(nation)) out.nation = nation;
        const region = q.get(KEY.region);
        if (region && REGIONS.includes(region)) out.region = region;
        const la = q.get(KEY.la);
        if (la && SLUG.test(la)) out.la = la;
        const ages = numberList(q.get(KEY.ages), 0, MAX_AGE).slice(0, urlState_MAX_CHILDREN);
        if (ages.length > 0) out.ages = ages;
        const disability = numberList(q.get(KEY.disability), 0, urlState_MAX_CHILDREN - 1);
        if (disability.length > 0) out.disability = disability;
        if (q.get(KEY.formerFosterCarer) === "1") out.formerFosterCarer = true;
        return out;
      }
      const SHARE_EXPLANATION =
        "This link shares the rates for your area and your children’s ages. It does not include " +
        "anything you told me about your finances."; // ./components/results/ResultsPanel.tsx

      /* __next_internal_client_entry_do_not_use__ ResultsPanel auto */

      /**
       * Output order matters, spec §21. Lead with the ceiling, not the estimate:
       *
       *   1. the maximum        5. the arithmetic
       *   2. the estimate       6. what to do next
       *   3. per-child table    7. citations
       *   4. flags              8. download / print
       */ function ResultsPanel({
        result,
        input,
        regionLabel,
        councilName,
        shareUrl,
        continuation,
      }) {
        const citations = result.perChild.flatMap((c) => c.citations);
        for (const f of result.flags) if (f.citation) citations.push(f.citation);
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "section",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)(PrintHeader, {
              result: result,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(PrintedInputs, {
              input: input,
              ...(councilName
                ? {
                    councilName,
                  }
                : {}),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(MaximumHero, {
              result: result,
              ...(regionLabel
                ? {
                    regionLabel,
                  }
                : {}),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(EstimateCard, {
              result: result,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(PerChildTable, {
              result: result,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Disclaimer, {}),
            continuation,
            /*#__PURE__*/ (0, jsx_runtime.jsx)(FlagList, {
              flags: result.flags,
            }),
            result.meansTestBreakdown &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(ArithmeticPanel, {
                breakdown: result.meansTestBreakdown,
              }),
            FLAGS.BACKDATING_ENABLED &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(BackdatingPanel, {
                input: input,
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(NextSteps, {
              result: result,
            }),
            FLAGS.LETTER_GENERATOR &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(LettersPanel, {
                result: result,
                input: input,
                ...(councilName
                  ? {
                      councilName,
                    }
                  : {}),
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(CitationsList, {
              citations: citations,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(PrintButton, {}),
            shareUrl &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(ShareControl, {
                url: shareUrl,
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(AdviceLines, {}),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              className: "muted small",
              children: [
                "Calculated ",
                new Date(result.computedAt).toLocaleString("en-GB"),
                " \xb7 rates",
                " ",
                result.financialYear.replace("-", "/"),
                " (data version ",
                result.dataVersion,
                ") \xb7 engine",
                " ",
                result.engineVersion,
              ],
            }),
          ],
        });
      }
      /**
       * Printed at the top of the page (§19 item 1) and hidden on screen, the carer
       * hands this to a social worker, so it needs to say what it is and when it was
       * produced.
       */ function PrintHeader({ result }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "print-only avoid-break",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              className: "flush-top",
              children: "Special guardianship allowance estimate",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              children: [
                "Generated ",
                new Date(result.computedAt).toLocaleDateString("en-GB"),
                " \xb7 rates for financial year ",
                result.financialYear.replace("-", "/"),
                " \xb7 produced with an online calculator, not by a solicitor or a council.",
              ],
            }),
          ],
        });
      }
      function ShareControl({ url }) {
        const { state, copy } = useCopyToClipboard();
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "print-hide share",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              className: "big",
              children: "Share this result",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children: SHARE_EXPLANATION,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
              type: "button",
              className: "btn btn--secondary",
              onClick: () => copy(url),
              children: "Copy the link",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
              "aria-live": "polite",
              className: "share__status",
              children: [
                state === "done" && "Link copied.",
                state === "failed" &&
                  "Your browser would not let me copy it. Select the address in the bar at the top and copy it yourself.",
              ],
            }),
          ],
        });
      } // ./components/calculator/formState.ts

      /**
       * The shape of the answers, and the pure functions over them.
       *
       * Nothing here touches React or the DOM, so the awkward parts (which child is
       * eldest, what a half-typed number means, how answers become engine input) can
       * be reasoned about and tested on their own.
       */ let childKeySeq = 0;
      function emptyChild() {
        return {
          key: `child-${(childKeySeq += 1)}`,
          ageYears: "",
          hasDisabilityOrAdditionalNeeds: false,
          wasLookedAfterImmediatelyBeforeOrder: "unknown",
        };
      }
      /** The schema's own limit. More rows than this cannot be calculated anyway. */ const formState_MAX_CHILDREN = 10;
      const MEANS_TESTED_BENEFITS = [
        {
          id: "universal-credit",
          label: "Universal Credit",
        },
        {
          id: "income-support",
          label: "Income Support",
        },
        {
          id: "jsa-income-based",
          label: "Jobseeker’s Allowance (income-based)",
        },
        {
          id: "esa-income-related",
          label: "Employment and Support Allowance (income-related)",
        },
        {
          id: "pension-credit",
          label: "Pension Credit",
        },
        {
          id: "housing-benefit",
          label: "Housing Benefit",
        },
        {
          id: "council-tax-support",
          label: "Council Tax Support",
        },
      ];
      const MONEY_FIELDS = [
        [
          "netEarnings",
          "Take-home pay, per month",
          "After tax and National Insurance. Include your partner’s.",
        ],
        [
          "otherIncome",
          "Other income, per month",
          "Pensions, maintenance you receive, money from a lodger.",
        ],
        [
          "countableBenefits",
          "Benefits that count, per month",
          "Do NOT include disability benefits for your child, or Guardian’s Allowance.",
        ],
        [
          "childBenefitOtherChildren",
          "Child Benefit for your OTHER children, per month",
          "Not for the child this is about.",
        ],
        ["housingCosts", "Rent or mortgage, per month", "After any Housing Benefit."],
        ["councilTax", "Council tax, per month", "After any Council Tax Support."],
        ["childcareCosts", "Childcare, per month", ""],
        ["essentialLoanRepayments", "Essential loan repayments, per month", ""],
        ["maintenancePaid", "Maintenance you pay out, per month", ""],
        ["pensionContributions", "Pension contributions, per month", ""],
        ["savingsCapital", "Savings, in total", "Not monthly, the total you have."],
      ];
      function emptyForm() {
        return {
          nation: "",
          region: "",
          la: "",
          children: [emptyChild()],
          eldestIndex: 0,
          eldestOverridden: false,
          wasFosterCarer: false,
          previousAllowance: {
            raw: "",
            pence: null,
          },
          orderDate: "",
          monthsSinceOrder: "",
          onMeansTestedBenefits: false,
          benefitsHeld: [],
          money: Object.fromEntries(
            MONEY_FIELDS.map(([n]) => [
              n,
              {
                raw: "",
                pence: 0,
              },
            ]),
          ),
          adults: "1",
          householdChildren: "1",
          householdChildrenTouched: false,
          applyChildBenefitDeduction: false,
          childWouldOtherwiseBeInCare: false,
          alreadyOnReg6: false,
        };
      }
      // ─── Derived answers ───────────────────────────────────────────────────────
      /**
       * Index of the oldest child entered, or 0 when no age has been typed yet.
       *
       * Only the eldest attracts the higher rate of Child Benefit, so this decides
       * money. It is derived on demand rather than held in state, because state
       * updated by an effect is not yet correct on the render that a shared link
       * calculates from, and the wrong child would take the higher rate with nothing
       * on screen to say so.
       */ function indexOfOldest(kids) {
        let best = 0;
        let bestAge = -1;
        kids.forEach((c, i) => {
          const age = Number.parseInt(c.ageYears, 10);
          if (Number.isInteger(age) && age > bestAge) {
            bestAge = age;
            best = i;
          }
        });
        return best;
      }
      function eldestIndexOf(form) {
        return form.eldestOverridden ? form.eldestIndex : indexOfOldest(form.children);
      }
      /**
       * A whole number from a text box, or NaN so the schema can object.
       *
       * `Number.parseInt(raw, 10) || fallback` looks equivalent and is not: 0 is
       * falsy, so someone who deliberately typed 0 had it silently replaced by the
       * fallback and never validated, and the form then accepted an answer they had
       * not given. Refusing is the house rule everywhere else here, so it applies to
       * a zero as much as to a word.
       */ function wholeNumber(raw, blank) {
        if (raw.trim() === "") return blank;
        const n = Number.parseInt(raw.trim(), 10);
        return Number.isInteger(n) ? n : Number.NaN;
      }
      // ─── Form to engine input ──────────────────────────────────────────────────
      function buildInput(form, withFinances) {
        const eldest = eldestIndexOf(form);
        const money = (name) => form.money[name].pence ?? 0;
        const finances = withFinances
          ? {
              netEarnings: money("netEarnings"),
              otherIncome: money("otherIncome"),
              countableBenefits: money("countableBenefits"),
              childBenefitOtherChildren: money("childBenefitOtherChildren"),
              savingsCapital: money("savingsCapital"),
              housingCosts: money("housingCosts"),
              councilTax: money("councilTax"),
              childcareCosts: money("childcareCosts"),
              essentialLoanRepayments: money("essentialLoanRepayments"),
              maintenancePaid: money("maintenancePaid"),
              pensionContributions: money("pensionContributions"),
              adultsInHousehold: wholeNumber(form.adults, 1),
              // Falls back to the children actually entered, both when the box is
              // blank and when the carer has never touched it. The default used to
              // be a literal 1 that no number of added children ever changed.
              dependentChildrenInHousehold: form.householdChildrenTouched
                ? wholeNumber(form.householdChildren, form.children.length)
                : form.children.length,
            }
          : undefined;
        return {
          carer: {
            nation: form.nation || "england",
            ...(form.region
              ? {
                  englandRegion: form.region,
                }
              : {}),
            ...(form.la
              ? {
                  localAuthoritySlug: form.la,
                }
              : {}),
            wasFosterCarerForThisChild: form.wasFosterCarer,
            ...(form.orderDate
              ? {
                  orderDate: form.orderDate,
                }
              : {}),
            // Left out entirely when the box is blank. It used to default to 0,
            // which the engine read as "the order was made today".
            ...(form.monthsSinceOrder.trim() === ""
              ? {}
              : {
                  monthsSinceOrderMade: wholeNumber(form.monthsSinceOrder, 0),
                }),
            ...(form.wasFosterCarer && form.previousAllowance.pence !== null
              ? {
                  previousWeeklyFosteringAllowance: form.previousAllowance.pence,
                }
              : {}),
            onMeansTestedBenefits: form.onMeansTestedBenefits,
            ...(form.benefitsHeld.length
              ? {
                  meansTestedBenefitsHeld: form.benefitsHeld,
                }
              : {}),
            ...(form.childWouldOtherwiseBeInCare
              ? {
                  childWouldOtherwiseBeInCare: true,
                }
              : {}),
            ...(form.alreadyOnReg6
              ? {
                  alreadyReceivingReg6Support: true,
                }
              : {}),
          },
          children: form.children.map((c, i) => ({
            id: `child-${i}`,
            ageYears: Number.parseInt(c.ageYears, 10),
            hasDisabilityOrAdditionalNeeds: c.hasDisabilityOrAdditionalNeeds,
            wasLookedAfterImmediatelyBeforeOrder:
              c.wasLookedAfterImmediatelyBeforeOrder === "unknown"
                ? "unknown"
                : c.wasLookedAfterImmediatelyBeforeOrder === "yes",
            isEldestInHousehold: i === eldest,
          })),
          ...(finances
            ? {
                finances,
              }
            : {}),
          applyChildBenefitDeduction: form.applyChildBenefitDeduction,
        };
      }
      /** The shareable, non-sensitive part of the answers. Never any finances (§22). */ function shareableState(
        form,
      ) {
        // Both lists are built from the SAME filtered set of children, or their
        // indexes drift apart. `ages` drops a child whose age box is blank; if
        // `disability` kept the original positions, a blank first child shifted the
        // flag onto whoever came next, and a shared link arrived with the wrong child
        // marked as disabled. That changes which warnings the reader is shown.
        const entered = form.children.filter((c) =>
          Number.isInteger(Number.parseInt(c.ageYears, 10)),
        );
        const ages = entered.map((c) => Number.parseInt(c.ageYears, 10));
        const disability = entered
          .map((c, i) => (c.hasDisabilityOrAdditionalNeeds ? i : -1))
          .filter((i) => i >= 0);
        return {
          ...(form.nation
            ? {
                nation: form.nation,
              }
            : {}),
          ...(form.region
            ? {
                region: form.region,
              }
            : {}),
          ...(form.la
            ? {
                la: form.la,
              }
            : {}),
          ...(ages.length
            ? {
                ages,
              }
            : {}),
          ...(disability.length
            ? {
                disability,
              }
            : {}),
          ...(form.wasFosterCarer
            ? {
                formerFosterCarer: true,
              }
            : {}),
        };
      } // ./components/calculator/steps.ts

      /**
       * The steps, and which one owns each thing that can go wrong.
       *
       * Spec §20: six steps, progressive. The rule that shapes the order is that the
       * maximum is shown after step 2, before any finances are asked for. It is the
       * figure most people came for, and it must never be gated behind a means test
       * they may not want to complete.
       */
      const STEP_ORDER = [
        "where",
        "children",
        "result",
        "history",
        "benefits",
        "finances",
        "council",
      ];
      function isAfter(step, other) {
        return STEP_ORDER.indexOf(step) > STEP_ORDER.indexOf(other);
      }
      /**
       * The step that owns each error, so a message can be shown once, beside the box
       * it belongs to.
       *
       * The summary at the top carries only what has nowhere else to go: an error
       * whose box is on a step the carer is not currently looking at. Anything else
       * would be said twice, once above the calculator and once beside the field.
       */ function stepForPath(path) {
        if (path === "children" || path.startsWith("children.")) return "children";
        if (path.startsWith("finances.")) return "finances";
        if (path === "carer.englandRegion" || path === "carer.localAuthoritySlug") return "where";
        if (path.startsWith("carer.")) return "history";
        return null;
      }
      /**
       * [§24] The error summary links to the field that failed. A list of messages
       * with no way to reach the input is close to useless to a screen-reader or
       * keyboard user on a six-step form.
       *
       * Keys are the Zod issue paths from the shared schema. The repeated child
       * fields are enumerated to the schema's own limit, because stopping short
       * leaves an error on a later child linking nowhere.
       */ const perChildAnchors = (field) =>
        Object.fromEntries(
          Array.from(
            {
              length: formState_MAX_CHILDREN,
            },
            (_, i) => [`children.${i}.${field}`, `age-${i}`],
          ),
        );
      const FIELD_ANCHORS = {
        "carer.englandRegion": "council-select",
        "carer.previousWeeklyFosteringAllowance": "months-since",
        "carer.orderDate": "order-date",
        "carer.monthsSinceOrderMade": "months-since",
        "finances.adultsInHousehold": "adults",
        "finances.dependentChildrenInHousehold": "household-children",
        children: "age-0",
        ...perChildAnchors("ageYears"),
        ...perChildAnchors("isEldestInHousehold"),
      }; // ./components/calculator/errors.tsx

      /* __next_internal_client_entry_do_not_use__ ErrorSummary,EngineErrorFallback auto */

      /**
       * [§24] Errors with no box on the current step to sit beside.
       *
       * Only these reach the summary, so nothing is said twice and nothing goes
       * unsaid either. Each links to the field that failed: a list of messages with
       * no way to reach the input is close to useless to a screen-reader or keyboard
       * user on a six-step form.
       */ function ErrorSummary({ issues, summaryRef }) {
        if (issues.length === 0) return null;
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          ref: summaryRef,
          tabIndex: -1,
          role: "alert",
          className: "callout callout--critical",
          "aria-labelledby": "error-summary-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "error-summary-heading",
              className: "flush-top big",
              children: "There is a problem",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("ul", {
              className: "flush",
              children: issues.map((issue, i) => {
                const anchor = FIELD_ANCHORS[issue.path];
                return /*#__PURE__*/ (0, jsx_runtime.jsx)(
                  "li",
                  {
                    children: anchor
                      ? /*#__PURE__*/ (0, jsx_runtime.jsx)("a", {
                          href: `#${anchor}`,
                          children: issue.message,
                        })
                      : issue.message,
                  },
                  i,
                );
              }),
            }),
          ],
        });
      }
      /**
       * [§15, §33] A GuardrailViolation is never shown raw to a user. A DataError
       * says what I do not have, rather than pretending.
       */ function EngineErrorFallback({ kind }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "callout callout--critical",
          role: "alert",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              className: "flush-top big",
              children:
                kind === "guardrail"
                  ? "I cannot produce a reliable estimate for your situation"
                  : "I do not have verified figures for that",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                kind === "guardrail"
                  ? "Something about your answers means I cannot give you a figure I am confident is right. I would rather tell you that than show you a number that might be wrong."
                  : "Rather than guess, I have stopped. This usually means I do not yet hold a verified rate table or benefit figure for the date or the situation you gave me.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "flush-bot",
              children:
                "Please talk to one of the advice organisations listed at the bottom of this page, they can look at your case properly.",
            }),
          ],
        });
      } // ./components/calculator/fields.tsx

      /* __next_internal_client_entry_do_not_use__ FieldError,TextField,Choice,RadioGroup,StepPanel,StepNav auto */
      /** One message, in one place: beside the box it belongs to. */ function FieldError({
        id,
        message,
      }) {
        if (!message) return null;
        return /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
          className: "field__error",
          id: id,
          role: "alert",
          children: message,
        });
      }
      /**
       * A labelled text box with an optional hint and an optional error.
       *
       * inputMode rather than type="number": spinners are hostile to screen readers
       * and to shaky hands (§24). The message sits next to the box as well as in the
       * summary at the top, because someone who types 80 and presses the button is
       * looking at the box, not the top of the page.
       */ function TextField({
        id,
        label,
        hint,
        value,
        error,
        type = "text",
        numeric = false,
        hintId: hintIdOverride,
        errorId: errorIdOverride,
        onChange,
      }) {
        const hintId = hintIdOverride ?? `${id}-hint`;
        const errorId = errorIdOverride ?? `${id}-error`;
        const describedBy = [hint ? hintId : null, error ? errorId : null]
          .filter(Boolean)
          .join(" ");
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "field",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
              className: "field__label",
              htmlFor: id,
              children: label,
            }),
            hint &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                className: "field__hint",
                id: hintId,
                children: hint,
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(FieldError, {
              id: errorId,
              message: error,
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
              id: id,
              type: type,
              ...(numeric
                ? {
                    inputMode: "numeric",
                  }
                : {}),
              value: value,
              "aria-invalid": error ? true : undefined,
              "aria-describedby": describedBy || undefined,
              onChange: (e) => onChange(e.target.value),
            }),
          ],
        });
      }
      /** A checkbox or radio with its label, sized as one tap target. */ function Choice({
        type,
        name,
        value,
        checked,
        onChange,
        children,
        describedBy,
      }) {
        return (
          // The selected state carries a class rather than relying on CSS :has().
          // :has() is unsupported on Safari below 15.4 and older Firefox, which is
          // exactly the older tablet this site is built for, and there the border and
          // tint marking the chosen answer silently vanished, leaving only the small
          // radio dot. React already knows what is checked, so it can just say so.
          /*#__PURE__*/ (0, jsx_runtime.jsxs)("label", {
            className: checked ? "choice choice--on" : "choice",
            children: [
              /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                type: type,
                ...(name
                  ? {
                      name,
                    }
                  : {}),
                ...(value
                  ? {
                      value,
                    }
                  : {}),
                checked: checked,
                "aria-describedby": describedBy,
                onChange: (e) => onChange(e.target.checked),
              }),
              /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                children: children,
              }),
            ],
          })
        );
      }
      /** A group of radios sharing one name, under a legend. */ function RadioGroup({
        legend,
        name,
        options,
        selected,
        onSelect,
        id,
        children,
        footer,
      }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("fieldset", {
          ...(id
            ? {
                id,
              }
            : {}),
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("legend", {
              children: legend,
            }),
            children,
            options.map(([value, label]) =>
              /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                "label",
                {
                  className: "choice",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                      type: "radio",
                      name: name,
                      value: value,
                      checked: selected === value,
                      onChange: () => onSelect(value),
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                      children: label,
                    }),
                  ],
                },
                value,
              ),
            ),
            footer,
          ],
        });
      }
      function StepPanel({ heading, stepNumber, headingRef, children }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          children: [
            stepNumber &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                className: "step-label",
                children: ["Step ", stepNumber],
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              ref: headingRef,
              tabIndex: -1,
              className: "gap-sm",
              children: heading,
            }),
            children,
          ],
        });
      }
      /** A visible "back" on every step. The form must never trap keyboard users. */ function StepNav({
        onBack,
        onNext,
        onSkip,
        nextLabel = "Continue",
        nextDisabled = false,
        nextSecondary = false,
      }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          className: "row gap-lg",
          children: [
            onBack &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
                type: "button",
                className: "btn btn--secondary",
                onClick: onBack,
                children: "Back",
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
              type: "button",
              className: nextSecondary ? "btn btn--secondary" : "btn",
              onClick: onNext,
              disabled: nextDisabled,
              children: nextLabel,
            }),
            onSkip &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
                type: "button",
                className: "btn btn--secondary",
                onClick: onSkip,
                children: "Skip this step",
              }),
          ],
        });
      } // ./components/calculator/steps/BenefitsStep.tsx

      /* __next_internal_client_entry_do_not_use__ BenefitsStep auto */

      function BenefitsStep({ form, set, headingRef, goTo, run }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "Benefits you receive",
          headingRef: headingRef,
          stepNumber: 4,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "This does not change your figure. It tells me which rules about your council's behaviour apply to you.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
              type: "checkbox",
              checked: form.onMeansTestedBenefits,
              onChange: (onMeansTestedBenefits) =>
                set((f) => ({
                  ...f,
                  onMeansTestedBenefits,
                })),
              children: "I receive at least one means-tested benefit",
            }),
            form.onMeansTestedBenefits &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)("fieldset", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("legend", {
                    children: "Which ones? (optional)",
                  }),
                  MEANS_TESTED_BENEFITS.map((benefit) =>
                    /*#__PURE__*/ (0, jsx_runtime.jsx)(
                      Choice,
                      {
                        type: "checkbox",
                        checked: form.benefitsHeld.includes(benefit.id),
                        onChange: (held) =>
                          set((f) => ({
                            ...f,
                            benefitsHeld: held
                              ? [...f.benefitsHeld, benefit.id]
                              : f.benefitsHeld.filter((x) => x !== benefit.id),
                          })),
                        children: benefit.label,
                      },
                      benefit.id,
                    ),
                  ),
                ],
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo("history"),
              onNext: () => {
                if (run(false)) goTo(FLAGS.MEANS_TEST_ENABLED ? "finances" : "council");
              },
            }),
          ],
        });
      } // ./components/calculator/steps/ChildrenStep.tsx

      /* __next_internal_client_entry_do_not_use__ ChildrenStep auto */

      const ChildrenStep_LOOKED_AFTER = [
        ["yes", "Yes"],
        ["no", "No"],
        ["unknown", "I’m not sure"],
      ];
      function ChildrenStep({
        form,
        set,
        errorFor,
        headingRef,
        goTo,
        run,
        addChildRef,
        onChildAdded,
        onChildRemoved,
      }) {
        const updateChild = (index, patch) =>
          set((f) => ({
            ...f,
            children: f.children.map((c, i) =>
              i === index
                ? {
                    ...c,
                    ...patch,
                  }
                : c,
            ),
          }));
        const addChild = () => {
          const next = emptyChild();
          onChildAdded(next.key);
          set((f) => ({
            ...f,
            children: [...f.children, next],
          }));
        };
        const removeChild = (index) => {
          // Land on the child above the gap, which is where the eye already is.
          // Removing the first leaves nothing above it, so the caller falls back to
          // the Add button rather than dropping focus on the document.
          onChildRemoved(form.children[index - 1]?.key ?? null);
          set((f) => ({
            ...f,
            children: f.children.filter((_, i) => i !== index),
            // The removed child may have been the eldest, so go back to working it
            // out from the ages rather than keeping a stale index.
            eldestOverridden: false,
          }));
        };
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "About the children",
          headingRef: headingRef,
          stepNumber: 2,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)(FieldError, {
              id: "children-error",
              message: errorFor("children"),
            }),
            form.children.map((child, i) =>
              /*#__PURE__*/ (0, jsx_runtime.jsxs)(
                "fieldset",
                {
                  "data-child-key": child.key,
                  className: "panel",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("legend", {
                      children: ["Child ", i + 1],
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsx)(TextField, {
                      id: `age-${i}`,
                      hintId: `age-hint-${i}`,
                      errorId: `age-error-${i}`,
                      label: "How old are they?",
                      hint: "In years, from 0 to 17.",
                      numeric: true,
                      value: child.ageYears,
                      error: errorFor(`children.${i}.ageYears`),
                      onChange: (ageYears) =>
                        updateChild(i, {
                          ageYears,
                        }),
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
                      type: "checkbox",
                      checked: child.hasDisabilityOrAdditionalNeeds,
                      onChange: (hasDisabilityOrAdditionalNeeds) =>
                        updateChild(i, {
                          hasDisabilityOrAdditionalNeeds,
                        }),
                      children: "They have a disability or additional needs",
                    }),
                    /*#__PURE__*/ (0, jsx_runtime.jsxs)("fieldset", {
                      children: [
                        /*#__PURE__*/ (0, jsx_runtime.jsx)("legend", {
                          children:
                            "Were they in the council's care immediately before the order was made?",
                        }),
                        ChildrenStep_LOOKED_AFTER.map(([value, label]) =>
                          /*#__PURE__*/ (0, jsx_runtime.jsx)(
                            Choice,
                            {
                              type: "radio",
                              name: `looked-after-${i}`,
                              checked: child.wasLookedAfterImmediatelyBeforeOrder === value,
                              onChange: () =>
                                updateChild(i, {
                                  wasLookedAfterImmediatelyBeforeOrder: value,
                                }),
                              children: label,
                            },
                            value,
                          ),
                        ),
                      ],
                    }),
                    form.children.length > 1 &&
                      /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                        children: [
                          /*#__PURE__*/ (0, jsx_runtime.jsx)(FieldError, {
                            id: `eldest-error-${i}`,
                            message: errorFor(`children.${i}.isEldestInHousehold`),
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
                            type: "radio",
                            name: "eldest",
                            checked: form.eldestIndex === i,
                            ...(errorFor(`children.${i}.isEldestInHousehold`)
                              ? {
                                  describedBy: `eldest-error-${i}`,
                                }
                              : {}),
                            onChange: () =>
                              set((f) => ({
                                ...f,
                                eldestIndex: i,
                                eldestOverridden: true,
                              })),
                            children: "This is the eldest child in the household",
                          }),
                          /*#__PURE__*/ (0, jsx_runtime.jsxs)("button", {
                            type: "button",
                            className: "btn btn--secondary",
                            onClick: () => removeChild(i),
                            children: ["Remove child ", i + 1],
                          }),
                        ],
                      }),
                  ],
                },
                child.key,
              ),
            ),
            form.children.length < formState_MAX_CHILDREN &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
                type: "button",
                className: "btn btn--secondary",
                ref: addChildRef,
                onClick: addChild,
                children: "Add another child",
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo("where"),
              onNext: () => {
                if (run(false)) goTo("result");
              },
              nextLabel: "Show me the figure",
            }),
          ],
        });
      } // ./components/calculator/steps/CouncilStep.tsx

      /* __next_internal_client_entry_do_not_use__ CouncilStep auto */

      function CouncilStep({ form, set, headingRef, goTo, run, wantsMeansTest }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "How your council behaves",
          headingRef: headingRef,
          stepNumber: FLAGS.MEANS_TEST_ENABLED ? 6 : 5,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "If you know any of this, it makes the guidance more useful. If you do not, leave it blank and the result will tell you how to find out.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
              type: "checkbox",
              checked: form.applyChildBenefitDeduction,
              onChange: (applyChildBenefitDeduction) =>
                set((f) => ({
                  ...f,
                  applyChildBenefitDeduction,
                })),
              children: "My council takes Child Benefit off my allowance",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              className: "field__hint",
              children:
                "I never do this unless you tick it. Whether a council may do it at all is contested, and it has been found wrong where the carer is on means-tested benefits.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
              type: "checkbox",
              checked: form.childWouldOtherwiseBeInCare,
              onChange: (childWouldOtherwiseBeInCare) =>
                set((f) => ({
                  ...f,
                  childWouldOtherwiseBeInCare,
                })),
              children: "Without me, this child would be in local authority care",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
              type: "checkbox",
              checked: form.alreadyOnReg6,
              onChange: (alreadyOnReg6) =>
                set((f) => ({
                  ...f,
                  alreadyOnReg6,
                })),
              children: "I already receive special guardianship financial support from my council",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo(FLAGS.MEANS_TEST_ENABLED ? "finances" : "benefits"),
              onNext: () => {
                if (run(wantsMeansTest && FLAGS.MEANS_TEST_ENABLED)) goTo("result");
              },
              nextLabel: "Update my result",
            }),
          ],
        });
      } // ./components/calculator/steps/FinancesStep.tsx

      /* __next_internal_client_entry_do_not_use__ FinancesStep auto */

      function FinancesStep({ form, set, errorFor, headingRef, goTo, run, onWantsMeansTest }) {
        // The carer's own answer wins once they have given one, even if they later
        // add a child: they know their household and we do not.
        const householdChildren = form.householdChildrenTouched
          ? form.householdChildren
          : String(form.children.length);
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "Your finances",
          headingRef: headingRef,
          stepNumber: 5,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
              className: "callout",
              role: "note",
              "aria-label": "Note",
              children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                className: "flush",
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                    children: "You can skip this.",
                  }),
                  " Fill it in only if you want an estimate of what you might get after a means test. Nothing you type here leaves your browser, there is no server to send it to.",
                ],
              }),
            }),
            MONEY_FIELDS.map(([name, label, hint]) =>
              /*#__PURE__*/ (0, jsx_runtime.jsx)(
                MoneyInput,
                {
                  name: name,
                  label: label,
                  ...(hint
                    ? {
                        hint,
                      }
                    : {}),
                  value: form.money[name].raw,
                  error: errorFor(`finances.${name}`),
                  onChange: (raw, pence) =>
                    set((f) => ({
                      ...f,
                      money: {
                        ...f.money,
                        [name]: {
                          raw,
                          pence,
                        },
                      },
                    })),
                },
                name,
              ),
            ),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(TextField, {
              id: "adults",
              label: "How many adults live in your household?",
              numeric: true,
              value: form.adults,
              error: errorFor("finances.adultsInHousehold"),
              onChange: (adults) =>
                set((f) => ({
                  ...f,
                  adults,
                })),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(TextField, {
              id: "household-children",
              label: "How many dependent children live in your household?",
              hint: "Include the children you have already told me about, plus any others.",
              numeric: true,
              // Starts at the number of children already entered, not at 1. It used
              // to sit at 1 however many children the carer had added, so anyone
              // with two or more was stopped by a validation error on a box they had
              // never touched, carrying a number we had put there.
              value: householdChildren,
              error: errorFor("finances.dependentChildrenInHousehold"),
              onChange: (next) =>
                set((f) => ({
                  ...f,
                  householdChildren: next,
                  householdChildrenTouched: true,
                })),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo("benefits"),
              onNext: () => {
                onWantsMeansTest(true);
                if (run(true)) goTo("council");
              },
              onSkip: () => {
                onWantsMeansTest(false);
                goTo("council");
              },
            }),
          ],
        });
      } // ./components/calculator/steps/HistoryStep.tsx

      /* __next_internal_client_entry_do_not_use__ HistoryStep auto */

      function HistoryStep({ form, set, errorFor, headingRef, goTo, run }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "Your history with this child",
          headingRef: headingRef,
          stepNumber: 3,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)(Choice, {
              type: "checkbox",
              checked: form.wasFosterCarer,
              onChange: (wasFosterCarer) =>
                set((f) => ({
                  ...f,
                  wasFosterCarer,
                })),
              children: "I was this child's foster carer before the order was made",
            }),
            form.wasFosterCarer &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(MoneyInput, {
                    label: "What were you paid in total as a foster carer, per week?",
                    hint: "Including the reward or fee element. If you were fostering more than one of these children, give the total for all of them, not the amount for each. Your council can keep paying that part for two years after the order.",
                    name: "previousWeeklyFosteringAllowance",
                    required: true,
                    value: form.previousAllowance.raw,
                    error: errorFor("carer.previousWeeklyFosteringAllowance"),
                    onChange: (raw, pence) =>
                      set((f) => ({
                        ...f,
                        previousAllowance: {
                          raw,
                          pence,
                        },
                      })),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(TextField, {
                    id: "order-date",
                    type: "date",
                    label: "When was the special guardianship order made?",
                    hint: "If you are not sure of the exact day, the month is close enough.",
                    value: form.orderDate,
                    error: errorFor("carer.orderDate"),
                    onChange: (orderDate) =>
                      set((f) => ({
                        ...f,
                        orderDate,
                      })),
                  }),
                ],
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(TextField, {
              id: "months-since",
              label: "Roughly how many months ago was the order made?",
              hint: "Leave blank if you gave the date above.",
              numeric: true,
              value: form.monthsSinceOrder,
              // The allowance error lands here too: it is the answer that decides
              // whether the reg 7 window is even open, and it is the box on screen.
              error:
                errorFor("carer.monthsSinceOrderMade") ??
                errorFor("carer.previousWeeklyFosteringAllowance"),
              onChange: (monthsSinceOrder) =>
                set((f) => ({
                  ...f,
                  monthsSinceOrder,
                })),
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo("result"),
              onNext: () => {
                if (run(false)) goTo("benefits");
              },
            }),
          ],
        });
      } // ./components/calculator/steps/ResultStep.tsx

      /* __next_internal_client_entry_do_not_use__ ResultStep,ResultContinuation auto */

      /**
       * The interstitial after step 2, spec §20.
       *
       * It exists to say out loud that the person can stop here. The figure itself
       * renders below the whole form, and pressing "Show me the figure" scrolls them
       * to it, so this step is in two pieces:
       *
       *   the heading and the reassurance stay above, where a screen reader meets
       *   them first and where someone scrolling back up finds them;
       *
       *   the offer to carry on goes below the figure, in ResultContinuation, because
       *   that is where the reader actually ends up. It used to sit up here with the
       *   heading, above the fold, and nobody ever saw it.
       */ function ResultStep({ headingRef }) {
        return /*#__PURE__*/ (0, jsx_runtime.jsx)(StepPanel, {
          heading: "Your result",
          headingRef: headingRef,
          children: /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
            className: "flush",
            children: "This is the figure you came for. You do not have to answer anything else.",
          }),
        });
      }
      /**
       * The offer to answer more questions, rendered inside the result panel just
       * after the figure and the caveat, and before the warnings.
       */ function ResultContinuation({ goTo }) {
        // print-hide: this is a control, not content, and it has no place on the page
        // a carer prints and hands to a social worker.
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("section", {
          className: "panel print-hide",
          "aria-labelledby": "more-questions-heading",
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)("h2", {
              id: "more-questions-heading",
              className: "flush-top big",
              children: "Do you want a more accurate figure?",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "You do not have to. The figure above is usable exactly as it is: print it, or send a letter with it.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              children:
                "If you tell me a little more about your situation, I can be more specific about what your council should be paying you, and which of the rules below apply to you.",
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onBack: () => goTo("children"),
              onNext: () => goTo("history"),
              nextLabel: "Answer a few more questions",
            }),
          ],
        });
      } // ./components/calculator/CouncilPicker.tsx

      /* __next_internal_client_entry_do_not_use__ CouncilPicker auto */

      /**
       * Council picker, spec §12, route 1 (the most reliable, and the default path).
       *
       * A native <datalist>-free, ARIA-compliant combobox would be a lot of JS for
       * this budget; a labelled <select> with all 153 authorities is fully keyboard
       * operable, announces its option count natively in every screen reader, works
       * with JS disabled, and costs nothing. That is the better trade for this
       * audience, see docs/DECISIONS.md.
       *
       * The postcode route (§12 route 2) sits alongside it and degrades silently to
       * the manual region picker if it fails.
       */ function CouncilPicker({ value, onChange, postcodeLookupEnabled }) {
        const [postcode, setPostcode] = (0, react.useState)("");
        const [status, setStatus] = (0, react.useState)(null);
        const [looking, setLooking] = (0, react.useState)(false);
        const statusRef = (0, react.useRef)(null);
        const councils = (0, react.useMemo)(
          () =>
            Object.keys(LA_REGION_MAP)
              .map((slug) => ({
                slug,
                name: LA_NAMES[slug] ?? slug,
              }))
              .sort((a, b) => a.name.localeCompare(b.name, "en-GB")),
          [],
        );
        /**
         * [HARD R8] Fires only on explicit user action, never on keystroke. Sends
         * only the outward code, enough for district resolution, and less
         * identifying than a full postcode. The result is used and discarded: the
         * postcode is never stored, logged, or put in the URL.
         */ async function findMyCouncil() {
          const outward = postcode.trim().split(/\s+/)[0] ?? "";
          if (!outward) {
            setStatus("Enter a postcode, or choose your council from the list.");
            return;
          }
          setLooking(true);
          setStatus("Looking up your council…");
          try {
            const res = await fetch(
              `https://api.postcodes.io/outcodes/${encodeURIComponent(outward)}`,
              {
                signal: AbortSignal.timeout(8000),
              },
            );
            if (!res.ok) throw new Error("lookup failed");
            const body = await res.json();
            const districts = body.result?.admin_district ?? [];
            const match = districts
              .map((d) =>
                d
                  .toLowerCase()
                  .replace(/[^a-z0-9]+/g, "-")
                  .replace(/^-|-$/g, ""),
              )
              .find((slug) => slug in LA_REGION_MAP);
            if (!match) {
              setStatus(
                "I could not match that postcode to a council. Choose yours from the list instead.",
              );
              return;
            }
            onChange(match, LA_REGION_MAP[match] ?? null);
            // Not "I think": this is what the lookup returned, and the hedge belongs on
            // the thing that is genuinely uncertain, which is whether the council for
            // the carer's address is the one responsible for the child at all.
            setStatus(
              `That postcode is in ${LA_NAMES[match] ?? match}. If a different council looked after your ` +
                `child before the order, change it below.`,
            );
          } catch {
            // Silent fallback to the manual picker. Never block on this (§12, §33).
            setStatus("Choose your council from the list below.");
          } finally {
            setLooking(false);
            statusRef.current?.focus();
          }
        }
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
              className: "field",
              children: [
                /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
                  className: "field__label",
                  htmlFor: "council-select",
                  children: "Which council is responsible for your child?",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                  className: "field__hint",
                  id: "council-hint",
                  children:
                    "This is usually the county or city council, not a district council. If you are not sure, you can skip this and pick a region instead.",
                }),
                /*#__PURE__*/ (0, jsx_runtime.jsxs)("select", {
                  id: "council-select",
                  name: "council",
                  value: value,
                  "aria-describedby": "council-hint",
                  onChange: (e) => {
                    const slug = e.target.value;
                    onChange(slug, slug ? (LA_REGION_MAP[slug] ?? null) : null);
                  },
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("option", {
                      value: "",
                      children: "Choose a council…",
                    }),
                    councils.map((c) =>
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(
                        "option",
                        {
                          value: c.slug,
                          children: c.name,
                        },
                        c.slug,
                      ),
                    ),
                  ],
                }),
              ],
            }),
            postcodeLookupEnabled &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)("details", {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("summary", {
                    children: "Or find it from your postcode",
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
                    className: "field",
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("label", {
                        className: "field__label",
                        htmlFor: "postcode",
                        children: "Postcode",
                      }),
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                        className: "field__hint",
                        id: "postcode-hint",
                        children:
                          "Only the first part (like SW1A) is sent. I do not store it, log it, or put it in the web address. Nothing else you have typed is sent with it.",
                      }),
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("input", {
                        id: "postcode",
                        name: "postcode",
                        type: "text",
                        autoComplete: "postal-code",
                        value: postcode,
                        "aria-describedby": "postcode-hint",
                        onChange: (e) => setPostcode(e.target.value),
                      }),
                    ],
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("button", {
                    type: "button",
                    className: "btn btn--secondary",
                    onClick: findMyCouncil,
                    disabled: looking,
                    children: looking ? "Looking…" : "Find my council",
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                    ref: statusRef,
                    tabIndex: -1,
                    "aria-live": "polite",
                    className: "gap-md",
                    children: status,
                  }),
                ],
              }),
          ],
        });
      } // ./components/calculator/steps/WhereStep.tsx

      /* __next_internal_client_entry_do_not_use__ WhereStep auto */

      const WhereStep_NATIONS = [
        ["england", "England"],
        ["wales", "Wales"],
        ["scotland", "Scotland"],
        ["northern-ireland", "Northern Ireland"],
      ];
      const WhereStep_REGIONS = [
        ["london", "London, the 32 boroughs and the City of London"],
        ["south-east", "South East England"],
        ["rest-of-england", "Anywhere else in England"],
      ];
      function WhereStep({ form, set, errorFor, headingRef, goTo }) {
        const chooseNation = (nation) =>
          set((f) => ({
            ...f,
            nation,
            // A region or council chosen for England means nothing anywhere else, and
            // leaving it set would send a Welsh carer down the English rate lookup.
            ...(nation === "england"
              ? {}
              : {
                  region: "",
                  la: "",
                }),
          }));
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)(StepPanel, {
          heading: "Where do you live?",
          headingRef: headingRef,
          stepNumber: 1,
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)(RadioGroup, {
              legend: "Which nation?",
              name: "nation",
              options: WhereStep_NATIONS,
              selected: form.nation,
              onSelect: chooseNation,
            }),
            form.nation === "wales" &&
              !FLAGS.WALES_ROUTE_ENABLED &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                className: "callout callout--important",
                role: "note",
                "aria-label": "Important",
                children: /*#__PURE__*/ (0, jsx_runtime.jsxs)("p", {
                  className: "flush",
                  children: [
                    /*#__PURE__*/ (0, jsx_runtime.jsx)("strong", {
                      children: "I am not showing Welsh figures yet.",
                    }),
                    " I am checking the Welsh rates against the Welsh Government's own published table before I publish them, one of the age bands in the sources I have looks wrong, and a wrong figure here is worse than none. The rest of this guide still applies in Wales.",
                  ],
                }),
              }),
            form.nation === "england" &&
              /*#__PURE__*/ (0, jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(CouncilPicker, {
                    value: form.la,
                    postcodeLookupEnabled: FLAGS.POSTCODE_LOOKUP,
                    onChange: (la, region) =>
                      set((f) => ({
                        ...f,
                        la,
                        ...(region
                          ? {
                              region,
                            }
                          : {}),
                      })),
                  }),
                  /*#__PURE__*/ (0, jsx_runtime.jsxs)(RadioGroup, {
                    id: "region-fieldset",
                    legend: "Or choose your region",
                    name: "region",
                    options: WhereStep_REGIONS,
                    selected: form.region,
                    onSelect: (region) =>
                      set((f) => ({
                        ...f,
                        region,
                      })),
                    footer: /*
                The government publishes rates by region but no list of which
                council is in which region, so the mapping is ours, not theirs.
                Saying so is both honest and practical: it pre-empts the
                complaint from a carer near a boundary, and it tells them the
                fix is the radio buttons they are already looking at.
              */ /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                      className: "field__hint",
                      children:
                        "The government publishes rates by region but does not publish a list of which council is in which region. I use the standard national regions. If you think yours is wrong, choose it here, your choice overrides mine.",
                    }),
                    children: [
                      /*#__PURE__*/ (0, jsx_runtime.jsx)(FieldError, {
                        id: "region-error",
                        message: errorFor("carer.englandRegion"),
                      }),
                      /*#__PURE__*/ (0, jsx_runtime.jsx)("span", {
                        className: "field__hint",
                        children:
                          "Rates are higher in London and the South East. If you picked a council above, I have already filled this in.",
                      }),
                    ],
                  }),
                ],
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)(StepNav, {
              onNext: () => goTo("children"),
              nextDisabled: !form.nation || (form.nation === "england" && !form.region && !form.la),
            }),
          ],
        });
      } // ./lib/scrollTo.ts

      /**
       * Moving someone to the part of the page that just changed.
       *
       * The form grows and shrinks under you: a step replaces another, a child row
       * appears below the fold, a result arrives further down than the button you
       * pressed. Without this, the page silently changes somewhere you are not
       * looking, and on a phone that means it appears to have done nothing at all.
       *
       * Two rules it keeps:
       *
       *  1. Focus first, scrolling second. Focus is what a screen reader and a
       *     keyboard follow, and it is the thing that must not be lost. `focus` is
       *     called with preventScroll so the browser's own jump does not fight the
       *     smooth scroll.
       *  2. `prefers-reduced-motion` is honoured. A smooth scroll is unpleasant, and
       *     for some people genuinely unwell-making, when motion is turned down. Those
       *     users still get taken to the right place, just instantly.
       */ function prefersReducedMotion() {
        if (false || !window.matchMedia) return false;
        return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      }
      /**
       * Bring an element into view, and optionally put focus on it.
       *
       * `block: 'start'` with scroll-padding-top in the stylesheet keeps the target
       * clear of the top edge rather than flush against it.
       */ function scrollToElement(el, opts = {}) {
        if (!el) return;
        const target = opts.focusWithin
          ? (el.querySelector(opts.focusWithin) ?? el)
          : opts.focus
            ? el
            : null;
        if (target) {
          // preventScroll is not universal; where it is missing the browser jumps and
          // the smooth scroll below simply refines it, which is still correct.
          try {
            target.focus({
              preventScroll: true,
            });
          } catch {
            target.focus();
          }
        }
        el.scrollIntoView({
          behavior: prefersReducedMotion() ? "auto" : "smooth",
          block: "start",
          inline: "nearest",
        });
      }
      /**
       * The same, once the browser has actually painted the new markup.
       *
       * React commits before layout is settled, so scrolling to a row that was added
       * in the same render can land at the wrong offset. A double frame is enough for
       * the element to have its final position.
       */ function scrollToElementAfterPaint(get, opts = {}) {
        if (false) {
        }
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => scrollToElement(get(), opts));
        });
      } // ./components/calculator/useStepFocus.ts

      /* __next_internal_client_entry_do_not_use__ useStepFocus,useChildFocus auto */ /**
       * Taking the person to whatever just changed.
       *
       * The form grows and shrinks as it is used, and on a phone the part that
       * changed is usually below the fold. Someone who presses a button and sees
       * nothing move concludes the button is broken.
       *
       * Focus is moved alongside the scroll throughout. Scrolling is what a sighted
       * user notices; focus is what a screen reader and a keyboard follow, and it is
       * the one that must not be lost when a row is removed from under it.
       */

      const childRow = (key) => document.querySelector(`[data-child-key="${key}"]`);
      function useStepFocus({ step, hasResult, headingRef, resultsRef }) {
        (0, react.useEffect)(() => {
          if (step === "where") return;
          const heading = headingRef.current;
          // On the result step these two want different places: the heading says
          // "Your result", the figure itself renders below the whole form. Scrolling
          // to both meant they raced, and on a short screen the figure lost. The
          // figure wins, and focus still goes to the heading so a screen reader
          // announces the step rather than jumping into the middle of the answer.
          if (step === "result" && hasResult) {
            try {
              heading?.focus({
                preventScroll: true,
              });
            } catch {
              heading?.focus();
            }
            scrollToElementAfterPaint(() => resultsRef.current);
            return;
          }
          scrollToElementAfterPaint(() => heading, {
            focus: true,
          });
        }, [step, hasResult, headingRef, resultsRef]);
      }
      /**
       * Scrolling to the row rather than to the box inside it keeps "Child 2" and the
       * question on screen; focus still goes to the box, so the next keystroke lands
       * where it should. Removing the first child falls back to the Add button,
       * because focus would otherwise be lost to the document body.
       */ function useChildFocus({ pending, onHandled, addChildRef }) {
        (0, react.useEffect)(() => {
          if (!pending) return;
          onHandled();
          scrollToElementAfterPaint(
            () => (pending.key ? childRow(pending.key) : null) ?? addChildRef.current,
            {
              focusWithin: "input",
            },
          );
        }, [pending, onHandled, addChildRef]);
      } // ./components/calculator/CalculatorShell.tsx

      /* __next_internal_client_entry_do_not_use__ CalculatorShell auto */
      /**
       * Step orchestration, spec §20.
       *
       * The rule that shapes everything here: NEVER ask for finances before showing
       * the maximum. The interstitial result after step 2 is the number most users
       * came for, and it must not be gated behind a means test they may not want to
       * complete.
       *
       * No localStorage or sessionStorage for anything (§22). A shared or family
       * computer is the normal case for this audience, and there is no server to send
       * anything to either: the whole calculation runs in the page.
       *
       * This file holds the state and decides what is on screen. Each step renders
       * itself, the answers and the arithmetic live in formState.ts, and neither
       * knows about the other.
       */

      function CalculatorShell() {
        const [form, setForm] = (0, react.useState)(emptyForm);
        const [step, setStep] = (0, react.useState)("where");
        const [maxStepReached, setMaxStepReached] = (0, react.useState)("where");
        const [wantsMeansTest, setWantsMeansTest] = (0, react.useState)(false);
        const [issues, setIssues] = (0, react.useState)([]);
        const [engineError, setEngineError] = (0, react.useState)(null);
        const [result, setResult] = (0, react.useState)(null);
        const [resultInput, setResultInput] = (0, react.useState)(null);
        const errorSummaryRef = (0, react.useRef)(null);
        const stepHeadingRef = (0, react.useRef)(null);
        const resultsRef = (0, react.useRef)(null);
        const addChildRef = (0, react.useRef)(null);
        const [pendingChildFocus, setPendingChildFocus] = (0, react.useState)(null);
        const clearPendingChildFocus = (0, react.useCallback)(() => setPendingChildFocus(null), []);
        // ── Calculating ─────────────────────────────────────────────────────────
        /**
         * Returns whether the calculation succeeded, so callers can decline to move
         * on. Advancing past a step whose field is wrong leaves the message on a
         * screen the person has just left, which is how "it shows nothing" happens.
         */ const runWith = (0, react.useCallback)((current, withFinances) => {
          setIssues([]);
          setEngineError(null);
          const built = buildInput(current, withFinances);
          try {
            setResult(calculate(built));
            setResultInput(built);
            return true;
          } catch (e) {
            setResult(null);
            setResultInput(null);
            if (e instanceof ValidationError) {
              setIssues(
                e.issues.length > 0
                  ? [...e.issues]
                  : [
                      {
                        path: "",
                        message: e.message,
                      },
                    ],
              );
              queueMicrotask(() => errorSummaryRef.current?.focus());
            } else if (e instanceof GuardrailViolation) {
              // [§15 UI contract] Never show the raw error. Log the rule code only:
              // no user data, and render the fallback.
              console.error(`GuardrailViolation: ${e.rule}`);
              setEngineError("guardrail");
            } else if (e instanceof errors_DataError) {
              setEngineError("data");
            } else {
              setEngineError("data");
            }
            return false;
          }
        }, []);
        const run = (0, react.useCallback)(
          (withFinances) => runWith(form, withFinances),
          [form, runWith],
        );
        const goTo = (0, react.useCallback)((next) => {
          setStep(next);
          setMaxStepReached((prev) => (isAfter(next, prev) ? next : prev));
        }, []);
        // ── Restoring the shareable part of the answers from the URL ────────────
        const hydrated = (0, react.useRef)(false);
        (0, react.useEffect)(() => {
          if (hydrated.current) return;
          hydrated.current = true;
          const shared = fromQueryString(window.location.search);
          const restored = {
            ...emptyForm(),
          };
          if (shared.nation) restored.nation = shared.nation;
          if (shared.region) restored.region = shared.region;
          if (shared.la) restored.la = shared.la;
          if (shared.formerFosterCarer) restored.wasFosterCarer = true;
          if (shared.ages?.length) {
            const disability = new Set(shared.disability ?? []);
            restored.children = shared.ages.map((age, i) => ({
              ...emptyChild(),
              ageYears: String(age),
              hasDisabilityOrAdditionalNeeds: disability.has(i),
            }));
            // Left untouched, so it tracks the children in the link. Setting it here
            // and calling it the carer's own answer would freeze it against a child
            // they add afterwards.
            restored.householdChildren = String(shared.ages.length);
          }
          setForm(restored);
          // Someone opening a shared link expects to see the figure, not a blank form
          // with their answers quietly pre-filled. Only jump to the result when the
          // link carries enough to actually calculate one; otherwise leave them at
          // the start, where the missing answer is asked for.
          //
          // Calculated from `restored` rather than from state, because the state set
          // above is not yet visible on this render and the calculation would run
          // against an empty form.
          const enough =
            Boolean(shared.ages?.length) &&
            Boolean(shared.nation) &&
            (shared.nation !== "england" || Boolean(shared.region) || Boolean(shared.la));
          if (enough && runWith(restored, false)) goTo("result");
        }, [runWith, goTo]);
        // [§20] Auto-mark the eldest by age. Only the eldest attracts the higher
        // Child Benefit rate, so getting it wrong shifts the figure. The carer's own
        // choice always wins, which is what eldestOverridden records.
        (0, react.useEffect)(() => {
          setForm((f) => {
            if (f.eldestOverridden) return f;
            const best = indexOfOldest(f.children);
            return f.eldestIndex === best
              ? f
              : {
                  ...f,
                  eldestIndex: best,
                };
          });
        }, [form.children, form.eldestOverridden]);
        useStepFocus({
          step,
          hasResult: Boolean(result),
          headingRef: stepHeadingRef,
          resultsRef,
        });
        useChildFocus({
          pending: pendingChildFocus,
          onHandled: clearPendingChildFocus,
          addChildRef,
        });
        // ── Deriving what the steps need ────────────────────────────────────────
        const shareUrl = (0, react.useMemo)(() => {
          if (false) {
          }
          const qs = toQueryString(shareableState(form));
          return `${window.location.origin}${window.location.pathname}${qs}`;
        }, [form]);
        const errorFor = (0, react.useCallback)(
          (path) => issues.find((e) => e.path === path)?.message,
          [issues],
        );
        const elsewhere = issues.filter((e) => stepForPath(e.path) !== step);
        const stepProps = {
          form,
          set: setForm,
          errorFor,
          headingRef: stepHeadingRef,
          goTo,
          run,
        };
        return /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
          children: [
            /*#__PURE__*/ (0, jsx_runtime.jsx)(ErrorSummary, {
              issues: elsewhere,
              summaryRef: errorSummaryRef,
            }),
            engineError &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)(EngineErrorFallback, {
                kind: engineError,
              }),
            /*#__PURE__*/ (0, jsx_runtime.jsxs)("div", {
              className: "calculator-form",
              children: [
                step === "where" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(WhereStep, {
                    ...stepProps,
                  }),
                step === "children" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(ChildrenStep, {
                    ...stepProps,
                    addChildRef: addChildRef,
                    onChildAdded: (key) =>
                      setPendingChildFocus({
                        kind: "added",
                        key,
                      }),
                    onChildRemoved: (key) =>
                      setPendingChildFocus({
                        kind: "removed",
                        key,
                      }),
                  }),
                step === "result" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(ResultStep, {
                    ...stepProps,
                  }),
                step === "history" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(HistoryStep, {
                    ...stepProps,
                  }),
                step === "benefits" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(BenefitsStep, {
                    ...stepProps,
                  }),
                step === "finances" &&
                  FLAGS.MEANS_TEST_ENABLED &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(FinancesStep, {
                    ...stepProps,
                    onWantsMeansTest: setWantsMeansTest,
                  }),
                step === "council" &&
                  /*#__PURE__*/ (0, jsx_runtime.jsx)(CouncilStep, {
                    ...stepProps,
                    wantsMeansTest: wantsMeansTest,
                  }),
              ],
            }),
            /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
              "aria-live": "polite",
              className: "sr-only",
              children: result
                ? `Your estimate is ready. ${formatMoney(result.totalWeekly)} a week. The full result follows.`
                : "",
            }),
            result &&
              resultInput &&
              !engineError &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("div", {
                ref: resultsRef,
                children: /*#__PURE__*/ (0, jsx_runtime.jsx)(ResultsPanel, {
                  result: result,
                  input: resultInput,
                  regionLabel: form.region || undefined,
                  councilName: form.la ? LA_NAMES[form.la] : undefined,
                  shareUrl: shareUrl,
                  // Only on the interstitial. Once the carer has gone on through the
                  // later steps there is nothing to invite them to.
                  continuation:
                    step === "result"
                      ? /*#__PURE__*/ (0, jsx_runtime.jsx)(ResultContinuation, {
                          goTo: goTo,
                        })
                      : undefined,
                }),
              }),
            result &&
              step !== "result" &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "print-hide muted",
                children: SHARE_EXPLANATION,
              }),
            maxStepReached !== "where" &&
              /*#__PURE__*/ (0, jsx_runtime.jsx)("p", {
                className: "print-hide muted",
                children:
                  "Nothing has been saved, and the only thing this page ever sends anywhere is the first part of your postcode, and only if you press “find my council”. If you leave this page or refresh it, you will start again, so finish here first or open other pages in a new tab.",
              }),
          ],
        });
      }

      /***/
    },

    /***/ 9479: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 4925),
      );

      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [406, 13, 511, 358], () => __webpack_exec__(9479));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
