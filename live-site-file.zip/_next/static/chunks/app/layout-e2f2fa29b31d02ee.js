(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([
  [177],
  {
    /***/ 1063: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ StaleWatch: () => /* binding */ StaleWatch,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5127);
      /* __next_internal_client_entry_do_not_use__ StaleWatch auto */

      /**
       * The stale-rates banner, checked against the READER's date.
       *
       * The deadline is baked in at build time; the comparison is not. A static site
       * that nobody rebuilds keeps serving the same HTML for years, so the only clock
       * that can tell a carer their figures have expired is the one in their own
       * browser.
       *
       * Rendered on the server too when the build itself was already stale, so the
       * warning survives with JavaScript off. In every other case the server renders
       * nothing and this fills it in after hydration, which is why the two branches
       * cannot be collapsed into one.
       */ function StaleWatch({ effectiveTo, staleAtBuildTime }) {
        const [staleNow, setStaleNow] = (0, react__WEBPACK_IMPORTED_MODULE_1__.useState)(
          staleAtBuildTime,
        );
        (0, react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
          // Compared as ISO strings in UTC, the same way the engine does it, so a
          // reader in BST at half past midnight on 1 April cannot see a different
          // answer from the one the calculation uses.
          const check = () => setStaleNow(new Date().toISOString().slice(0, 10) > effectiveTo);
          check();
          // A tab left open across the boundary is a real case for this audience:
          // people leave the page up and come back to it.
          const daily = setInterval(check, 60 * 60 * 1000);
          return () => clearInterval(daily);
        }, [effectiveTo]);
        if (!staleNow) return null;
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
          role: "alert",
          className: "banner-critical",
          children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "wrap",
            children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
              children: [
                /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                  children: "These rates may be out of date.",
                }),
                " My newest figures ran to ",
                effectiveTo,
                ". New rates take effect on 1 April each year. Please check the current national minimum allowance before using anything here in a letter.",
              ],
            }),
          }),
        });
      }

      /***/
    },

    /***/ 3041: /***/ () => {
      // extracted by mini-css-extract-plugin
      /***/
    },

    /***/ 3601: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";
      /* harmony export */ __webpack_require__.d(__webpack_exports__, {
        /* harmony export */ ConsentBanner: () => /* binding */ ConsentBanner,
        /* harmony export */
      });
      /* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ =
        __webpack_require__(8767);
      /* harmony import */ var _useAnalyticsConsent__WEBPACK_IMPORTED_MODULE_1__ =
        __webpack_require__(3937);
      /* __next_internal_client_entry_do_not_use__ ConsentBanner auto */

      /**
       * The cookie consent bar.
       *
       * Renders nothing on the server and nothing without a configured
       * measurement ID, so a site without analytics has no banner and nothing to
       * consent to, exactly as before.
       *
       * The reader is asked once. Until they answer, no tag is loaded, which is what
       * makes this consent rather than notice. Both buttons are the same size and
       * the same prominence: a "reject" hidden in small grey text is not a free
       * choice, and this audience is the wrong one to play that game with.
       */ function ConsentBanner() {
        const { consent, configured, answer } = (0,
        _useAnalyticsConsent__WEBPACK_IMPORTED_MODULE_1__ /* .useAnalyticsConsent */.W)();
        if (!configured || consent !== "unset") return null;
        return /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("section", {
          className: "consent print-hide",
          "aria-label": "Cookies on this site",
          children: /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "wrap consent__inner",
            children: [
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "consent__text",
                children: [
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    children: [
                      /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(
                        "strong",
                        {
                          children: "May I count your visit?",
                        },
                      ),
                      " I would like to use Google Analytics to see which pages people find useful. It sets cookies and sends Google the pages you look at.",
                    ],
                  }),
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "consent__note",
                    children: [
                      "Nothing you type into the calculator is ever sent, whichever you choose. Saying no changes nothing about how the site works. You can change your mind at any time on the",
                      " ",
                      /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "/privacy",
                        children: "privacy page",
                      }),
                      ".",
                    ],
                  }),
                ],
              }),
              /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "consent__actions",
                children: [
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn",
                    onClick: () => answer("granted"),
                    children: "Yes, that is fine",
                  }),
                  /*#__PURE__*/ (0, react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                    type: "button",
                    className: "btn btn--secondary",
                    onClick: () => answer("denied"),
                    children: "No thank you",
                  }),
                ],
              }),
            ],
          }),
        });
      }

      /***/
    },

    /***/ 3814: /***/ (module, exports, __webpack_require__) => {
      "use strict";
      /* __next_internal_client_entry_do_not_use__  cjs */
      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        default: function () {
          return _default;
        },
        handleClientScriptLoad: function () {
          return handleClientScriptLoad;
        },
        initScriptLoader: function () {
          return initScriptLoader;
        },
      });
      const _interop_require_default = __webpack_require__(7543);
      const _interop_require_wildcard = __webpack_require__(212);
      const _jsxruntime = __webpack_require__(8767);
      const _reactdom = /*#__PURE__*/ _interop_require_default._(__webpack_require__(8534));
      const _react = /*#__PURE__*/ _interop_require_wildcard._(__webpack_require__(5127));
      const _headmanagercontextsharedruntime = __webpack_require__(2037);
      const _setattributesfromprops = __webpack_require__(7637);
      const _requestidlecallback = __webpack_require__(8441);
      const _htmlescape = __webpack_require__(6053);
      const ScriptCache = new Map();
      const LoadCache = new Set();
      const insertStylesheets = (stylesheets) => {
        // Case 1: Styles for afterInteractive/lazyOnload with appDir injected via handleClientScriptLoad
        //
        // Using ReactDOM.preinit to feature detect appDir and inject styles
        // Stylesheets might have already been loaded if initialized with Script component
        // Re-inject styles here to handle scripts loaded via handleClientScriptLoad
        // ReactDOM.preinit handles dedup and ensures the styles are loaded only once
        if (_reactdom.default.preinit) {
          stylesheets.forEach((stylesheet) => {
            _reactdom.default.preinit(stylesheet, {
              as: "style",
            });
          });
          return;
        }
        // Case 2: Styles for afterInteractive/lazyOnload with pages injected via handleClientScriptLoad
        //
        // We use this function to load styles when appdir is not detected
        // TODO: Use React float APIs to load styles once available for pages dir
        if (true) {
          let head = document.head;
          stylesheets.forEach((stylesheet) => {
            let link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = stylesheet;
            head.appendChild(link);
          });
        }
      };
      const loadScript = (props) => {
        const {
          src,
          id,
          onLoad = () => {},
          onReady = null,
          dangerouslySetInnerHTML,
          children = "",
          strategy = "afterInteractive",
          onError,
          stylesheets,
        } = props;
        const cacheKey = id || src;
        // Script has already loaded
        if (cacheKey && LoadCache.has(cacheKey)) {
          return;
        }
        // Contents of this script are already loading/loaded
        if (ScriptCache.has(src)) {
          LoadCache.add(cacheKey);
          // It is possible that multiple `next/script` components all have same "src", but has different "onLoad"
          // This is to make sure the same remote script will only load once, but "onLoad" are executed in order
          ScriptCache.get(src).then(onLoad, onError);
          return;
        }
        /** Execute after the script first loaded */ const afterLoad = () => {
          // Run onReady for the first time after load event
          if (onReady) {
            onReady();
          }
          // add cacheKey to LoadCache when load successfully
          LoadCache.add(cacheKey);
        };
        const el = document.createElement("script");
        const loadPromise = new Promise((resolve, reject) => {
          el.addEventListener("load", function (e) {
            resolve();
            if (onLoad) {
              onLoad.call(this, e);
            }
            afterLoad();
          });
          el.addEventListener("error", function (e) {
            reject(e);
          });
        }).catch(function (e) {
          if (onError) {
            onError(e);
          }
        });
        if (dangerouslySetInnerHTML) {
          // Casting since lib.dom.d.ts doesn't have TrustedHTML yet.
          el.innerHTML = dangerouslySetInnerHTML.__html || "";
          afterLoad();
        } else if (children) {
          el.textContent =
            typeof children === "string"
              ? children
              : Array.isArray(children)
                ? children.join("")
                : "";
          afterLoad();
        } else if (src) {
          el.src = src;
          // do not add cacheKey into LoadCache for remote script here
          // cacheKey will be added to LoadCache when it is actually loaded (see loadPromise above)
          ScriptCache.set(src, loadPromise);
        }
        (0, _setattributesfromprops.setAttributesFromProps)(el, props);
        if (strategy === "worker") {
          el.setAttribute("type", "text/partytown");
        }
        el.setAttribute("data-nscript", strategy);
        // Load styles associated with this script
        if (stylesheets) {
          insertStylesheets(stylesheets);
        }
        document.body.appendChild(el);
      };
      function handleClientScriptLoad(props) {
        const { strategy = "afterInteractive" } = props;
        if (strategy === "lazyOnload") {
          window.addEventListener("load", () => {
            (0, _requestidlecallback.requestIdleCallback)(() => loadScript(props));
          });
        } else {
          loadScript(props);
        }
      }
      function loadLazyScript(props) {
        if (document.readyState === "complete") {
          (0, _requestidlecallback.requestIdleCallback)(() => loadScript(props));
        } else {
          window.addEventListener("load", () => {
            (0, _requestidlecallback.requestIdleCallback)(() => loadScript(props));
          });
        }
      }
      function addBeforeInteractiveToCache() {
        const scripts = [
          ...document.querySelectorAll('[data-nscript="beforeInteractive"]'),
          ...document.querySelectorAll('[data-nscript="beforePageRender"]'),
        ];
        scripts.forEach((script) => {
          const cacheKey = script.id || script.getAttribute("src");
          LoadCache.add(cacheKey);
        });
      }
      function initScriptLoader(scriptLoaderItems) {
        scriptLoaderItems.forEach(handleClientScriptLoad);
        addBeforeInteractiveToCache();
      }
      /**
       * Load a third-party scripts in an optimized way.
       *
       * Read more: [Next.js Docs: `next/script`](https://nextjs.org/docs/app/api-reference/components/script)
       */ function Script(props) {
        const {
          id,
          src = "",
          onLoad = () => {},
          onReady = null,
          strategy = "afterInteractive",
          onError,
          stylesheets,
          ...restProps
        } = props;
        // Context is available only during SSR
        let { updateScripts, scripts, getIsSsr, appDir, nonce } = (0, _react.useContext)(
          _headmanagercontextsharedruntime.HeadManagerContext,
        );
        // if a nonce is explicitly passed to the script tag, favor that over the automatic handling
        nonce = restProps.nonce || nonce;
        /**
         * - First mount:
         *   1. The useEffect for onReady executes
         *   2. hasOnReadyEffectCalled.current is false, but the script hasn't loaded yet (not in LoadCache)
         *      onReady is skipped, set hasOnReadyEffectCalled.current to true
         *   3. The useEffect for loadScript executes
         *   4. hasLoadScriptEffectCalled.current is false, loadScript executes
         *      Once the script is loaded, the onLoad and onReady will be called by then
         *   [If strict mode is enabled / is wrapped in <OffScreen /> component]
         *   5. The useEffect for onReady executes again
         *   6. hasOnReadyEffectCalled.current is true, so entire effect is skipped
         *   7. The useEffect for loadScript executes again
         *   8. hasLoadScriptEffectCalled.current is true, so entire effect is skipped
         *
         * - Second mount:
         *   1. The useEffect for onReady executes
         *   2. hasOnReadyEffectCalled.current is false, but the script has already loaded (found in LoadCache)
         *      onReady is called, set hasOnReadyEffectCalled.current to true
         *   3. The useEffect for loadScript executes
         *   4. The script is already loaded, loadScript bails out
         *   [If strict mode is enabled / is wrapped in <OffScreen /> component]
         *   5. The useEffect for onReady executes again
         *   6. hasOnReadyEffectCalled.current is true, so entire effect is skipped
         *   7. The useEffect for loadScript executes again
         *   8. hasLoadScriptEffectCalled.current is true, so entire effect is skipped
         */ const hasOnReadyEffectCalled = (0, _react.useRef)(false);
        (0, _react.useEffect)(() => {
          const cacheKey = id || src;
          if (!hasOnReadyEffectCalled.current) {
            // Run onReady if script has loaded before but component is re-mounted
            if (onReady && cacheKey && LoadCache.has(cacheKey)) {
              onReady();
            }
            hasOnReadyEffectCalled.current = true;
          }
        }, [onReady, id, src]);
        const hasLoadScriptEffectCalled = (0, _react.useRef)(false);
        (0, _react.useEffect)(() => {
          if (!hasLoadScriptEffectCalled.current) {
            if (strategy === "afterInteractive") {
              loadScript(props);
            } else if (strategy === "lazyOnload") {
              loadLazyScript(props);
            }
            hasLoadScriptEffectCalled.current = true;
          }
        }, [props, strategy]);
        if (strategy === "beforeInteractive" || strategy === "worker") {
          if (updateScripts) {
            scripts[strategy] = (scripts[strategy] || []).concat([
              {
                id,
                src,
                onLoad,
                onReady,
                onError,
                ...restProps,
                nonce,
              },
            ]);
            updateScripts(scripts);
          } else if (getIsSsr && getIsSsr()) {
            // Script has already loaded during SSR
            LoadCache.add(id || src);
          } else if (getIsSsr && !getIsSsr()) {
            loadScript({
              ...props,
              nonce,
            });
          }
        }
        // For the app directory, we need React Float to preload these scripts.
        if (appDir) {
          // Injecting stylesheets here handles beforeInteractive and worker scripts correctly
          // For other strategies injecting here ensures correct stylesheet order
          // ReactDOM.preinit handles loading the styles in the correct order,
          // also ensures the stylesheet is loaded only once and in a consistent manner
          //
          // Case 1: Styles for beforeInteractive/worker with appDir - handled here
          // Case 2: Styles for beforeInteractive/worker with pages dir - Not handled yet
          // Case 3: Styles for afterInteractive/lazyOnload with appDir - handled here
          // Case 4: Styles for afterInteractive/lazyOnload with pages dir - handled in insertStylesheets function
          if (stylesheets) {
            stylesheets.forEach((styleSrc) => {
              _reactdom.default.preinit(styleSrc, {
                as: "style",
              });
            });
          }
          // Before interactive scripts need to be loaded by Next.js' runtime instead
          // of native <script> tags, because they no longer have `defer`.
          if (strategy === "beforeInteractive") {
            if (!src) {
              // For inlined scripts, we put the content in `children`.
              if (restProps.dangerouslySetInnerHTML) {
                // Casting since lib.dom.d.ts doesn't have TrustedHTML yet.
                restProps.children = restProps.dangerouslySetInnerHTML.__html;
                delete restProps.dangerouslySetInnerHTML;
              }
              return /*#__PURE__*/ (0, _jsxruntime.jsx)("script", {
                nonce: nonce,
                dangerouslySetInnerHTML: {
                  __html:
                    "(self.__next_s=self.__next_s||[]).push(" +
                    (0, _htmlescape.htmlEscapeJsonString)(
                      JSON.stringify([
                        0,
                        {
                          ...restProps,
                          id,
                        },
                      ]),
                    ) +
                    ")",
                },
              });
            } else {
              // @ts-ignore
              _reactdom.default.preload(
                src,
                restProps.integrity
                  ? {
                      as: "script",
                      integrity: restProps.integrity,
                      nonce,
                      crossOrigin: restProps.crossOrigin,
                    }
                  : {
                      as: "script",
                      nonce,
                      crossOrigin: restProps.crossOrigin,
                    },
              );
              return /*#__PURE__*/ (0, _jsxruntime.jsx)("script", {
                nonce: nonce,
                dangerouslySetInnerHTML: {
                  __html:
                    "(self.__next_s=self.__next_s||[]).push(" +
                    (0, _htmlescape.htmlEscapeJsonString)(
                      JSON.stringify([
                        src,
                        {
                          ...restProps,
                          id,
                        },
                      ]),
                    ) +
                    ")",
                },
              });
            }
          } else if (strategy === "afterInteractive") {
            if (src) {
              // @ts-ignore
              _reactdom.default.preload(
                src,
                restProps.integrity
                  ? {
                      as: "script",
                      integrity: restProps.integrity,
                      nonce,
                      crossOrigin: restProps.crossOrigin,
                    }
                  : {
                      as: "script",
                      nonce,
                      crossOrigin: restProps.crossOrigin,
                    },
              );
            }
          }
        }
        return null;
      }
      Object.defineProperty(Script, "__nextScript", {
        value: true,
      });
      const _default = Script;
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=script.js.map

      /***/
    },

    /***/ 3937: /***/ (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
      "use strict";

      // EXPORTS
      __webpack_require__.d(__webpack_exports__, {
        W: () => /* binding */ useAnalyticsConsent,
      });

      // EXTERNAL MODULE: ../../node_modules/.pnpm/next@15.5.24_@playwright+test@1.62.1_@types+node@22.20.1_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/next/dist/compiled/react/index.js
      var react = __webpack_require__(5127); // ./lib/analytics.ts
      /** Google Analytics loads only after an explicit, remembered Yes. */ const CONSENT_KEY =
        "sgo-analytics-consent";
      const CONSENT_EVENT = "sgo-analytics-consent-change";
      let pageConsent;
      /** Read the editable public config after its beforeInteractive script loads. */ function getMeasurementId() {
        if (false) {
        }
        const configured = window.SGO_GOOGLE_CONFIG?.ga4MeasurementId;
        const id = typeof configured === "string" ? configured.trim() : "";
        // Google's example tag and our placeholder must never start tracking.
        return /^G-[A-Z0-9]+$/.test(id) && !["G-MYTAG", "G-XXXXXXXXXX"].includes(id) ? id : "";
      }
      function readConsent() {
        if (false) {
        }
        if (pageConsent !== undefined) return pageConsent;
        try {
          const value = window.localStorage.getItem(CONSENT_KEY);
          return value === "granted" || value === "denied" ? value : "unset";
        } catch {
          return "unset";
        }
      }
      /** Keep this page's choice even when the browser refuses persistent storage. */ function writeConsent(
        value,
      ) {
        pageConsent = value;
        try {
          if (value === "unset") window.localStorage.removeItem(CONSENT_KEY);
          else window.localStorage.setItem(CONSENT_KEY, value);
        } catch {
          /* The in-memory choice still holds for this page. */
        }
        window.dispatchEvent(new Event(CONSENT_EVENT));
      }
      /** Synchronize the banner, privacy controls, and other open tabs. */ function subscribeToConsent(
        callback,
      ) {
        const storageChanged = (event) => {
          if (event.key !== CONSENT_KEY && event.key !== null) return;
          pageConsent = undefined;
          callback();
        };
        window.addEventListener(CONSENT_EVENT, callback);
        window.addEventListener("storage", storageChanged);
        return () => {
          window.removeEventListener(CONSENT_EVENT, callback);
          window.removeEventListener("storage", storageChanged);
        };
      }
      function cleanUrl(value) {
        try {
          const url = new URL(value);
          return ["http:", "https:"].includes(url.protocol) ? url.origin + url.pathname : "";
        } catch {
          return "";
        }
      }
      function pageDetails() {
        return {
          page_location: cleanUrl(window.location.href),
          page_referrer: cleanUrl(document.referrer),
          page_title: document.title,
        };
      }
      /** One tag per document; withdrawing and granting again also resets opt-out. */ function loadAnalytics() {
        const id = getMeasurementId();
        if (!id || readConsent() !== "granted") return;
        const flags = window;
        const wasDisabled = flags[`ga-disable-${id}`] === true;
        flags[`ga-disable-${id}`] = false;
        if (document.getElementById("ga-tag")) {
          if (wasDisabled) window.gtag?.("event", "page_view", pageDetails());
          return;
        }
        // Use Google's documented queue format (Arguments objects), and queue the
        // configuration before fetching the script so a fast load cannot race it.
        window.dataLayer = window.dataLayer ?? [];
        window.gtag = function gtag() {
          window.dataLayer?.push(arguments);
        };
        window.gtag("js", new Date());
        window.gtag("config", id, {
          send_page_view: false,
          allow_google_signals: false,
          allow_ad_personalization_signals: false,
          ...pageDetails(),
        });
        // Share-link query strings, fragments and calculator answers are excluded.
        window.gtag("event", "page_view", pageDetails());
        const script = document.createElement("script");
        script.id = "ga-tag";
        script.async = true;
        script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`;
        document.head.appendChild(script);
      }
      /** Google's documented opt-out flag is checked before subsequent hits. */ function disableAnalytics() {
        const id = getMeasurementId();
        if (!id) return;
        window[`ga-disable-${id}`] = true;
      } // ./components/ui/useAnalyticsConsent.ts

      /* __next_internal_client_entry_do_not_use__ useAnalyticsConsent auto */

      function useAnalyticsConsent() {
        const [consent, setConsent] = (0, react.useState)(null);
        const [configured, setConfigured] = (0, react.useState)(null);
        (0, react.useEffect)(() => {
          const synchronize = () => {
            const available = getMeasurementId() !== "";
            const choice = readConsent();
            setConfigured(available);
            setConsent(choice);
            if (available && choice === "granted") loadAnalytics();
            else disableAnalytics();
          };
          synchronize();
          return subscribeToConsent(synchronize);
        }, []);
        return {
          consent,
          configured,
          answer: writeConsent,
        };
      }

      /***/
    },

    /***/ 4008: /***/ (__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 3601),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.bind(__webpack_require__, 1063),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.t.bind(__webpack_require__, 3041, 23),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.t.bind(__webpack_require__, 9552, 23),
      );
      Promise.resolve(/* import() eager */).then(
        __webpack_require__.t.bind(__webpack_require__, 3814, 23),
      );

      /***/
    },

    /***/ 6053: /***/ (__unused_webpack_module, exports) => {
      "use strict";
      // This utility is based on https://github.com/zertosh/htmlescape
      // License: https://github.com/zertosh/htmlescape/blob/0527ca7156a524d256101bb310a9f970f63078ad/LICENSE

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        ESCAPE_REGEX: function () {
          return ESCAPE_REGEX;
        },
        htmlEscapeAttributeString: function () {
          return htmlEscapeAttributeString;
        },
        htmlEscapeJsonString: function () {
          return htmlEscapeJsonString;
        },
      });
      const ESCAPE_LOOKUP = {
        "&": "\\u0026",
        ">": "\\u003e",
        "<": "\\u003c",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029",
      };
      const ESCAPE_REGEX = /[&><\u2028\u2029]/g;
      const ATTRIBUTE_ESCAPE_LOOKUP = {
        "&": "&amp;",
        '"': "&quot;",
        "'": "&#39;",
        "<": "&lt;",
        ">": "&gt;",
      };
      const ATTRIBUTE_ESCAPE_REGEX = /[&"'<>]/g;
      function htmlEscapeJsonString(str) {
        return str.replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
      }
      function htmlEscapeAttributeString(str) {
        return str.replace(ATTRIBUTE_ESCAPE_REGEX, (match) => ATTRIBUTE_ESCAPE_LOOKUP[match]);
      } //# sourceMappingURL=htmlescape.js.map

      /***/
    },

    /***/ 8441: /***/ (module, exports) => {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true,
      });
      0 && 0;
      function _export(target, all) {
        for (var name in all)
          Object.defineProperty(target, name, {
            enumerable: true,
            get: all[name],
          });
      }
      _export(exports, {
        cancelIdleCallback: function () {
          return cancelIdleCallback;
        },
        requestIdleCallback: function () {
          return requestIdleCallback;
        },
      });
      const requestIdleCallback =
        (typeof self !== "undefined" &&
          self.requestIdleCallback &&
          self.requestIdleCallback.bind(window)) ||
        function (cb) {
          let start = Date.now();
          return self.setTimeout(function () {
            cb({
              didTimeout: false,
              timeRemaining: function () {
                return Math.max(0, 50 - (Date.now() - start));
              },
            });
          }, 1);
        };
      const cancelIdleCallback =
        (typeof self !== "undefined" &&
          self.cancelIdleCallback &&
          self.cancelIdleCallback.bind(window)) ||
        function (id) {
          return clearTimeout(id);
        };
      if (
        (typeof exports.default === "function" ||
          (typeof exports.default === "object" && exports.default !== null)) &&
        typeof exports.default.__esModule === "undefined"
      ) {
        Object.defineProperty(exports.default, "__esModule", {
          value: true,
        });
        Object.assign(exports.default, exports);
        module.exports = exports.default;
      } //# sourceMappingURL=request-idle-callback.js.map

      /***/
    },

    /***/ 9552: /***/ () => {
      // extracted by mini-css-extract-plugin
      /***/
    },
  },
  /******/ (__webpack_require__) => {
    // webpackRuntimeModules
    /******/ var __webpack_exec__ = (moduleId) =>
      __webpack_require__((__webpack_require__.s = moduleId));
    /******/ __webpack_require__.O(0, [518, 13, 511, 358], () => __webpack_exec__(4008));
    /******/ var __webpack_exports__ = __webpack_require__.O();
    /******/ _N_E = __webpack_exports__;
    /******/
  },
]);
