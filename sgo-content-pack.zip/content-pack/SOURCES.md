# Every source the site relies on

Exported 2026-09-01. 49 sources.

Each page lists the ones it uses. This is the full set, for reference.

A blank link means we hold the source but have not yet found a permanent public
address for it. That is tracked and is not an invitation to drop the claim.

### Barrett v Kirklees MBC [2010] EWHC 467 (Admin)

- Reference: `kirklees-2010`
- Kind: case
- Link: no public link yet
- What it decided: A flat two-thirds of the core fostering allowance was an unjustified departure from guidance.

### Care Inspectorate Wales, National Minimum Allowances for Foster Carers 2023 to 2024, bulletin of 27 January 2023

- Reference: `ciw-nma-bulletin-2023-24`
- Kind: dataset
- Link: https://content.govdelivery.com/accounts/UKWALES_CSSIW_INT/bulletins/3450cef
- What it decided: Welsh national minimum allowances are issued as bilingual bulletins produced by Care Inspectorate Wales on behalf of the Welsh Government, addressed to local authorities and independent fostering providers, setting rates the Welsh Government expects to be applied from 1 April.

### Child Benefit and Guardian's Allowance Up-rating Order 2025

- Reference: `cb-ga-uprating-order-2025`
- Kind: regulation
- Link: no public link yet

### Child Benefit and Guardian's Allowance Up-rating Order 2026

- Reference: `cb-ga-uprating-order-2026`
- Kind: regulation
- Link: no public link yet

### Children Act 1989, s.14A

- Reference: `ca1989-s14a`
- Kind: statute
- Link: https://www.legislation.gov.uk/ukpga/1989/41/section/14A

### CoramBAAF Practice Note 75 - special guardianship financial support

- Reference: `corambaaf-pn75`
- Kind: guidance
- Link: no public link yet
- What it decided: The DfE standardised means-test model is non-statutory and pre-dates Universal Credit.

### Department of Health (Northern Ireland), Foster care allowances, Model Scheme 2024-25

- Reference: `ni-model-scheme-2024-25`
- Kind: dataset
- Link: https://www.health-ni.gov.uk/sites/default/files/publications/health/model-scheme-2024-25.pdf
- What it decided: Sets the weekly foster care scale rates in Northern Ireland from 1 April 2024 at 149, 166, 187 and 219 pounds across four age bands.

### Derby City Council, Special Guardianship Orders and Derby Support Scheme

- Reference: `derby-sg-scheme`
- Kind: guidance
- Link: https://derbycsc.trixonline.co.uk/chapter/special-guardianship-orders-and-derby-support-scheme
- What it decided: A Special Guardianship Order allowance is set at the equivalent of Derby's basic fostering rate for a child of that age.

### Devon County Council, Applications for Special Guardianship Orders (procedures manual), last updated 24 October 2024

- Reference: `devon-sgo-procedures-2024`
- Kind: guidance
- Link: https://devoncs.trixonline.co.uk/chapter/applications-for-special-guardianship-orders
- What it decided: Devon uses the standardised means-test model with the living costs disregard set at 100% of the Income Support applicable amount, states that paying a fixed percentage of the fostering allowance would not be lawful, and stopped deducting Child Benefit from special guardians on means-tested benefits from 1 January 2024.

### DfE National Minimum Allowance for foster carers, 2024 to 2025 (National Archives snapshot)

- Reference: `dfe-nma-2024-25`
- Kind: dataset
- Link: https://webarchive.nationalarchives.gov.uk/ukgwa/*/https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering
- What it decided: Weekly allowances for the tax year from 6 April 2024 to 5 April 2025, by region and age band. This guidance applies to England.

### DfE National Minimum Allowance for foster carers, 2025 to 2026

- Reference: `dfe-nma-2025-26`
- Kind: dataset
- Link: no public link yet

### DfE National Minimum Allowance for foster carers, 2026 to 2027

- Reference: `dfe-nma-2026-27`
- Kind: dataset
- Link: https://www.gov.uk/support-for-foster-parents/help-with-the-cost-of-fostering

### DfE Special Guardianship Guidance (Jan 2017), para 65

- Reference: `dfe-guidance-2017-para65`
- Kind: guidance
- Link: https://www.gov.uk/government/publications/special-guardianship-guidance

### DfE, Kinship Care: statutory guidance for local authorities (October 2024)

- Reference: `kinship-care-guidance-2024`
- Kind: guidance
- Link: https://assets.publishing.service.gov.uk/media/670d3ed5e84ae1fd8592f2fa/Kinship_Care_-_statutory_guidance_for_local_authorities__October_2024.pdf
- What it decided: In calculating ongoing special guardianship financial support, the local authority should have regard to the fostering allowance that would have been paid if the child was fostered.

### DWP, Benefit and pension rates 2026 to 2027

- Reference: `dwp-benefit-rates-2026-27`
- Kind: dataset
- Link: https://www.gov.uk/government/publications/benefit-and-pension-rates-2026-to-2027/proposed-benefit-and-pension-rates-2026-to-2027

### Fostering news, '2025 Allowance Uplifts Across the UK'

- Reference: `fostering-news-2025-uplifts`
- Kind: dataset
- Link: https://fosteringnews.co.uk/fostering/2025-allowance-uplifts-across-the-uk-england-wales-scotland-ni/
- What it decided: Records the 2025/26 Welsh National Minimum Allowance as £224 (0-4), £204 (5-10 and 11-15), £255 (16-17).

### HSC (Northern Ireland) fostering allowances, 2026 to 2027

- Reference: `hsc-fostering-2026-27`
- Kind: dataset
- Link: no public link yet

### Kinship Zones - kinship allowance pilot (2026-2029)

- Reference: `kinship-zones-2026`
- Kind: dataset
- Link: https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care
- What it decided: A pilot in seven English councils paying a non-means-tested allowance equal to the fostering National Minimum Allowance.

### Leeds City Council, Revised Special Guardianship Support Offer, cover report, 1 March 2024

- Reference: `leeds-sgo-support-offer-2024`
- Kind: guidance
- Link: https://democracy.leeds.gov.uk/documents/s254642/Special%20Guardianship%20Order%20Support%20Cover%20Report%20010324.pdf
- What it decided: Under the revised offer, carers of children subject to non-agency orders who already receive a means-tested benefit are to receive support that is not means tested.

### LGSCO decision, Devon County Council (23 000 973, 25 January 2024)

- Reference: `lgsco-devon-2024`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973
- What it decided: The council was at fault for deducting Child Benefit from all special guardians on Universal Credit as a blanket rule, without looking at individual circumstances. It was ordered to recalculate and to refund deductions. Devon changed the policy with effect from 1 January 2024, and a later complaint about its current practice was not upheld.

### LGSCO decision, Devon County Council (24 003 172), not upheld

- Reference: `lgsco-devon-24-003-172`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/24-003-172
- What it decided: A later complaint about Devon's deductions was not upheld. The Ombudsman found the practice consistent with government guidance, the council paying its maximum allowance less child-related benefits.

### LGSCO decision, fostering (20 005 985)

- Reference: `lgsco-20-005-985`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/fostering/20-005-985
- What it decided: Squarely about the two-year transitional provision and the skills or reward element ending two years after the special guardianship order.

### LGSCO decision, friends and family carers (22 011 906)

- Reference: `lgsco-22-011-906`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/22-011-906
- What it decided: Concerns a 2020 policy change and how it affected the calculation of allowances.

### LGSCO decision, friends and family carers (22 018 116)

- Reference: `lgsco-22-018-116`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/22-018-116
- What it decided: Fault for not following the guidance on how much to pay, and for not considering exceptional circumstances.

### LGSCO decision, Rochdale MBC (17 010 167, May 2019), upheld on judicial review

- Reference: `lgsco-rochdale-2019`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/17-010-167
- What it decided: Grandparents were paid 119.18 pounds a week where the council's own fostering rate was 132 pounds, about 13 pounds a week short, under a policy departing from the statutory guidance without a rational explanation. Backdating to November 2013 was recommended.

### LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)

- Reference: `lgsco-southend-2020`
- Kind: ombudsman
- Link: https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363
- What it decided: Reducing the whole allowance to 75% of the core fostering allowance in year one and 50% in year two misapplied the two-year transitional provision, which protects the reward element only. Backdating of about 6,948 pounds was recommended, and the council estimated 37 other families were affected.

### LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)

- Reference: `lgsco-north-tyneside-17002928`
- Kind: ombudsman
- Link: https://web.archive.org/web/https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf
- What it decided: Calculating a special guardianship allowance as a percentage of the fostering allowance was contrary to statutory guidance and case law. The council identified 171 families who may not have received the right support, and payments were backdated to November 2013.

### Lincolnshire County Council, Special Guardianship Allowance Assessment Framework

- Reference: `lincolnshire-sg-framework`
- Kind: guidance
- Link: https://www.lincolnshire.gov.uk/directory-record/82363/special-guardianship-allowance-assessment-framework
- What it decided: Distinguishes the statutory 'Special Guardianship Guidance' from the non-statutory 'Standardised means test model for adoption and special guardianship financial support'.

### North Tyneside Council, Decision Record: Foster Care, Special Guardianship, Adoption and Child Arrangement Order Allowance Increases

- Reference: `north-tyneside-decision-2025`
- Kind: guidance
- Link: https://northtyneside.gov.uk/sites/default/files/web-page-related-files/20250321%20-%20Decision%20Record%20-%20Fostering%20Allowance.pdf
- What it decided: Special guardianship allowances are uplifted alongside fostering allowances, with London and South East weighting applied in line with the recommended minimum levels. All uplifts take effect from 1 April 2025.

### R (B) v Lewisham LBC [2008] EWHC 738 (Admin)

- Reference: `lewisham-2008`
- Kind: case
- Link: no public link yet
- What it decided: Using the lower adoption allowance model was unlawful. Fostering allowances are the starting point.

### R (TT) v Merton LBC [2012] EWHC 2055 (Admin)

- Reference: `merton-2012`
- Kind: case
- Link: no public link yet
- What it decided: Blanket percentage deduction unlawful. BUT: no duty to pay every special guardian an allowance, and the means-test methodology itself was upheld as lawful.

### R (X) v Tower Hamlets LBC [2013] EWCA Civ 904

- Reference: `tower-hamlets-2013`
- Kind: case
- Link: no public link yet
- What it decided: Paying family foster carers less than unrelated foster carers was unlawful. Former foster carers should not be worse off.

### Scottish Government, Foster and kinship carers, Scottish Recommended Allowance: implementation review

- Reference: `sra-implementation-review`
- Kind: dataset
- Link: no public link yet
- What it decided: Records that there was no uplift to payments in the financial year 2024/25.

### Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026

- Reference: `sra-2026-27`
- Kind: dataset
- Link: https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/
- What it decided: A national minimum for foster and kinship carers alike. Councils may pay more.

### Scottish Recommended Allowance, rates announced 29 August 2023, unchanged for 2024/25

- Reference: `sra-2024-25`
- Kind: dataset
- Link: https://www.gov.scot/news/new-national-allowance-for-foster-and-kinship-carers/
- What it decided: A national minimum for foster and kinship carers alike. Councils may pay more.

### Shropshire Council, Special Guardianship Allowances Policy (Cabinet, 8 February 2021)

- Reference: `shropshire-sg-policy-2021`
- Kind: guidance
- Link: https://shropshire.gov.uk/committee-services/documents/s26540/Special Guardianship Allowances Policy.pdf

### Special Guardianship Regulations 2005, reg 13(2)

- Reference: `sg-regs-2005-reg13`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/13
- What it decided: Requires a council to take into account other grants, benefits, allowances and resources available to the guardian, and allows it to deduct an amount to take account of Child Benefit received for the child.

### Special Guardianship Regulations 2005, reg 5

- Reference: `sg-regs-2005-reg5`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/5
- What it decided: The council remains responsible for assessing support needs for three years from the making of the order.

### Special Guardianship Regulations 2005, reg 6

- Reference: `sg-regs-2005-reg6`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

### Special Guardianship Regulations 2005, reg 6(2)(b)

- Reference: `sg-regs-2005-reg6-2-b`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- What it decided: The specific provision on taking a child's needs into account when deciding financial support, including any disability or the consequences of earlier abuse or neglect.

### Special Guardianship Regulations 2005, reg 7

- Reference: `sg-regs-2005-reg7`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/7

### Special Guardianship Regulations 2005, reg 9

- Reference: `sg-regs-2005-reg9`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/9
- What it decided: Financial support ceases in the circumstances set out in the regulation, including when the child reaches 18 unless the conditions for continuing are met.

### Special Guardianship Regulations 2005, regs 10-11

- Reference: `sg-regs-2005-reg10-11`
- Kind: regulation
- Link: https://www.legislation.gov.uk/uksi/2005/1109/regulation/10
- What it decided: Financial support is subject to annual review, and the council must notify the special guardian of any proposed variation.

### The Fostering Network, Foster Care Allowances

- Reference: `fostering-network-allowances`
- Kind: dataset
- Link: https://www.thefosteringnetwork.org.uk/policy-and-campaigns/empowering-children-and-young-people/allowances/
- What it decided: In February 2026 the Welsh Government announced an uplift of 2.2% to allowances for 2026/27.

### UK Parliament written question 14259 (National Minimum Allowance uplifts)

- Reference: `parliament-wq-14259`
- Kind: dataset
- Link: https://questions-statements.parliament.uk/written-questions/detail/2024-11-13/14259
- What it decided: The National Minimum Allowance was uplifted by 6.88% for 2024/25, following 12.43% in 2023/24.

### Universal Credit (Removal of Two Child Limit) Act 2026 c.13

- Reference: `uc-two-child-limit-act-2026`
- Kind: statute
- Link: no public link yet

### Welsh Government National Minimum Allowance, 2026 to 2027

- Reference: `wg-nma-2026-27`
- Kind: dataset
- Link: no public link yet

### Welsh Government, consultation on changes to two codes of practice: Part 6 and Special Guardianship Orders, 12 February to 7 April 2026

- Reference: `wg-codes-consultation-2026`
- Kind: guidance
- Link: https://www.gov.wales/written-statement-launch-consultation-revisions-part-6-and-special-guardianship-codes-practice
- What it decided: Draft revisions would require all services to pay the national minimum allowance and introduce an enhanced fostering allowance and fee.

### Welsh Government, National Minimum Allowances for foster carers 2024 to 2025, circular of 26 February 2024

- Reference: `wg-nma-2024-25`
- Kind: dataset
- Link: no public link yet
- What it decided: Sets the Welsh national minimum allowances from 1 April 2024 at 218 pounds for ages 0 to 4, 199 pounds for 5 to 15 and 248 pounds for 16 and over, a rise of 3 per cent.
