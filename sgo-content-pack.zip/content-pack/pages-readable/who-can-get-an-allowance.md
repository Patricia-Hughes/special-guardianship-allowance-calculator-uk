# Who can get a special guardianship allowance?

| | |
|---|---|
| Web address | /guidance/who-can-get-an-allowance |
| Length now | 496 words (388 in the page, 108 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> How strong your position is depends on whether the child was in the council's care immediately before the order. Either way, you can ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **Children Act 1989, s.14A**
  https://www.legislation.gov.uk/ukpga/1989/41/section/14A
- **Special Guardianship Regulations 2005, reg 5**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/5
  What it decided: The council remains responsible for assessing support needs for three years from the making of the order.

## Letter template linked from this page

- "Ask for your council's written policy"

## The page as it reads now

Special guardianship orders are made under section 14A of the Children Act 1989. They exist in
England, Wales and Northern Ireland. They do not exist in Scots law, if you are in Scotland,
[kinship care works differently](/guidance/scotland-kinship-care).

*[SOURCE: Children Act 1989, s.14A]*

## The question that decides how strong your position is

**Was the child in the council's care immediately before the order was made?**

**If yes**, and the child was "looked after", your position is much the stronger of the two. The
regulations set out when financial support is payable, and a child who was looked after immediately
before the order is squarely within them.

**If no**, the council can still consider financial support, but the circumstances in which it is
payable are narrower. You can still ask, and many councils will consider it. What it should not do
is refuse to consider the request at all.

*[SOURCE: Special Guardianship Regulations 2005, reg 6]*

> **Important box, shown in amber:**
>
An earlier version of this page said the council **must** assess you where the child was looked
after. That is very likely right, but regulation 6 governs when financial support is payable rather
than when an assessment is owed, so it is not the provision that establishes it. We are having the
correct provision confirmed rather than pointing you at the wrong one. In the meantime, ask for an
assessment in writing: nothing here stops you asking, and a council that declines should give you
its reasons.

If you are not sure which applies to you, ask your social worker or check the court paperwork. It
matters enough to be worth confirming.

## The money is up to the council, the decision is not

Even where an assessment is mandatory, there is no fixed amount you are entitled to. Financial
support under regulation 6 is discretionary, which means it is up to the council.

What you can expect is a proper decision:

- starting from the right figure, [the core fostering allowance](/guidance/what-your-council-must-consider)
- taking account of your circumstances and the child's needs
- explained to you in writing
- [reviewed every year](/guidance/annual-reviews)

## Which council

For three years from the making of the order, the council that looked after the child stays
responsible for assessing support needs, even if you have moved away.

*[SOURCE: Special Guardianship Regulations 2005, reg 5]*

More on that in [which council is responsible](/guidance/which-council-is-responsible).

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**The child was never in care. Can I still get support?**

Yes. The council does not have to assess you, but it can, and you can ask it to. Put the request in writing and ask for the decision and its reasons in writing too.

**How do I know if the child was 'looked after'?**

It means the child was in the council's care or accommodated by it immediately before the order was made. Your social worker or the court paperwork will confirm it.

