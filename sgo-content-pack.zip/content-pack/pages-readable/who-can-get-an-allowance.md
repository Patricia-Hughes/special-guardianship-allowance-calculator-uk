# Who can get a special guardianship allowance?

| | |
|---|---|
| Web address | /guidance/who-can-get-an-allowance |
| Length now | 535 words (407 in the page, 128 in the description and questions) |
| Last reviewed | 2026-09-03 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> How strong your position is depends on whether the child was in the council's care immediately before the order. Either way, you can ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Children Act 1989, s.14F(3)**
  https://www.legislation.gov.uk/ukpga/1989/41/section/14F
  What it decided: A local authority MAY assess a person's needs for special guardianship support services on request, but MUST do so where that person is of a description prescribed in regulations. The duty to assess therefore does not exist in the Act alone: it needs reg 11(1) to supply the prescribed description.
- **Special Guardianship Regulations 2005, reg 11**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/11
  What it decided: Prescribes, for the purposes of s.14F(3), the persons at whose request an assessment MUST be carried out: reg 11(1)(a) a relevant child looked after, or looked after immediately before the order; (b) a special guardian or prospective special guardian of such a child; (c) a parent of such a child. Where reg 11(1) does not apply, reg 11(2) to (3) require the authority, if minded not to assess, to give notice with reasons and allow representations.
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **Children Act 1989, s.14A**
  https://www.legislation.gov.uk/ukpga/1989/41/section/14A
- **Special Guardianship Regulations 2005, reg 5**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/5
  What it decided: The council remains responsible for assessing support needs for three years from the making of the order.

## Letter template linked from this page

- "Ask for your council's written policy"

## The page as it reads now

Special guardianship orders are made under section 14A of the Children Act 1989. They exist in
England, Wales and Northern Ireland. They do not exist in Scots law, if you are in Scotland,
[kinship care works differently](/guidance/scotland-kinship-care).

*[SOURCE: Children Act 1989, s.14A]*

## The question that decides how strong your position is

**Was the child in the council's care immediately before the order was made?**

**If yes**, and you ask, your council **must** assess your needs for support. This is not a
courtesy and it is not discretionary. The Children Act says a council may carry out an assessment
on request, and that it must do so where the person asking is of a description set out in
regulations.

*[SOURCE: Children Act 1989, s.14F(3)]*

The regulations then name the people it must assess, and that list includes a special guardian of a
child who was looked after immediately before the order was made.

*[SOURCE: Special Guardianship Regulations 2005, reg 11]*

So the two go together: the Act creates the duty, and the regulation says who it applies to.

**If no**, and the child was not looked after, your council does not have to assess you. But it
cannot simply ignore you either. If it is minded not to carry out an assessment, it has to tell you
so, give its reasons, and give you a chance to make representations before it decides. That is
worth knowing, because "no" without reasons is not a proper answer even here.

Whether support is then payable is a separate question, and that is what regulation 6 governs.

*[SOURCE: Special Guardianship Regulations 2005, reg 6]*

If you are not sure which applies to you, ask your social worker or check the court paperwork. It
matters enough to be worth confirming.

## The money is up to the council, the decision is not

Even where an assessment is mandatory, there is no fixed amount you are entitled to. Financial
support under regulation 6 is discretionary, which means it is up to the council.

What you can expect is a proper decision:

- starting from the right figure, [the core fostering allowance](/guidance/what-your-council-must-consider)
- taking account of your circumstances and the child's needs
- explained to you in writing
- [reviewed every year](/guidance/annual-reviews)

## Which council

For three years from the making of the order, the council that looked after the child stays
responsible for assessing support needs, even if you have moved away.

*[SOURCE: Special Guardianship Regulations 2005, reg 5]*

More on that in [which council is responsible](/guidance/which-council-is-responsible).

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**The child was never in care. Can I still get support?**

Yes. Where the child was not looked after immediately before the order, the council does not have to assess you, but it can, and you can ask it to. If it is minded to refuse, it has to give you its reasons and let you respond before it decides. Put the request in writing.

**How do I know if the child was 'looked after'?**

It means the child was in the council's care or accommodated by it immediately before the order was made. Your social worker or the court paperwork will confirm it.

