# Who can get a special guardianship allowance?

| | |
|---|---|
| Web address | /guidance/who-can-get-an-allowance |
| Length now | 368 words (260 in the page, 108 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Whether your council must assess you depends on whether the child was in its care immediately before the order. Either way, you can ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **Children Act 1989, s.14A**
  https://www.legislation.gov.uk/ukpga/1989/41/section/14A
- **Special Guardianship Regulations 2005, reg 5**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/5
  What it decided: The council remains responsible for assessing support needs for three years from the making of the order.

## Letter template linked from this page

- "Ask for your council's written policy"

## The page as it reads now

Special guardianship orders are made under section 14A of the Children Act 1989. They exist in
England, Wales and Northern Ireland. They do not exist in Scots law, if you are in Scotland,
[kinship care works differently](/guidance/scotland-kinship-care).

*[SOURCE: Children Act 1989, s.14A]*

## The question that decides how strong your position is

**Was the child in the council's care immediately before the order was made?**

**If yes**, and the child was "looked after", the council **must** assess you for special
guardianship support if you ask. That is not discretionary.

**If no**, the council **may** assess you, but does not have to. You can still ask, and many
councils will. What it must not do is refuse to consider the request at all.

*[SOURCE: Special Guardianship Regulations 2005, reg 6]*

If you are not sure which applies to you, ask your social worker or check the court paperwork. It
matters enough to be worth confirming.

## Support is discretionary, the decision is not

Even where an assessment is mandatory, there is no fixed amount you are entitled to. Financial
support under regulation 6 is discretionary.

What you can expect is a proper decision:

- starting from the right figure, [the core fostering allowance](/guidance/what-your-council-must-consider)
- taking account of your circumstances and the child's needs
- explained to you in writing
- [reviewed every year](/guidance/annual-reviews)

## Which council

For three years from the making of the order, the council that looked after the child stays
responsible for assessing support needs, even if you have moved away.

*[SOURCE: Special Guardianship Regulations 2005, reg 5]*

More on that in [which council is responsible](/guidance/which-council-is-responsible).

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**The child was never in care. Can I still get support?**

Yes. The council does not have to assess you, but it can, and you can ask it to. Put the request in writing and ask for the decision and its reasons in writing too.

**How do I know if the child was 'looked after'?**

It means the child was in the council's care or accommodated by it immediately before the order was made. Your social worker or the court paperwork will confirm it.

