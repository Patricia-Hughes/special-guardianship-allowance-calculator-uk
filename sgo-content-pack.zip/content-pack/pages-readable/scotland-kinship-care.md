# Kinship care in Scotland

| | |
|---|---|
| Web address | /guidance/scotland-kinship-care |
| Length now | 360 words (241 in the page, 119 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Special guardianship orders do not exist in Scots law. Scotland has the Scottish Recommended Allowance, which is a minimum and applies equally to foster and kinship carers.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026**
  https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/
  What it decided: A national minimum for foster and kinship carers alike. Councils may pay more.

## The page as it reads now

> **Important box, shown in red:**
>
Special guardianship orders **do not exist in Scots law**. If you are caring for a relative's child
in Scotland, the English rules on this site (regulation 6, regulation 7 and the statutory
guidance) do not apply to you.

Our calculator routes Scotland to a different set of figures for exactly this reason, and it will
not attach English case law to a Scottish result.

## The Scottish Recommended Allowance

Scotland sets a recommended allowance covering both foster carers and kinship carers, at the same
rates:

<RateTable nation="scotland" />

*[SOURCE: Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026]*

## Three things that follow from it

**It is a floor, not a ceiling.** Your council can pay more, and some do. If you are being offered
less than the recommended rate, ask why in writing.

**Foster and kinship carers get the same recommended rate.** If your council pays its foster carers
more than it pays you for a child of the same age, that is a difference worth asking it to explain.

**No family should be worse off.** Where you already have an arrangement paying more than the
recommended allowance, the higher amount applies. Moving onto the recommended rate should not
reduce what you receive.

## Where to get help in Scotland

The Local Government and Social Care Ombudsman covers England only. Scotland has the Scottish
Public Services Ombudsman. Citizens Advice Scotland and local kinship care groups can help with the
Scottish system specifically.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Can I get a special guardianship order in Scotland?**

No. Special guardianship is a creation of the Children Act 1989, which does not apply in Scotland. Scottish kinship care operates under a different legal framework entirely.

**Is the recommended allowance means tested?**

Not in the way an English special guardianship allowance is. It is a recommended minimum rate.

**My council pays less than the recommended allowance. What can I do?**

Ask why, in writing. The allowance is a floor, and there is an explicit expectation of parity between foster and kinship carers.

