# If you fostered the child before the order: your two-year protection

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/former-foster-carers |
| Length now | 485 words (324 in the page, 161 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Former foster carers keep the reward element of their fostering allowance for two years after a special guardianship order. What that covers, what it does not, and how to ask for it to continue.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 7**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/7
- **R (X) v Tower Hamlets LBC [2013] EWCA Civ 904**
  no public link yet, we are still sourcing one
  What it decided: Paying family foster carers less than unrelated foster carers was unlawful. Former foster carers should not be worse off.
- **LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363
  What it decided: Reducing the whole allowance to 75% of the core fostering allowance in year one and 50% in year two misapplied the two-year transitional provision, which protects the reward element only. Backdating of about 6,948 pounds was recommended, and the council estimated 37 other families were affected.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Letter template linked from this page

- "Ask for your two-year former foster carer protection to continue"

## The page as it reads now

If you were the child's foster carer before the special guardianship order was made, you have a
protection that other special guardians do not.

## What regulation 7 does

For **two years** from the date of the order, the reward or fee element of the fostering allowance
you were receiving for that child is protected. You should not simply drop to a lower figure the
week the order is made.

*[SOURCE: Special Guardianship Regulations 2005, reg 7]*

Our calculator applies this automatically. If you tell us what you were paid as a foster carer and
the order was made less than two years ago, we hold your figure at that amount rather than showing
you a lower one, even where the national minimum for your area is lower.

## Why it exists

The Court of Appeal held that paying family foster carers less than unrelated foster carers was
unlawful, and that a carer should not be made worse off by taking on a special guardianship order
for a child they were already looking after.

*[SOURCE: R (X) v Tower Hamlets LBC [2013] EWCA Civ 904]*

## The mistake to watch for

> **Important box, shown in amber:**
>
Regulation 7 protects the **reward element**. It is not permission to taper the whole allowance.

In 2020 the Ombudsman looked at a council that reduced carers' entire allowances to 75% and then
50% over the two years, treating regulation 7 as authority to do so. The Ombudsman found that
misapplied the rule.

*[SOURCE: LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)]*

If your payments are being stepped down, ask your council in writing **which element it is
reducing** and on what basis. That single question often resolves it.

## Before the two years are up

The end of the protection is not automatic and it is not final. A council can agree to continue the
reward element where the child's needs justify it. Ask in good time, several months before the
anniversary, and set out what has not changed about the child's needs.

> **[BUTTON]** Opens the letter template: "Ask for your two-year former foster carer protection to continue".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Does the protection cover my whole allowance?**

No. Regulation 7 protects the reward or fee element, the part that paid you for your work as a foster carer. It is not authority to taper your entire allowance down over two years.

**What happens after two years?**

The protection ends, but it is not a hard stop. A council can agree to carry on paying it where the child's needs justify it. Ask before the two years are up, not after your payments drop.

**I fostered the child but through a different council. Does it still apply?**

The protection relates to the allowance you were receiving for that child immediately before the order. If your situation is unusual, get advice. This is one worth checking with an adviser.

