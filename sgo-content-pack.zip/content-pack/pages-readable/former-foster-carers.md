# If you fostered the child before the order: the two-year rule

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/former-foster-carers |
| Length now | 778 words (581 in the page, 197 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> A council can keep paying a former foster carer the reward element of their fostering allowance for two years after a special guardianship order, and for longer if it thinks that right. What that covers, what it does not, and how to ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 7**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/7
- **R (X) v Tower Hamlets LBC [2013] EWCA Civ 904**
  https://caselaw.nationalarchives.gov.uk/ewca/civ/2013/904
  What it decided: Paying family foster carers less than unrelated foster carers was unlawful. Former foster carers should not be worse off.
- **LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363
  What it decided: Reducing the whole allowance to 75% of the core fostering allowance in year one and 50% in year two misapplied the two-year transitional provision, which protects the reward element only. Backdating of about 6,948 pounds was recommended, and the council estimated 37 other families were affected.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Letter template linked from this page

- "Ask which part of your allowance is being reduced"
- "Ask for the reward element to continue past two years"

## The page as it reads now

If you were the child's foster carer before the special guardianship order was made, there is a rule
that applies to you and not to other special guardians. The end of it is not automatic and it is not
final, which is the part most people are not told.

## What regulation 7 does

For **two years** from the date of the order, your council can carry on paying the reward or fee
element of the fostering allowance you were receiving for that child, and for longer where it
considers that appropriate.

Read that carefully: it says **can**, not **must**. Regulation 7 gives your council a power rather
than giving you an entitlement. Your position is still a strong one, but the argument comes from the
statutory guidance and from the Court of Appeal holding that family foster carers should not be
worse off than unrelated ones, not from regulation 7 creating a right.

*[SOURCE: Special Guardianship Regulations 2005, reg 7]*

Our calculator applies this automatically. If you tell us what you were paid as a foster carer and
the order was made less than two years ago, we hold your figure at that amount rather than showing
you a lower one, even where the national minimum for your area is lower.

## Why it exists

The Court of Appeal held that paying family foster carers less than unrelated foster carers was
unlawful, and that a carer should not be made worse off by taking on a special guardianship order
for a child they were already looking after.

*[SOURCE: R (X) v Tower Hamlets LBC [2013] EWCA Civ 904]*

## The mistake to watch for

> **Important box, shown in amber:**
>
Regulation 7 is about the **reward element**. It is not permission to step the whole allowance down.

In 2020 the Ombudsman looked at a council that reduced carers' entire allowances to 75% and then
50% over the two years, treating regulation 7 as authority to do so. The Ombudsman found that
misapplied the rule.

*[SOURCE: LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)]*

If your payments are being stepped down, ask your council in writing **which element it is
reducing** and on what basis. That single question often resolves it.

## First, a question that comes before all of this

Regulation 7 only applies at all where your council decided to include a reward element in your
financial support **before the special guardianship order was made**. If it never took that
decision, regulation 7 is not the rule for your situation, and an argument built on it will not
land.

So the first thing to ask is simply whether that decision was taken, and when. If it was not, your
position rests on the statutory guidance and on the Tower Hamlets case instead, which say a council
should not pay family carers less than unrelated foster carers without cogent reasons.

## Before the two years are up

The end of the two years is not automatic and it is not final. But the test for continuing is
higher than it sounds. A council may carry on paying the reward element only where it considers
that necessary because of the **exceptional needs of the child, or other exceptional
circumstances**.

That wording matters. "My child's needs have not reduced" does not engage the test, and a request
put that way can be refused without the council ever having to weigh anything. Set out what is
exceptional about your child's needs or your circumstances, and say so in those terms.

Ask in good time, several months before the anniversary.

> **[BUTTON]** Opens the letter template: "Ask for the reward element to continue past two years".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Does the two-year rule cover my whole allowance?**

No. Regulation 7 is about the reward or fee element, the part that paid you for your work as a foster carer. It is not authority to step your entire allowance down over two years. If your whole allowance is being reduced, ask which part is being reduced and on what basis.

**What happens after two years?**

It cuts both ways. The reward element can lawfully stop, and it can also lawfully carry on: the council can agree to continue it where it considers that appropriate. Nothing happens automatically, so ask before the two years are up rather than after your payments drop.

**I fostered the child but through a different council. Does it still apply?**

Regulation 7 is about the allowance you were receiving for that child immediately before the order. Beyond that, this is one to check with an adviser rather than with us.

