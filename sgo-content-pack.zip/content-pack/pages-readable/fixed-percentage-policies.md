# Why a fixed percentage of the fostering rate is a problem

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/fixed-percentage-policies |
| Length now | 535 words (410 in the page, 125 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Two-thirds, a third, 75%. Councils have repeatedly been found at fault for setting special guardianship allowances at a flat share of the fostering rate, without looking at the individual case.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Barrett v Kirklees MBC [2010] EWHC 467 (Admin)**
  https://www.bailii.org/ew/cases/EWHC/Admin/2010/467.html
  What it decided: A flat two-thirds of the core fostering allowance was an unjustified departure from guidance.
- **R (TT) v Merton LBC [2012] EWHC 2055 (Admin)**
  https://caselaw.nationalarchives.gov.uk/ewhc/admin/2012/2055
  What it decided: Blanket percentage deduction unlawful. BUT: no duty to pay every special guardian an allowance, and the means-test methodology itself was upheld as lawful.
- **LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)**
  https://web.archive.org/web/https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf
  What it decided: Calculating a special guardianship allowance as a percentage of the fostering allowance was contrary to statutory guidance and case law. The council identified 171 families who may not have received the right support, and payments were backdated to November 2013.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Letter template linked from this page

- "Ask how your allowance was calculated, where a percentage seems to have been used"

## The page as it reads now

If someone has told you your allowance is "two-thirds of the fostering rate", or a third, or any
other flat fraction, this is worth reading.

## The short answer

Whether your council's particular policy is lawful depends on its wording and on how it is applied.
No court has said that fixed percentages are unlawful as a class. Each case that reached a court
concerned one council's policy on its own facts. So the thing to ask for is the written policy and
the reasons in your case, not a ruling.

## What the courts have said

A council that set every special guardianship allowance at a flat two-thirds of the core fostering
allowance was found to have departed from the statutory guidance without justification. In plainer
words, it stepped away from a rule it is supposed to follow, without explaining why. That is where
the unlawfulness lies, and it is why the phrase matters more than it sounds.

*[SOURCE: Barrett v Kirklees MBC [2010] EWHC 467 (Admin)]*

A blanket percentage deduction was held unlawful in that council's case in a later judgment. The
same judgment confirmed two things that cut the other way, and they matter just as much: there is no
duty to pay every special guardian an allowance at all, and a means test is not in itself unlawful.

*[SOURCE: R (TT) v Merton LBC [2012] EWHC 2055 (Admin)]*

The Ombudsman has found a council at fault over a fixed-percentage policy and recommended
backdating. Note the word: the Ombudsman finds **fault**, and reserves "unlawful" for describing
what a court has held.

*[SOURCE: LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)]*

## The distinction that matters

> **Important box, shown in amber:**
>
The objection is to starting from a percentage, not to ending up at a lower figure.

A council is entitled to assess your circumstances and conclude that a lower allowance is
appropriate. What it should not do is decide the answer in advance and apply it to everybody
regardless.

That is why our calculator never outputs a fixed fraction of the fostering rate as an answer, and
why it will refuse to produce a figure at all rather than show you one that has been arrived at
that way.

## What to ask

1. What figure did you use as the starting point, and where does it come from?
2. Was a fixed percentage or proportion applied at any stage?
3. What did you take into account about my circumstances and my child's needs?

Ask for the written policy at the same time.

> **[BUTTON]** Opens the letter template: "Ask how your allowance was calculated, where a percentage seems to have been used".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**My council pays two-thirds of the fostering rate to everyone. Is that unlawful?**

A blanket rule of that kind has been found to be an unjustified departure from the guidance. Whether your council's particular policy is lawful depends on its wording and how it is applied, which is why the thing to ask for is the written policy and the reasons in your case.

**Can a council ever end up paying two-thirds?**

Yes, if that is where a proper assessment of your circumstances lands. The problem is starting from a percentage, not arriving at one.

