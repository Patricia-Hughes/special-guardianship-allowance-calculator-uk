# Benefits, tax and your special guardianship allowance

| | |
|---|---|
| Web address | /guidance/benefits-and-your-allowance |
| Length now | 429 words (323 in the page, 106 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Your allowance is not taxable and is not counted as your income for means-tested benefits. Guardian's Allowance is widely missed. The two-child limit has gone.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Universal Credit (Removal of Two Child Limit) Act 2026 c.13**
  https://www.legislation.gov.uk/ukpga/2026/13
- **Child Benefit and Guardian's Allowance Up-rating Order 2026**
  https://www.legislation.gov.uk/uksi/2026/232/made
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The page as it reads now

Two rules that catch people out, and one benefit that is widely missed.

## Your allowance is not taxed, and does not reduce your benefits

Special guardianship allowance is treated as a residence-order allowance. It has been **exempt from
income tax** since 6 April 2010, and it is **disregarded** as your income when your own means-tested
benefits are worked out.

If your Universal Credit dropped when your allowance started, that is worth querying.

> **Important box, shown in amber:**
>
**Qualifying Care Relief does not apply to special guardians.** It is a relief for foster carers
and shared-lives carers. If you also still foster other children, you can use it for that income,
but not for your special guardianship allowance.

## Guardian's Allowance, check whether you can claim it

This is the most commonly missed payment in kinship care.

Guardian's Allowance is a weekly payment for someone bringing up a child whose parents have died,
or where one parent has died and the other cannot be traced, is serving a long prison sentence, or
whose whereabouts are unknown.

It is worth <BenefitAmount name="guardians-allowance" /> for each child, on top of anything else
you receive.

- It is **tax free**.
- It is **ignored** for means-tested benefits.
- It is **exempt from the benefit cap**.

*[SOURCE: Child Benefit and Guardian's Allowance Up-rating Order 2026]*

There are conditions, including about the parents' UK residence. It is worth a conversation with an
adviser if there is any chance it applies.

## The two-child limit has been abolished

From April 2026 the two-child limit in Universal Credit was removed.

*[SOURCE: Universal Credit (Removal of Two Child Limit) Act 2026 c.13]*

If you are caring for three or more children and your Universal Credit has not changed, check your
award.

## Child Benefit

Child Benefit for the child you care for is yours to claim. Whether your **council** may take it
into account when setting your allowance is [a separate and contested
question](/guidance/child-benefit-deduction). But the answer is never to stop claiming it.

> **[LIST]** The advice line contact details are inserted here automatically.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Do I pay tax on my special guardianship allowance?**

No. It is treated as a residence-order allowance and has been exempt from income tax since 6 April 2010.

**Does it reduce my Universal Credit?**

It should not. The allowance is disregarded as your income for your own means-tested benefits.

**Can I use Qualifying Care Relief?**

Not for special guardianship. QCR is for foster carers and shared-lives carers. If you also still foster other children, you can use it for that income.

