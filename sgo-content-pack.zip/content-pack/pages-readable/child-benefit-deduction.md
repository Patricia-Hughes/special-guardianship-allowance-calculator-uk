# Can your council take Child Benefit off your special guardianship allowance?

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/child-benefit-deduction |
| Length now | 519 words (379 in the page, 140 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Some councils deduct Child Benefit from special guardianship allowances. The Ombudsman has found that wrong where the carer is on means-tested benefits. Here is what to ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **LGSCO decision, Devon County Council (23 000 973, 25 January 2024)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973
  What it decided: The council was at fault for deducting Child Benefit from all special guardians on Universal Credit as a blanket rule, without looking at individual circumstances. It was ordered to recalculate and to refund deductions. Devon changed the policy with effect from 1 January 2024, and a later complaint about its current practice was not upheld.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## Letter template linked from this page

- "Ask about Child Benefit being taken off your allowance"

## The page as it reads now

If your allowance seems low, this is one of the first things worth checking. It is also one of the
most commonly contested.

## What some councils do

A number of councils treat Child Benefit as income when they work out a special guardianship
allowance, and take it off pound for pound. So a carer who would otherwise get the full amount
receives that much less each week.

## Why it is contested

In 2024 the Local Government and Social Care Ombudsman looked at a council that deducted Child
Benefit from every carer, including those receiving means-tested benefits, as a matter of blanket
policy. The Ombudsman found that approach wrong. The council had to recalculate the allowances of
around 170 carers, pay refunds, and make remedy payments to the carers who complained.

*[SOURCE: LGSCO decision, Devon County Council (23 000 973, 25 January 2024)]*

The point was not that Child Benefit can never be considered. It was that applying a rule to
everybody, without thinking about the individual case, is not the same thing as assessing someone's
circumstances, which is what the regulations require.

> **Important box, shown in red:**
>
If you receive Universal Credit, Income Support, income-based Jobseeker's Allowance,
income-related Employment and Support Allowance or Pension Credit, **and** your council deducts
Child Benefit from your allowance, this is worth raising in writing.

## What our calculator does

We never deduct Child Benefit unless you explicitly tell us your council does. Even then, we show
you the figure with and without it, and we flag the deduction rather than burying it in the
arithmetic. That is a deliberate choice: a tool that quietly reduces your figure the way a
contested policy does is not helping you.

## What to ask your council

Keep it short and ask for answers in writing:

1. Do you take Child Benefit into account when calculating my allowance, and if so how much?
2. Does your policy treat carers on means-tested benefits differently?
3. How was that decided in my case?

Asking for the written policy at the same time saves a round of correspondence.

> **[BUTTON]** Opens the letter template: "Ask about Child Benefit being taken off your allowance".

## If you get nowhere

Use your council's complaints procedure first, the Ombudsman will normally expect you to have
done that. If you are still not satisfied, you can ask the Ombudsman to look at it.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Does every council take Child Benefit off?**

No. Practice varies a lot. Some deduct it in full, some not at all, and some only from carers who are not on means-tested benefits. Ask yours in writing what it does and why.

**Should I stop claiming Child Benefit?**

No. Child Benefit is money for your child and stopping it would leave you worse off. If your council is deducting it, the thing to question is the deduction, not the claim.

**What if the deduction has been happening for years?**

It is still worth raising. The Ombudsman has ordered councils to recalculate awards and pay refunds, in one case for around 170 carers at once.

