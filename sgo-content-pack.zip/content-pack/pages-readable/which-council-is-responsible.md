# Which council is responsible for your support?

| | |
|---|---|
| Web address | /guidance/which-council-is-responsible |
| Length now | 393 words (285 in the page, 108 in the description and questions) |
| Last reviewed | 2026-09-03 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> For three years after the order, the council that looked after the child stays responsible, even if you have moved. After that it usually passes to where you live.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 5**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/5
  What it decided: The council remains responsible for assessing support needs for three years from the making of the order.
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The page as it reads now

This catches people out, particularly where a family has moved to be closer to relatives after an
order was made.

## The three-year rule

For **three years** from the making of the special guardianship order, the council that was looking
after the child immediately before the order remains responsible for assessing support needs, even
if you now live somewhere else entirely.

*[SOURCE: Special Guardianship Regulations 2005, reg 5]*

After three years, responsibility normally passes to the council for the area where you live.

## The exception, and it is an important one

If your council was **already paying you financial support**, and it decided to pay it **before**
the order was made, then the three-year cut-off does not apply to that support. The original
council stays responsible for it, indefinitely.

That will often be the case if you were the child's foster carer before the order, because the
support was usually agreed as part of the arrangements at the time.

So if you have been told your support ends, or passes to a new council, because three years have
gone by, the question to ask is: **when was the decision to provide my financial support taken, and
was it before the order was made?**

> **Important box, shown in amber:**
>
Financial support that has already been agreed is a separate question from who assesses new needs.
If you are being passed back and forth, ask each council to confirm its position in writing.

## Why it is worth pinning down early

Every request you make, for a review, for an enhancement, for the written policy, has to go to
the right council to get an answer. Time spent asking the wrong one is time your allowance stays
where it is.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**I moved shortly after the order. Who do I ask?**

For the first three years, the council that looked after the child. After that, normally the council where you now live.

**Both councils say it is the other one. What now?**

Put the question to both in writing, referring to the three-year rule, and ask each to confirm its position in writing. If they still disagree, this is a good moment to use a complaints procedure or get advice.

