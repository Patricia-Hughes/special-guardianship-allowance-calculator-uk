# Asking for more because of your child's needs

| | |
|---|---|
| Web address | /guidance/enhancements-for-additional-needs |
| Length now | 380 words (257 in the page, 123 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> The regulations allow a council to pay more where a child has a disability, or where they are living with the consequences of abuse or neglect. There is no national figure, so you have to ask.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Letter template linked from this page

- "Ask for more because of your child's needs"

## The page as it reads now

Regulation 6 allows financial support to take account of a child's disability, and of the
consequences of any abuse or neglect they experienced.

*[SOURCE: Special Guardianship Regulations 2005, reg 6]*

## Why our calculator adds nothing for this

> **Important box, shown in amber:**
>
There is **no national figure** for an enhancement. It varies entirely by council.

So we add nothing, and we tell you to ask instead. Applying an invented percentage would produce a
figure that looks authoritative and is not, and if you took it to your council, the first thing
that would happen is that it would be dismissed, along with everything else you said.

## What helps a request succeed

Be specific and put costs against things. A social worker deciding this needs something concrete to
work with:

- **Travel**: appointments, therapy, contact arrangements. Mileage and how often.
- **Therapy or support** you are paying for privately, and why.
- **Equipment** and adaptations.
- **Respite**: what you need and what it costs.
- **Extra wear and tear**: replacement bedding, clothing, damage.
- **Lost earnings** where you have had to reduce your hours.

Where the need arises from what happened to the child before they came to you, say so plainly. That
is squarely within what the regulation covers, and it is often left out because carers assume it
only means physical disability.

> **[BUTTON]** Opens the letter template: "Ask for more because of your child's needs".

## If you are turned down

Ask for the reasons in writing. Then ask what evidence would change the answer. A refusal that
cannot explain itself is worth taking to the [complaints
procedure](/guidance/complaining-to-the-ombudsman).

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**How much extra should I get?**

There is no national figure. It is decided council by council, on the child's needs. That is exactly why our calculator adds nothing for it, inventing a number would be worse than telling you to ask.

**My child does not have a diagnosis. Can I still ask?**

Yes. The regulations refer to the consequences of a disability, or of abuse or neglect the child suffered. A diagnosis helps, but the question is what the child needs and what it costs you.

