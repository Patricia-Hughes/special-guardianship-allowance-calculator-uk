# What your council must consider when setting your allowance

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/what-your-council-must-consider |
| Length now | 486 words (390 in the page, 96 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> The fostering allowance is the starting point, not an adoption allowance and not a percentage. What the guidance and the courts actually say.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **R (B) v Lewisham LBC [2008] EWHC 738 (Admin)**
  no public link yet, we are still sourcing one
  What it decided: Using the lower adoption allowance model was unlawful. Fostering allowances are the starting point.
- **Barrett v Kirklees MBC [2010] EWHC 467 (Admin)**
  no public link yet, we are still sourcing one
  What it decided: A flat two-thirds of the core fostering allowance was an unjustified departure from guidance.
- **R (TT) v Merton LBC [2012] EWHC 2055 (Admin)**
  no public link yet, we are still sourcing one
  What it decided: Blanket percentage deduction unlawful. BUT: no duty to pay every special guardian an allowance, and the means-test methodology itself was upheld as lawful.

## Letter template linked from this page

- "Ask for the arithmetic behind your figure"
- "Ask for your council's written policy"

## The page as it reads now

The single most useful thing to understand is this: **there is no amount you are entitled to, but
there is a figure your council is supposed to start from.**

## The starting point is the fostering allowance

The statutory guidance says the amount of a special guardianship allowance should not exceed the
amount the council would pay a foster carer for that child, and that the core fostering allowance
is the basis for the calculation.

*[SOURCE: DfE Special Guardianship Guidance (Jan 2017), para 65]*

That is why the fostering national minimum allowance matters to you, even though you are not a
foster carer:

<RateTable nation="england" />

## What has been ruled out

Three patterns have been challenged successfully in the courts:

**Using the adoption allowance model instead.** Adoption allowances are generally lower. A council
that used them as the basis for special guardianship support was found to have acted unlawfully.

*[SOURCE: R (B) v Lewisham LBC [2008] EWHC 738 (Admin)]*

**Paying a flat two-thirds.** A council that set every special guardianship allowance at two-thirds
of the core fostering allowance was found to have departed from the guidance without justifying it.

*[SOURCE: Barrett v Kirklees MBC [2010] EWHC 467 (Admin)]*

**Any blanket percentage.** A blanket percentage deduction was held unlawful. Importantly, the same
case confirmed there is no duty to pay every special guardian an allowance, and that a means-test
methodology can itself be perfectly lawful.

*[SOURCE: R (TT) v Merton LBC [2012] EWHC 2055 (Admin)]*

> **Important box, shown in amber:**
>
The problem in each case was the *blanket* nature of the rule, not the arithmetic. A council can
reach a lower figure. It has to get there by considering your case.

## What the council should consider

Regulation 6 sets out what financial support is for and when it may be paid. In deciding the
amount, a council should be looking at:

- the child's needs, including any disability or the consequences of abuse or neglect
- your financial resources, including any income the child has
- what it costs you to look after the child
- the nature of the child's relationship with you, and the arrangement's stability

*[SOURCE: Special Guardianship Regulations 2005, reg 6]*

## What to ask for

Ask for the calculation in writing: the starting figure and where it came from, what income was
counted, what outgoings were allowed, and every deduction with its reason. A figure without a
breakdown cannot be checked, and a figure that cannot be checked cannot be challenged.

> **[BUTTON]** Opens the letter template: "Ask for the arithmetic behind your figure".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Am I entitled to an allowance?**

No, financial support for special guardians is discretionary. What you are entitled to is a proper decision: one that starts from the right figure, considers your actual circumstances, and is explained to you.

**Can my council pay me less than the fostering rate?**

Yes, after properly assessing your circumstances. What it should not do is start from a lower figure, or apply a fixed reduction to everybody.

