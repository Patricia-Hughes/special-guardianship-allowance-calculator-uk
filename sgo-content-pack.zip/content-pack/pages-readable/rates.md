# How the rates work, and when they change

| | |
|---|---|
| Web address | /guidance/rates |
| Length now | 565 words (465 in the page, 100 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Councils raise allowance rates on 1 April, the government states the same rates for a tax year starting 6 April, and benefit rates change in the first full week. The gaps between those dates matter.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Welsh Government, National Minimum Allowances for foster carers 2024 to 2025, circular of 26 February 2024**
  no public link yet, we are still sourcing one
  What it decided: Sets the Welsh national minimum allowances from 1 April 2024 at 218 pounds for ages 0 to 4, 199 pounds for 5 to 15 and 248 pounds for 16 and over, a rise of 3 per cent.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance
- **Child Benefit and Guardian's Allowance Up-rating Order 2026**
  no public link yet, we are still sourcing one
- **Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026**
  https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/
  What it decided: A national minimum for foster and kinship carers alike. Councils may pay more.

## The page as it reads now

## Two different calendars

> **Important box, shown in amber:**
>
There are three dates in April, not two. Councils normally raise allowance rates on **1 April**.
The government states those same rates for a **tax year running 6 April to 5 April**. Benefit rates
change in the **first full week of April**, around the 6th. Between the 1st and the 6th, the new
allowance rates coexist with last year's benefit rates, and a council following the tax year may
still be paying last year's allowance.

Those gaps are a real source of confusion, including inside councils. Our calculator treats
allowances and benefits as two independent lookups with their own effective dates, so a calculation
dated 3 April uses the new allowance rates and the old benefit rates. That is correct, and it is not
what you get if you assume one financial year covers both.

We follow the council convention of 1 April, because that is what decides what a carer is actually
paid. If you are working out what you were owed over past years, the site tells you in pounds how
much of the total depends on that choice. It is a few pounds per April, not a few hundred.

## The current rates

<RateTable nation="england" />
<RateTable nation="scotland" />
<RateTable nation="northern-ireland" />

The full tables, including previous years, are on the [rates page](/rates).

## Why we do not publish figures we have not verified

We hold rate data as versioned files with an effective date, and the build fails if a figure looks
wrong, if rates fall as age rises, if a value sits outside a sane range, or if a year-on-year
change is implausible.

Where a figure has not been confirmed against its original source, we do not publish it. That is
why there is no 2024/25 table here: working a historic rate backwards from an uplift percentage
would produce a number that looks precise and could be a few pounds out, and a few pounds out
across two years of backdating is exactly the kind of error that gets a carer's complaint
dismissed.

The Welsh rates are an exception worth explaining, because they look wrong. In Wales a child under
five attracts a higher rate than a child aged five to fifteen, which is the reverse of every other
table we hold.

We have now seen the Welsh Government's own circular, which prints them that way, so this is settled
rather than inferred. We publish them as published and explain them on screen, rather than quietly
correcting a government figure to look more sensible.

*[SOURCE: Welsh Government, National Minimum Allowances for foster carers 2024 to 2025, circular of 26 February 2024]*

## What rises are expected

Committed uplifts to the fostering national minimum allowance are the higher of 2.5% or CPI for
2027/28 and 2028/29. We do not publish projections as though they were rates.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Why do you show fostering rates on a special guardianship site?**

Because the statutory guidance treats the core fostering allowance as the starting point for a special guardianship allowance. It is the benchmark your council should be working from.

**My council pays more than these figures. Is that allowed?**

Yes. These are minimums for fostering allowances. Nothing stops a council paying more, and some do.

