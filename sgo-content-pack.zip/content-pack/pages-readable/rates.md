# How the rates work, and when they change

| | |
|---|---|
| Web address | /guidance/rates |
| Length now | 445 words (357 in the page, 88 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Allowance rates change on 1 April. Benefit rates change in the first full week of April. The gap between the two dates matters.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance
- **Child Benefit and Guardian's Allowance Up-rating Order 2026**
  no public link yet, we are still sourcing one
- **Scottish Recommended Allowance for foster and kinship carers, Scottish Government, page updated 11 May 2026**
  https://www.gov.scot/publications/scottish-recommended-allowance-for-foster-and-kinship-carers-information-for-carers-and-professionals/
  What it decided: A national minimum for foster and kinship carers alike. Councils may pay more.

## The page as it reads now

## Two different calendars

> **Important box, shown in amber:**
>
Allowance rates change on **1 April**. Benefit rates change in the **first full week of April**,
around the 6th. Between those dates, new allowance rates coexist with last year's benefit rates.

That gap is a real source of confusion, including inside councils. Our calculator treats them as
two independent lookups with their own effective dates, so a calculation dated 3 April uses the new
allowance rates and the old benefit rates. That is correct, and it is not what you get if you
assume one financial year covers both.

## The current rates

<RateTable nation="england" />
<RateTable nation="scotland" />
<RateTable nation="northern-ireland" />

The full tables, including previous years, are on the [rates page](/rates).

## Why we do not publish figures we have not verified

We hold rate data as versioned files with an effective date, and the build fails if a figure looks
wrong, if rates fall as age rises, if a value sits outside a sane range, or if a year-on-year
change is implausible.

Where a figure has not been confirmed against its original source, we do not publish it. That is
why there is no 2024/25 table here: working a historic rate backwards from an uplift percentage
would produce a number that looks precise and could be a few pounds out, and a few pounds out
across two years of backdating is exactly the kind of error that gets a carer's complaint
dismissed.

The Welsh rates are an exception worth explaining, because they look wrong. In Wales a child under
five attracts a higher rate than a child aged five to fifteen, which is the reverse of every other
table we hold. We have checked that against two separate years and it holds, so we publish it as
published. But we have not seen the Welsh Government's own circular, and we say so on the page
rather than presenting it as settled.

## What rises are expected

Committed uplifts to the fostering national minimum allowance are the higher of 2.5% or CPI for
2027/28 and 2028/29. We do not publish projections as though they were rates.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Why do you show fostering rates on a special guardianship site?**

Because the statutory guidance treats the core fostering allowance as the starting point for a special guardianship allowance. It is the benchmark your council should be working from.

**My council pays more than these figures. Is that allowed?**

Yes. These are minimums for fostering allowances. Nothing stops a council paying more, and some do.

