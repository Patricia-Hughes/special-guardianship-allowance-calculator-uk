# What happens when your child turns 18

| | |
|---|---|
| Web address | /guidance/turning-18 |
| Length now | 276 words (185 in the page, 91 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Special guardianship financial support normally ends at 18, unless the young person stays in full-time education or training. Plan for it before it happens.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 9**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/9
  What it decided: Financial support ceases in the circumstances set out in the regulation, including when the child reaches 18 unless the conditions for continuing are met.
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The page as it reads now

Special guardianship orders end when the young person turns 18, and financial support normally ends
with them.

*[SOURCE: Special Guardianship Regulations 2005, reg 9]*

## The exception

Where the young person remains in full-time education or training, support can continue. This is
not automatic and it is not always offered, it often has to be asked for.

> **Important box, shown in amber:**
>
Ask **before** the eighteenth birthday, not after. Several months before is not too early.

## What to ask

1. What happens to my support on my child's eighteenth birthday?
2. If they stay in education or training, will it continue, and for how long?
3. What do you need from me, and by when?

Ask for the answer in writing. It is the document you will need if payments stop unexpectedly.

## Other things that change at 18

The young person may be able to claim benefits in their own right, and your own Child Benefit and
Universal Credit will be affected. This is a good moment to get a full benefits check from an
adviser, the changes interact, and a check often finds something.

> **[LIST]** The advice line contact details are inserted here automatically.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**My child is staying at school. Does the allowance carry on?**

It can. Where the young person remains in full-time education or training, financial support may continue. Ask your council to confirm in writing what it will do and from when.

**When should I ask?**

Well before the eighteenth birthday, several months. Sorting it out after payments have stopped is much harder than sorting it out before.

