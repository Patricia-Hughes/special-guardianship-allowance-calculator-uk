# Ask your council for its written policy

| | |
|---|---|
| Web address | /guidance/asking-for-the-policy |
| Length now | 358 words (262 in the page, 96 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Every council should have a published policy on financial support for special guardians. It is the document every later question rests on.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Letter template linked from this page

- "Ask for your council's written policy"

## The page as it reads now

If you do one thing after using the calculator, make it this.

## Why it is the first step

Everything else follows from the policy:

- It tells you what starting figure your council uses, and whether it is [the fostering
  allowance](/guidance/what-your-council-must-consider) or something lower.
- It tells you [how the means test is applied](/guidance/how-the-means-test-works), and in what
  order.
- It tells you whether [Child Benefit is deducted](/guidance/child-benefit-deduction).
- It is the document any later complaint is measured against.

A conversation can be remembered differently by two people. A policy cannot.

## What to ask for

1. Your current policy on financial support for special guardians.
2. How the starting figure for an allowance is decided.
3. How any means test is applied, and what income is taken into account.
4. Whether Child Benefit is taken into account.
5. How allowances are reviewed each year.

A link is fine if it is on the website.

> **[BUTTON]** Opens the letter template: "Ask for your council's written policy".

## We may not hold your council's policy

Our calculator uses the national minimum figures for your area unless we hold a **sourced and dated
copy** of your council's own published policy. We deliberately do not use policy details we cannot
point at a live public source for, naming a council and describing what it does requires being able
to show where that came from.

So if the result said we do not have your council's policy, that is not a gap in your council's
duties. It is a gap in ours, and asking them directly is the fastest way round it.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**What if they will not send it?**

Ask again in writing, referring to your earlier request and the date. If it is genuinely published, they can send you a link. If there is no answer, that is itself something to complain about.

**Do I need to make a Freedom of Information request?**

Usually not, most policies are published, or will be sent if you ask. FOI is there if a simple request gets nowhere.

