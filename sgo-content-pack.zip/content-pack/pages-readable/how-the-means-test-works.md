# How the means test works, and why it is not the law

| | |
|---|---|
| Web address | /guidance/how-the-means-test-works |
| Length now | 741 words (612 in the page, 129 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Most English councils use a Department for Education spreadsheet model that no law requires and that pre-dates Universal Credit. Here is how it works and where it commonly goes wrong.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **CoramBAAF Practice Note 75 - special guardianship financial support**
  https://corambaaf.org.uk/sites/default/files/Members%20Area/Resources/Practice%20Notes/PN%2075%20Financial%20Support%20for%20Special%20Guardians_Englandv2.pdf
  What it decided: The DfE standardised means-test model is non-statutory and pre-dates Universal Credit.
- **Lincolnshire County Council, Special Guardianship Allowance Assessment Framework**
  https://www.lincolnshire.gov.uk/directory-record/82363/special-guardianship-allowance-assessment-framework
  What it decided: Distinguishes the statutory 'Special Guardianship Guidance' from the non-statutory 'Standardised means test model for adoption and special guardianship financial support'.
- **R (TT) v Merton LBC [2012] EWHC 2055 (Admin)**
  https://caselaw.nationalarchives.gov.uk/ewhc/admin/2012/2055
  What it decided: Blanket percentage deduction unlawful. BUT: no duty to pay every special guardian an allowance, and the means-test methodology itself was upheld as lawful.
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance

## Note on the figures in this page

This is the one page allowed to print pound amounts, because they are invented
worked examples rather than real rates. They are listed as exceptions in the page
settings and each one has to be justified there. Keep them as examples, and do not
add any real rates.

## Letter template linked from this page

- "Ask for the arithmetic behind your figure"

## The page as it reads now

Most English councils work out how much of your income to take into account using a standard
spreadsheet model produced by the Department for Education.

> **Important box, shown in amber:**
>
That model is **not statutory**. No law requires it, and it was written before Universal Credit
existed. Treat any figure it produces as an illustration of how the common model works, not as the
answer your council will reach.

*[SOURCE: CoramBAAF Practice Note 75 - special guardianship financial support]*

Here is how far behind it has fallen. The model measures your basic living costs against **Income
Support** rates. Income Support is a legacy benefit that is largely closed to new claims, and most
of the people it once covered are now on Universal Credit. So the yardstick at the centre of the
calculation is one that most households can no longer even claim.

At least one council publishes the model in its own words as non-statutory guidance, which is worth
knowing if yours presents it as a rule it has to follow.

*[SOURCE: Lincolnshire County Council, Special Guardianship Allowance Assessment Framework]*

It is also worth knowing that a means test is not in itself unlawful. When a blanket percentage
deduction was struck down, the court upheld the means-test methodology itself.

*[SOURCE: R (TT) v Merton LBC [2012] EWHC 2055 (Admin)]*

## The steps

1. **Add up your countable income.** Earnings after tax, pensions, maintenance you receive, income
   from a lodger, and most benefits.
2. **Ignore 20% of it.** A fifth of your income is disregarded.
3. **Subtract your allowable outgoings.** Rent or mortgage, council tax, childcare, essential loan
   repayments, maintenance you pay out, pension contributions, plus a figure for basic living
   costs, calculated as the Income Support rates for a household your size plus 25%.
4. **What is left is your disposable income.**
5. **Some or all of it is treated as your contribution** towards the child's costs, and taken off
   the maximum.

## The mistake that costs people the most

> **Important box, shown in red:**
>
The 20% disregard comes off your **income**, before your outgoings are subtracted. Not afterwards.

The difference is large. Take a household with £3,000 a month of income and £2,000 a month of
allowable outgoings:

- **Correct:** £3,000 × 0.8 = £2,400, then − £2,000 = **£400** disposable
- **Wrong:** £3,000 − £2,000 = £1,000, then × 0.8 = **£800** disposable

Done the wrong way round, this household is assessed as able to contribute twice as much, and the
allowance drops accordingly. If you have a written breakdown, check which order yours was done in.

## What counts and what does not

**Counted:** earnings (both partners), self-employed drawings, employer sick pay, pensions, most
benefits, Child Benefit for your *other* children, savings interest, lodger and property income,
maintenance you receive.

**Ignored:** disability benefits for the child (DLA or PIP), Guardian's Allowance, criminal
injuries compensation, fostering income for other children you still foster, the special
guardianship allowance itself, and the childcare element of Working Tax Credit.

The Child Benefit rule confuses almost everybody, including social workers: Child Benefit for your
**other** children counts as income; Child Benefit for the child this assessment is about does not.
That child's Child Benefit is only ever dealt with as a separate deduction, if at all, and whether
it should be deducted is [itself contested](/guidance/child-benefit-deduction).

## The step nobody publishes

There is **no published national rule** for how much of your disposable income a council takes off
the allowance. Some take it pound for pound, some take a percentage, some ignore anything under a
threshold. Policies genuinely differ, and no one has published a national figure.

So ask yours which it uses. If a figure has been put to you, that question alone often produces the
breakdown you have been asking for.

> **[BUTTON]** Opens the letter template: "Ask for the arithmetic behind your figure".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Does my council have to use this model?**

No. It is not statutory. Some councils use it, some adapt it, and some do an individual needs assessment instead. What a council cannot do is apply any model so rigidly that it never looks at your actual circumstances.

**Is my special guardianship allowance counted as my income for benefits?**

No. It is disregarded for your own means-tested benefits, and it is not taxable.

**Are my child's disability benefits counted?**

They should not be. Disability Living Allowance or Personal Independence Payment for the child is disregarded income, as is Guardian's Allowance.

