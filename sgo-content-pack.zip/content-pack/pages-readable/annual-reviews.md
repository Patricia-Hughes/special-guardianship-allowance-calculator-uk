# Your allowance should be reviewed every year

| | |
|---|---|
| Web address | /guidance/annual-reviews |
| Length now | 429 words (337 in the page, 92 in the description and questions) |
| Last reviewed | 2026-09-03 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Special guardianship financial support is subject to annual review. Rates rise every April. If you have not had a review, ask for one.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Special Guardianship Regulations 2005, reg 18(2)(a)**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/18
  What it decided: The local authority must review financial support payable periodically on receipt of the annual statement mentioned in reg 10. The trigger is receipt of the statement, not the passage of twelve months.
- **Special Guardianship Regulations 2005, reg 10**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/10
  What it decided: Conditions. Reg 10(1)(b) requires the special guardian to agree to supply an annual statement of their circumstances. That statement is what triggers the review duty in reg 18(2)(a).
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## Letter template linked from this page

- "Ask for your annual review"

## The page as it reads now

Financial support is subject to review. In practice, this is one of the easiest things to let slip
and one of the easiest to put right.

## What actually triggers a review

This is worth getting right, because it changes the question you ask.

Your council has to review your financial support **when it receives your annual statement of
circumstances**. The trigger is that statement, not simply a year going by.

*[SOURCE: Special Guardianship Regulations 2005, reg 18(2)(a)]*

Supplying that statement is something you agree to when support is set up.

*[SOURCE: Special Guardianship Regulations 2005, reg 10]*

So if your council has never asked you for an annual statement, you are not late for a review. Your
council has not set up the thing that produces one. That is a stronger point to make than "it has
been more than a year", and it is the question to put in writing: **have you asked me for an annual
statement, and if not, why has my support not been reviewed?**

## What a review should involve

- The council asks you for up-to-date information about your circumstances.
- It works out whether the support should change.
- It tells you what it proposes, **before** it changes anything.
- It gives you a reasonable chance to comment.
- It tells you the outcome, with reasons.

## Why it matters more than it sounds

Councils normally raise their rates on **1 April** every year. (The government states the same
rates for a tax year beginning 6 April, which is explained on [the rates
page](/guidance/rates).)

<RateTable nation="england" />

An allowance that has not been reviewed in several years has quietly lost value against those
figures. Nothing dramatic has to have gone wrong for you to be materially underpaid. It is enough
for nobody to have looked.

## Asking for one

You do not need a reason beyond "it has been more than a year". Ask in writing, and ask what
information the council needs from you so it can get on with it.

> **[BUTTON]** Opens the letter template: "Ask for your annual review".

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**My allowance has been the same for years. Is that right?**

It is worth querying. The national minimum allowance rises every April, so an allowance that has not moved has, in real terms, been falling.

**Can my council reduce my allowance at a review?**

It can vary support after a review, but it should tell you what it proposes and give you a chance to comment before it does.

