# Complaining: your council first, then the Ombudsman

> **HIGHEST RISK PAGE.** The wording here carries legal weight. Brief this one hardest
> and have the solicitor spend the most time on it.

| | |
|---|---|
| Web address | /guidance/complaining-to-the-ombudsman |
| Length now | 421 words (295 in the page, 126 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P6M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> How to complain about a special guardianship allowance decision, and what the Ombudsman has actually ordered councils to do.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **LGSCO decision, Devon County Council (23 000 973, 25 January 2024)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/23-000-973
  What it decided: The council was at fault for deducting Child Benefit from all special guardians on Universal Credit as a blanket rule, without looking at individual circumstances. It was ordered to recalculate and to refund deductions. Devon changed the policy with effect from 1 January 2024, and a later complaint about its current practice was not upheld.
- **LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)**
  https://www.lgo.org.uk/decisions/children-s-care-services/friends-and-family-carers/19-003-363
  What it decided: Reducing the whole allowance to 75% of the core fostering allowance in year one and 50% in year two misapplied the two-year transitional provision, which protects the reward element only. Backdating of about 6,948 pounds was recommended, and the council estimated 37 other families were affected.
- **LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)**
  https://web.archive.org/web/https://www.lgo.org.uk/assets/attach/4322/REPORT-17002928-N-Tyneside.pdf
  What it decided: Calculating a special guardianship allowance as a percentage of the fostering allowance was contrary to statutory guidance and case law. The council identified 171 families who may not have received the right support, and payments were backdated to November 2013.
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## Letter template linked from this page

- "Make a stage 1 complaint"

## The page as it reads now

Most problems are resolved by asking clear questions in writing and getting a proper answer. The
complaints route is for when that has not worked.

## Step 1: your council's own procedure

Councils have a formal complaints procedure, usually with two or three stages. Use it. The
Ombudsman will normally expect you to have been through it before it looks at anything.

Keep it factual and specific:

- what you asked for, and when
- what the council did or did not do
- what effect it has had on you and your child
- what you would like to happen

> **[BUTTON]** Opens the letter template: "Make a stage 1 complaint".

## Step 2: the Ombudsman

In England, that is the Local Government and Social Care Ombudsman. Wales, Scotland and Northern
Ireland each have their own.

Normally you should complain within **12 months** of becoming aware of the problem, though the
Ombudsman has discretion where there is a good reason for delay.

## What it has ordered

These are real outcomes in special guardianship allowance cases, not hypotheticals:

**Recalculation and refunds for around 170 carers**, plus remedy payments to the complainants,
where a council deducted Child Benefit as a blanket rule, meaning the same rule applied to
everyone without looking at individual cases, including carers on means-tested
benefits.

*[SOURCE: LGSCO decision, Devon County Council (23 000 973, 25 January 2024)]*

**Backdating**, where a council's fixed-percentage policy was found to be at fault.

*[SOURCE: LGSCO public report, North Tyneside Council (17 002 928, 27 February 2018)]*

**A finding of fault** where a council tapered a whole allowance to 75% and then 50%, misapplying
the rule that concerns only the reward element.

*[SOURCE: LGSCO decision, Southend-on-Sea (19 003 363, 5 October 2020)]*

## Before you start

Gather the paperwork: the written policy, any breakdown of your calculation, and your
correspondence. A complaint with documents attached is a great deal harder to answer with a general
reassurance.

> **[LIST]** The advice line contact details are inserted here automatically.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**How long do I have?**

The Ombudsman normally expects a complaint within 12 months of you becoming aware of the problem, though it has discretion to look at older matters.

**Will complaining damage my relationship with my social worker?**

It is a reasonable worry. Most cases are resolved well before that stage by asking clear questions in writing. A complaint is what you use when those questions have not been answered.

**What can the Ombudsman actually do?**

It can find fault, order a council to recalculate and backdate payments, and require a payment to recognise the distress caused. It has done all three in special guardianship cases.

