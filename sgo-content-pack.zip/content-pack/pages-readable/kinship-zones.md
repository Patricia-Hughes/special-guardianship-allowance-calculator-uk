# Kinship Zones: the pilot paying the full fostering rate

| | |
|---|---|
| Web address | /guidance/kinship-zones |
| Length now | 372 words (262 in the page, 110 in the description and questions) |
| Last reviewed | 2026-08-29 |
| Review needed every | P3M |

## One line description

Shown on search results and link previews. The rewrite needs one of these too.

> Seven English councils are piloting a non-means-tested kinship allowance at the full fostering National Minimum Allowance, from April 2026 to 2029.

## Sources this page relies on

Every legal claim on the page must still trace to one of these after the rewrite.
The writer may not add a claim we cannot cite.

- **Kinship Zones - kinship allowance pilot (2026-2029)**
  https://www.communitycare.co.uk/content/news/councils-to-test-paying-kinship-carers-to-look-after-children-who-would-otherwise-go-into-care
  What it decided: A pilot in seven English councils paying a non-means-tested allowance equal to the fostering National Minimum Allowance.
- **DfE Special Guardianship Guidance (Jan 2017), para 65**
  https://www.gov.uk/government/publications/special-guardianship-guidance
- **Special Guardianship Regulations 2005, reg 6**
  https://www.legislation.gov.uk/uksi/2005/1109/regulation/6

## The page as it reads now

> **Important box, shown in amber:**
>
This is a **pilot in seven councils only**. It does not change the law anywhere else, and it is
funded to 2029.

## What it is

From April 2026, seven English councils are paying eligible kinship carers an allowance equal to
the full fostering National Minimum Allowance, with **no means test**.

<RateTable nation="england" />

*[SOURCE: Kinship Zones - kinship allowance pilot (2026-2029)]*

## The seven councils

Bexley · Bolton · Newcastle upon Tyne · North East Lincolnshire · Medway · Thurrock · Wiltshire

Councils that were already paying an NMA-equivalent allowance were not eligible to apply, so the
absence of a council from this list does not mean it pays less.

## Who qualifies

- You hold a special guardianship order, or a "lives with" child arrangements order.
- Without you, the child would otherwise be in local authority care.
- You are **not** already receiving regulation 6 financial support for that child.

## If you are in a pilot area but already on support

You cannot have both. But the comparison is still useful: if the pilot rate for your child's age
band is higher than what you receive, that is a concrete figure to put to your council when you ask
for a review. Our calculator shows you the comparison when it applies.

## The caveats worth holding on to

- It is a pilot, running to 2029, and it is being evaluated.
- It does not change any council's legal obligations outside the seven areas.
- A national rollout would be a significant change, but nobody can promise one.

> **[BUTTON]** Takes the reader to the calculator.

## Questions and answers shown at the bottom of the page

**Which councils are in it?**

Bexley, Bolton, Newcastle upon Tyne, North East Lincolnshire, Medway, Thurrock and Wiltshire.

**Can I get the pilot allowance and regulation 6 support?**

No. The pilot excludes carers already receiving regulation 6 financial support for the same child. If you are in a pilot area and already on support, it is still worth comparing the two figures.

**What happens in 2029?**

The pilot is being evaluated. Nobody can tell you yet what follows it. Do not make long-term financial commitments on the assumption it continues.

