# The sixteen guidance pages, as they read today

Exported 2026-09-01 for the content brief team.

16 pages, 7,413 words in total.

## What is in this pack

- **pages-readable/** is what you want. One file per page, in plain Markdown,
  with the sources spelled out and the moving parts described in English.
- **pages-original/** is the same content in the format the website actually
  uses. Handed over so nothing is lost, and so the developer can check the
  rewrite against it. The writer does not need to open these.

## The pages

| Page | Words to rewrite | Address |
|---|---|---|
| Your allowance should be reviewed every year | 296 | /guidance/annual-reviews |
| Ask your council for its written policy | 411 | /guidance/asking-for-the-policy |
| Benefits, tax and your special guardianship allowance | 429 | /guidance/benefits-and-your-allowance |
| **Can your council take Child Benefit off your special guardianship allowance?** (highest risk) | 703 | /guidance/child-benefit-deduction |
| **Complaining: your council first, then the Ombudsman** (highest risk) | 421 | /guidance/complaining-to-the-ombudsman |
| Asking for more because of your child's needs | 380 | /guidance/enhancements-for-additional-needs |
| **Why a fixed percentage of the fostering rate is a problem** (highest risk) | 535 | /guidance/fixed-percentage-policies |
| **If you fostered the child before the order: the two-year rule** (highest risk) | 608 | /guidance/former-foster-carers |
| How the means test works, and why it is not the law | 741 | /guidance/how-the-means-test-works |
| Kinship Zones: the pilot paying the full fostering rate | 372 | /guidance/kinship-zones |
| How the rates work, and when they change | 565 | /guidance/rates |
| Kinship care in Scotland | 422 | /guidance/scotland-kinship-care |
| What happens when your child turns 18 | 276 | /guidance/turning-18 |
| **What your council must consider when setting your allowance** (highest risk) | 486 | /guidance/what-your-council-must-consider |
| Which council is responsible for your support? | 272 | /guidance/which-council-is-responsible |
| Who can get a special guardianship allowance? | 496 | /guidance/who-can-get-an-allowance |

## Five things the writer has to know before starting

**1. The strength of a word is a legal decision, not a style decision.** If a
source says "should", the copy says "should". Making a claim land harder is not
the writer's call. Flag every word choice that carries weight rather than
quietly picking one.

**2. Never write a figure.** No pound amounts anywhere in the prose. The rates
change every April and are inserted automatically from our data. An automatic
check rejects the copy if a figure appears in it. Mark where a number belongs.
The one exception is the means test page, which uses invented worked examples
to show an order of operations. Those are listed as exceptions in that page's
settings and each has to be justified. They are not real rates.

**3. Never say a named council broke the law.** Say what the guidance requires
and what a published decision found, and let the reader draw the conclusion.
This is a hard rule.

**4. No em dashes.** An automatic check fails the build if one appears. Commas,
full stops, colons and brackets cover every case.

**5. Every claim needs a source.** The sources for each page are listed in its
file. The writer may not introduce a claim we cannot cite. If they believe
something is true and we have no source, it goes on a query list and stays out
of the copy.

## Who this is for

Grandparents and other family carers, mostly aged 55 to 75, often reading at a
stressful moment and sometimes after being given wrong information by their
council. Target reading age 12 to 14. Many are on a phone.

Where precision needs a longer sentence, take the longer sentence. Accuracy
beats brevity on this site every time.

## What is not in this pack

The words inside the calculator itself: the warnings shown on a carer's result,
and the eight letter templates they send to their council. Those are the highest
risk copy on the whole site and they need rewriting too. Ask and we will export
them the same way.
